// @ts-check

import { test, expect } from '@playwright/test'
import { BasePage } from '../pages/basePage'
import { LocatorType } from '../framework/locatorHandler'
import { generalSelectors } from '@pages/PageGeneral/selectorGeneral'
import { fileURLToPath } from 'url'
import { dirname } from 'path'
import path from 'path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
// import { quotePLE } from '../../pages/PagePropertyLegalEntities/IdPropertyLegalEntities'
//

/**
 * @class
 * @classdesc **Общие шаги для использования в сценариях**
 */
export class StepGeneral extends BasePage {
  /**
   * **ADI-T2607 Авторизация**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2607|Открыть ADI-T2607}
   * @param {string} filltext  - имя пользователя
   * @param {string} filltext2 - пароль
   * @param {string} url       - адрес страницы
   * @example
   * await stepGeneral.ADI_T2607( filltext:Tarov.Mikhail, filltext2:Test_12345, url:stage.adinsure.sogaz.ru )
   */
  async ADI_T2607(filltext, filltext2, url) {
    await test.step('ADI-T2607 Авторизация', async () => {
      await this.goToPage(url)
      await this.clickButton(LocatorType.byTestId, {
        idElement: generalSelectors.кнопкаВход,
        nameElement: 'Вход',
      })
      await this.page.waitForTimeout(1000)
      await this.clickButton(LocatorType.byTestId, {
        idElement: generalSelectors.типВходаВнешнийСотрудник,
        nameElement: 'Внешний сотрудник (по логину/паролю)',
      })
      await this.fillTextbox(LocatorType.byTestId, 'Имя пользователя', generalSelectors.имяПользователя, filltext)
      await this.fillTextbox(LocatorType.byTestId, 'Пароль', generalSelectors.пароль, filltext2)
      await this.clickButton(LocatorType.byTestId, {
        idElement: generalSelectors.кнопкаВойти,
        nameElement: 'Войти',
      })
    })
  }

  /**
   * **Нажать на кнопку "Сохранить/Расчитать"**
   *
   * В методе реализована возможность ожидания ответа запроса после нажатия на кнопку. Аргумент responseURL необязательный.
   * В каждом вызове метода, в большинстве случаев, запрос будет разный.
   * Если аргумент responseURL не передан при вызове, шаг выполняется без ожидания.
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2044|Открыть ADI-T2044}
   * @param {string} roleName - название кнопки
   * @param {string} [responseURL] - url ответа
   * @example
   * await stepGeneral.ADI_T2044( roleName:'Сохранить' )
   * await stepGeneral.ADI_T2044( roleName:'Расчитать' )
   * // ожидание запроса
   * await stepGeneral.ADI_T2044('Сохранить', '/server/api/sogaz/party/shared/v1/sod-integration/party/')
   */
  async ADI_T2044(roleName, responseURL) {
    await test.step('Нажать на кнопку "Сохранить/Расчитать"', async () => {
      this.roleName = roleName
      if (responseURL) {
        try {
          const responsePromise = this.page.waitForResponse(
            (response) => response.url().includes(responseURL) && response.status() === 200,
            { timeout: 60 * 1000 }
          )
          await this.clickButton(LocatorType.byRole, { roleName })
          await responsePromise
        } catch (error) {
          console.log(`Catched error: ${error}`)
        }
      } else {
        await this.clickButton(LocatorType.byRole, { roleName })
      }
    })
  }

  /**
   * **ADI-T2641 Переход на вкладку локумента**
   *
   * В методе реализована возможность ожидания ответа запроса после перехода на вкладку. Аргумент responseURL необязательный.
   * В каждом вызове метода, в большинстве случаев, запрос будет разный.
   * Если аргумент responseURL не передан при вызове, шаг выполняется без ожидания.
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2641|Открыть ADI-T2641}
   * @param {string | RegExp} id      - id элемента
   * @param {string}          nameTab - имя вкладки
   * @param {string} [requestURL] - url ответа
   * @example
   * await stepGeneral.ADI_T2641(id:'tab-paymentData-nav', nameTab:'График платежей и оплата' )
   */
  async ADI_T2641(id, nameTab, requestURL) {
    await test.step('ADI-T2641 Переход на вкладку документа', async () => {
      if (requestURL) {
        try {
          const responsePromise = this.page.waitForResponse(
            (response) => response.url().includes(requestURL) && response.status() === 200,
            { timeout: 60 * 1000 }
          )
          await this.changeTab(LocatorType.byTestId, nameTab, id)
          await responsePromise
        } catch (error) {
          console.log(`Catched error: ${error}`)
        }
      } else {
        await this.changeTab(LocatorType.byTestId, nameTab, id)
      }
    })
  }

  /**
   * **ADI-T2399 Выполнение действия (без выбора исполнителя)**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2399|Открыть ADI-T2399}
   * @param {string | RegExp} id      - id элемента
   * @param {string}             name    - пункт меню "Действия"
   * @param {string}          heading - проверка заголовка
   * @param {string}          status  - проверка статуса
   * @param {string} [requestURL] - url запроса (для ожидания ответа)
   * @example
   * await stepGeneral.ADI_T2399( id:'ai-transitions-relations-control-Draft_to_OnConfirmationL2', name:'На согласование Уровень 2', heading:'Котировка:', status:'(На согласовании Уровень 2)' )
   */
  async ADI_T2399(id, name, heading, status, requestURL) {
    await test.step('ADI-T2399 Выполнение действия (без выбора исполнителя)', async () => {
      await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
      await this.clickButton(LocatorType.byTestId, {
        idElement: id,
        nameElement: name,
      })
      if (requestURL) {
        try {
          const responsePromise = this.page.waitForResponse(
            (response) => response.url().includes(requestURL) && response.status() === 200,
            { timeout: 60 * 1000 }
          )
          await this.clickButton(LocatorType.byRole, { roleName: ' Дa' })
          await responsePromise
        } catch (error) {
          console.log(`Catched error: ${error}`)
        }
      } else {
        await this.clickButton(LocatorType.byRole, { roleName: ' Дa' })
      }
      await expect(this.page.getByTestId('header-document-name')).toContainText(heading)
      await expect(this.page.getByTestId('header-document-state')).toContainText(status)
    })
  }
  /**
   * **ADI-T1990 Переход по главному меню**
   * Добавлено событие движение мышью для предотвращения появления всплывающих окон при наведение на локатор
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T1990|Открыть ADI-T1990}
   * @param {string}  firstLevel   - первый уровень
   * @param {string} [secondLevel] - второй уровень
   * @param {string} [thirdLevel]  - третий уровень
   * @param {string} [fourthLevel] - четвертый уровень
   * @example
   *
   * await stepGeneral.ADI_T1990( firstLevel:'Dashboards_menu_1', secondLevel:'TravelInsurance_1_2', thirdLevel:'TravelApplication_1_3' )
   * await stepGeneral.ADI_T1990( firstLevel:'Workflow_1_2' ) - (Переход до 'Витрина задач')
   * await stepGeneral.ADI_T1990( firstLevel:'Global_1_2' )   - (Переход до 'Рабочий стол')
   */
  async ADI_T1990(firstLevel, secondLevel, thirdLevel, fourthLevel) {
    await test.step('ADI-T1990 Переход по главному меню', async () => {
      const menuList = [firstLevel, secondLevel, thirdLevel, fourthLevel]
      for (const value of menuList) {
        if (value != null) {
          await this.page.mouse.move(0, 0)
          await this.clickButton(LocatorType.byTestId, {
            idElement: value,
            nameElement: value,
          })
        }
      }
    })
  }

  /**
   * **ADI-T3194 Установка, снятие чек-бокса в блоке**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3194|Открыть ADI-T3194}
   * Активация checkbox на странице
   * @param {'check' | 'uncheck'}action      - тип действия (check/uncheck)
   * @param {string | RegExp}    id          - id элемента
   * @param {string}             nameElement - текст рядом с checkbox
   * @param {number}             [nth]       - параметр nth
   * @example
   * // Активация checkbox
   * await stepGeneral.ADI_T3194('check','allSalesBranches','Все филиалы продаж')
   * await stepGeneral.ADI_T3194('check','AAExtraInformation-extraInformation','Краткий цикл согласования',1)
   * // Снятие checkbox
   * await stepGeneral.ADI_T3194('uncheck','AAExtraInformation-extraInformation','Краткий цикл согласования',1)
   */
  async ADI_T3194(action, id, nameElement, nth) {
    await test.step(`ADI-T3194 Установка, снятие чек-бокса "${nameElement}" в блоке`, async () => {
      switch (action) {
        case 'check':
          await this.checkCheckbox(LocatorType.byTestIdByRole, id, nameElement, nth)
          break
        case 'uncheck':
          await this.uncheckCheckBox(LocatorType.byTestIdByRole, id, nameElement, nth)
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T6613 Проверка номера документа на содержание префикса**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T6613|Открыть ADI-T6613}
   * @param {string| RegExp} value  -  префикс
   * @example
   * await stepGeneral.ADI_T6613( value:'VZRP' )
   */
  async ADI_T6613(value) {
    await test.step('ADI-T6613 Проверка номера документа на содержание префикса', async () => {
      await expect(this.page.getByTestId(generalSelectors.номерДокумента)).toContainText(value)
    })
  }

  /**
   * **ADI-T2477 Поиск и выбор в форме "Поиск подразделения" (с уточнением подразделения)**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2477|Открыть ADI-T2477}
   * @param {string | RegExp} id - id значка 'Лупа'
   * @param {string} filltext - Подразделение
   * @example
   * await stepGeneral.ADI_T2477( filltext:'Тюменский филиал' )
   */
  async ADI_T2477(id, filltext) {
    await test.step('ADI-T2477 Поиск и выбор в форме "Поиск подразделения" (с уточнением подразделения)', async () => {
      await this.clickButton(LocatorType.byTestIdByRole, {
        idElement: id,
        roleName: '',
      })

      try {
        const responsePromise = this.page.waitForResponse(
          (response) =>
            response
              .url()
              .includes(
                '/server/api/entity-infrastructure/shared/datasource/execute?configurationCodeName=DepartmentsDataSource'
              ) && response.status() === 200
        )

        await responsePromise
      } catch (error) {
        console.log(`Catched error: ${error}`)
      }

      await this.fillTextbox(LocatorType.byTestIdByRole, 'Подразделение', generalSelectors.подразделение, filltext)

      await this.page.getByRole('button', { name: ' Поиск' }).focus()

      await this.clickButton(LocatorType.byRole, { roleName: 'Поиск' })

      await this.checkCheckboxInTable(LocatorType.byRole, filltext)

      await this.clickButton(LocatorType.byRole, { roleName: 'Выбрать' })
    })
  }

  /**
   * **ADI-T3165 Заполнение одного поля в блоке (универсальное)**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3165|Открыть ADI-T3165}
   * @param {'checkbox'|'fillText'|'combobox'} action  - тип заполнения ('checkbox'|'fillText'|'combobox')
   * @param {string} [id]          - id элемента
   * @param {string} [nameElement] - название элемента (текст рядом с элементом)
   * @param {string} [value]       - заполняемое значение
   * @param {number} [nth] -
   * @example
   *  await stepGeneral.ADI_T3165( action:'checkbox', id:'incoming-reinsurance', nameElement:'Входящее перестрахование' )
   *  await stepGeneral.ADI_T3165( action:'fillText', id:'incoming-reinsurance', nameElement:'Входящее перестрахование', value:'пункт 1' )
   *  await stepGeneral.ADI_T3165( action:'combobox', id:'incoming-reinsurance', nameElement:'Входящее перестрахование', value:'пункт 1' )
   */
  async ADI_T3165(action, id, nameElement, value, nth) {
    await test.step('ADI-T3165 Заполнение одного поля в блоке (универсальное)', async () => {
      switch (action) {
        case 'checkbox':
          await this.checkCheckbox(LocatorType.byTestIdByRole, id, nameElement, null)
          break
        case 'fillText':
          await this.fillTextbox(LocatorType.byTestIdByRole, nameElement, id, value, nth)
          break
        case 'combobox':
          await this.fillCombobox(LocatorType.byTestIdByRole, nameElement, id, value, true, nth)
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T2413 Переключение и проверка роли**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2413|Открыть ADI-T2413}
   * @param {object}  stepArguments             - параметры локатора
   * @param {string} [stepArguments.idElement]  - id роли
   * @param {string} [stepArguments.buttonName] - имя роли
   * @param {string} [stepArguments.actorName] -  проверка роли
   * @example
   * await stepGeneral.ADI_T2413({actorName:'А',buttonName:'Андеррайтер',idElement:'ai-actor-selection-control-Underwriter'})
   * await stepGeneral.ADI_T2413({actorName:'П',buttonName: 'Продавец',idElement: 'ai-actor-selection-control-Agent'})
   * await stepGeneral.ADI_T2413({actorName:'Д',buttonName:'ДЭБ',idElement:'ai-actor-selection-control-DEB'})
   * await stepGeneral.ADI_T2413({actorName:'О',buttonName: 'Операционист',idElement: 'ai-actor-selection-control-Operations'})
   */
  async ADI_T2413(stepArguments) {
    await test.step('ADI-T2413 Переключение и проверка роли', async () => {
      await this.clickButton('byTestId', {
        idElement: generalSelectors.роли,
        roleName: 'Роли',
      })

      await this.clickButton('byTestId', {
        idElement: stepArguments.idElement,
        roleName: stepArguments.buttonName,
      })
      await expect(this.page.getByTestId(generalSelectors.роли)).toContainText(stepArguments.actorName)
    })
  }

  /**
   * **ADI-T2387 Выполнение действия (с выбором исполнителя)**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2387|Открыть ADI-T2387}
   * @param {string | RegExp} id             - id элемента
   * @param {any}             name           - пункт меню "Действия"
   * @param {string}          value          - исполнитель
   * @param {string}          documentName   - значение поля "Заголовок"
   * @param {string}          documentStatus - значение поля "Статус"
   * @example
   * await stepGeneral.ADI_T2387(id:'ai-transitions-relations-control-UW3_to_UW3h', name:'Направить на согласование', value:'Сирота Лев Дмитриевич',documentName:'Котировка:',documentStatus:'(На согласовании у андеррайтера ГО)')
   */
  async ADI_T2387(id, name, value, documentName, documentStatus) {
    await test.step('ADI-T2387 Выполнение действия (с выбором исполнителя)', async () => {
      await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
      await this.clickButton(LocatorType.byTestId, {
        idElement: id,
        roleName: name,
      })
      await this.page.getByRole('combobox').click()
      await this.page.getByRole('option', { name: value }).click()
      await this.clickButton(LocatorType.byRole, { roleName: 'OK' })
      await expect(this.page.getByTestId(generalSelectors.названиеДокумента)).toContainText(documentName)
      await expect(this.page.getByTestId(generalSelectors.состояниеДокумента)).toContainText(documentStatus)
    })
  }

  /**
   * **ADI-T1026 Проверка статуса с ожиданием изменения**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T1026|Открыть ADI-T1026}
   * @param {string} value - статус документа
   * @example
   * await stepGeneral.ADI_T1026( value:'(Импортировано)')
   */
  async ADI_T1026(value) {
    await test.step('ADI-T1026 Проверка статуса с ожиданием изменения', async () => {
      await this.page.waitForTimeout(20000)
      await this.page.reload()
      await expect(this.page.getByTestId(generalSelectors.состояниеДокумента)).toContainText(value)
    })
  }

  /**
   * **ADI-T2360 Обновление страницы и ожидание появление элементов, проверка на смене статуса документа**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2360|Открыть ADI-T2360}
   * @param {string} value  - Статус документа
   * @example
   * await stepGeneral.ADI_T2360( value:'(Импортировано)' )
   */
  async ADI_T2360(value) {
    await test.step('ADI-T2360 Обновление страницы и ожидание появление элементов, проверка на смене статуса документа', async () => {
      const responsePromise = this.page.waitForResponse(
        (response) =>
          response.url().includes('/server/api/shell/internal/documents/recent-documents/') && response.status() === 200
      )
      await responsePromise
      await this.page.reload()
      await expect(this.page.getByTestId(generalSelectors.состояниеДокумента)).toContainText(value)
    })
  }

  /**
   * **ADI-T2612 Проверка количества ошибок в информационном меню**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2612|Открыть ADI-T2612}
   * @param {string} value - количество ошибок
   * @example
   * await stepGeneral.ADI_T2612( value:'0' )
   */
  async ADI_T2612(value) {
    await test.step('ADI-T2612 Проверка количества ошибок в информационном меню', async () => {
      await this.clickButton(LocatorType.byTestId, {
        idElement: generalSelectors.проверкиИОшибки,
        nameElement: 'Проверки и ошибки',
      })
      await expect(this.page.getByTestId('RequiredPropertiesValidations-error-count')).toContainText(value)
    })
  }

  /**
   * **ADI-T2642 Добавление вложения**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2642|Открыть ADI-T2642}
   * @param {string}   pathToFile      - путь до файла
   * @param {string}   attachmentType  - тип вложения
   * @example
   * await stepGeneral.ADI_T2642( path:'./fixtures/testDataSuite/MTPL/test.pdf', value:'Бумажный чек')
   */
  async ADI_T2642(pathToFile, attachmentType) {
    await test.step('ADI-T2642 Добавление вложения', async () => {
      await this.clickButton(LocatorType.byRole, { roleName: '+ Добавить' })
      await this.page.locator("input[type='file']").setInputFiles(path.join(pathToFile))
      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Тип вложений',
        generalSelectors.типВложения,
        attachmentType,
        true
      )
      await this.clickButton(LocatorType.byRole, { roleName: 'OK' })
    })
  }

  /**
   * **ADI-T1241 [Витрина задач] Поиск Моих задач по параметрам и переход к документу**
   *
   * В методе используется необязательные и обязательные параметры. Сначала вызывается необязательные параметр в { }, после один обязательный.
   * Для необязательных параметров можно не указывать аргументы, и тогда функция будет использовать значения по умолчанию.
   * Список необязательных параментров можно посмотреть и выбрать при помощи сочитания CTRL + Space.
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T1241|Открыть ADI-T1241}
   * @param {object}  stepArguments            - опции для формирования локаторов
   * @param {string} [stepArguments.group]     - группа
   * @param {string} [stepArguments.number]    - номер документа
   * @param {string} [stepArguments.type]      - тип документа
   * @param {string} [stepArguments.product]   - продукт
   * @param {string} [stepArguments.fillText1] - дата создания с
   * @param {string} [stepArguments.fillText2] - дата создания по
   * @param {string} [stepArguments.status]    - статус задачи
   * @param {string}  testData                 - выбор номера из таблицы
   * @example
   * await stepGeneral.ADI_T1241( { number: quoteNumber }, 'MCQ-' )
   */
  async ADI_T1241(stepArguments, testData) {
    await test.step('ADI-T1241 [Витрина задач] Поиск Моих задач по параметрам и переход к документу', async () => {
      //await this.fillCombobox(LocatorType.byTestIdByRole, 'Группа', generalSelectors.группа, ` ${stepArguments.group}`, true)

      if (stepArguments.group) {
        await this.page.getByTestId('userGroupsSelect').getByRole('combobox').click()
        await this.page.getByText(stepArguments.group, { exact: true }).click()
      }

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Номер документа',
        generalSelectors.задачиНомерДокумента,
        stepArguments.number
      )

      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Тип документа',
        generalSelectors.типДокумента,
        stepArguments.type,
        true
      )

      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Продукт',
        generalSelectors.продукт,
        stepArguments.product,
        true
      )

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Дата создания с',
        generalSelectors.датаСозданияС,
        stepArguments.fillText1
      )

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Дата создания по',
        generalSelectors.датаСозданияПо,
        stepArguments.fillText2
      )

      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Статус задачи',
        generalSelectors.статусЗадачи,
        stepArguments.status,
        true
      )

      await this.clickButton(LocatorType.byRole, { roleName: 'Поиск' })

      await this.page.getByTestId('my-tasks-table_doc-number-link').getByRole('link', { name: testData }).click()
    })
  }

  /**
   * **ADI-T2501 Проверка наличия или отсутствия текстового сообщения в информационном меню**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2501|Открыть ADI-T2501}
   * @param {'есть текст'|'нет текста'} action  - тип заполнения ('есть текст'|'нет текста')
   * @param {string} text - текст который нужно проверить
   * @example
   * await stepGeneral.ADI_T2501( action:'есть текст', text:'Приложите фотографии строений на вкладке "Вложения"')
   */
  async ADI_T2501(action, text) {
    await test.step('ADI-T2501 Проверка наличия или отсутствия текстового сообщения в информационном меню', async () => {
      switch (action) {
        case 'есть текст':
          await this.clickButton(LocatorType.byTestId, {
            idElement: generalSelectors.проверкиИОшибки,
          })
          await expect(this.page.getByTestId('RequiredPropertiesValidations')).toContainText(text)
          break
        case 'нет текста':
          await this.clickButton(LocatorType.byTestId, {
            idElement: generalSelectors.проверкиИОшибки,
          })
          await expect(this.page.getByTestId('RequiredPropertiesValidations')).not.toContainText(text)
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T4765 Проверка текста валидационной ошибки в сайдбаре**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T4765|Открыть ADI-T4765}
   * @param {string} text - текст который нужно проверить
   * @example
   * await stepGeneral.ADI_T4765( text:'Приложите фотографии строений на вкладке "Вложения"')
   */
  async ADI_T4765(text) {
    await test.step('ADI-T4765 [ИнфоМеню] Проверка текста валидационной ошибки в сайдбаре', async () => {
      await this.clickButton(LocatorType.byTestId, {
        idElement: generalSelectors.проверкиИОшибки,
      })
      await expect(this.page.getByTestId('RequiredPropertiesValidations')).toContainText(text)
    })
  }

  /**
   * **ADI-T11970 Проверка значения одного поля в информационном меню**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T11970|Открыть ADI-T11970}
   * @param {string} id   - id поля
   * @param {string} text - проверяемый текст
   * @example
   * await stepGeneral.ADI_T11970( id:'business-type', text:'Новый бизнес Б/у ТС переход из другой СК')
   */
  async ADI_T11970(id, text) {
    await test.step('ADI-T11970 Проверка значения одного поля в информационном меню', async () => {
      await this.clickButton(LocatorType.byTestId, {
        idElement: generalSelectors.общаяИнформация,
      })
      await expect(this.page.getByTestId(id).first()).toContainText(text)
    })
  }

  /**
   * **ADI-T1127 Поиск и выбор в форме "Поиск сотрудников"**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T1127|Открыть ADI-T1127}
   * @param {string} id         - id значка лупы
   * @param {string} fillText   - значение в поле поиск
   * @param {string} filltext1  - пользователь в таблице
   * @example
   * await stepGeneral.ADI_T1127( id:'employee-search', fillText:'Севидова Надежда Григорьевна', filltext1:'Севидова Надежда Григорьевна' )
   */
  async ADI_T1127(id, fillText, filltext1) {
    await test.step('ADI-T1127 Поиск и выбор в форме "Поиск сотрудников"', async () => {
      await this.clickButton(LocatorType.byTestIdByRole, {
        idElement: id,
        roleName: '',
      })
      await this.fillTextbox(LocatorType.byTestIdByRole, 'Поиск', generalSelectors.полеПоискСотрудников, fillText)
      await this.clickButton(LocatorType.byRole, { roleName: 'Поиск' })
      await this.checkCheckboxInTable(LocatorType.byRole, filltext1)
      await this.clickButton(LocatorType.byRole, { roleName: 'Выбрать' })
    })
  }

  /**
   * **ADI-T11860 Поиск и выбор в форме "Поиск контрагентов по параметрам" ЮЛ (без выбора типа КА и выбора поиска в системах)**
   *
   *  Метод реализован с использованием необязательных аргументов (тестовые танные). Т.е. для выполнения шага заполнение всех полей необязательно, достаточно заполнить необходимые.
  
  Например. КА можно найти:
  - только по названию КА
  - по названию+ИНН
  - по названию ИНН+КПП
  - по ИНН+КПП
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T11860|Открыть ADI-T11860}
   * @param {object} stepArguments - объект с необязательными аргументами метода
   * @param {string} [stepArguments.fillText] - наименование
   * @param {string} [stepArguments.inn] - ИНН
   * @param {string} [stepArguments.kpp] - КПП
   * @param {string} cellText - код КА в таблице с результатами поиска
   * @example 
   * // поиск КА только по названию
   * await stepGeneral.ADI_T11860({ fillText:'общество с ограниченной ответственностью "Страховая компания "Капитал-полис"' }, cellText: '1014691')
   * // поиск КА только по ИНН
   * await stepGeneral.ADI_T11860({ inn: '7838066700' }, cellText: '1014691')
   * // поиск КА по ИНН и КПП
   * await stepGeneral.ADI_T11860({ inn: '7838066700', kpp: '000000000' }, cellText: '1014691')
   */
  async ADI_T11860(stepArguments, cellText) {
    await test.step('ADI-T11860 Поиск и выбор в форме "Поиск контрагентов по параметрам" ЮЛ (без выбора типа КА и выбора поиска в системах)', async () => {
      await this.clickButton(LocatorType.byTestIdByRole, {
        idElement: generalSelectors.кнопкаЛупаИсторияВладения,
        roleName: '',
      })
      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Наименование',
        generalSelectors.полеНаименование,
        stepArguments.fillText
      )
      await this.fillTextbox(LocatorType.byTestIdByRole, 'ИНН', generalSelectors.полеИНН, stepArguments.inn)
      await this.fillTextbox(LocatorType.byTestIdByRole, 'КПП', generalSelectors.полеКПП, stepArguments.kpp)
      await this.clickButton(LocatorType.byTestIdByRole, {
        idElement: generalSelectors.кнопкаПоискСотрудника,
        roleName: 'Поиск',
      })

      await this.checkCheckboxInTable(LocatorType.byRole, cellText)

      await this.clickButton(LocatorType.byRole, { roleName: 'Выбрать' })
    })
  }

  /**
   * **ADI-T5175 Проверка наличия или отсутствия действия в меню 'Действия'**
   * @see {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T5175|Открыть ADI-T5175}
   * @param {'присутствует'|'отсутствует'} action - тип заполнения ('присутствует'|'отсутствует')
   * @param {string} id  - id элемента
   * @example
   * await stepGeneral.ADI_T5175( action:'присутствует', id:'сover-general-deductible' )
   * await stepGeneral.ADI_T5175( action:'отсутствует', id:'сover-general-deductible' )
   */
  async ADI_T5175(action, id) {
    await test.step('ADI-T5175 Проверка наличия или отсутствия действия в списке "Действия"', async () => {
      switch (action) {
        case 'присутствует':
          await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
          await expect(this.page.getByTestId(id)).toBeVisible()
          await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
          break
        case 'отсутствует':
          await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
          await expect(this.page.getByTestId(id)).toBeHidden()
          await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T3002 Проверка наличия в меню "Действия" не активного пункта**
   * @see {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3002|Открыть ADI-T3002}
   * @param {string} name - пункт меню "Действия"
   * @param {string} id   - id элемента
   * @example
   * await stepGeneral.ADI_T3002( name:'Которовка', id:'сover-general-deductible' )
   */
  async ADI_T3002(name, id) {
    await test.step('ADI-T3002 Проверка наличия в меню "Действия" не активного пункта', async () => {
      await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
      await this.clickButton(LocatorType.byTestId, {
        idElement: id,
        nameElement: name,
      })
      await this.clickButton(LocatorType.byRole, { roleName: 'Закрыть' })
    })
  }

  /**
   * **ADI_11698 Универсальный шаг по 'Поиск контрагента'**
   *
   * В методе используется необязательные и обязательные параметры. Сначала вызывается необязательные параметр в { }, после один обязательный.
   * Для необязательных параметров можно не указывать аргументы, и тогда функция будет использовать значения по умолчанию.
   * Список необязательных параментров можно посмотреть и выбрать при помощи сочитания CTRL + Space.
   * @see {@link https://jira.sogaz.ru|Jira}
   * @param {'Физ.лицо'|'Юр.лицо'|'ИП'}  action     -  тип контрагента ('Физ.лицо'|'Юр.лицо'|'ИП')
   * @param {object}  stepArguments                 -  опции для формирования локаторов
   * @param {string} [stepArguments.surname]        -  фамилия
   * @param {string} [stepArguments.name]           -  имя
   * @param {string} [stepArguments.middleName]     -  отчество
   * @param {string} [stepArguments.dateOfBirth]    -  дата рождения
   * @param {string} [stepArguments.gender]         -  пол
   * @param {string} [stepArguments.typeOfDocument] -  вид документа
   * @param {string} [stepArguments.series]         -  серия
   * @param {string} [stepArguments.number]         -  номер
   * @param {string} [stepArguments.designation]    -  наименование
   * @param {string} [stepArguments.inn]            -  ИНН
   * @param {string} [stepArguments.kpp]            -  КПП
   * @param {string} [stepArguments.code]           -  код
   * @param {string} [stepArguments.id]             -  id значка лупы
   * @example
   * await stepGeneral.ADI_11698( action:'Физ.лицо', { id: 'btn-policy-holder-search', surname: 'Федоров',name: 'Ярослав', middleName: 'Юрьевич', code: '1687564'})
   */
  async ADI_11698(action, stepArguments) {
    await test.step('ADI-T11698 Универсальный шаг по "Поиск контрагента"', async () => {
      switch (action) {
        case 'Физ.лицо':
          await this.clickButton(LocatorType.byTestIdByRole, {
            idElement: stepArguments.id,
            nameElement: 'О',
          })

          await this.fillCombobox(
            LocatorType.byTestIdByRole,
            'Тип контрагента',
            generalSelectors.типКонтрагента,
            'Физ. лицо'
          )

          await this.fillCombobox(
            LocatorType.byTestIdByRole,
            'Поиск контрагента в системах',
            generalSelectors.поискКонтрагентаВСистеме,
            'Поиск в системе Адакта'
          )
          await this.fillTextbox(LocatorType.byTestIdByRole, 'Фамилия', generalSelectors.фамилия, stepArguments.surname)

          await this.fillTextbox(LocatorType.byTestIdByRole, 'Имя', generalSelectors.имя, stepArguments.name)

          await this.fillTextbox(
            LocatorType.byTestIdByRole,
            'Отчество',
            generalSelectors.отчество,
            stepArguments.middleName
          )

          await this.fillTextbox(
            LocatorType.byTestIdByRole,
            'Дата рождения',
            generalSelectors.датаРождения,
            stepArguments.dateOfBirth
          )

          await this.fillCombobox(LocatorType.byTestIdByRole, 'Пол', generalSelectors.пол, stepArguments.gender)

          await this.fillCombobox(
            LocatorType.byTestIdByRole,
            'Вид документа',
            generalSelectors.видДокумента,
            stepArguments.typeOfDocument
          )

          await this.fillTextbox(LocatorType.byTestIdByRole, 'Серия', generalSelectors.серия, stepArguments.series)

          await this.fillTextbox(LocatorType.byTestIdByRole, 'Номер', generalSelectors.номер, stepArguments.number)

          await this.clickButton(LocatorType.byTestIdByRole, {
            idElement: generalSelectors.кнопкаПоиск,
            roleName: 'Поиск',
          })

          await this.checkCheckboxInTable(LocatorType.byRole, stepArguments.code)

          await this.clickButton(LocatorType.byRole, { roleName: 'Выбрать' })
          break

        case 'Юр.лицо':
          await this.clickButton(LocatorType.byTestIdByRole, {
            idElement: stepArguments.id,
            nameElement: 'О',
          })

          await this.fillCombobox(
            LocatorType.byTestIdByRole,
            'Тип контрагента',
            generalSelectors.типКонтрагента,
            'Юр. лицо'
          )

          await this.fillCombobox(
            LocatorType.byTestIdByRole,
            'Поиск контрагента в системах',
            generalSelectors.поискКонтрагентаВСистеме,
            'Поиск в системе Адакта'
          )
          await this.fillTextbox(
            LocatorType.byTestIdByRole,
            'Наименование',
            generalSelectors.наименование,
            stepArguments.designation
          )

          await this.fillTextbox(LocatorType.byTestIdByRole, 'ИНН', generalSelectors.инн, stepArguments.inn)

          await this.fillTextbox(LocatorType.byTestIdByRole, 'КПП', generalSelectors.кпп, stepArguments.kpp)

          await this.clickButton(LocatorType.byTestIdByRole, {
            idElement: generalSelectors.кнопкаПоиск,
            roleName: 'Поиск',
          })

          await this.checkCheckboxInTable(LocatorType.byRole, stepArguments.code)

          await this.clickButton(LocatorType.byRole, {
            roleName: 'Выбрать',
          })
          break

        case 'ИП':
          await this.clickButton(LocatorType.byTestIdByRole, {
            idElement: stepArguments.id,
            nameElement: 'О',
          })

          await this.fillCombobox(LocatorType.byTestIdByRole, 'Тип контрагента', generalSelectors.типКонтрагента, 'ИП')

          await this.fillCombobox(
            LocatorType.byTestIdByRole,
            'Поиск контрагента в системах',
            generalSelectors.поискКонтрагентаВСистеме,
            'Поиск в системе Адакта'
          )
          await this.fillTextbox(LocatorType.byTestIdByRole, 'Фамилия', generalSelectors.фамилия, stepArguments.surname)

          await this.fillTextbox(LocatorType.byTestIdByRole, 'Имя', generalSelectors.имя, stepArguments.name)

          await this.fillTextbox(
            LocatorType.byTestIdByRole,
            'Отчество',
            generalSelectors.отчество,
            stepArguments.middleName
          )

          await this.fillTextbox(LocatorType.byTestIdByRole, 'ИНН', generalSelectors.инн, stepArguments.inn)

          await this.fillTextbox(
            LocatorType.byTestIdByRole,
            'Дата рождения',
            generalSelectors.датаРождения,
            stepArguments.dateOfBirth
          )

          await this.fillCombobox(LocatorType.byTestIdByRole, 'Пол', generalSelectors.пол, stepArguments.gender)

          await this.clickButton(LocatorType.byTestIdByRole, {
            idElement: generalSelectors.кнопкаПоиск,
            roleName: 'Поиск',
          })

          await this.checkCheckboxInTable(LocatorType.byRole, stepArguments.code)

          await this.clickButton(LocatorType.byRole, { roleName: 'Выбрать' })
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T4565 Проверка активности действия в списке действий**
   * @see {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T4565|Открыть ADI-T4565}
   * @param {'toHaveClass'|'toBeHidden'|'toBeEnabled'}  action - тип проверки ('toHaveClass'|'toBeHidden'|'toBeEnabled')
   * @param {string}  id     - id элемента
   * @param {string} [value] - проверяемое значение (используется в проверки 'toHaveClass', пример класса 'dropdown-item')
   * @example
   * //toHaveClass
   * await stepGeneral.ADI_T4565( action:'toHaveClass', id:'ai-transitions-relations-control-Draft_SendToHigherLevel', value:'dropdown-item')
   * //toBeHidden
   * await stepGeneral.ADI_T4565( action:'toBeHidden', id:'ai-transitions-relations-control-Draft_SendToHigherLevel' )
   * //toBeEnabled
   * await stepGeneral.ADI_T4565( action:'toBeEnabled', id:'ai-transitions-relations-control-Draft_SendToHigherLevel' )
   */
  async ADI_T4565(action, id, value) {
    await test.step('ADI-T4565 Проверка активности действия в списке действий', async () => {
      switch (action) {
        case 'toHaveClass':
          await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
          await expect(await this.getLocator(LocatorType.byTestId, { testId: id })).toHaveClass(value)
          break
        case 'toBeHidden':
          await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
          await expect(await this.getLocator(LocatorType.byTestId, { testId: id })).toBeHidden()
          break
        case 'toBeEnabled':
          await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
          await expect(await this.getLocator(LocatorType.byTestId, { testId: id })).toBeVisible()
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T10352 Проверка отсутствия ПФ в списке "Печать"**
   * @see {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T10352|Открыть ADI-T10352}
   * @param {string} id - id пф в списке
   * @example
   * await stepGeneral.ADI_T10352('ai-printouts-control-MotorCascoPolicyLeasingSealImprintPrintout')
   */
  async ADI_T10352(id) {
    await test.step('ADI-T10352 Проверка отсутствия ПФ в списке "Печать"', async () => {
      await this.clickButton(LocatorType.byTestIdByRole, {
        idElement: generalSelectors.кнопкаПечать,
        nameElement: 'Печать',
      })

      await expect(await this.getLocator(LocatorType.byTestId, { testId: id })).toBeHidden()

      await this.page.getByRole('button', { name: ' ' }).click()
    })
  }

  /**
   * **ADI-T8049 Проверка наличия или отсутствия поля в блоке (универсальное)**
   * @see {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T8049|Открыть ADI-T8049}
   * @param {'textbox'|'id'|'combobox'}  action  - тип проверки ('textbox'|'id'|'combobox')
   * @param {boolean} shouldBeVissible  - виден или невиден элемент (true/false)
   * @param {string}  idElement         - id элемента
   * @example
   * //'id'
   * await stepGeneral.ADI_T8049(action:'id', shouldBeVissible: true, idElement:'insurance-end')
   * //'combobox'
   * await stepGeneral.ADI_T8049(action:'combobox', shouldBeVissible: false, idElement:'general-rules')
   * //'textbox'
   * await stepGeneral.ADI_T8049(action:'textbox', shouldBeVissible: false, idElement:'sales-outlet-name')
   */
  async ADI_T8049(action, shouldBeVissible = true, idElement) {
    await test.step('ADI-T8049 Проверка наличия или отсутствия поля в блоке (универсальное)', async () => {
      switch (action) {
        case 'textbox':
          if (shouldBeVissible) {
            await expect(
              await this.getLocator(LocatorType.byTestIdByRole, {
                testId: idElement,
                role: 'textbox',
              })
            ).toBeVisible()
          } else {
            await expect(
              await this.getLocator(LocatorType.byTestIdByRole, {
                testId: idElement,
                role: 'textbox',
              })
            ).toBeHidden()
          }
          break
        case 'id':
          if (shouldBeVissible) {
            await expect(await this.getLocator(LocatorType.byTestId, { testId: idElement })).toBeVisible()
          } else {
            await expect(await this.getLocator(LocatorType.byTestId, { testId: idElement })).toBeHidden()
          }
          break
        case 'combobox':
          if (shouldBeVissible) {
            await expect(
              await this.getLocator(LocatorType.byTestIdByRole, {
                testId: idElement,
                role: 'combobox',
              })
            ).toBeVisible()
          } else {
            await expect(
              await this.getLocator(LocatorType.byTestIdByRole, {
                testId: idElement,
                role: 'combobox',
              })
            ).toBeHidden()
          }
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T3231 Проверка значения одного поля в блоке (универсальная)**
   * @see {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3231|Открыть ADI-T3231}
   * @param {'toHaveClass'|'toHaveText'|'toContainText'|'toHaveValue'}  action - тип проверки ('toHaveClass'|'toHaveText'|'toContainText'|'toHaveValue')
   * @param {'id'|'locator'|'combobox'|'textbox'}  locatorType  - тип локатора ('id'|'locator'|'combobox'|'textbox')
   * @param {string|RegExp}  value - проверяемое значение
   * @param {string}  idElement    - id локатора
   * @param {string} [nameLocator] - наименование локатора
   * @example
   * await stepGeneral.ADI_T3231('toContainText','id','Усова Елена Михайловна','poadata-terminated-link')
   */
  async ADI_T3231(action, locatorType, value, idElement, nameLocator) {
    await test.step('ADI-T3231 Проверка значения одного поля в блоке (универсальная)', async () => {
      const locators = {
        id: () => this.getLocator(LocatorType.byTestId, { testId: idElement }),
        locator: () => this.page.getByTestId(idElement).locator(nameLocator),
        combobox: () =>
          this.getLocator(LocatorType.byTestIdByRole, {
            testId: idElement,
            role: 'combobox',
          }),
        textbox: () =>
          this.getLocator(LocatorType.byTestIdByRole, {
            testId: idElement,
            role: 'textbox',
          }),
      }

      const actions = {
        toHaveClass: async () => {
          await expect(locators[locatorType]()).toHaveClass(value)
        },
        toHaveText: async () => {
          await expect(locators[locatorType]()).toHaveText(value)
        },
        toContainText: async () => {
          await expect(locators[locatorType]()).toContainText(value)
        },
        toHaveValue: async () => {
          await expect(locators[locatorType]()).toHaveValue(value)
        },
      }

      if (actions[action]) {
        await actions[action]()
      } else {
        throw new Error(`Неизвестный тип ${action}`)
      }
    })
  }

  /**
   * **ADI-T1237 Поиск, назначение нераспределенной задачи и переход к документу**
   * @see {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T1237|Открыть ADI-T1237}
   * @param {object}  stepArguments               - опции для формирования локаторов
   * @param {string} [stepArguments.group]        - группа
   * @param {string} [stepArguments.executor]     - исполнитель
   * @param {string} [stepArguments.docNumber]    - номер документа
   * @param {string} [stepArguments.documentType] - тип докуента
   * @param {string} [stepArguments.dateFrom]     - дата создания с
   * @param {string} [stepArguments.dateBy]       - дата создания по
   * @param {string} [stepArguments.taskStatus]   - статус задачи
   * @param {string} [stepArguments.testData]     - чекбокс номер документа
   * @param {string} [stepArguments.number]       - номер документа
   * @example
   * await stepGeneral.ADI_T1237( stepArguments: { group: 'Андеррайтинг ГО (авто, уровень 2)', docNumber: quoteNumber, documentType:'Котировка',number:quoteNumber,testData:quoteNumber})
   */
  async ADI_T1237(stepArguments) {
    await test.step('ADI-T1237 [Витрина задач] Поиск, назначение нераспределенной задачи и переход к документу', async () => {
      // await this.fillCombobox(
      //   LocatorType.byTestIdByRole,
      //   'Группа',
      //   generalSelectors.группаЛокатор,
      //   ` ${stepArguments.group}`,
      //   true
      // )

      if (stepArguments.group) {
        await this.page.getByTestId('userGroupsSelect').getByRole('combobox').click()
        await this.page.getByText(stepArguments.group, { exact: true }).click()
      }

      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Исполнитель',
        generalSelectors.исполнительНераспределенныеЗадачи,
        stepArguments.executor,
        true
      )

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Номер документа',
        generalSelectors.номерДокументаЛокатор,
        stepArguments.docNumber
      )

      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Тип документа',
        generalSelectors.типДокументаЛокатор,
        stepArguments.documentType,
        true
      )

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Дата создания с',
        generalSelectors.датаСозданияЛокатор,
        stepArguments.dateFrom,
        9
      )

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Дата создания по',
        generalSelectors.датаСозданияЛокатор,
        stepArguments.dateBy,
        10
      )

      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Статус задачи',
        generalSelectors.статусЗадачиЛокатор,
        stepArguments.taskStatus,
        true
      )

      await this.clickButton(LocatorType.byRole, { roleName: 'Поиск' })

      await this.page.getByRole('row', { name: stepArguments.number }).getByRole('checkbox').click()

      await this.clickButton(LocatorType.byRole, { roleName: 'Назначить задачу на себя' })

      await this.page.getByRole('button', { name: 'Поиск' }).hover()

      await this.page
        .getByTestId('group-tasks-table_doc-number-link')
        .getByRole('link', { name: stepArguments.testData })
        .click()
    })
  }

  /**
   * **ADI-T1129 Поиск и переход к документу (по номеру, типу документа, продукту, статусу)**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T1129|Открыть ADI-T1129}
   * @param {string} docNumber - номер документа
   * @param {string} number    - ключ
   * @example
   * await stepGeneral.ADI_T1129(quoteNumber,'MCQ-' )
   */
  async ADI_T1129(docNumber, number) {
    await test.step('ADI-T1129 [Страховые продукты] Поиск и переход к документу (по номеру, типу документа, продукту, статусу)', async () => {
      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Номер документа',
        generalSelectors.номерДокументаПоиск,
        docNumber,
        0
      )

      await this.clickButton(LocatorType.byRole, { roleName: 'Поиск' })

      await this.page.getByTestId('contract-search-table_doc-number-link').getByRole('link', { name: number }).click()
    })
  }

  /**
   * **ADI-T3266 Проверка заполненного атрибута значением по умолчанию**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3266|Открыть ADI-T3266}
   * @param {'id'|'textbox'|'combobox'} action           - тип локатора ('id'|'textbox'|'combobox')
   * @param {string} typeVerification - тип проверки
   * @param {string} idElement        - id элемента
   * @param {string} [value]          - проверяемое значение
   * @example
   * //id
   * await stepGeneral.ADI_T3266(action:'id', typeVerification:'toContainText', idElement:'deductible-option-ng-select', value:'безусловная')
   * //combobox
   * await stepGeneral.ADI_T3266(action:'combobox',typeVerification:'toBeEmpty',idElement:'promotion-ng-select')
   */
  async ADI_T3266(action, typeVerification, idElement, value) {
    await test.step('ADI-T3266 Проверка заполненного атрибута значением по умолчанию', async () => {
      switch (action) {
        case 'id':
          if (typeVerification === 'toContainText') {
            await expect(await this.getLocator(LocatorType.byTestId, { testId: idElement })).toContainText(value)
          } else if (typeVerification === 'toHaveValue') {
            await expect(await this.getLocator(LocatorType.byTestId, { testId: idElement })).toHaveValue(value)
          }
          break
        case 'textbox':
          if (typeVerification === 'toHaveValue') {
            await expect(
              await this.getLocator(LocatorType.byTestIdByRole, {
                testId: idElement,
                role: 'textbox',
              })
            ).toHaveValue(value)
          } else if (typeVerification === 'toContainText') {
            await expect(
              await this.getLocator(LocatorType.byTestIdByRole, {
                testId: idElement,
                role: 'textbox',
              })
            ).toContainText(value)
          }
          break
        case 'combobox':
          if (typeVerification === 'toBeEmpty') {
            await expect(
              await this.getLocator(LocatorType.byTestIdByRole, {
                testId: idElement,
                role: 'combobox',
              })
            ).toBeEmpty()
          }
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T4839 Проверка присутствия ссылки на странице**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T4839|Открыть ADI-T4839}
   * @param {string} link - проверяемая ссылка
   * @example
   * await stepGeneral.ADI_T4839(fio)
   */
  async ADI_T4839(link) {
    await test.step('ADI-T4839 Проверка присутствия ссылки на странице', async () => {
      await expect(this.page.getByRole('link', { name: link })).toBeVisible()
    })
  }

  /**
   * **ADI-T4966 Выбор значения из выпадающего списка**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T4966|Открыть ADI-T4966}
   * @param {string} nameElement - название элемента
   * @param {string} idElement   - id элемента
   * @param {string}   value     - значение
   * @param {number} [nth]  - условие строгого соответствия
   * @example
   * await stepGeneral.ADI_T4966(nameElement:'Страховая сумма', idElement:'accident-sum-ng-select', value:'2 000 000')
   */
  async ADI_T4966(nameElement, idElement, value, nth) {
    await test.step('ADI-T4966 Выбор значения из выпадающего списка', async () => {
      await this.fillCombobox(LocatorType.byTestIdByRole, nameElement, idElement, value, true, nth)
    })
  }

  /**
   * **ADI-T3240 Проверка наличия или отсутствия валидационного сообщения под полем (универсальная)**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3240|Открыть ADI-T3240}
   * @param {'id'|'locator'}  action           - тип элемента ('id'|'locator')
   * @param {object}  stepArguments            - опции для формирования локаторов
   * @param {string} [stepArguments.idElement] - id элемента
   * @param {string} [stepArguments.value]     - проверяемое значение
   * @param {string} [stepArguments.LocatorId] - локатор
   * @param {'присутствует'|'отсутствует'} [stepArguments.typeVerification] - тип проверки
   * @example
   * //locator
   * await stepGeneral.ADI_T3240(action:'locator', {idElement:'pts-number',LocatorId:'input-control-errors-bootstrap',value:'Номер электронного ПТС не соответствует шаблону'})
   * //id
   * await stepGeneral.ADI_T3240(action:'id', {idElement:'commission-value',value:'Значение КВ должно быть меньше или равно 10'})
   */
  async ADI_T3240(action, stepArguments) {
    await test.step('ADI-T3240 Проверка наличия или отсутствия валидационного сообщения под полем (универсальная)', async () => {
      switch (action) {
        case 'id':
          if (stepArguments.typeVerification === 'присутствует') {
            await expect(
              await this.getLocator(LocatorType.byTestId, { testId: stepArguments.idElement })
            ).toContainText(stepArguments.value)
          } else if (stepArguments.typeVerification === 'отсутствует') {
            await expect(
              await this.getLocator(LocatorType.byTestId, { testId: stepArguments.idElement })
            ).not.toContainText(stepArguments.value)
          }
          break
        case 'locator':
          if (stepArguments.typeVerification === 'присутствует') {
            await expect(
              await this.getLocator(LocatorType.byTestIdAndLocatorName, {
                testId: stepArguments.idElement,
                locatorName: stepArguments.LocatorId,
              })
            ).toContainText(stepArguments.value)
          } else if (stepArguments.typeVerification === 'отсутствует') {
            await expect(
              await this.getLocator(LocatorType.byTestIdAndLocatorName, {
                testId: stepArguments.idElement,
                locatorName: stepArguments.LocatorId,
              })
            ).not.toContainText(stepArguments.value)
          }
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T6021 Переключение роли с проверкой знака роли**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T6021|Открыть ADI-T6021}
   * @param {string} buttonValue - роль кнопки
   * @param {string} value       - роль для переключения
   * @example
   * await stepGeneral.ADI_T6021( buttonValue:'П ' , value:'Андеррайтер')
   */
  async ADI_T6021(buttonValue, value) {
    await test.step('ADI-T6021 Переключение роли с проверкой знака роли', async () => {
      await this.clickButton(LocatorType.byRole, { roleName: buttonValue })

      await this.clickButton(LocatorType.byRole, { roleName: value })
    })
  }

  /**
   * **ADI-T3008 Поиск и выбор в форме "Поиск контрагента - по параметрам" ИП в системе Адакта**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3008|Открыть ADI-T3008}
   * @param {object}  stepArguments              - опции для формирования локаторов
   * @param {string} [stepArguments.id]          - id значка лупы
   * @param {string} [stepArguments.surname]     - фамилия
   * @param {string} [stepArguments.name]        - имя
   * @param {string} [stepArguments.middleName]  - отчество
   * @param {string} [stepArguments.inn]         - инн
   * @param {string} [stepArguments.dateOfBirth] - дата рождения
   * @param {string} [stepArguments.gender]      - пол
   * @param {string} [stepArguments.code]        - код
   * @example
   * await stepGeneral.ADI_T3008({ id: 'select-policyholder-button', surname: 'Ярославцев', name: 'Валерий', middleName: 'Александрович', code:'2868134'})
   */
  async ADI_T3008(stepArguments) {
    await test.step('ADI-T3008 Поиск и выбор в форме "Поиск контрагента - по параметрам" ИП в системе Адакта', async () => {
      await this.clickButton(LocatorType.byTestIdByRole, {
        idElement: stepArguments.id,
        nameElement: 'О',
      })

      await this.fillCombobox(LocatorType.byTestIdByRole, 'Тип контрагента', generalSelectors.типКонтрагента, 'ИП')

      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Поиск контрагента в системах',
        generalSelectors.поискКонтрагентаВСистеме,
        'Поиск в системе Адакта'
      )
      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Фамилия',
        generalSelectors.страховательФамилия,
        stepArguments.surname
      )

      await this.fillTextbox(LocatorType.byTestIdByRole, 'Имя', generalSelectors.страховательИмя, stepArguments.name)

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Отчество',
        generalSelectors.страховательОтчество,
        stepArguments.middleName
      )

      await this.fillTextbox(LocatorType.byTestIdByRole, 'ИНН', generalSelectors.страховательИнн, stepArguments.inn)

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Дата рождения',
        generalSelectors.страховательДатаРождения,
        stepArguments.dateOfBirth
      )

      await this.fillCombobox(LocatorType.byTestIdByRole, 'Пол', generalSelectors.страховательПол, stepArguments.gender)

      await this.clickButton(LocatorType.byTestIdByRole, {
        idElement: generalSelectors.кнопкаПоиск,
        roleName: 'Поиск',
      })

      await this.checkCheckboxInTable(LocatorType.byRole, stepArguments.code)

      await this.clickButton(LocatorType.byRole, { roleName: 'Выбрать' })
    })
  }

  /**
   * **ADI-T6605 Поиск и выбор в форме "Поиск контрагентов" ЮЛ (Страховая компания)**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T6605|Открыть ADI-T6605}
   * @param {object}  stepArguments                     - опции для формирования локаторов
   * @param {string} [stepArguments.inn]                - инн
   * @param {string} [stepArguments.kpp]                - кпп
   * @param {string} [stepArguments.codeSk]             - код СК
   * @param {string} [stepArguments.registrationNumber] - регистрационный номер
   * @param {string} [stepArguments.code]               - код
   * @param {string} [stepArguments.organisationName]   - наименование организации
   * @example
   * await stepGeneral.ADI_T6605({organisationName:'АО "АЛЬФАСТРАХОВАНИЕ"',inn:'7713056834',code:'657730'})
   */
  async ADI_T6605(stepArguments) {
    await test.step('ADI-T6605 Поиск и выбор в форме "Поиск контрагентов" ЮЛ (Страховая компания)', async () => {
      await this.clickButton(LocatorType.byRole, { roleName: ' Предыдущая страховая компания' })

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Наименование',
        generalSelectors.наименованиеСтраховаяКомпания,
        stepArguments.organisationName
      )

      await this.fillTextbox(LocatorType.byTestIdByRole, 'ИНН', generalSelectors.полеИНН, stepArguments.inn)
      await this.fillTextbox(LocatorType.byTestIdByRole, 'КПП', generalSelectors.полеКПП, stepArguments.kpp)

      await this.fillTextbox(LocatorType.byTestIdByRole, 'Код СК', generalSelectors.кодСк, stepArguments.codeSk)

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Регистрационный номер',
        generalSelectors.регистрационныйНомер,
        stepArguments.registrationNumber
      )

      await this.clickButton(LocatorType.byTestIdByRole, {
        idElement: generalSelectors.кнопкаПоиск,
        roleName: 'Поиск',
      })

      await this.checkCheckboxInTable(LocatorType.byRole, stepArguments.code)

      await this.clickButton(LocatorType.byRole, { roleName: 'Выбрать' })
    })
  }

  /**
   * **ADI-T9876 Поиск и выбор в форме "Поиск контрагента - по параметрам" в системе Адакта для всех типов КА (по ФИО или наименованию)**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T9876|Открыть ADI-T9876}
   * @param {'Юр. лицо'}  action               - действие ('Юр. лицо')
   * @param {object}  stepArguments            - опции для формирования локаторов
   * @param {string} [stepArguments.nameParty] - наименование
   * @param {string} [stepArguments.inn]       - инн
   * @param {string} [stepArguments.kpp]       - кпп
   * @param {string} [stepArguments.code]      - код
   * @param {string} [stepArguments.id]        - id значка 'Лупа'
   * @example
   * await stepGeneral.ADI_T9876( action:'Юр. лицо',stepArguments:{ nameParty:'ФОНД ПОДДЕРЖКИ КИНО, РАДИО, ТЕЛЕВИДЕНИЯ, МУЛЬТИМЕДИА И АНИМАЦИИ НИКОЛАЯ РАСТОРГУЕВА'})
   */
  async ADI_T9876(action, stepArguments) {
    await test.step('ADI-T9876 Поиск и выбор в форме "Поиск контрагента - по параметрам" в системе Адакта для всех типов КА (по ФИО или наименованию)', async () => {
      switch (action) {
        case 'Юр. лицо':
          await this.clickButton(LocatorType.byTestIdByRole, {
            idElement: stepArguments.id,
            roleName: '',
          })

          await this.fillCombobox(
            LocatorType.byTestIdByRole,
            'Поиск контрагента в системах',
            generalSelectors.поискКонтрагентаВСистемах,
            'Поиск в системе Адакта'
          )

          await this.fillTextbox(
            LocatorType.byTestIdByRole,
            'Наименование',
            generalSelectors.наименование,
            stepArguments.nameParty
          )

          await this.fillTextbox(LocatorType.byTestIdByRole, 'ИНН', generalSelectors.инн, stepArguments.inn)
          await this.fillTextbox(LocatorType.byTestIdByRole, 'КПП', generalSelectors.кпп, stepArguments.kpp)

          await this.clickButton(LocatorType.byTestIdByRole, {
            idElement: generalSelectors.кнопкаПоиск,
            roleName: 'Поиск',
          })

          await this.checkCheckboxInTable(LocatorType.byRole, stepArguments.code)

          await this.clickButton(LocatorType.byRole, { roleName: 'Выбрать' })
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }
  /**
   * **ADI-T2492 Поиск и открытие карточки контрагента по коду**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2492|Открыть ADI-T2492}
   * @param {string} generalSearch - код контрагента
   * @param {string} checkDocument - заголовок
   * @example
   * await stepGeneral.ADI_T2492( generalSearch: counterpartyNumber,checkDocument:'Физ. лицо:')
   */
  async ADI_T2492(generalSearch, checkDocument) {
    await test.step('ADI-T2492 Поиск и открытие карточки контрагента по коду', async () => {
      await this.fillTextbox(LocatorType.byTestIdByRole, 'Общий поиск', generalSelectors.общийПоиск, generalSearch)

      await this.clickButton(LocatorType.byRole, { roleName: 'Поиск' })

      let linkCounterpartyCard =
        'https://stage.adinsure.sogaz.ru/' +
        (await this.page
          .getByTestId('detailedparty-search-table')
          .getByRole('link', { name: generalSearch })
          .getAttribute('href'))

      await this.goToPage(linkCounterpartyCard)

      await expect(
        await this.getLocator(LocatorType.byTestId, { testId: generalSelectors.названиеДокумента })
      ).toContainText(checkDocument)
      await expect(
        await this.getLocator(LocatorType.byTestId, { testId: generalSelectors.номерДокумента })
      ).toContainText(generalSearch)
    })
  }

  /**
   * **ADI-T3269 Выполнение действия (с отправкой уведомления клиенту)**
   * @see   {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3269|Открыть ADI-T3269}
   * @param {string} id            - id действия из выпадающего списка
   * @param {string} name          - название действия из выпадающего списка
   * @param {string} checkDocument - заголовок
   * @param {string} stateDocument - статус
   * @example
   * await stepGeneral.ADI_T3269('ai-transitions-relations-control-Draft_to_PaymentWaiting','К Оплате','Договор:','(Ожидает оплаты)')
   */
  async ADI_T3269(id, name, checkDocument, stateDocument) {
    await test.step('ADI-T3269 Выполнение действия (с отправкой уведомления клиенту)', async () => {
      await this.clickButton(LocatorType.byRole, { roleName: 'Действия' })
      await this.clickButton(LocatorType.byTestId, {
        idElement: id,
        nameElement: name,
      })

      await this.clickButton(LocatorType.byRole, { roleName: 'Дa' })

      await this.clickButton(LocatorType.byRole, { roleName: ' OK' })

      await expect(
        await this.getLocator(LocatorType.byTestId, { testId: generalSelectors.названиеДокумента })
      ).toContainText(checkDocument)
      await expect(
        await this.getLocator(LocatorType.byTestId, { testId: generalSelectors.состояниеДокумента })
      ).toContainText(stateDocument)
    })
  }

  /**
   * **ADI-T6811 Проверка статуса документа (универсальный)**
   * @see {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T6811|Открыть ADI-T6811}
   * @param {string} value  - Статус документа
   * @example
   * await stepGeneral.ADI_T6811( value:'(Импортировано)' )
   */
  async ADI_T6811(value) {
    await test.step('ADI-T6811 Проверка статуса документа (универсальный)', async () => {
      await expect(this.page.getByTestId('header-document-state')).toContainText(value)
    })
  }

  /**
   * **ADI-T5207 Проверка наличия вкладки документа (универсальный)**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T5207|Открыть ADI-T5207}
   * @param {'присутствует'|'отсутствует'} type - тип проверки
   * @param {string} id   - id вкладки
   * @example
   * await stepGeneral.ADI_T5207( 'присутствует','tab-rsa-integration-nav')
   */
  async ADI_T5207(type, id) {
    await test.step('ADI-T5207 Проверка наличия вкладки документа (универсальный)', async () => {
      switch (type) {
        case 'присутствует':
          await expect(this.page.getByTestId(id)).toBeVisible()
          break
        case 'отсутствует':
          await expect(this.page.getByTestId(id)).toBeHidden()
          break
        default:
          throw new Error('Не удалось найти элемент')
      }
    })
  }

  /**
   * **ADI-T2522 Проверка значения атрибута Уровень согласования договора**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T2522|Открыть ADI-T2522}
   * @param {string} value - значение атрибута
   * @example
   * await stepGeneral.ADI_T2522( 'Согласование проекта договора осуществляется андеррайтером ТД')
   */
  async ADI_T2522(value) {
    await test.step('ADI-T2522 Проверка значения атрибута Уровень согласования договора', async () => {
      await expect(
        this.page.getByTestId(generalSelectors.уровеньСогласованияДоговора).getByTestId('-ng-select')
      ).toContainText(value)
    })
  }

  /**
   * **ADI-T6014 Проверка значения атрибута Уровень согласования ДопСа**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T6014|Открыть ADI-T6014}
   * @param {string} value - значение атрибута
   * @example
   * await stepGeneral.ADI_T6014( 'Согласование проекта договора осуществляется андеррайтером ТД')
   */
  async ADI_T6014(value) {
    await test.step('ADI-T6014 Проверка значения атрибута Уровень согласования ДопСа', async () => {
      await expect(
        this.page.getByTestId(generalSelectors.уровеньСогласованияДопса).getByTestId('-ng-select')
      ).toContainText(value)
    })
  }

  /**
   * **ADI-T3619 Проверка доступности ПФ в списке "Печать"**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3619 |Открыть ADI-T3619}
   * @param {string} value - значение атрибута Название ПФ
   * @example
   * await stepGeneral.ADI_T3619( 'Проверка доступности ПФ в списке "Печать"')
   */
  async ADI_T3619(value) {
    await test.step('ADI-T3619 Проверка доступности ПФ в списке "Печать"', async () => {
      await this.clickButton(LocatorType.byTestId, { idElement: generalSelectors.кнопкаПечать })
      await expect(this.page.getByText(value)).toBeVisible()
    })
  }

  /**
   * **ADI-T12765 Проверка доступности ПФ в списке "Печать" и закрытие списка ПФ**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T12765 |Открыть ADI-T12765}
   * @param {string} value - значение атрибута Название ПФ
   * @example
   * await stepGeneral.ADI_T12765('Полис-оферта "СОГАЗ-Квартира"')
   */
  async ADI_T12765(value) {
    await test.step('ADI-T12765 Проверка доступности ПФ в списке "Печать" и закрытие списка ПФ', async () => {
      await this.clickButton(LocatorType.byTestId, { idElement: generalSelectors.кнопкаПечать })
      await expect(this.page.getByText(value)).toBeVisible()
      await this.clickButton(LocatorType.byTestId, { idElement: generalSelectors.кнопкаПечать })
    })
  }

  /**
   * **ADI-T3628 Открыть и перейти в карточку контрагента из документа**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3628 |Открыть ADI-T3628}
   * @param {string} policyholderName - значение атрибута Имя контрагента
   * @param {string} policyholderCode - значение атрибута Код контрагента
   * @example
   * await stepGeneral.ADI_T3628('Глухов Михаил Юрьевич', '2529417')
   */
  async ADI_T3628(policyholderName, policyholderCode) {
    await test.step('ADI-T3628 Открыть и перейти в карточку контрагента из документа', async () => {
      const page1Promise = this.page.waitForEvent('popup')
      await this.page.getByRole('link', { name: policyholderName }).click()
      const page1 = await page1Promise
      await page1.waitForLoadState()
      await expect(page1.getByTestId(generalSelectors.номерДокумента)).toContainText(policyholderCode)
    })
  }

  /**
   * **ADI-T3163 Переход на вкладку браузера**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3163 |Открыть ADI-T3163}
   * @param {string} value - значение Заголовка вкладки браузера
   * @example
   * await stepGeneral.ADI_T3163('Котировка:')
   */
  async ADI_T3163(value) {
    await test.step('ADI-T3163 Переход на вкладку браузера', async () => {
      await this.page.bringToFront()
      await expect(this.page.getByTestId(generalSelectors.названиеДокумента)).toContainText(value)
    })
  }

  /**
   * **ADI-T3444 Проверка наличия вложения**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T3444 |Открыть ADI-T3444}
   * @param {string} name - значение атрибута Имя вложения
   * @param {string} type - значение атрибута Тип вложения
   * @param {string} author - значение атрибута Автор
   * @param {string} date - значение атрибута Дата вложения
   * @example
   * await stepGeneral.ADI_T3444('document.jpg', 'Действующий полис ОСАГО/ДВС', 'Молчанова Светлана Николаевна', insertDate(0, 0, 0))
   */
  async ADI_T3444(name, type, author, date) {
    await test.step('ADI-T3444 [Контрагенты] Проверка наличия вложения', async () => {
      await expect(
        this.page
          .getByTestId(generalSelectors.таблицаВложения)
          .getByRole('row')
          .filter({ hasText: name })
          .filter({ hasText: type })
          .filter({ hasText: author })
          .filter({ hasText: date })
      ).toBeVisible()
    })
  }

  /**
   * **ADI-T5234 Проверка заполнения таблицы в блоке "Связанные документы"**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T5234 |Открыть ADI-T5234}
   * @param {string} type - значение атрибута Тип документа
   * @param {string} number - значение атрибута Номер документа
   * @param {string} status - значение атрибута Создан (МСК Время)
   * @param {string} [date] - значение атрибута Статус
   * @example
   * await stepGeneral.ADI_T3628('Котировка', 'ранее сохраненный номер документа', Выпущена, insertDate(0, 0, 0))
   */
  async ADI_T5234(type, number, status, date) {
    await test.step('ADI-T5234 Проверка заполнения таблицы в блоке "Связанные документы"', async () => {
      await expect(
        this.page
          .getByTestId(generalSelectors.таблицаСвязанныеДокументы)
          .getByRole('row')
          .filter({ hasText: type })
          .filter({ hasText: number })
          .filter({ hasText: date })
          .filter({ hasText: status })
      ).toBeVisible()
    })
  }

  /**
   * **ADI-T8734 Проверка доступности кнопки для нажатия в таблице на вкладке "Вложения"**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T8734 |Открыть ADI-T8734}
   * @param {string} attachmentType - значение атрибута Тип вложения
   * @param {'Редактировать'|'Удалить'} button - значение атрибута Кнопка
   * @param {'Активна'|'Неактивна'} activity - активность кнопки
   * @param {number} [rowNumber] - порядковый номер ряда (при наличии в таблице нескольких одинаковых документов)
   * @example
   * await stepGeneral.ADI_T8734('Действующий полис ОСАГО/ДВС', 'Редактировать', 'Активна')
   */
  async ADI_T8734(attachmentType, button, activity, rowNumber) {
    await test.step('ADI-T8734 Проверка доступности кнопки для нажатия в таблице на вкладке "Вложения"', async () => {})
    switch (button) {
      case 'Редактировать':
        switch (activity) {
          case 'Активна':
            if (rowNumber) {
              await expect(
                this.page
                  .getByTestId(generalSelectors.таблицаВложения)
                  .getByRole('row')
                  .nth(rowNumber)
                  .filter({ hasText: attachmentType })
                  .locator('span')
                  .nth(6)
              ).toBeEnabled()
              break
            }
            await expect(
              this.page
                .getByTestId(generalSelectors.таблицаВложения)
                .getByRole('row')
                .filter({ hasText: attachmentType })
                .locator('span')
                .nth(6)
            ).toBeEnabled()
            break
          case 'Неактивна':
            if (rowNumber) {
              await expect(
                this.page
                  .getByTestId(generalSelectors.таблицаВложения)
                  .getByRole('row')
                  .nth(rowNumber)
                  .filter({ hasText: attachmentType })
                  .locator('span')
                  .nth(6)
              ).toHaveClass('disabled')
              break
            }
            await expect(
              this.page
                .getByTestId(generalSelectors.таблицаВложения)
                .getByRole('row')
                .filter({ hasText: attachmentType })
                .locator('span')
                .nth(6)
            ).toHaveClass('disabled')
            break
          default:
            console.log(`Failed to read value from: ${activity}`)
            break
        }
        break
      case 'Удалить':
        switch (activity) {
          case 'Активна':
            if (rowNumber) {
              await expect(
                this.page
                  .getByTestId(generalSelectors.таблицаВложения)
                  .getByRole('row')
                  .nth(rowNumber)
                  .filter({ hasText: attachmentType })
                  .locator('span')
                  .nth(7)
              ).toBeEnabled()
              break
            }
            await expect(
              this.page
                .getByTestId(generalSelectors.таблицаВложения)
                .getByRole('row')
                .filter({ hasText: attachmentType })
                .locator('span')
                .nth(7)
            ).toBeEnabled()
            break
          case 'Неактивна':
            if (rowNumber) {
              await expect(
                this.page
                  .getByTestId(generalSelectors.таблицаВложения)
                  .getByRole('row')
                  .nth(rowNumber)
                  .filter({ hasText: attachmentType })
                  .locator('span')
                  .nth(7)
              ).toHaveClass('disabled')
              break
            }
            await expect(
              this.page
                .getByTestId(generalSelectors.таблицаВложения)
                .getByRole('row')
                .filter({ hasText: attachmentType })
                .locator('span')
                .nth(7)
            ).toHaveClass('disabled')
            break
          default:
            console.log(`Failed to read value from: ${activity}`)
            break
        }
        break
      default:
        console.log(`Failed to read value from: ${button}`)
        break
    }
  }

  /**
   * **ADI-T6682 Проверка наличия или отсутствия блока (универсальный)**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T6682 |Открыть ADI-T6682}
   * @param {string} sectionName - название блока (секции)
   * @param {'присутствует'|'отсутствует'} presense - наличие или отсутствие
   * @example
   * await stepGeneral.ADI_T6682('Агенты и КВ', 'присутствует')
   */
  async ADI_T6682(sectionName, presense) {
    await test.step('ADI-T5234 Проверка наличия или отсутствия блока (универсальный)', async () => {
      switch (presense) {
        case 'присутствует':
          await expect(this.page.getByText(sectionName)).toBeVisible()
          break
        case 'отсутствует':
          await expect(this.page.getByText(sectionName)).toBeHidden()
          break
        default:
          throw new Error(`Ошибка при чтении данных из переменной presense: ${presense}`)
      }
    })
  }

  /**
   * **ADI-T6358 Проверка доступности кнопки для нажатия (универсальный)**
   * @see   {@link https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T6358 |Открыть ADI-T6358}
   * @param {object} button - опции для формирования локаторов
   * @param {'активна'|'неактивна'} button.activity - доступность для нажатия
   * @param {string} [button.id] - id кнопки
   * @param {string} [button.buttonName] - название кнопки (опционально)
   * @example
   * await stepGeneral.ADI_T6358(generalSelectors.кнопкаПечать, 'активна')
   */
  async ADI_T6358(button) {
    await test.step('ADI-T6358 Проверка доступности кнопки для нажатия (универсальный)', async () => {
      switch (button.activity) {
        case 'активна':
          if (button.buttonName) {
            await expect(this.page.getByRole('button', { name: button.buttonName })).toBeEnabled()
            break
          }
          if (button.id) {
            await expect(this.page.getByTestId(button.id).getByRole('button')).toBeEnabled()
            break
          }
        case 'неактивна':
          if (button.buttonName) {
            await expect(this.page.getByRole('button', { name: button.buttonName })).toBeDisabled()
            break
          }
          if (button.id) {
            await expect(this.page.getByTestId(button.id).getByRole('button')).toBeDisabled()
            break
          }
        default:
          throw new Error(`Ошибка при чтении данных из переменной activity: ${button.activity}`)
      }
    })
  }

  /**
   * **ADI-T5618 Проверка атрибута на редактирование (универсальный)**
   * @description
   * Универсальная функция для проверки атрибута на редактирование элемента интерфейса.
   * Поддерживает проверку доступности (enabled/disabled) для различных типов элементов (текстовое поле,чекбокс, выпадающий список).
   * @see {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T5618|Открыть ADI-T5618}
   * @param {'toBeDisabled'|'toBeEnabled'}  action - действие, которое необходимо выполнить (Обязательный параметр).
   * Поддерживаемые действия:
   *  - 'toBeDisabled': Проверяет, что элемент недоступен для редактирования (отключен).
   *  - 'toBeEnabled' : Проверяет, что элемент доступен для редактирования (включен).
   * @param {'id'|'locator'|'combobox'|'textbox'|'checkbox'}  locatorType  - тип локатора, который определяет, какой элемент на странице будет проверяться (Обязательный параметр).
   * Поддерживаемые типы:
   *  - 'id': Локатор по 'Id'.
   *  - 'locator' : Локатор по 'Id' и дополнительному локатору ('locator').
   *  - 'combobox': Локатор для элемента с 'Id' и ролью 'combobox'.
   *  - 'textbox' : Локатор для элемента с 'Id' и ролью 'textbox'.
   *  - 'checkbox': Локатор для элемента с 'Id' и ролью 'checkbox'.
   * @param {object}  stepArguments  - аргумент с тестовыми данными шага
   *  Содержит:
   *  - 'idElement': id локатора (используется для типов 'id','locator','combobox','textbox','checkbox').
   *  - 'nameLocator': дополнительный локатор (используется только для типа 'locator').
   * @param {string} [stepArguments.idElement]   - id локатора (Необязательный параметр).
   * @param {string} [stepArguments.nameLocator] - наименование локатора (Необязательный параметр).
   * @throws {Error} Если передан неизвестный тип действия ('action').
   * @example
   * // Проверка, что локатор недоступен для проверки.
   *  await stepGeneral.ADI_T5618('toBeDisabled', 'locator', { idElement: 'insurance-type',nameLocator: 'div.ng-input input'})
   * // Проверка, что текстовое поле недоступено для проверки.
   *  await stepGeneral.ADI_T5618('toBeDisabled', 'textbox', { idElement: 'insurance-type'})
   */
  async ADI_T5618(action, locatorType, stepArguments) {
    await test.step('ADI-T5618 Проверка атрибута на редактирование (универсальный)', async () => {
      const locators = {
        id: () => this.getLocator(LocatorType.byTestId, { testId: stepArguments.idElement }),
        locator: () => this.page.getByTestId(stepArguments.idElement).locator(stepArguments.nameLocator),
        combobox: () =>
          this.getLocator(LocatorType.byTestIdByRole, {
            testId: stepArguments.idElement,
            role: 'combobox',
          }),
        textbox: () =>
          this.getLocator(LocatorType.byTestIdByRole, {
            testId: stepArguments.idElement,
            role: 'textbox',
          }),
        checkbox: () =>
          this.getLocator(LocatorType.byTestIdByRole, {
            testId: stepArguments.idElement,
            role: 'checkbox',
          }),
      }

      const actions = {
        toBeDisabled: async () => {
          await expect(locators[locatorType]()).toBeDisabled()
        },
        toBeEnabled: async () => {
          await expect(locators[locatorType]()).toBeEnabled()
        },
      }

      if (actions[action]) {
        await actions[action]()
      } else {
        throw new Error(`Неизвестный тип ${action}`)
      }
    })
  }

  /**
   * **Поиск документа через рабочий стол (Статус)**
   * @param {object}  stepArguments  - аргумент с тестовыми данными шага
   * @param {string} [stepArguments.product] - продукт
   * @param {string} [stepArguments.type] - тип документа
   * @param {string} [stepArguments.status] - статус документа
   * @param {string} [stepArguments.code] - код документа
   * @example
   * await stepGeneral.ADI_T8661({ product: 'СПЕЦТЕХНИКА',type:'Договор' ,status:'Заключен',code:'SGST0000035393'})
   */
  async ADI_T8661(stepArguments) {
    await test.step('ADI-T8661 Поиск документа через рабочий стол (Статус)', async () => {
      await this.clickButton(LocatorType.byRole, { roleName: 'Поиск Поиск документов' })

      await this.fillCombobox(LocatorType.byTestIdByRole, 'Продукт', '-ng-select', stepArguments.product, true, 0)

      await this.fillCombobox(LocatorType.byTestIdByRole, 'Тип документа', '-ng-select', stepArguments.type, true, 1)
      await this.fillCombobox(LocatorType.byTestIdByRole, 'Статус', '-ng-select', stepArguments.status, true, 2)

      await this.clickButton(LocatorType.byRole, { roleName: 'Поиск' })

      await this.page.getByTestId('contract-search-table').getByRole('link', { name: stepArguments.code }).click()
    })
  }

  /**
   * **ADI-T3277 Проверка присутствия или отсутствия ПФ при нажатии на кнопку 'Печать' (универсальная)**
   * @param {string} action                    - действие
   * @param {object} stepArguments             - аргумент с тестовыми данными шага
   * @param {string} [stepArguments.idElement] - id элемента
   * @example
   * await stepGeneral.ADI_T3277('отсутствует', { idElement: 'ai-printouts-control-MotorCascoKeyInformationPaper' })
   */
  async ADI_T3277(action, stepArguments) {
    await test.step('ADI-T3277 Проверка присутствия или отсутствия ПФ при нажатии на кнопку "Печать" (универсальная)', async () => {
      switch (action) {
        case 'отсутствует':
          await this.clickButton(LocatorType.byRole, { roleName: ' ' })
          await expect(this.page.getByTestId(stepArguments.idElement)).toBeHidden()
          await this.clickButton(LocatorType.byRole, { roleName: ' ' })
          break
        case 'присутствует':
          await this.clickButton(LocatorType.byRole, { roleName: ' ' })
          await expect(this.page.getByTestId(stepArguments.idElement)).toBeVisible()
          await this.clickButton(LocatorType.byRole, { roleName: ' ' })
          break
      }
    })
  }

  /**
   * **ADI-T6540 Нажатие на кнопку в блоке (универсальное)**
   * @description
   * Функция для нажатие на элемента интерфейса.
   * Поддерживает различные типы элементов.
   * @see {@link  https://jira.sogaz.ru/secure/Tests.jspa#/testCase/ADI-T6540|Открыть ADI-T6540}
   * @param {'byRole'|'byTestIdByRole'}  action - тип локатора (Обязательный параметр)
   * Типы локаторов:
   *  - 'byRole': Локатор по роли.
   *  - 'byTestIdByRole': Локатор по роли и 'id'.
   * @param {object}  stepArguments  - аргумент с тестовыми данными шага
   *  Содержит:
   *  - 'idElement': id локатора (используется для типа 'byTestIdByRole').
   *  - 'roleName': роль локатор (используется  для типов 'locator').
   * @param {string} [stepArguments.idElement] - id локатора (Необязательный параметр).
   * @param {string} [stepArguments.roleName]  - название роли (Необязательный параметр).
   * @example
   *  await stepGeneral.ADI_T5618( action: 'byRole',{ idElement: 'insurance-type',roleName: 'Поиск'})
   */
  async ADI_T6540(action, stepArguments) {
    await test.step('ADI-T3433 Нажатие на кнопку с ОР', async () => {
      const actions = {
        byRole: async () => {
          await this.clickButton('byRole', { roleName: stepArguments.roleName })
        },
        byTestIdByRole: async () => {
          await this.clickButton('byTestIdByRole', {
            idElement: stepArguments.idElement,
            roleName: stepArguments.roleName,
          })
        },
      }

      if (actions[action]) {
        await actions[action]()
      } else {
        throw new Error(`Неизвестный тип ${action}`)
      }
    })
  }

  /**
   * **ADI-T3614 Поиск и выбор в форме "Поиск контрагентов - по параметрам" по ФИО и коду в системе Адакта (по кнопке "Поиск стархователя")**
   *
   * В методе используется необязательные и обязательные параметры. Сначала вызывается необязательные параметр в { }, после один обязательный.
   * Для необязательных параметров можно не указывать аргументы, и тогда функция будет использовать значения по умолчанию.
   * Список необязательных параментров можно посмотреть и выбрать при помощи сочитания CTRL + Space.
   * @see {@link https://jira.sogaz.ru|Jira}
   * @param {object}  stepArguments                 -  опции для формирования локаторов
   * @param {string} [stepArguments.randomSearch]   -  произвольный поиск (ФИО, номер документа, ИНН)
   * @param {string} [stepArguments.surname]        -  фамилия
   * @param {string} [stepArguments.name]           -  имя
   * @param {string} [stepArguments.middleName]     -  отчество
   * @param {string} [stepArguments.dateOfBirth]    -  дата рождения
   * @param {string} [stepArguments.gender]         -  пол
   * @param {string} [stepArguments.typeOfDocument] -  вид документа
   * @param {string} [stepArguments.series]         -  серия
   * @param {string} [stepArguments.number]         -  номер
   * @param {string} [stepArguments.designation]    -  наименование
   * @param {string} [stepArguments.inn]            -  ИНН
   * @param {string} [stepArguments.kpp]            -  КПП
   * @param {string} [stepArguments.code]           -  код
   * @param {string} [stepArguments.id]             - id значка 'Лупа'
   * @param {string} [stepArguments.nameButtonSearch] - Название кнопки поиска
   * @example
   * await stepGeneral.ADI_T3614( {  surname: 'Федоров',name: 'Ярослав', middleName: 'Юрьевич', code: '1687564'})
   */
  async ADI_T3614(stepArguments) {
    await test.step('ADI-T3614 Поиск и выбор в форме "Поиск контрагентов - по параметрам" по ФИО и коду в системе Адакта (по кнопке "Поиск стархователя")', async () => {
      if (stepArguments.id) {
        await this.clickButton(LocatorType.byTestIdByRole, {
          idElement: stepArguments.id,
          roleName: '',
        })
      } else {
        await this.clickButton(LocatorType.byRole, { roleName: stepArguments.nameButtonSearch })
      }

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Произвольный поиск (ФИО, номер документа, ИНН)',
        'party-freeText',
        stepArguments.randomSearch
      )

      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Поиск контрагента в системах',
        generalSelectors.поискКонтрагентаВСистеме,
        'Поиск в системе Адакта'
      )
      await this.fillTextbox(LocatorType.byTestIdByRole, 'Фамилия', generalSelectors.фамилия, stepArguments.surname)

      await this.fillTextbox(LocatorType.byTestIdByRole, 'Имя', generalSelectors.имя, stepArguments.name)

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Отчество',
        generalSelectors.отчество,
        stepArguments.middleName
      )

      await this.fillTextbox(
        LocatorType.byTestIdByRole,
        'Дата рождения',
        generalSelectors.датаРождения,
        stepArguments.dateOfBirth
      )

      await this.fillCombobox(LocatorType.byTestIdByRole, 'Пол', generalSelectors.пол, stepArguments.gender)

      await this.fillCombobox(
        LocatorType.byTestIdByRole,
        'Вид документа',
        generalSelectors.видДокумента,
        stepArguments.typeOfDocument
      )

      await this.fillTextbox(LocatorType.byTestIdByRole, 'Серия', generalSelectors.серия, stepArguments.series)

      await this.fillTextbox(LocatorType.byTestIdByRole, 'Номер', generalSelectors.номер, stepArguments.number)

      await this.clickButton(LocatorType.byTestIdByRole, {
        idElement: generalSelectors.кнопкаПоиск,
        roleName: 'Поиск',
      })

      await this.checkCheckboxInTable(LocatorType.byRole, stepArguments.code)

      await this.clickButton(LocatorType.byRole, { roleName: 'Выбрать' })
    })
  }
}
