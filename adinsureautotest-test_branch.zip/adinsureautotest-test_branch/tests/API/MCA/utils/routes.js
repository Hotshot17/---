export const baseUrl = 'https://stage.adinsure.sogaz.ru/server/api/core/shared/integration-services/'
export const Auth = 'https://stage.adinsure.sogaz.ru/auth/connect/token'

export const MCAurl = baseUrl + 'CreateMotorCascoApplication/1'
export const MCQurl = baseUrl + 'MotorCascoApplicationToQuote/1'
export const AttachmentMCQurl = baseUrl + 'UploadAttachmentsByDocumentumId/1'
export const updMCQurl = baseUrl + 'UpdateMotorCascoQuote/1'
export const toConfirmMCQurl = baseUrl + 'MotorCascoQuoteDraftToOnConfirmation/1'
export const toPolurl = baseUrl + 'MotorCascoQuoteToPolicy/1'
export const updPolurl = baseUrl + 'UpdateMotorCascoPolicy/1'
export const GetPFurl = baseUrl + 'GetMotorCascoPrintoutId/1'
export const GetPLurl = baseUrl + 'GetPaymentLink/1'
export const ActPolurl = baseUrl + 'MotorCascoPolicyDraftToActivated/1'

// роуты до файлов
export const user = '../MCA/json_folder/user.js'
export const MCA = '../MCA/json_folder/MCA.js'
// export const updMCQ = '../MCA/json_folder/upd_MCQ.js'
