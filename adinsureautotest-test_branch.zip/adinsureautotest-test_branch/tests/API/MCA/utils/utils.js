import JSONdb from 'simple-json-db'
import path from 'path'
const __dirname = path.resolve()
const dbDir = __dirname + '/tests/API/MCA/db.json'

const db = new JSONdb(dbDir, { asyncWrite: true })

async function dbSetter(key, value) {
  db.set(key, value)
  return 'set ok'
}

function dbGetter(key) {
  try {
    return db.get(key)
  } catch (error) {
    return error
  }
}

function dbCleaner() {
  try {
    db.JSON({})
    return 'dbclean OK'
  } catch (error) {
    return error
  }
}

function dbAll() {
  return db.JSON()
}

export { dbSetter, dbGetter, dbCleaner, dbAll }
