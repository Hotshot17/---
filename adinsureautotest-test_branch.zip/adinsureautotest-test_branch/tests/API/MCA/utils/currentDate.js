import moment from 'moment'
function getToday() {
  let today = moment(new Date()).format('YYYY-MM-DD')
  return today
}

export { getToday }
