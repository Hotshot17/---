function generateVin() {
  // Строка с разрешёнными символами для VIN-кода
  const allowedCharacters = '0123456789ABCDEFGHJKLMNPRSTUVWXYZ'

  // Генерация VIN-кода из 17 символов
  let vin = ''
  for (let i = 0; i < 13; i++) {
    // Добавление случайного символа из разрешённых
    vin += allowedCharacters[Math.floor(Math.random() * allowedCharacters.length)]
  }
  // Генерация последних 4 символов VIN в виде строки, содержащей только цифры
  const lastPart = Math.floor(Math.random() * 10000).toString()
  return vin + lastPart
}
export { generateVin }
