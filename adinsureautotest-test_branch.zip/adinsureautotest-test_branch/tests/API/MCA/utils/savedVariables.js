export const savedVariables = {}
