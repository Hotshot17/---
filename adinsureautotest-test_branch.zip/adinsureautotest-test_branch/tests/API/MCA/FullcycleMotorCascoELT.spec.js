import { test, expect } from '@playwright/test'
import {
  Auth,
  MCAurl,
  MCQurl,
  AttachmentMCQurl,
  updMCQurl,
  toConfirmMCQurl,
  toPolurl,
  updPolurl,
  GetPFurl,
  GetPLurl,
  ActPolurl,
} from './utils/routes.js'
import { user } from './json_folder/user.js'
import { MCA } from './json_folder/MCA.js'
import { generateVin } from './utils/vinGen.js'
import { savedVariables } from './utils/savedVariables.js'

let token
test.use({
  ignoreHTTPSErrors: true,
})

test.describe('Полный цикл ELT', () => {
  test.describe.configure({ mode: 'serial', timeout: 90000 })
  test('Авторизация @smoke', async ({ request }) => {
    savedVariables.vin = generateVin()
    const response = await request.post(Auth, {
      form: user,
    })

    const responseBody = await response.json()
    token = responseBody.access_token
    expect(response.status()).toBe(200)
  })

  test('Создание предрасчета', async ({ request }) => {
    const response = await request.post(MCAurl, {
      data: MCA,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
    const responseBody = await response.json()
    savedVariables.contractNumber = responseBody.data.application.contractNumber
    expect(response.status()).toBe(200)
    //expect(responseBody.data.application.calculatedPremium).to.be.above(0)
    expect(responseBody.data.application.calculatedPremium).toBeGreaterThan(0)
    ///expect(responseBody).stringContaining('periodsList')
    //var json1 = JSON.parse(responseBody)
    //expect(responseBody).toHaveAttribute('{periodsList:}')
    //expect(responseBody).toHaveLength('periodsList')
    // expect(responseBody).objectContaining('periodsList')
    // tests["Наличие массива periodsList"] = responseBody.has('periodsList')
    // tests["Массив periodsList содержит periodStartDate"] = responseBody.has('periodStartDate')
    // tests["Массив periodsList содержит periodEndDate"] = responseBody.has('periodEndDate')
    // tests["Массив periodsList содержит periodPremium"] = responseBody.has('periodPremium');
    //expect(responseBody.data.application).stringContaining('{periodsList}')
  })

  test('Создание котировки', async ({ request }) => {
    let { toMCQ } = await import('./json_folder/to_MCQ.js')
    const response = await request.post(MCQurl, {
      data: JSON.stringify(toMCQ),
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })

    const responseBody = await response.json()
    savedVariables.quoteNumber = responseBody.data.quoteData.contractData.contractNumber
    expect(response.status()).toBe(200)
  })

  test('Вложения для котировки', async ({ request }) => {
    let { attachment } = await import('./json_folder/attachment.js')
    const response = await request.post(AttachmentMCQurl, {
      data: JSON.stringify(attachment),
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })
    expect(response.status()).toBe(200)
  })

  test('Обновление котировки', async ({ request }) => {
    let { updMCQ } = await import('./json_folder/upd_MCQ.js')
    const response = await request.post(updMCQurl, {
      data: JSON.stringify(updMCQ),
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })
    expect(response.status()).toBe(200)
  })

  test('Смена статуса котировки', async ({ request }) => {
    let { toConfirmMCQ } = await import('./json_folder/change_mcq_status.js')
    const response = await request.post(toConfirmMCQurl, {
      data: JSON.stringify(toConfirmMCQ),
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })
    expect(response.status()).toBe(200)
  })

  test('Создание договора', async ({ request }) => {
    let { toPolicy } = await import('./json_folder/to_policy.js')
    const response = await request.post(toPolurl, {
      data: JSON.stringify(toPolicy),
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })

    const responseBody = await response.json()
    savedVariables.PolNumber = responseBody.data.documentData.documentNumber
    expect(response.status()).toBe(200)
  })

  test('Обновление договора', async ({ request }) => {
    let { updPolicy } = await import('./json_folder/upd_policy.js')
    const response = await request.post(updPolurl, {
      data: JSON.stringify(updPolicy),
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })
    expect(response.status()).toBe(200)
  })
  test('Получение печатных форм', async ({ request }) => {
    let { getPF } = await import('./json_folder/getPF.js')
    const response = await request.post(GetPFurl, {
      data: JSON.stringify(getPF),
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })
    expect(response.status()).toBe(200)
  })

  test('Активация договора', async ({ request }) => {
    let { actPol } = await import('./json_folder/activationPol.js')
    const response = await request.post(ActPolurl, {
      data: actPol,
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
    })
    expect(response.status()).toBe(200)
  })
})
