import { test, expect } from '@playwright/test'
import { ZNPolicyPage } from '../../pages/bank_products/RealEstateProtection/ZNPolicy.page'
export class REProtection {
  constructor(page) {
    this.page = page
  }

  async ADI_7690(nameProgramm, packageVariant) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T7690 (1.0) [ЗН]Выбор варианта коробки в блоке ВАРИАНТЫ КОРОБКИ ', async () => {
      switch (nameProgramm) {
        case 'Мой дом':
          await this.page.getByTestId('select-with-details-my-house').getByText(packageVariant, { exact: true }).click()
          await expect(
            this.page
              .getByTestId('select-with-details-my-house')
              .locator('th')
              .filter({ hasText: packageVariant })
              .first()
          ).toHaveClass(/ai-selected-column/)
          // await this.page.getByTestId('rep-select-width-detail').getByText(packageVariant, { exact: true }).click()
          // const RegBoxVariant = new RegExp(`${packageVariant}$`) // регулярное выражение для точного определения имени варианта коробки
          // await expect(
          //   this.page.locator('#rep-select-width-detail').locator('th').filter({ hasText: RegBoxVariant })
          // ).toHaveClass(/ai-selected-column/)
          break

        case 'ОСО':
          await this.page.getByRole('cell', { name: packageVariant }).click()
          await expect(this.page.locator('th').filter({ hasText: packageVariant })).toHaveClass(/ai-selected-column/)
          break
      }
    })
  }

  async ADI_6852(lastName, firstName, middleName, fullName, partyCode) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T6852 (1.0) [ЗН]Заполнение блока СТРАХОВАТЕЛЬ через ПОИСК КОНТРАГЕНТОВ-ПО ПАРАМЕТРАМ ', async () => {
      // await this.page.getByTestId('REPPolicyHolder-#').getByTestId('search-policyholder-button').click()
      await znPolicyCore.searchPolicyHolderButton.click()
      await znPolicyCore.partySearch.click()
      await znPolicyCore.selectCombobox('Поиск в системе Адакта')
      await znPolicyCore.lastName.fill(lastName)
      await znPolicyCore.firstName.fill(firstName)
      await znPolicyCore.middleName.fill(middleName)
      await znPolicyCore.searchButtonPolicy.click()
      await znPolicyCore.selectCheckboxTable(partyCode)
      await znPolicyCore.selectButtonPolicy.click()
      await expect(this.page.getByRole('link', { name: fullName })).toBeVisible()
    })
  }

  async ADI_6853(adress, objectType) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T6853 (1.0) [ЗН]Заполнение блока ОБЪЕКТ ', async () => {
      await znPolicyCore.policyHolderAddressButton.click()
      await expect(znPolicyCore.fullAdress).toContainText(adress)
      await znPolicyCore.objectType.click()
      await znPolicyCore.selectCombobox(objectType)
      await znPolicyCore.checkComboboxValue(znPolicyCore.objectType, 0, objectType)
    })
  }

  async ADI_8567(actionRealestate) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T8567 (1.0) [ЗН] Выполнение действия и проверка текста во всплывающем окне ', async () => {
      await znPolicyCore.actionsButton.click() // кнопка действия
      await actionRealestate.click()
      // await znPolicyCore.draftToPaymentWaiting.click()
      await this.page.getByRole('button', { name: 'Дa' }).click()
      await expect(znPolicyCore.generalTextModalWindow).toContainText(
        'Необходимо распечатать страховую документацию: Полис-оферта, Памятка, Условия страхования.'
      )
      await this.page.getByRole('button', { name: 'OK' }).click()
      await expect(znPolicyCore.documentState).toContainText('(Ожидает оплаты)')
    })
  }

  async ADI_7879(BoxOption) {
    await test.step('ADI-T7879 (1.0) [ЗН]Проверка заполнения чекбокса в варианте коробки ', async () => {
      const RegBoxBoxOption = new RegExp(`${BoxOption}$`)
      await expect(
        this.page.locator('#rep-select-width-detail').getByRole('cell', { name: RegBoxBoxOption }).getByRole('checkbox')
      ).toBeChecked()
    })
  }

  async ADI_13703() {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T13703 (1.0) [ЗН] Проверка доступности нескольких ПФ в списке Печать ', async () => {
      await this.page.getByRole('button', { name: ' ' }).click()
      await expect(znPolicyCore.policyOferta).toBeVisible()
      await expect(znPolicyCore.conditionsPrintout).toBeVisible()
      await expect(znPolicyCore.memoPrintout).toBeVisible()
      await expect(znPolicyCore.kidPrintout).toBeVisible()
    })
  }

  async ADI_9152() {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T9152 (1.0) [ЗН] Проверка блока Подписание', async () => {
      await expect(znPolicyCore.conclusionType).toContainText('Оферта')
      await expect(znPolicyCore.signingType).toContainText('Факсимиле')
      await expect(znPolicyCore.signerName).toContainText('Епишина Елена Валерьевна')
      await expect(znPolicyCore.proxyNumber).toHaveValue('590/24')
      await expect(znPolicyCore.proxyDate).toHaveValue('13.05.2024')
    })
  }

  async ADI_12140() {
    await test.step('ADI-T12140 (1.0) [ЗН]Проверка текста под полем', async () => {
      await expect(this.page.getByTestId('object-section')).toContainText(
        'Необходимо уточнить у клиента.Внимание! Таунхаусы и строения (дом) на страхование не принимаются'
      )
    })
  }

  async ADI_6867(paymentMethod) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T6867 (1.0) [ЗН]Выбор способа оплаты ', async () => {
      await znPolicyCore.paymentMethod.click()
      // await this.page.getByTestId('REPPaymentData-#').locator('ng-select').nth(2).getByRole('combobox').click() // локатор для выбора способа уведомления
      await znPolicyCore.selectCombobox(paymentMethod)
    })
  }

  async ADI_6873(paymentNotificationMethod) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T6873 (1.0) [ЗН]Выбор способа уведомления ', async () => {
      await znPolicyCore.paymentNotificationMethod.click()
      await znPolicyCore.selectCombobox(paymentNotificationMethod)
    })
  }

  async ADI_6869(actionRealestate, TextNotific, Header, Status) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T6869 (1.0) [ЗН]Выполнение действия', async () => {
      await znPolicyCore.actionsButton.click() // кнопка действия
      await actionRealestate.click()
      await expect(this.page.getByText(`Вы уверены, что хотите выполнить действие "${TextNotific}"?`)).toBeVisible()
      await this.page.getByRole('button', { name: 'Дa' }).click()
      await expect(znPolicyCore.generalTextModalWindow).toContainText('Сообщение успешно отправлено!')
      await this.page.getByRole('button', { name: 'OK' }).click()
      await expect(znPolicyCore.documentName).toContainText(Header)
      await expect(znPolicyCore.documentState).toContainText(Status)
    })
  }

  async ADI_7256(fulladress) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T7256 (1.0) [ЗН] Заполнение блока Объект поля Адрес объекта вручную', async () => {
      await znPolicyCore.fullAdress.getByRole('textbox').fill(fulladress)
      await this.page.waitForTimeout(1500)
      await znPolicyCore.fullAdress.getByRole('textbox').press('Enter')
      await znPolicyCore.checkComboboxValue(znPolicyCore.fullAdress, 0, fulladress)
      // await expect(znPolicyCore.fullAdress).toContainText(fulladress)
    })
  }
}

export class MyHouse {
  constructor(page, context) {
    this.page = page
    this.context = context
  }

  async ADI_12139() {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T12139 (1.0) [ЗН]Переход на вкладку документа с отображением уведомления ', async () => {
      await this.page.getByTestId(znPolicyCore.tabObject).click()
      await expect(znPolicyCore.generalTextModalWindow).toContainText(
        'Необходимо уточнить у клиента "Тип объекта".Внимание! Таунхаусы и строения (дом) на страхование не принимаются'
      )
      await this.page.getByRole('button', { name: 'OK' }).click()
    })
  }

  async ADI_10735_save(status) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T10735 (1.0) [ЗН] Сохранение с проверка уведомления по распечатке КИД', async () => {
      await this.page.getByRole('button', { name: ' Сохранить' }).click()
      await expect(znPolicyCore.generalTextModalWindow).toContainText(
        'Перед оплатой договора необходимо ознакомить Страхователя с Ключевым информационным документом'
      )
      await this.page.getByRole('button', { name: ' OK' }).click()
      await expect(znPolicyCore.documentName).toContainText('Договор:')
      await expect(znPolicyCore.documentState).toContainText(status)
    })
  }

  async ADI_8402(
    servis,
    ssNedvi,
    ssDvi,
    ssGo,
    spNedvi,
    spDvi,
    spGo,
    baseTarifNedvi,
    baseTarifDvi,
    baseTarifGo,
    spElriskNedvi,
    spElriskDvi,
    varLimitNedvi,
    ArrayNameRisk
  ) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    // Проверка объема услуг
    await expect(znPolicyCore.service).toContainText(`Объём услуг ${servis}`)
    await test.step('ADI-T8402 (1.0) [ЗН] Проверка расчета СС и СП по рискам Имущества и ГО', async () => {
      /* Блок Недвижимое имущество */
      // --- СС и СП:
      await expect(znPolicyCore.sumInsuredRealsestate).toHaveValue(ssNedvi)
      await expect(znPolicyCore.premiumRealsestate).toHaveValue(spNedvi)

      // ---таблица "застрахованные риски":
      await znPolicyCore.checkTableProperty(
        znPolicyCore.tableRiskRealsestate,
        5,
        1,
        ArrayNameRisk,
        baseTarifNedvi,
        spElriskNedvi
      )

      // ---таблица "лимиты"
      await znPolicyCore.checkTableProperty(
        znPolicyCore.tableRiskLimitRealsestate,
        5,
        1,
        ArrayNameRisk,
        'В рублях на 1 кв. м.',
        varLimitNedvi
      )

      /* Блок Движимое имущество */
      // --- СС и СП:

      await expect(znPolicyCore.sumInsuredMova).toHaveValue(ssDvi)
      await expect(znPolicyCore.premiumMova).toHaveValue(spDvi)

      // ---таблица "застрахованные риски":
      await znPolicyCore.checkTableProperty(znPolicyCore.tableRiskMova, 5, 1, ArrayNameRisk, baseTarifDvi, spElriskDvi)

      // ---таблица "лимиты"
      await znPolicyCore.checkTableProperty(
        znPolicyCore.tableRiskLimitMova,
        5,
        1,
        ArrayNameRisk,
        'В % от страховой суммы',
        '5%'
      )

      /* Блок Гражданская ответственность */
      // --- СС и СП:
      await expect(znPolicyCore.sumInsuredCivil).toHaveValue(ssGo)
      await expect(znPolicyCore.premiumCivil).toHaveValue(spGo)

      // ---таблица "застрахованные риски":
      // столбец "риск"

      await expect(this.page.getByText('С ответственностью за все риски')).toBeVisible()

      // столбец "базовый тариф"

      await expect(this.page.getByTestId('PPSummaryObjects-civilResponsibility').getByText(baseTarifGo)).toBeVisible()
      // столбец "премия"

      await expect(this.page.getByTestId('PPSummaryObjects-civilResponsibility').getByText(spGo)).toBeVisible()
    })
  }

  async ADI_11572(packageVariant, inStartDate, endDate, objectType, startDate, premium) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T11572 (1.0) [ЗН] Проверка атрибутов правой панели, вкладка Общая информация , программа Мой дом', async () => {
      await expect(znPolicyCore.summaryInsuranceType).toContainText('Мой дом')
      await expect(znPolicyCore.summaryPackageVariant).toContainText(packageVariant)
      await expect(znPolicyCore.summaryPaymentFrequency).toContainText('Единовременно')
      await expect(znPolicyCore.summaryValidFrom).toContainText(inStartDate)
      await expect(znPolicyCore.summaryValidUntil).toContainText(endDate)
      await expect(znPolicyCore.summaryObjectType).toContainText(objectType)
      await expect(znPolicyCore.summaryInsuranceDuration).toContainText('365')
      await expect(znPolicyCore.summaryIssueDate).toContainText(startDate)
      await expect(znPolicyCore.summaryPremium).toContainText(premium)
    })
  }

  async ADI_13236(
    ssKlining,
    spKlining,
    baseTarifKlining,
    arrayNameRiskMaster,
    arrayNameRiskKlining,
    baseTarifMaster,
    typeLimitMaster,
    varLimitMaster,
    typeLimitKlining,
    varLimitKlining,
    premiumElRiskMaster,
    premiumElRiskKlining
  ) {
    const znPolicyPage = new ZNPolicyPage(this.page)

    await test.step('ADI-T13236 (1.0) [ЗН] Проверка расчета СС и СП по непредвиденным расходам (Мастер на час и Клининг) вариантов коробки (Премиум, Вип)', async () => {
      /* непредвиденные расходы */
      // -----------------------------------------------------------Мастер на час
      // ---СС и СП
      await expect(znPolicyPage.sumInsuredUnexpectedMaster).toHaveValue('15 000,00')
      await this.page.pause()

      await expect(znPolicyPage.premiumUnexpectedMaster).toHaveValue('390,00')
      // ----таблица Застрахованные риски
      await znPolicyPage.checkTableProperty(
        znPolicyPage.tableRiskUnexpectedMaster,
        3,
        1,
        arrayNameRiskMaster,
        baseTarifMaster,
        premiumElRiskMaster
      )
      // столбец "риск"
      // await expect(this.page.getByTestId('unexpected-expenses-section').getByTestId('insured-risks-table-row-0').getByText('Поломка замков')).toBeVisible()

      // ----таблица "лимиты"
      await znPolicyPage.checkTablelimitUnexpected(
        znPolicyPage.tableLimitUnexpectedMaster,
        6,
        arrayNameRiskMaster,
        typeLimitMaster,
        varLimitMaster
      )

      // столбец "риск"

      // await expect(this.page.getByTestId('unexpected-expenses-section').getByTestId('limits-table-row-0').getByText('Поломка замков')).toBeVisible()

      // -------------------------------------------------------------------- Клининг
      // ------------СС и СП
      await expect(znPolicyPage.sumInsuredUnexpectedKlining).toHaveValue(ssKlining)
      await expect(znPolicyPage.premiumUnexpectedKlining).toHaveValue(spKlining)

      // -----------таблица Застрахованные риски
      await znPolicyPage.checkTableProperty(
        znPolicyPage.tableRiskUnexpectedKlining,
        1,
        1,
        arrayNameRiskKlining,
        baseTarifKlining,
        premiumElRiskKlining
      )

      // // столбец "риск"
      // await expect(this.page.getByTestId('unexpected-expenses-section').getByTestId('insured-risks-table-row-0').getByText('Уборка загрязнений')).toBeVisible()

      // -------------таблица "лимиты"
      await znPolicyPage.checkTablelimitUnexpected(
        znPolicyPage.tableLimitUnexpectedKlining,
        2,
        arrayNameRiskKlining,
        typeLimitKlining,
        varLimitKlining
      )

      // // столбец "риск"
      // await expect(this.page.getByTestId('unexpected-expenses-section').getByTestId('limits-table-row-0').getByText('Уборка загрязнений')).toBeVisible()
    })
  }

  async ADI_9151() {
    await test.step('ADI-T9151 (1.0) [ЗН] Проверка блока Организационная структура в роли Андеррайтер', async () => {
      await expect(this.page.getByTestId('initiator-link').getByRole('link')).toContainText('Костюкова Татьяна Юрьевна')
      await expect(this.page.getByTestId('manager-link').locator('ng-component')).toContainText(
        'Костюкова Татьяна Юрьевна'
      )
      await expect(this.page.getByTestId('branch-name').getByRole('textbox')).toHaveValue('Головной офис')
      await expect(this.page.getByTestId('department-name').getByRole('textbox')).toHaveValue(
        'Дирекция по розничному банкострахованию'
      )
      await expect(this.page.getByTestId('profile-program-ng-select')).toContainText('Коробки ДРБС×')
      await expect(
        this.page.locator('app-text-input').filter({ hasText: 'Точка продаж партнёра --' }).getByRole('textbox')
      ).toHaveValue('Ф-л Банка ГПБ (АО) "Южный" ОО № 007/2010 Ф-л Банка ГПБ (АО) "Южный"')
    })
  }

  async ADI_7695(kv, kvRub) {
    const znPolicyCore = new ZNPolicyPage(this.page)

    await test.step('ADI-T7965 (1.0) [ЗН] Проверка автозаполнения полей в блоке Агенты и КВ', async () => {
      await expect(znPolicyCore.agent).toContainText('АКЦИОНЕРНОЕ ОБЩЕСТВО "ГАЗПРОМБАНК"')
      await expect(znPolicyCore.agentAgreement).toContainText('СГ/01 ДАА-528')
      await expect(znPolicyCore.conclusionDateAgent).toBeVisible()
      await expect(znPolicyCore.endDateAgent).toBeVisible()
      await expect(znPolicyCore.commissionRate).toBeVisible(kv)
      await expect(znPolicyCore.commissionAmount).toBeVisible(kvRub)
    })
  }
}

export class OSO {
  constructor(page) {
    this.page = page
  }

  async ADI_11565() {
    await test.step('ADI-T9151 (1.0) [ЗН] Проверка блока Организационная структура в роли Андеррайтер', async () => {
      await expect(this.page.getByTestId('initiator-link').getByRole('link')).toContainText('Тихомирова Юлия Андреевна')
      await expect(this.page.getByTestId('manager-link').locator('ng-component')).toContainText(
        'Тихомирова Юлия Андреевна'
      )
      await expect(this.page.getByTestId('branch-name').getByRole('textbox')).toHaveValue('Головной офис')
      await expect(this.page.getByTestId('department-name').getByRole('textbox')).toHaveValue(
        'Дирекция по розничному банкострахованию'
      )
      await expect(this.page.getByTestId('profile-program-ng-select')).toContainText('Коробки ДРБС')
    })
  }

  async ADI_11166(
    ssNedvi,
    ssDvi,
    ssGo,
    spNedvi,
    spDvi,
    spGo,
    baseTarifNedvi,
    baseTarifDvi,
    baseTarifGo,
    spElriskNedvi,
    spElriskDvi,
    spElriskGo
  ) {
    await test.step('ADI-T11166 (1.0) [ЗН] Проверка расчета СС и СП объектов и рисков в роли Андеррайтер, программа ОСО вариантов коробки (Вариант 1,2,3,4,5)', async () => {
      /* -------------------------------------------Блок Недвижимое имущество */
      // СС и СП
      await expect(this.page.getByTestId('PPSummaryObjects-#').getByTestId('sum-insured-input')).toHaveValue(ssNedvi)
      await expect(this.page.getByTestId('PPSummaryObjects-#').getByTestId('premium-input')).toHaveValue(spNedvi)

      //  -----------таблица "застрахованные риски"
      // столбец "Риски"

      await expect(
        this.page.getByTestId('PPSummaryObjects-#').getByTestId('insured-risks-table-row-0').getByText('Огонь')
      ).toBeVisible()
      await expect(
        this.page.getByTestId('PPSummaryObjects-#').getByTestId('insured-risks-table-row-1').getByText('Вода')
      ).toBeVisible()
      await expect(
        this.page
          .getByTestId('PPSummaryObjects-#')
          .getByTestId('insured-risks-table-row-2')
          .getByText('Противоправные действия третьих лиц')
      ).toBeVisible()

      // столбец "Базовый тариф"
      await expect(
        this.page.getByTestId('PPSummaryObjects-#').getByTestId('insured-risks-table-row-0').getByText(baseTarifNedvi)
      ).toBeVisible()
      // столбец "Премия"
      await expect(
        this.page.getByTestId('PPSummaryObjects-#').getByTestId('insured-risks-table-row-0').getByText(spElriskNedvi)
      ).toBeVisible()

      /* -------------------------------------------Блок Движимое имущество */
      // СС и СП
      await expect(this.page.getByTestId('PPSummaryObjects-#-2').getByTestId('sum-insured-input')).toHaveValue(ssDvi)
      await expect(this.page.getByTestId('PPSummaryObjects-#-2').getByTestId('premium-input')).toHaveValue(spDvi)

      //  -----------таблица "застрахованные риски"
      // столбец "Риски"
      await expect(
        this.page.getByTestId('PPSummaryObjects-#-2').getByTestId('insured-risks-table-row-0').getByText('Огонь')
      ).toBeVisible()
      await expect(
        this.page.getByTestId('PPSummaryObjects-#-2').getByTestId('insured-risks-table-row-1').getByText('Вода')
      ).toBeVisible()
      await expect(
        this.page
          .getByTestId('PPSummaryObjects-#-2')
          .getByTestId('insured-risks-table-row-2')
          .getByText('Противоправные действия третьих лиц')
      ).toBeVisible()

      // столбец "Базовый тариф"
      await expect(
        this.page.getByTestId('PPSummaryObjects-#-2').getByTestId('insured-risks-table-row-0').getByText(baseTarifDvi)
      ).toBeVisible()

      // столбец "Премия"
      await expect(
        this.page.getByTestId('PPSummaryObjects-#-2').getByTestId('insured-risks-table-row-0').getByText(spElriskDvi)
      ).toBeVisible()

      /* -------------------------------------------Блок Гражданская ответственность */
      // СС и СП
      await expect(
        this.page.getByTestId('PPSummaryObjects-civilResponsibility').getByTestId('sum-insured-input')
      ).toHaveValue(ssGo)
      await expect(
        this.page.getByTestId('PPSummaryObjects-civilResponsibility').getByTestId('premium-input')
      ).toHaveValue(spGo)

      //  -----------таблица "застрахованные риски"
      // столбец "Риски"
      await expect(
        this.page
          .getByTestId('PPSummaryObjects-civilResponsibility')
          .getByTestId('insured-risks-table-row-0')
          .getByText('Пожар, взрыв')
      ).toBeVisible()
      await expect(
        this.page
          .getByTestId('PPSummaryObjects-civilResponsibility')
          .getByTestId('insured-risks-table-row-1')
          .getByText('Залив')
      ).toBeVisible()

      // столбец "Базовый тариф"
      await expect(
        this.page
          .getByTestId('PPSummaryObjects-civilResponsibility')
          .getByTestId('insured-risks-table-row-0')
          .getByText(baseTarifGo)
      ).toBeVisible()
      await expect(
        this.page
          .getByTestId('PPSummaryObjects-civilResponsibility')
          .getByTestId('insured-risks-table-row-1')
          .getByText(baseTarifGo)
      ).toBeVisible()

      // столбец "Премия"
      await expect(
        this.page
          .getByTestId('PPSummaryObjects-civilResponsibility')
          .getByTestId('insured-risks-table-row-0')
          .getByText(spElriskGo)
      ).toBeVisible()
      await expect(
        this.page
          .getByTestId('PPSummaryObjects-civilResponsibility')
          .getByTestId('insured-risks-table-row-0')
          .getByText(spElriskGo)
      ).toBeVisible()
    })
  }

  async ADI_11172(policyholder, packageVariant, inStartDate, endDate, objectType, startDate, premium) {
    await test.step('ADI-T11572 (1.0) [ЗН] Проверка атрибутов правой панели, вкладка Общая информация , программа Мой дом', async () => {
      await expect(this.page.getByTestId('REPSummary-#')).toContainText(policyholder)
      await expect(this.page.getByTestId('REPSummary-#').getByText('От стечения обстоятельств 1.0.')).toBeVisible()
      await expect(this.page.getByTestId('REPSummary-#').getByText(packageVariant)).toBeVisible()
      await expect(this.page.getByTestId('REPSummary-#').getByText('Единовременно')).toBeVisible()
      await expect(this.page.getByTestId('REPSummary-#').getByText(inStartDate)).toBeVisible()
      await expect(this.page.getByTestId('REPSummary-#').getByText(endDate)).toBeVisible()
      await expect(this.page.getByTestId('REPSummary-#').getByText(objectType)).toBeVisible()
      await expect(
        this.page.getByTestId('REPSummary-#').getByText('Новый бизнес Не переход из другой СК')
      ).toBeVisible()
      await expect(this.page.getByTestId('REPSummary-#').getByText('365')).toBeVisible()
      await expect(this.page.getByTestId('REPSummary-#').getByText(startDate)).toBeVisible()
      await expect(this.page.getByTestId('REPSummary-#').getByText(premium)).toBeVisible()
    })
  }
}
