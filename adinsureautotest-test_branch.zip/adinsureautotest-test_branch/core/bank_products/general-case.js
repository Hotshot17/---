import { test, expect } from '@playwright/test'
import { LoginPage } from '../../pages/general/login-page'
import { GeneralPageBankProducts } from '../../pages/bank_products/generalPageBankProducts.page'
export class GeneralCase {
  constructor(page) {
    this.page = page
    // this.loginPage = new LoginPage(page)
  }

  async ADI_2607(username, password) {
    await test.step('Логинизация', async () => {
      const loginPage = new LoginPage(this.page)
      await this.page.goto('https://stage.adinsure.sogaz.ru/entry')
      await loginPage.enterButton.click()
      await this.page.waitForTimeout(1500)
      // await this.page.waitForLoadState('networkidle')
      await loginPage.userName.fill(username)
      await loginPage.password.fill(password)
      await loginPage.loginType.click()
      await loginPage.loginButton.click()
    })
  }

  async ADI_1990(product, document) {
    await test.step('Переход по меню', async () => {
      const generalPage = new GeneralPageBankProducts(this.page)
      if (await this.page.locator('.ai-item-level-1.ai-opened-link').isVisible()) {
        await document.click()
      } else {
        await generalPage.contractsMenu.click()
        await product.click()
        await document.click()
      }
      // await generalPage.contractsMenu.click()
      // await product.click()
      // await document.click()
    })
  }

  async ADI_2399(Action, TextNotific, Header, Status) {
    const generalPage = new GeneralPageBankProducts(this.page)

    await test.step('ADI-T2399 (1.0) Выполнение действия (без выбора исполнителя) ', async () => {
      await generalPage.actionsButton.click() // кнопка действия
      await this.page.getByTestId(Action).click()
      await expect(this.page.getByText(`Вы уверены, что хотите выполнить действие "${TextNotific}"?`)).toBeVisible()
      await this.page.getByRole('button', { name: 'Дa' }).click()
      await expect(generalPage.documentName).toContainText(Header)
      await expect(generalPage.documentState).toContainText(Status)
    })
  }

  async ADI_2413(nameRole, idRole) {
    const generalPage = new GeneralPageBankProducts(this.page)

    await test.step('ADI-T2413 (1.0)Переключение и проверка роли', async () => {
      await generalPage.actorButton.click()
      await idRole.click()
      await expect(generalPage.actorButton.getByRole('button', { name: nameRole })).toBeVisible()
    })
  }

  async ADI_6613(prefix) {
    const generalPage = new GeneralPageBankProducts(this.page)

    await test.step('ADI-T6613 (1.0) Проверка номера документа на содержание префикса', async () => {
      await expect(generalPage.documentNumber).toContainText(prefix)
    })
  }

  async ADI_2641(idTab) {
    await test.step('ADI-T2641 (1.0) Переход на вкладку документа', async () => {
      await this.page.getByTestId(idTab).click()
    })
  }

  async ADI_3231(idValue, type, value) {
    await test.step('ADI-T3231 (1.0) Проверка значения одного поля в блоке (универсальная)', async () => {
      await expect(this.page.getByTestId(idValue).getByRole(type)).toHaveValue(value)
    })
  }

  async ADI_3266(defaulvalue) {
    await test.step('ADI-T3266 (1.0) Проверка заполненного атрибута значением по умолчанию', async () => {
      await expect(this.page.getByTestId('REPPaymentData-#').getByTestId('-ng-select')).toContainText(defaulvalue)
    })
  }

  async ADI_2612(numError) {
    await test.step('ADI-T2612 (1.0) Проверка количества ошибок в информационном меню', async () => {
      const generalPage = new GeneralPageBankProducts(this.page)

      await this.page.getByTestId('tab-Notifications-nav').click()
      await expect(generalPage.totalIssues).toContainText(numError)
    })
  }

  async ADI_6358(buttonId) {
    await test.step('ADI-T6358 (1.0) Проверка доступности кнопки для нажатия (универсальный)', async () => {
      await expect(this.page.getByTestId(buttonId)).toBeEnabled()
    })
  }

  async ADI_2044() {
    const generalPage = new GeneralPageBankProducts(this.page)

    await test.step('ADI-T2044 (1.0) Сохранить / Рассчитать', async () => {
      await generalPage.saveButton.click()
      await expect(generalPage.actionsButton).toBeVisible() // кнопка действия видима
    })
  }

  async ADI_3619(idPrint) {
    const generalPage = new GeneralPageBankProducts(this.page)

    await test.step('ADI-T3619 (1.0) Проверка доступности ПФ в списке Печать', async () => {
      await generalPage.printButton.click()
      await expect(this.page.getByTestId(idPrint)).toBeVisible() // полис
      await generalPage.printButton.click()
    })
  }

  async ADI_3153(validText) {
    const generalPage = new GeneralPageBankProducts(this.page)

    await test.step('ADI-T3153 (1.0) [ИнфоМеню] Проверка наличия/отсутствия ошибки', async () => {
      await expect(generalPage.totalNameValidations).toContainText(validText)
    })
  }

  async ADI_3316(text) {
    const generalPage = new GeneralPageBankProducts(this.page)

    await test.step('ADI-T3316 (2.0)Проверка текста в модальном окне (универсальный)', async () => {
      await expect(generalPage.generalTextModalWindow).toContainText(text)
      await this.page.getByRole('button', { name: 'OK' }).click()
    })
  }

  async logout(userName, password) {
    await test.step('Выход из аккаунта и авторизация', async () => {
      await this.page.getByTestId('header-user-dropdown-menu').click()
      await this.page.getByRole('button', { name: ' Выйти' }).click()
      await this.page.getByRole('link', { name: 'сюда' }).click()
      await this.page.getByTestId('enter-button').click()
      await this.page.waitForTimeout(2500)
      await this.page.getByTestId('login-type-adinsure').check()
      await this.page.getByTestId('Username').fill(userName)
      await this.page.getByTestId('Password').fill(password)
      await this.page.getByTestId('login-button').click()
    })
  }

  async ADI_2987(docNumber) {
    const generalPage = new GeneralPageBankProducts(this.page)
    await test.step('Сохранить уникальный номер в заголовке (документа/контрагента)', async () => {
      docNumber = await generalPage.documentNumber.textContent()
      console.log(docNumber)
    })
  }
}
