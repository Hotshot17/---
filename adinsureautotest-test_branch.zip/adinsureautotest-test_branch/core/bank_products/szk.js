import { test, expect } from '@playwright/test'

export class SzkGeneral {
  constructor(page) {
    this.page = page
  }

  async ADI_2557(InsuranceProgramme, InsuranceProgrammeCode) {
    await test.step('ADI-T2557 (1.0) [СЗК] Заполнение блока ПРОГРАММА СТРАХОВАНИЯ для программы Оптимум', async () => {
      await this.page.getByTestId('insuranceProgramme-ng-select').getByRole('textbox').click()
      await this.page.getByRole('option', { name: InsuranceProgramme }).click()
      await expect(this.page.getByTestId('insurance-program-code-ng-select')).toContainText(InsuranceProgrammeCode)
    })
  }

  async ADI_4173(fullName, partyCode, dateBirth, placeBirth, gender, registrationCountry, address, phones, email) {
    await test.step('ADI-T4173 (1.0) [СЗК] Заполнение блока СТРАХОВАТЕЛЬ через ПОИСК КОНТРАГЕНТОВ', async () => {
      await this.page.getByTestId('policyholder-search').click()
      await this.page.getByTestId('partyapi-search').getByRole('textbox').fill(fullName)
      await this.page.getByTestId('partyapi-search-button').click()
      await this.page.getByRole('row', { name: partyCode }).getByRole('checkbox').check()
      await this.page.getByRole('button', { name: 'Выбрать' }).click()

      await expect(this.page.getByTestId('date-birth-input')).toHaveValue(dateBirth)
      await expect(this.page.getByTestId('place-birth').getByRole('textbox')).toHaveValue(placeBirth)

      await expect(this.page.getByTestId('gender-ng-select')).toContainText(gender)
      await expect(this.page.getByTestId('registration-country-ng-select')).toContainText(registrationCountry)

      await expect(this.page.getByTestId('address-table-row-0')).toContainText(address)
      await expect(this.page.getByTestId('phones-table-row-0')).toContainText(phones)
      await expect(this.page.getByTestId('email-table-row-0')).toContainText(email)
    })
  }

  async ADI_8049() {
    await test.step('ADI-T8049 (1.0) Проверка наличия или отсутствия поля в блоке (универсальное)', async () => {
      await expect(this.page.getByTestId('insuredPolicyholder').locator('i')).toBeVisible()
    })
  }

  async ADI_8042(duration, conclusionDate, InsuranceStartDate, endDate, lag) {
    await test.step('ADI-T8042 (1.0) [СЗК] Заполнения блока СРОК СТРАХОВАНИЯ', async () => {
      await this.page.getByTestId('policy-duration-input').fill(duration)
      await this.page.getByTestId('policy-duration-input').blur()
      await expect(this.page.getByTestId('conclusion-date-input')).toHaveValue(conclusionDate)
      await expect(this.page.getByTestId('insurance-start-date-input')).toHaveValue(InsuranceStartDate)
      await expect(this.page.getByTestId('start-date-input')).toHaveValue(conclusionDate)
      await expect(this.page.getByTestId('insurance-end-date-input')).toHaveValue(endDate)
      await expect(this.page.getByTestId('first-installment-date-input')).toHaveValue(conclusionDate)
      await expect(this.page.getByTestId('end-date-input')).toHaveValue(endDate)
      await expect(this.page.getByTestId('LBInsuranceDuration-insuranceDuration').getByTestId('-input')).toHaveValue(
        lag
      )
    })
  }

  async ADI_8956(
    pledgeDocNumber,
    bankSuminsured,
    policyNumber,
    premium,
    pledgeDocumentStartDate,
    bankPremium,
    agentCommissionCommon,
    agentCommissionValue
  ) {
    await test.step('ADI-T8956 (1.0) [СЗК] Заполнение и проверка полей блока ДОГОВОР  для программ', async () => {
      await this.page.getByTestId('pledge-doc-number').getByRole('textbox').click()
      await this.page.getByTestId('pledge-doc-number').getByRole('textbox').fill(pledgeDocNumber)
      await this.page
        .getByTestId('LBPolicyAttributes-policyAttributes')
        .getByTestId('-input')
        .first()
        .fill(bankSuminsured)
      await this.page.getByTestId('signature-precense').locator('i').click()
      await this.page.getByTestId('signatureType-ng-select').getByRole('combobox').click()
      await this.page.getByRole('option', { name: 'УКЭП' }).click()
      await expect(this.page.getByTestId('signatureType-ng-select')).toContainText('УКЭП')
      await expect(
        this.page.getByTestId('LBPolicyAttributes-policyAttributes').getByTestId('-input').first()
      ).toHaveValue(bankSuminsured)
      await expect(this.page.getByTestId('sales-city').getByRole('textbox')).toHaveValue('ГЦ Москва Запад')
      await expect(this.page.getByTestId('bank-sales-channel-ng-select')).toContainText('КЭШ')
      await expect(this.page.getByTestId('branch').getByRole('textbox')).toHaveValue('Головной офис')
      await expect(this.page.getByTestId('department').getByRole('textbox')).toHaveValue(
        'Дирекция по розничному банкострахованию'
      )
      await expect(this.page.getByTestId('department-upr').getByRole('textbox')).toHaveValue(
        'Дирекция по розничному банкострахованию'
      )
      await expect(this.page.getByTestId('sales-channel-ng-select')).toContainText('Почта банк')
      await expect(this.page.getByTestId('agent-name').getByRole('textbox')).toHaveValue('"Почта Банк" АО')
      await expect(this.page.getByTestId('responsible-manager-ng-select')).toContainText('Епишина Е.В.')
      await expect(this.page.getByTestId('policy-creating-method-ng-select')).toContainText('Ручной ввод')
      // await expect(this.page.getByTestId('policy-number').getByRole('textbox')).toHaveValue(/ПБ14-\d{8,9}/)
      await expect(this.page.getByTestId('policy-number').getByRole('textbox')).toHaveValue(policyNumber)

      await this.page.getByTestId('ai-operations-control').click() // сохранить
      await expect(this.page.getByTestId('premium-input').first()).toHaveValue(premium) // Страховая премия по договору,руб*
      await expect(this.page.getByTestId('pledge-start-date-input')).toHaveValue(pledgeDocumentStartDate) // Дата кредитного договора
      await expect(
        this.page.getByTestId('LBPolicyAttributes-policyAttributes').getByTestId('-input').nth(1)
      ).toHaveValue(bankPremium) // Страховая премия по договору от банка*
      await expect(this.page.getByTestId('profile-programme-ng-select')).toContainText('ПОТРЕБКРЕДИТЫ') // Профильная программа
      await expect(this.page.getByTestId('agent-commission-common-input')).toHaveValue(agentCommissionCommon) // КВ,%
      await expect(this.page.getByTestId('agent-commission-value-input')).toHaveValue(agentCommissionValue) // КВ,руб.
      await expect(this.page.getByTestId('ai-transitions-relations-control')).toBeVisible() // кнопка действия видима
    })
  }

  async ADI_3433(address) {
    await test.step('ADI-T3433 (1.0) Нажатие на кнопку с ОР Стандартизация адреса для СЗК', async () => {
      await this.page.getByTestId('address-section').getByRole('button', { name: 'Стандартизация' }).click()
      // Заполнение блока "Адрес"
      await expect(this.page.getByTestId('address-section').getByTestId('AddressAutocomplete-ng-select')).toContainText(
        address
      )
      await expect(
        this.page.getByTestId('address-section').getByTestId('postal-code').getByRole('textbox')
      ).not.toBeEmpty()
      await expect(this.page.getByTestId('address-section').getByTestId('city').getByRole('textbox')).not.toBeEmpty()

      // Заполнение блока "Территория страхования"
      await this.page.getByTestId('insurance-territory-section').getByRole('button', { name: 'Стандартизация' }).click()
      await expect(
        this.page.getByTestId('insurance-territory-section').getByTestId('AddressAutocomplete-ng-select')
      ).toContainText(address)
      await expect(this.page.getByTestId('insurance-territory-section').getByTestId('postal-code')).not.toBeEmpty()
      await expect(this.page.getByTestId('insurance-territory-section').getByTestId('region')).not.toBeEmpty()
    })
  }
}

export class MaximumPlus {
  constructor(page) {
    this.page = page
  }

  async ADI_8952(
    insuredSum,
    insuredPremium,
    sumElDeath,
    premiumDeath,
    sumDisabilityAccident1,
    premiumDisabilityAccident1,
    sumDisabilityAccident2,
    premiumDisabilityAccident2,
    sumInjuryAccident,
    premiumInjuryAccident,
    sumHospitalization,
    premiumHospitalization,
    premiumFin,
    sumUnemployment
  ) {
    await test.step('ADI-T8952 (1.0) [СЗК]Проверка наличия и добавления групповых рисков Максимум плюс', async () => {
      await expect(this.page.getByTestId('083ai-sum-input')).toHaveValue(insuredSum)
      await expect(this.page.getByTestId('083ai-premium-input')).toHaveValue(insuredPremium)
      await expect(
        this.page
          .locator('ng-select')
          .filter({ hasText: 'Весь мир за исключением зон военных конфликтов' })
          .getByRole('combobox')
      ).toBeVisible()
      await expect(
        this.page
          .locator('ng-select')
          .filter({ hasText: 'Правила общего добровольного страхования от несчастных случаев и болезней' })
          .getByRole('combobox')
      ).toBeVisible()
      await expect(this.page.getByTestId('083ai-tariff-str-ng-select')).toContainText('9-91(90)%')
      await expect(this.page.getByTestId('max-kv-input')).toHaveValue('90,00')

      //  Смерть НСИБ
      await expect(this.page.getByTestId('083da-sum-input')).toHaveValue(sumElDeath)
      await expect(this.page.getByTestId('083da-premium-input')).toHaveValue(premiumDeath)

      // ------ ПУТ

      // Инвалидность в результате НСиБ (I группа) - Доп
      await expect(
        this.page.getByTestId('risk083_disabilityAccident_group_one_additional').getByTestId('083dis-sum-input')
      ).toHaveValue(sumDisabilityAccident1)
      await expect(
        this.page.getByTestId('risk083_disabilityAccident_group_one_additional').getByTestId('083dis-premium-input')
      ).toHaveValue(premiumDisabilityAccident1)
      // Инвалидность в результате НСиБ (2 группа) - Доп

      await expect(
        this.page.getByTestId('risk083_disabilityAccident_group_two_additional').getByTestId('083dis-sum-input')
      ).toHaveValue(sumDisabilityAccident2)
      await expect(
        this.page.getByTestId('risk083_disabilityAccident_group_two_additional').getByTestId('083dis-premium-input')
      ).toHaveValue(premiumDisabilityAccident2)

      // Травма - Доп

      await expect(this.page.getByTestId('083ia-sum-input')).toHaveValue(sumInjuryAccident)
      await expect(this.page.getByTestId('083ia-premium-input')).toHaveValue(premiumInjuryAccident)
      await expect(this.page.getByTestId('083ia-limit-type-ng-select')).toContainText('Лимит на выплату по НС')
      await expect(this.page.getByTestId('083ia-limit-percent-input')).toHaveValue('10,00')

      // Госпитализация НСиБ - Доп

      await expect(
        this.page.getByTestId('risk083_hospitalization_additional').getByTestId('-input').first()
      ).toHaveValue(sumHospitalization)
      await expect(
        this.page.getByTestId('risk083_hospitalization_additional').getByTestId('-input').nth(1)
      ).toHaveValue(premiumHospitalization)

      await expect(this.page.getByTestId('083ha-duration-restrictions').locator('i')).toBeVisible()
      await expect(this.page.getByTestId('083ha-restrictions-period-ng-select')).toContainText('Срок страхования')
      await expect(this.page.getByTestId('083ha-restrictions-input')).toHaveValue('30')
      await expect(this.page.getByTestId('risk083_hospitalization_additional')).toContainText(
        'Лимит на выплату за период'
      )
      await expect(this.page.getByTestId('risk083_hospitalization_additional')).toContainText('Не более 30 дней')
      await expect(this.page.getByTestId('risk083_hospitalization_additional')).toContainText(
        'Доля от страховой суммы за период'
      )
      await expect(this.page.getByTestId('risk083_hospitalization_additional')).toContainText('1 день')
      await expect(
        this.page
          .getByTestId('risk083_hospitalization_additional')
          .locator('percentage-permille-numeric-input-bootstrap')
          .getByTestId('-input')
      ).toHaveValue('0,20')

      // фин.риск

      await expect(this.page.getByTestId('166fr-premium-input')).toHaveValue(premiumFin)
      await expect(this.page.getByTestId('166fr-territory-ng-select')).toContainText('Российская Федерация')
      await expect(this.page.getByTestId('166fr-rules-ng-select')).toContainText(
        'Правила страхования на случай потери работы в редакции от 01.08.2019'
      )
      await expect(this.page.getByTestId('166fr-tariff-str-ng-select')).toContainText('9-91(90)%')
      await expect(this.page.getByTestId('166fr-max-kv-input')).toHaveValue('90,00')

      // потеря работы
      await expect(this.page.getByTestId('166-sum-input')).toHaveValue(sumUnemployment)
      await expect(this.page.getByTestId('166-premium-input')).toHaveValue(premiumFin)
      await expect(this.page.getByTestId('166-duration-restrictions').locator('i')).toBeVisible()
      await expect(this.page.getByTestId('risks166-unemployment').getByTestId('-ng-select')).toContainText(
        'Срок страхования'
      )
      await expect(this.page.getByTestId('166-restrictions-input')).toHaveValue('120')
      await expect(
        this.page
          .locator('ng-select')
          .filter({ hasText: 'Количество дней от начала ответственности по договору' })
          .getByRole('combobox')
      ).toBeVisible()
      await expect(
        this.page
          .locator('sub-view-layout')
          .filter({ hasText: 'Тип периода ожидания Количество дней от начала ответственности по договору×--Пер' })
          .getByTestId('wait-period-input')
      ).toHaveValue('60')

      await expect(
        this.page
          .locator('ng-select')
          .filter({ hasText: 'Количество месяцев от последней выплаты по страховому случаю×' })
          .getByRole('combobox')
      ).toBeVisible()
      await expect(
        this.page
          .locator('sub-view-layout')
          .filter({ hasText: 'Тип периода ожидания Количество месяцев от последней выплаты по страховому случа' })
          .getByTestId('wait-period-input')
      ).toHaveValue('12')

      await expect(
        this.page
          .locator('ng-select')
          .filter({ hasText: 'Количество месяцев с даты прекращения Контракта×' })
          .getByRole('combobox')
      ).toBeVisible()
      await expect(
        this.page
          .locator('sub-view-layout')
          .filter({ hasText: 'Тип периода ожидания Количество месяцев с даты прекращения Контракта×--Период ож' })
          .getByTestId('wait-period-input')
      ).toHaveValue('2')
      await expect(this.page.getByTestId('166-deductible-type-ng-select')).toContainText(
        'В днях в зависимости от условий'
      )
      await expect(this.page.getByTestId('166-deductible-size-input')).toHaveValue('60')
      await expect(this.page.getByTestId('166-deductible-condition').getByRole('textbox')).toHaveValue(
        'В течение заданного количества дней с даты прекращения Контракта'
      )
      await expect(this.page.getByTestId('166-limit-type-ng-select')).toContainText('Доля от страховой суммы за период')
      await expect(this.page.getByTestId('166-limit-period-ng-select')).toContainText('1 день')
      await expect(this.page.getByTestId('166-limit-percent-input')).toHaveValue('0,10')
    })
  }
}

export class ZabotaPlus {
  constructor(page) {
    this.page = page
  }

  async ADI_8948(
    propertyType,
    buildingTypeDetailed,
    insuredSumImmov,
    premiumImmov,
    insuredSumMova,
    premiumMova,
    insuredSumAccident,
    insuredPremiumAccident,
    sumElDeath,
    premiumDeath,
    sumDisabilityAccident,
    premiumDisabilityAccident,
    sumInjuryAccident,
    premiumInjuryAccident,
    sumPropertyRisk,
    premiumPropertyRisk,
    sumCivilRisk,
    premiumCivilRisk
  ) {
    await test.step('ADI-T8948 (1.0) [СЗК]Проверка наличия и добавления групповых рисков Забота плюс', async () => {
      await expect(this.page.getByTestId('property-type-ng-select')).toContainText(propertyType)
      await expect(this.page.getByTestId('building-type-detailed-ng-select')).toContainText(buildingTypeDetailed)
      await expect(this.page.getByTestId('insured-sum-input')).toHaveValue(insuredSumImmov)
      await expect(this.page.getByTestId('immovable-property-section').getByTestId('premium-input')).toHaveValue(
        premiumImmov
      )
      // чекбоксы недвижимого имущества
      await expect(this.page.getByTestId('interior-decoration').locator('i')).toBeVisible()
      await expect(this.page.getByTestId('communication-systems').locator('i')).toBeVisible()
      // блок движимое имущество
      await expect(this.page.getByTestId('movable-property-type-ng-select')).toContainText('Домашнее имущество')
      await expect(this.page.getByTestId('movable-property-sum-input')).toHaveValue(insuredSumMova)
      await expect(this.page.getByTestId('movable-property-premium-input')).toHaveValue(premiumMova)
      // чекбоксы движимого имущества
      await expect(this.page.getByTestId('furniture').locator('i')).toBeVisible()
      await expect(this.page.getByTestId('interior').locator('i')).toBeVisible()
      await expect(this.page.getByTestId('weaving').locator('i')).toBeVisible()
      await expect(this.page.getByTestId('appliances').locator('i')).toBeVisible()
      await expect(this.page.getByTestId('equipment').locator('i')).toBeVisible()
      await expect(this.page.getByTestId('sport').locator('i')).toBeVisible()
      await expect(this.page.getByTestId('other').locator('i')).toBeVisible()

      // ----------------------------------------------------------------- Застрахованные риски
      // -------------------------------------------------Нсиб
      await expect(this.page.getByTestId('083ai-sum-input')).toHaveValue(insuredSumAccident)
      await expect(this.page.getByTestId('083ai-premium-input')).toHaveValue(insuredPremiumAccident)

      await expect(this.page.getByTestId('risks083_accidentIllnessRisks')).toContainText(
        'Весь мир за исключением зон военных конфликтов'
      )
      await expect(this.page.getByTestId('risks083_accidentIllnessRisks')).toContainText(
        'Правила общего добровольного страхования от несчастных случаев и болезней'
      )
      await expect(this.page.getByTestId('max-kv-input')).toHaveValue('95,00')
      // --------- Раздел Смерть в результате НСиБ
      await expect(this.page.getByTestId('083di-sum-input')).toHaveValue(sumElDeath)
      await expect(this.page.getByTestId('083di-premium-input')).toHaveValue(premiumDeath)
      // ---------ПУТ
      await expect(this.page.getByTestId('083disil-sum-input')).toHaveValue(sumDisabilityAccident)
      await expect(this.page.getByTestId('083disil-premium-input')).toHaveValue(premiumDisabilityAccident)

      // ---------Травма
      await expect(this.page.getByTestId('083ia-sum-input')).toHaveValue(sumInjuryAccident)
      await expect(this.page.getByTestId('083ia-premium-input')).toHaveValue(premiumInjuryAccident)
      await expect(this.page.getByTestId('083ia-limit-type-ng-select')).toContainText('Лимит на выплату по НС')
      await expect(this.page.getByTestId('083ia-limit-percent-input')).toHaveValue('15,00')

      // --------- Блок Имущество
      await expect(this.page.getByTestId('167pr-sum-input')).toHaveValue(sumPropertyRisk)
      await expect(this.page.getByTestId('167pr-premium-input')).toHaveValue(premiumPropertyRisk)
      await expect(this.page.getByTestId('167pr-rules-ng-select')).toContainText('Соответствуют правилам ИФЛ')
      await expect(this.page.getByTestId('167pr-tariff-str-ng-select')).toContainText('(75-25)%+КВ(0-95)%')
      await expect(this.page.getByTestId('167pr-max-kv-input')).toHaveValue('95,00')
      // --------- Блок Гражданская ответственность
      await expect(this.page.getByTestId('167cr-sum-input')).toHaveValue(sumCivilRisk)
      await expect(this.page.getByTestId('167cr-premium-input')).toHaveValue(premiumCivilRisk)
      await expect(this.page.getByTestId('167cr-rules-ng-select')).toContainText('Соответствуют правилам ИФЛ')
      await expect(this.page.getByTestId('167cr-tariff-str-ng-select')).toContainText('(75-25)%+КВ(0-95)%')
      await expect(this.page.getByTestId('167cr-max-kv-input')).toHaveValue('95,00')
    })
  }
}
