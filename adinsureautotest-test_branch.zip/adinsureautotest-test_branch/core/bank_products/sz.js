/* eslint-disable no-useless-escape */
import { test, expect } from '@playwright/test'
import { SZPolicyPage } from '../../pages/bank_products/PersonalMedicalInsurance/SZPolicy.page'

// const szPolicy = new SZPolicy(this.page)
export class PersonalMedicalInsurance {
  constructor(page) {
    this.page = page
  }

  /* ------------------------------------------------------ общие методы  ----------------------------- */
  // async selectCombobox (nameValue) {
  //   await this.page.getByRole('option', { name: nameValue }).click() // метод для выбора значений в комбобоксе
  // }

  // async selectCheckboxTable (nameValue) {
  //   await this.page.getByRole('row', { name: nameValue }).getByRole('checkbox').check() // метод для установки чек-бокса
  // }

  // async checkComboboxValue (locatorSection, paymentMethod, numNth) {
  //   await expect(locatorSection.locator('.ng-value-label').numNth).toContainText(paymentMethod) // метод для проверки значения в комбобоксе
  // }

  /* ------------------------------------------------------ ТК для спутника ----------------------------- */

  async ADI_3007_sz(lastName, firstName, middleName, fullName, partyCode, partySearch) {
    await test.step('ADI-T3007 (1.0) Поиск и выбор в форме Поиск контрагента - по параметрам ФЛ в системе Адакта ', async () => {
      const szPolicy = new SZPolicyPage(this.page)

      await szPolicy.searchPolicyHolder.click()
      await szPolicy.partySearch.click()
      await szPolicy.selectCombobox(partySearch)
      await szPolicy.lastName.fill(lastName)
      await szPolicy.firstName.fill(firstName)
      await szPolicy.middleName.fill(middleName)
      await szPolicy.searchButtonPolicy.click()
      await szPolicy.selectCheckboxTable(partyCode)
      await szPolicy.selectButtonPolicy.click()
      await expect(this.page.getByRole('link', { name: fullName })).toBeVisible()
    })
  }

  async ADI_3194_sz(locatorCheckbox, classValueCheck) {
    await test.step('ADI-T3194 (1.0) Установка, снятие чек-бокса в блоке', async () => {
      await locatorCheckbox.click()
      await expect(locatorCheckbox).toHaveClass(classValueCheck)
    })
  }

  async ADI_8940(lastName, firstName, middleName, fullName, partyCode, partySearch) {
    await test.step('ADI-T8940 (1.0) Спутник здоровья Заполнение блока ЗАСТРАХОВАННЫЙ с созданием нового', async () => {
      const szPolicy = new SZPolicyPage(this.page)

      await szPolicy.insuredSearchPolicyHolder.click()
      await szPolicy.insuredPartySearch.click()
      await szPolicy.selectCombobox(partySearch)
      await szPolicy.insuredLastName.fill(lastName)
      await szPolicy.insuredFirstName.fill(firstName)
      await szPolicy.insuredMiddleName.fill(middleName)
      await szPolicy.insuredSearchButtonPolicy.click()
      await szPolicy.selectCheckboxTable(partyCode)
      await szPolicy.insuredSelectButtonPolicy.click()
      await expect(this.page.getByRole('link', { name: fullName })).toBeVisible()
    })
  }

  async ADI_8011(paymentMethod) {
    await test.step('ADI-T8011 (1.0) [Спутник здоровья] Заполнение блока Оплата (Способ оплаты)', async () => {
      const szPolicy = new SZPolicyPage(this.page)

      await szPolicy.paymentMethod.click()
      szPolicy.selectCombobox(paymentMethod)
      await expect(szPolicy.checkPaymentMethod).toContainText(paymentMethod)
    })
  }

  /**
   * Заполнение блока Условия расчета, при создании Предрасчета с программой Мед расходы, в рамках единовременной поездки
   *
   * @param {string} iconAmbulatoryTreatment - иконка поля 'Амбулаторно-поликлиническое обслуживание'
   * @param {string} iconTelemed - иконка поля 'Телемедицинские услуги	'
   * @param {string} iconDentalTreatment  - иконка поля 'Стоматологическое обслуживание	'
   * @param {string} franchise - значение поля  'Безусловная франшиза. В % от оплаты мед услуг (только для Амбулаторно-поликлиническое обслуживание)	'
   * @param {number} numBoxOptionTable - номер варианта коробки в таблице (1-Стандарт ,2- ДМС-стандарт, 3-ДМС-Дент)
   * @param {string} sum - значение поля  'Страховая сумма'
   * @param {string} premium - значение поля  'Премия'
   */
  async ADI_7964(
    iconAmbulatoryTreatment,
    iconTelemed,
    iconDentalTreatment,
    franchise,
    numBoxOptionTable,
    sum,
    premium
  ) {
    await test.step('ADI-T7964 (1.0) [Спутник здоровья ]Проверка блока ВАРИАНТ КОРОБКИ программа Стандарт', async () => {
      const szPolicy = new SZPolicyPage(this.page)

      await expect(szPolicy.basePremium.nth(numBoxOptionTable)).toContainText(premium)
      await expect(szPolicy.sumInsured.nth(numBoxOptionTable)).toContainText(sum)
      await expect(szPolicy.ambulatoryTreatment.nth(numBoxOptionTable).locator('i')).toHaveClass(
        iconAmbulatoryTreatment
      )

      await expect(szPolicy.telemed.nth(numBoxOptionTable).locator('i')).toHaveClass(iconTelemed)
      await expect(szPolicy.dentalTreatment.nth(numBoxOptionTable).locator('i')).toHaveClass(iconDentalTreatment)
      await expect(szPolicy.deductable.nth(numBoxOptionTable)).toContainText(franchise)
      await expect(szPolicy.deductableDays.nth(numBoxOptionTable)).toContainText('14')
    })
  }

  async ADI_8971(notificationMethod) {
    // const szPolicy = new SZPolicy(this.page)
    const szPolicy = new SZPolicyPage(this.page)

    await test.step('ADI-T8971 (1.0) [Спутник здоровья]Договор заполнение блока Плательщик (способ уведомления)', async () => {
      await szPolicy.paymentNotificationMethod.click()
      szPolicy.selectCombobox(notificationMethod)
      await szPolicy.payerEmail.fill('mail@mail.ru')

      if (notificationMethod === 'SMS') {
        await expect(this.page.getByTestId('payer-mobile').getByRole('textbox')).toBeVisible()
      }
    })
  }

  async ADI_8015(boxVariant, numBoxOptionTable) {
    const szPolicy = new SZPolicyPage(this.page)

    await test.step('ADI-T8015 (1.0) [Спутник здоровья]Заполнение блока ВАРИАНТ КОРОБКИ', async () => {
      await szPolicy.boxVariant.getByText(boxVariant, { exact: true }).click()
      const RegBoxVariant = new RegExp(`^${boxVariant}`) // регулярное выражение для точного определения имени варианта коробки
      await expect(this.page.locator('#rep-select-width-detail').locator('th').nth(numBoxOptionTable)).toHaveClass(
        'ai-col-width-none ai-selected-column'
      )
    })
  }

  async ADI_10665() {
    const szPolicy = new SZPolicyPage(this.page)

    await test.step('ADI-T10665 (1.0) [Спутник здоровья ] Проверка появления модального окна Подтверждение инф. о Ключ. Инф.', async () => {
      await expect(szPolicy.generalTextModalWindow).toContainText(
        'Перед оплатой договора необходимо ознакомить Страхователя с Ключевым информационным документом'
      )
      await this.page.getByRole('button', { name: 'OK' }).click()
    })
  }

  async ADI_8444(docNumber, currDate, context, testInfo) {
    const szPolicy = new SZPolicyPage(this.page)

    await test.step('ADI-T8444 (1.0) [Спутник здоровья] Проверка отправки и получения уведомление по e-mail с ссылкой на оплату', async () => {
      // проверка отображания модального окна с уведомлением, что сообщение отправлено
      await expect(szPolicy.generalTextModalWindow).toContainText('Сообщение успешно отправлено!')
      await this.page.getByRole('button', { name: 'OK' }).click()

      //  открытие паперката в новой вкладке
      const papercut = await context.newPage()
      await papercut.goto('https://test.adinsure.sogaz.ru:37408/')
      if (await papercut.getByRole('link', { name: 'Papercut SMTP' }).isVisible()) {
        await papercut.getByText(`Договор страхования ${docNumber}`).first().click()

        const str = `
            Уважаемый Станислав Владимирович,
            Направляем Вам договор страхования (Полис) ${docNumber}, который будет являться заключенным после уплаты
            страховой  премии в размере и сроки, предусмотренные Полисом. Памятка получателю страховых услуг, Полис,
            Программа ДМС, Ключевой информационный документ находятся во вложении.
            Для оплаты договора страхования, пожалуйста, перейдите по ссылке: ссылка на оплату. Ссылка действительна до ${currDate} 23:59:59.
            Данное письмо сформировано автоматически. Просьба не отвечать на него.
            C уважением,
            Страховая группа «СОГАЗ»
            www.sogaz.ru
            Круглосуточный телефон Единого контактного центра 8-800-333-0-888
            `
        await expect(papercut.frameLocator('#preview-html').locator('div')).toContainText(str)

        // Проверка ссылок
        await expect(
          papercut.frameLocator('#preview-html').getByRole('link', { name: 'ссылка на оплату' })
        ).toHaveAttribute('href', /https:\/\/lk-stage\.sogaz\.ru\/p\/.*/) // проерка ссылки
        await expect(
          papercut.frameLocator('#preview-html').getByRole('link', { name: 'www.sogaz.ru' })
        ).toHaveAttribute('href', 'https://www.sogaz.ru/') // проерка ссылки

        // проверка вложенных ПФ
        await papercut.getByRole('link', { name: 'Sections' }).click()
        await expect(
          papercut.getByRole('row', { name: 'application/pdf Памятка.pdf ' }).getByRole('link')
        ).toBeVisible()
        await expect(
          papercut.getByRole('row', { name: 'application/pdf Полис-оферта.' }).getByRole('link')
        ).toBeVisible()
        await expect(
          papercut.getByRole('row', { name: 'application/pdf Программа страхования.pdf ' }).getByRole('link')
        ).toBeVisible()
        await expect(papercut.getByRole('row', { name: 'application/pdf КИД.pdf ' }).getByRole('link')).toBeVisible()
      } else {
        console.log('Ошибка авторизации или papercut не работает')
        await papercut.waitForTimeout(4000)
        const screenshot = await papercut.screenshot()
        await testInfo.attach('Скриншот страницы papercut', { body: screenshot, contentType: 'image/png' })
      }
    })
  }

  async ADI_11414(lastName, firstName, midleName, premium, docNumber, currDate, context, testInfo) {
    await test.step('ADI-T11414 (1.0) [Спутник здоровья] Проверка текста по SMS с ссылкой на оплату', async () => {
      /* открытие паперката в новой вкладке */
      const papercut = await context.newPage()
      /* -------------------------------------------- Открытие и проверка СМС уведомления */
      await papercut.goto('https://test.adinsure.sogaz.ru:37408/')
      if (await papercut.getByRole('link', { name: 'Papercut SMTP' }).isVisible()) {
        await papercut.getByText('SMS 70000000000').first().click()

        /* Регулярное выражение по тексту уведомления */
        const regSmS = new RegExp(`Уважаемый ${lastName} ${firstName} ${midleName}.
Для оплаты ${premium} руб. по договору страхования ${docNumber}, пожалуйста, перейдите по ссылке: https:\/\/lk-stage\.sogaz\.ru\/p\/.*. Оплата возможна до ${currDate} 23:59:59.
С Уважением, АО «СОГАЗ»`)

        /* Проверка текста уведомлени */
        await expect(papercut.getByTestId('preview-plain')).toContainText(regSmS)

        /* Проверка ссылки на оплату */
        await expect(papercut.getByRole('link', { name: /https:\/\/lk-stage\.sogaz\.ru\/p\/.*/ })).toHaveAttribute(
          'href',
          /https:\/\/lk-stage\.sogaz\.ru\/p\/.*/
        )

        /* --------------------------------------------Открытие и проверка уведомления по e-mail */

        await papercut.locator('i.glyphicon.glyphicon-arrow-left').click() // кнопка "назад" для возвращения к списку уведомлений

        await papercut.getByText(`Договор страхования ${docNumber}`).first().click()

        const email = `
            Уважаемый ${firstName} ${midleName},
            Направляем Вам договор страхования (Полис) ${docNumber}, который будет являться заключенным после уплаты
            страховой  премии в размере и сроки, предусмотренные Полисом. Памятка получателю страховых услуг, Полис,
            Программа ДМС, Ключевой информационный документ находятся во вложении.
            Данное письмо сформировано автоматически. Просьба не отвечать на него.
            С уважением,
            Страховая группа «СОГАЗ»
            www.sogaz.ru
            Круглосуточный телефон Единого контактного центра 8-800-333-0-888
            `

        await expect(papercut.frameLocator('#preview-html').locator('div')).toContainText(email)

        // проверка вложенных ПФ
        await papercut.getByRole('link', { name: 'Sections' }).click()
        await expect(
          papercut.getByRole('row', { name: 'application/pdf Памятка.pdf ' }).getByRole('link')
        ).toBeVisible()
        await expect(
          papercut.getByRole('row', { name: 'application/pdf Полис-оферта.' }).getByRole('link')
        ).toBeVisible()
        await expect(
          papercut.getByRole('row', { name: 'application/pdf Программа страхования.pdf ' }).getByRole('link')
        ).toBeVisible()
        await expect(papercut.getByRole('row', { name: 'application/pdf КИД.pdf ' }).getByRole('link')).toBeVisible()
      } else {
        console.log('Ошибка авторизации или papercut не работает')
        await papercut.waitForTimeout(4000)
        const screenshot = await papercut.screenshot()
        await testInfo.attach('Скриншот страницы papercut', { body: screenshot, contentType: 'image/png' })
      }
    })
  }

  async ADI_8973(sumRisk, premiumRisk, tarifRisk) {
    const szPolicy = new SZPolicyPage(this.page)

    await test.step('ADI-T8973 (1.0) [Спутник здоровья ]Проверка блока РИСКИ, программа Стандарт ( только под ролью андеррайтер)', async () => {
      //  Блок "Риски"
      await expect(szPolicy.insuredRiskName).toHaveValue('Спутник здоровья')
      await expect(szPolicy.insuredRiskSumInsured).toHaveValue(sumRisk)
      await expect(szPolicy.insuredRiskPremium).toHaveValue(premiumRisk)
      await expect(szPolicy.insuredRiskRule).toContainText('Правилами добровольного медицинского страхования граждан')
      await expect(szPolicy.insuredRiskTariff).toContainText(tarifRisk)
      /* -------------------------------------------Таблица "Застрахованные риски" */

      //       // Столбец "ЭЛ.РИСК"
      //       await expect(szPolicy.elRiskNameRow0).toContainText('Амбулаторно-поликлиническое обслуживание')
      //       await expect(szPolicy.elRiskNameRow1).toContainText('Телемедицинские услуги')

      //       // Столбец "СТРАХОВАЯ СУММА ПО ЭЛ.РИСКУ"
      //       await expect(szPolicy.elRiskSumRow0).toContainText('400 000,00')
      //       await expect(szPolicy.elRiskSumRow1).toContainText('100 000,00')

      //       // Столбец "СТРАХОВАЯ ПРЕМИЯ ПО ЭЛ.РИСКУ"
      //       await expect(szPolicy.elRiskPremiumRow0).toContainText('14 775,00')
      //       await expect(szPolicy.elRiskPremiumRow1).toContainText('225,00')

      //       // Столбец "ТЕРРИТОРИЯ СТРАХОВАНИЯ"
      //       await expect(szPolicy.territiryRow0).toContainText('Российская федерация')
      //       await expect(szPolicy.territiryRow1).toContainText('Весь мир')

      //       // Столбец "ФРАНШИЗА"
      // await expect(page1.getByRole('paragraph')).toContainText('Необходимо уточнить у клиента "Тип объекта".Внимание! Таунхаусы и строения (дом) на страхование не принимаются');
      //       await expect(szPolicy.deductableRow0Input1).toHaveValue('Временная')
      //       await expect(szPolicy.deductableRow0Input2).toHaveValue('В днях от Даты начала страхования')
      //       await expect(szPolicy.deductableRow0Input3).toHaveValue('14')
      //       await expect(szPolicy.deductableRow0Input4).toHaveValue('Безусловная')
      //       await expect(szPolicy.deductableRow0Input5).toHaveValue('В процентах от оплаты медицинских услуг')
      //       await expect(szPolicy.deductableRow0Input6).toHaveValue(franchise)

      //       await expect(szPolicy.deductableRow1Input1).toHaveValue('Временная')
      //       await expect(szPolicy.deductableRow1Input2).toHaveValue('В днях от Даты начала страхования')
      //       await expect(szPolicy.deductableRow1Input3).toHaveValue('14')

      if (await this.page.getByTestId('el-risk-name').getByText('Стоматологическое обслуживание').isVisible()) {
        await expect(this.page.getByTestId('suminsured').nth(2)).toContainText('100 000,00')
      }
    })
  }

  async ADI_14829(comissionSum) {
    await test.step('ADI-T14829 (1.0) [Спутник здоровья] Проверка блока ПОСРЕДНИКИ И КВ', async () => {
      const szPolicy = new SZPolicyPage(this.page)

      await expect(szPolicy.agent).toContainText("'Банк ГПБ' (АО)")
      await expect(szPolicy.agentAgreement).toContainText('--')
      await expect(szPolicy.conclusionDate).toContainText('08.06.2015')
      await expect(szPolicy.startDateAgent).toContainText('08.06.2015')
      await expect(szPolicy.endDateAgent).toContainText('31.12.2100')
      await expect(szPolicy.commissionRate).toContainText('40,00')
      await expect(szPolicy.commissionAmount).toContainText(comissionSum)
    })
  }

  async ADI_9810() {
    await test.step('ADI-T9810 (1.0) [Спутник здоровья ] Проверка модального окна Уведомление инф. о печати документа.', async () => {
      const szPolicy = new SZPolicyPage(this.page)

      await expect(szPolicy.generalTextModalWindow).toContainText(
        'Необходимо распечатать страховую документацию: Полис-оферта, Памятка, Программа ДМС'
      )
      await this.page.getByRole('button', { name: 'OK' }).click()
    })
  }

  async ADI_8016(policyHolder, boxVariant, issueDate, startDate, endDate, premium) {
    const szPolicy = new SZPolicyPage(this.page)

    await test.step('ADI-T8016 (1.0) [Спутник здоровья] Проверка боковой панели, вкладка ОБЩАЯ ИНФОРМАЦИЯ', async () => {
      await expect(szPolicy.summaryPolicyHolder).toContainText(policyHolder)
      await expect(szPolicy.summaryInsuranceProgram).toContainText('Спутник здоровья')
      await expect(szPolicy.summaryBoxVariant).toContainText(boxVariant)
      await expect(szPolicy.summaryPaymentFrequency).toContainText('Единовременно')
      await expect(szPolicy.summaryIssueDate).toContainText(issueDate)
      await expect(szPolicy.summaryStartDate).toContainText(startDate)
      await expect(szPolicy.summaryEndDate).toContainText(endDate)
      await expect(szPolicy.summaryPolicyDuration).toContainText('365')
      await expect(szPolicy.summaryPremium).toContainText(premium)
    })
  }

  async ADI_3231_sz(paymentMethod) {
    await test.step('ADI-T3231 (1.0) Проверка значения одного поля в блоке (универсальная)', async () => {
      await expect(
        this.page.getByTestId('SZPaymentData-#').locator('#-ng-select').locator('.ng-value-label')
      ).toContainText(paymentMethod)
    })
  }

  async ADI_14927() {
    await test.step('ADI-T14927 (1.0) [Спутник здоровья ]Проверка блока "Организационная структура"', async () => {
      const szPolicy = new SZPolicyPage(this.page)

      await expect(szPolicy.salesOutlet).toHaveValue('Банк ГПБ (АО) ДО № 099/1072 Банка ГПБ (АО)')
      await expect(szPolicy.department).toContainText('Дирекция розничного банкострахования')
      await expect(szPolicy.branch).toContainText('Головной офис')
      await expect(szPolicy.profileProgram).toContainText('Коробки ДРБС')
      await expect(szPolicy.sellingChannel).toContainText('Газпромбанк')
    })
  }

  async correctDateOfBirth(currDate, under18Year) {
    await test.step('Изменение даты рождения и добавление вложения в карточке ', async () => {
      await this.page.getByTestId('Parties_menu_1').click()
      await this.page.getByTestId('DetailedPartySearchView_1_2').click()

      await this.page
        .getByTestId('detailedparty-param_general-search')
        .getByRole('textbox')
        .fill('Мостовой Евгений Александрович')
      await this.page.getByTestId('detailedparty-param_general-search').getByRole('textbox').press('Enter')

      const page1Promise = this.page.waitForEvent('popup')
      await this.page.getByTestId('detailedparty-search-table').getByRole('link', { name: '3393248' }).click()
      const page1 = await page1Promise

      await page1.getByTestId('tab-Attachments-nav').click()
      await page1.getByTestId('attachments-table-paginator').getByTestId('page-sizes').click()
      // await page1.getByRole('option', { name: '50' }).click()
      await page1.getByRole('option').last().click()

      const isVisiblecurrdate = await page1
        .getByTestId('attachments-table')
        .locator('td')
        .getByText(/\d{2}\.\d{2}.\d{4}/gm)
        .last()
        .textContent()

      if (isVisiblecurrdate === currDate) {
        console.log('Сегодня уже добавлялось вложение и изменялась дата рождения страхователя!')
      } else {
        await page1.getByRole('button', { name: '+ Добавить' }).click()
        await page1
          .getByTestId('attachment-upload')
          .getByRole('textbox')
          .setInputFiles('./fixtures/testDataSuite/PersonalMedicalInsurance/Screenshot_4.jpg')
        await page1.getByTestId('attachment-type-ng-select').getByRole('textbox').click()
        await page1.getByRole('option', { name: 'Паспорт гражданина РФ' }).click()
        await page1.getByRole('button', { name: 'OK' }).click()
        await page1.getByTestId('tab-Natural-Party-Data-nav').click()
        await page1.getByTestId('-input').clear()
        await page1.getByTestId('-input').fill(under18Year)
        await page1.getByRole('button', { name: 'Сохранить' }).click()
      }
    })
  }
}
