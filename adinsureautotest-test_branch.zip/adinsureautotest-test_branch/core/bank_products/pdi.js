import { test, expect } from '@playwright/test'

export class StepPdi {
  constructor(page) {
    this.page = page
  }

  async ADI_3007(lastName, firstName, midleName, birthDate, gender, series, number, partyCode) {
    await test.step('Поиск контрагента - по параметрам - ADI-T3007', async () => {
      await this.page.getByRole('button', { name: 'Поиск страхователя' }).click()
      await this.page.getByTestId('last-name').getByRole('textbox').fill(lastName)
      await this.page.getByTestId('first-name').getByRole('textbox').fill(firstName)
      await this.page.getByTestId('middle-name').getByRole('textbox').fill(midleName)
      await this.page.getByTestId('birth-date-input').fill(birthDate)
      await this.page.getByTestId('gender-ng-select').getByRole('combobox').click()
      await this.page.getByText(gender).click()
      await this.page.getByTestId('document-type-ng-select').getByRole('combobox').click()
      await this.page.getByRole('option', { name: 'Паспорт гражданина России' }).click()
      await this.page.getByTestId('series').getByRole('textbox').fill(series)
      await this.page.getByTestId('number').getByRole('textbox').fill(number)
      await this.page
        .getByTestId('DetailedPartySearchView_SearchButton')
        .getByRole('button', { name: ' Поиск' })
        .click()
      await this.page.getByRole('row', { name: partyCode }).getByRole('checkbox').first().check()
      await this.page.getByRole('button', { name: ' Выбрать' }).click()
    })
  }

  async ADI_3165_pdi(paymentMethod) {
    await test.step(' заполнение программы страхования', async () => {
      await this.page.getByRole('combobox').click()
      await this.page.getByRole('option', { name: paymentMethod }).click()
      await expect(this.page.getByTestId('-ng-select')).toContainText(paymentMethod) // проверка на заполнение программы
    })
  }

  async ADI_6540_adress(adress) {
    await test.step('ADI-T6540 (1.0) Нажатие на кнопку в блоке (универсальное) - Для ПдИ нажатие на кнопку "По адресу страхователя"', async () => {
      await this.page.getByTestId('policyholder-address-button').click()
      await expect(this.page.getByTestId('AddressAutocomplete-ng-select')).toContainText(adress)
      await expect(this.page.getByTestId('postal-code').getByRole('textbox')).not.toBeEmpty()
    })
  }

  async ADI_2399_pdi_qote(action, header, status) {
    await test.step('Выполнение действия(без выбора исполнителя) - ADIT2399', async () => {
      // выпуск котировки
      await this.page.getByTestId('ai-transitions-relations-control').click()
      await this.page.getByTestId(action).nth(0).click()
      await this.page.getByRole('button', { name: ' Дa' }).click()
      // Проверка заголовка документа:
      await expect(this.page.getByTestId('header-document-name')).toContainText(header)
      await expect(this.page.getByTestId('header-document-state')).toContainText(status)
    })
  }

  async ADI_4032(paymentMethod) {
    await test.step("Заполнение поля 'Способ оплаты' - ADIT4032", async () => {
      await this.page.getByRole('combobox').nth(1).click()
      await this.page.getByRole('option', { name: paymentMethod }).click()
    })
  }

  async ADI_3231_pdi(idValue, type, value) {
    await test.step('ADI-T3231 (1.0) Проверка значения одного поля в блоке (универсальная)', async () => {
      await expect(this.page.getByTestId(idValue).getByTestId(type)).toHaveValue(value)
    })
  }

  async ADI_4037(lastName, firstName, midleName, birthDate, gender, series, number, partyCode) {
    await test.step('ADI-T4037 (1.0) [ПдИ] Заполнение блока СТРАХОВАТЕЛЬ (Отменяем обстоятельства)', async () => {
      await this.page.getByRole('button', { name: 'Поиск страхователя' }).click()
      await this.page.getByTestId('last-name').getByRole('textbox').fill(lastName)
      await this.page.getByTestId('first-name').getByRole('textbox').fill(firstName)
      await this.page.getByTestId('middle-name').getByRole('textbox').fill(midleName)
      await this.page.getByTestId('birth-date-input').fill(birthDate)
      await this.page.getByTestId('gender-ng-select').getByRole('combobox').click()
      await this.page.getByText(gender).click()
      await this.page.getByTestId('document-type-ng-select').getByRole('combobox').click()
      await this.page.getByRole('option', { name: 'Паспорт гражданина России' }).click()
      await this.page.getByTestId('series').getByRole('textbox').fill(series)
      await this.page.getByTestId('number').getByRole('textbox').fill(number)
      await this.page
        .getByTestId('DetailedPartySearchView_SearchButton')
        .getByRole('button', { name: ' Поиск' })
        .click()
      await this.page.getByRole('row', { name: partyCode }).getByRole('checkbox').first().check()
      await this.page.getByRole('button', { name: ' Выбрать' }).click()
      await expect(this.page.getByRole('button', { name: ' Обновить' })).toBeVisible()
      await expect(
        this.page
          .getByTestId('MPPolicyHolderData-policyHolder')
          .locator('ng-component')
          .filter({ hasText: 'Страхователь и застрахованный совпадают' })
          .locator('i')
          .first()
      ).toBeVisible()
      await expect(this.page.getByTestId('MPPolicyHolderData-policyHolder').getByTestId('-input')).not.toBeEmpty()
      // await expect(this.page.getByTestId('MPPolicyHolderData-policyHolder').locator('app-text-input').getByRole('textbox')).not.toBeEmpty()
    })
  }

  async ADI_T9217(conclusionDate, validFrom, endDate) {
    await test.step('ADI-T9217 (1.0) [ПдИ] Проверка вкладки Условия страхования в роли Андеррайтер программа Отменяем обстоятельства', async () => {
      // Блок срок страхования
      await expect(this.page.getByTestId('MPPaymentDate-#').getByTestId('-input').first()).toHaveValue(conclusionDate)
      await expect(this.page.getByTestId('MPInsuranceDuration-#').getByTestId('-input').first()).toHaveValue(
        conclusionDate
      )
      await expect(this.page.getByTestId('MPPaymentDate-#').getByTestId('-input').nth(1)).toHaveValue(validFrom)
      await expect(this.page.getByTestId('MPInsuranceDuration-#').getByTestId('-input').nth(1)).toHaveValue(
        conclusionDate
      )
      await expect(
        this.page.getByTestId('MPPaymentDate-#').locator('numeric-input-bootstrap').getByTestId('-input')
      ).toHaveValue('12')
      await expect(this.page.getByTestId('MPInsuranceDuration-#').getByTestId('-input').nth(2)).toHaveValue(endDate)
      // Блок ОБЩЕЕ ДОБРОВОЛЬНОЕ СТРАХОВАНИЕ ОТ НЕСЧАСТНЫХ СЛУЧАЕВ И БОЛЕЗНЕЙ
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').first()).toHaveValue('3 050,00')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText(
        'Правила общего добровольного страхования от несчастных случаев и болезней'
      )
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('49-51(50)%')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('Весь мир')
      await expect(
        this.page.locator('.ai-percentage-permille-numeric-input-bootstrap > [id="-input"]').first()
      ).toHaveValue('50,00')
      // смерть в результате НСиБ
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(2)).toHaveValue('500 000,00')
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(3)).toHaveValue('2 570,00')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText(
        '1 год с даты наступления несчастного случая'
      )
      // Инвалидность в результате НС (1-группа)
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(4)).toHaveValue('500 000,00')
      await expect(
        this.page
          .getByTestId('MPPersonalRisks-#')
          .locator(
            'app-text-input > .ai-text-input-bootstrap-container > .form-group > .position-relative > .form-control'
          )
          .first()
      ).toHaveValue('150.34')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText(
        '1 год с даты наступления несчастного случая'
      )

      // Инвалидность в результате НС (2-группа)
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(5)).toHaveValue('500 000,00')
      await expect(
        this.page
          .getByTestId('MPPersonalRisks-#')
          .locator(
            'app-text-input > .ai-text-input-bootstrap-container > .form-group > .position-relative > .form-control'
          )
          .nth(1)
      ).toHaveValue('289.66')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText(
        '1 год с даты наступления несчастного случая'
      )
      // ВУТ
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(6)).toHaveValue('60 000,00')
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(7)).toHaveValue('40,00')

      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('Срок действия договора страхования')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('Срок страхования')
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(8)).toHaveValue('90')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('В днях в зависимости от условий')
      await expect(
        this.page
          .getByTestId('MPPersonalRisks-#')
          .locator(
            'app-text-input > .ai-text-input-bootstrap-container > .form-group > .position-relative > .form-control'
          )
          .nth(2)
      ).toHaveValue('В течение заданного количества дней с даты начала временной нетрудоспособности')
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(9)).toHaveValue('30')

      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText(
        'Доля от страховой суммы по договору за период'
      )
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('1 день')
      await expect(
        this.page.locator('.ai-percentage-permille-numeric-input-bootstrap > [id="-input"]').nth(1)
      ).toHaveValue('1,11')

      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('Лимит на выплату за период')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('30 дней')
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(11)).toHaveValue('20 000,00')

      // блока Фин.риски
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(12)).toHaveValue('1 950,00')

      await expect(
        this.page
          .locator('ng-select')
          .filter({ hasText: 'Правила страхования на случай потери работы×' })
          .getByRole('combobox')
      ).toBeVisible()
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('49-51(50)%')

      await expect(
        this.page.locator('.ai-percentage-permille-numeric-input-bootstrap > [id="-input"]').nth(2)
      ).toHaveValue('50,00')
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(14)).toHaveValue('50 000,00')
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(15)).toHaveValue('1 950,00')
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(16)).toHaveValue('100')
      await expect(
        this.page
          .locator('ng-select')
          .filter({ hasText: 'Количество дней от начала ответственности по договору' })
          .getByRole('combobox')
      ).toBeVisible()
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(17)).toHaveValue('60')

      await expect(
        this.page
          .locator('ng-select')
          .filter({ hasText: 'Количество месяцев от последней выплаты по страховому случаю×' })
          .getByRole('combobox')
      ).toBeVisible()
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(18)).toHaveValue('6')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText('В днях в зависимости от условий')
      await expect(
        this.page
          .getByTestId('MPPersonalRisks-#')
          .locator(
            'app-text-input > .ai-text-input-bootstrap-container > .form-group > .position-relative > .form-control'
          )
          .nth(3)
      ).toHaveValue('В течении заданного количества дней с даты прекращения Контракта')
      await expect(this.page.getByTestId('MPPersonalRisks-#').locator('#-input').nth(19)).toHaveValue('60')
      await expect(this.page.getByTestId('MPPersonalRisks-#')).toContainText(
        'Доля от страховой суммы по договору за период'
      )
      await expect(
        this.page.locator('.ai-percentage-permille-numeric-input-bootstrap > [id="-input"]').nth(3)
      ).toHaveValue('1,00')
    })
  }

  async ADI_T9216() {
    await test.step('ADI-T9216 (1.0) [ПдИ] Проверка полей вкладки "Договор" в роли Андеррайтер', async () => {
      // Блок "Орг.структура"
      await expect(
        this.page.locator('app-text-input').filter({ hasText: 'Подразделение --' }).getByRole('textbox')
      ).toHaveValue('Дирекция по розничному банкострахованию')
      await expect(
        this.page.locator('app-text-input').filter({ hasText: 'Город --' }).getByRole('textbox')
      ).toHaveValue('г. Москва')
      await expect(
        this.page.getByTestId('MPOrganisationInformation-policyData').getByTestId('-ng-select').first()
      ).toContainText('Прямые продажи')
      await expect(
        this.page.getByTestId('MPOrganisationInformation-policyData').getByTestId('-ng-select').nth(1)
      ).toContainText('КОРОБКИ- ВТБ')
      // Блок "Менеджер договора"
      await expect(
        this.page.locator('app-text-input').filter({ hasText: 'ФИО Менеджера --' }).getByRole('textbox')
      ).toHaveValue('Коротин Иван Львович')
      await expect(
        this.page.locator('app-text-input').filter({ hasText: 'Филиал --' }).getByRole('textbox')
      ).toHaveValue('Головной офис')
      // Блок "Ответственный руководитель"
      await expect(this.page.getByTestId('MPInsuranceSupervisor-#').getByTestId('-ng-select')).toContainText(
        'Епишина Е.В.'
      )
    })
  }

  async ADI_T9214(
    conclusionDate,
    validFrom,
    endDate,
    buildingType,
    buildingTypeDetailed,
    sumImovable,
    premiumImovable,
    sumMovable,
    premiumMovable,
    sumProperty,
    premiumProperty,
    sumCivil,
    premiumCivil,
    fullName,
    policyPremium
  ) {
    await test.step('ADI-T9214 (1.0) [ПдИ] Проверка вкладки Условия страхования в роли Андеррайтер', async () => {
      // Блок срок страхования
      await expect(this.page.getByTestId('MPPaymentDate-#').getByTestId('-input').first()).toHaveValue(conclusionDate)
      await expect(this.page.getByTestId('MPInsuranceDuration-#').getByTestId('-input').first()).toHaveValue(
        conclusionDate
      )
      await expect(this.page.getByTestId('MPPaymentDate-#').getByTestId('-input').nth(1)).toHaveValue(validFrom)
      await expect(this.page.getByTestId('MPInsuranceDuration-#').getByTestId('-input').nth(1)).toHaveValue(
        conclusionDate
      )
      await expect(
        this.page.getByTestId('MPPaymentDate-#').locator('numeric-input-bootstrap').getByTestId('-input')
      ).toHaveValue('12')
      await expect(this.page.getByTestId('MPInsuranceDuration-#').getByTestId('-input').nth(2)).toHaveValue(endDate)
      // Блок "Застрахованные объекты"

      // Раздел Недвижимое имущество

      await expect(this.page.locator('ng-select').filter({ hasText: buildingType }).getByRole('combobox')).toBeVisible()
      await expect(
        this.page.locator('ng-select').filter({ hasText: buildingTypeDetailed }).getByRole('combobox')
      ).toBeVisible()

      await expect(this.page.getByTestId('MPInsuredObjects-#').getByTestId('-input').first()).toHaveValue(sumImovable)
      await expect(this.page.getByTestId('MPInsuredObjects-#').getByTestId('-input').nth(1)).toHaveValue(
        premiumImovable
      )

      // Раздел Домашнее имущество
      await expect(
        this.page.locator('ng-select').filter({ hasText: 'Домашнее имущество' }).getByRole('combobox')
      ).toBeVisible()
      await expect(this.page.getByTestId('MPInsuredObjects-#').getByTestId('-input').nth(6)).toHaveValue(sumMovable)
      await expect(this.page.getByTestId('MPInsuredObjects-#').getByTestId('-input').nth(7)).toHaveValue(premiumMovable)

      // Блок "Застрахованные риски"

      // Раздел  Имущество
      await expect(this.page.getByTestId('MPInsuredRisks-#').getByTestId('-input').first()).toHaveValue(sumProperty)
      await expect(this.page.getByTestId('MPInsuredRisks-#').getByTestId('-input').nth(1)).toHaveValue(premiumProperty)
      await expect(
        this.page.getByTestId('MPInsuredRisks-#').locator('.ng-value').filter({ hasText: '169' }).first()
      ).toBeVisible()
      await expect(this.page.getByTestId('MPInsuredRisks-#').getByRole('combobox').first()).toBeVisible()
      // Раздел Гражданская ответственность
      await expect(this.page.getByTestId('MPInsuredRisks-#').getByTestId('-input').nth(18)).toHaveValue(sumCivil)
      await expect(this.page.getByTestId('MPInsuredRisks-#').getByTestId('-input').nth(19)).toHaveValue(premiumCivil)
      await expect(
        this.page.getByTestId('MPInsuredRisks-#').locator('.ng-value').filter({ hasText: '169' }).nth(1)
      ).toBeVisible()
      await expect(this.page.getByTestId('MPInsuredRisks-#').getByRole('combobox').first()).toBeVisible()

      // Раздел  "Общая информация" в боковом меню
      await expect(this.page.getByTestId('tab-Summary').locator('ai-tab')).toContainText(fullName)
      await expect(this.page.getByTestId('tab-Summary').locator('ai-tab')).toContainText(validFrom)
      await expect(this.page.getByTestId('tab-Summary').locator('ai-tab')).toContainText(endDate)
      await expect(this.page.getByTestId('tab-Summary').locator('ai-tab')).toContainText(policyPremium)
    })
  }

  async ADI_T7979(insuranceProgramme, docNumber, fullName, policyPremium, papercutDate, context, testInfo) {
    await test.step('ADI-T7979 (1.0) [ПдИ] Отправка уведомления плательщику по E-mail , способ оплаты Интернет-эквайринг/PAYMO', async () => {
      /**
     @param {string} insuranceProgramme - наименование программы страхования
     @param {string} docNumber - номер документа в заголовке
     @param {string} fullName - ФИО страхователя
     @param {string} policyPremium - общая страховая премия
     @param {string} papercutDate - дата в уведомлении papercut в формате ГГГ-ММ-ДД
     @param {string} context - контекст браузера для создания новой вкладки (передается из сценария)
     @param {string} testInfo - информация о тесте которая идет в отчет (передается из сценария)
       */
      await this.page.getByTestId('MPPayerData-#').getByRole('combobox').click()
      await this.page.getByRole('option', { name: 'E-mail' }).click()
      await this.page.getByRole('button', { name: ' Отправить уведомление' }).click()
      await expect(this.page.getByText('Уведомление успешно отправлено')).toBeVisible()
      await this.page.getByRole('button', { name: ' OK' }).click()

      const papercut = await context.newPage()
      await papercut.goto('https://test.adinsure.sogaz.ru:37408/')

      if (await papercut.getByRole('link', { name: 'Papercut SMTP' }).isVisible()) {
        await papercut.getByText(`Оплата полиса ${insuranceProgramme} №${docNumber}`).first().click()
        // console.log(await papercut.frameLocator('#preview-html').locator('div').textContent())
        const email = `
            Уважаемый(ая) ${fullName}.
            Ваш страховой продукт: ${insuranceProgramme}
            Номер вашего договора: ${docNumber}
            Итого сумма на оплату: ${policyPremium} руб.
            Для оплаты договора, пожалуйста, перейдите по ссылке: ссылка на оплату
            Срок оплаты страховой премии до - ${papercutDate}
            C уважением, АО «СОГАЗ»
            `
        await expect(papercut.frameLocator('#preview-html').locator('div')).toContainText(email)
        // проверка ссылки на оплату и отправка скриншота уведомления в отчет автотеста
        await expect(
          papercut.frameLocator('#preview-html').getByRole('link', { name: 'ссылка на оплату' })
        ).toHaveAttribute('href', /https:\/\/lk-stage\.sogaz\.ru\/p\/.*/) // проерка ссылки
        const screenshot = await papercut.screenshot()
        await testInfo.attach('Уведомление на оплату по E-mail', { body: screenshot, contentType: 'image/png' })
      } else {
        console.log('Ошибка авторизации или papercut не работает')
        await papercut.waitForTimeout(4000)
        const screenshot = await papercut.screenshot()
        await testInfo.attach('Скриншот страницы papercut', { body: screenshot, contentType: 'image/png' })
      }
    })
  }

  async ADI_T12648(
    subjectSms,
    insuranceProgramme,
    docNumber,
    firstName,
    midleName,
    policyPremium,
    papercutDate,
    context,
    testInfo
  ) {
    await test.step('ADI-T12648 (1.0) [ПдИ] Отправка уведомления плательщику по SMS, способ оплаты Интернет-эквайринг/PAYMO', async () => {
      await this.page.getByTestId('MPPayerData-#').getByRole('combobox').click()
      await this.page.getByRole('option', { name: 'SMS' }).click()
      await this.page.getByRole('button', { name: 'Отправить уведомление' }).click()
      await expect(this.page.getByText('Уведомление успешно отправлено')).toBeVisible()
      await this.page.getByRole('button', { name: 'OK' }).click()

      const papercut = await context.newPage()
      await papercut.goto('https://test.adinsure.sogaz.ru:37408/')
      if (await papercut.getByRole('link', { name: 'Papercut SMTP' }).isVisible()) {
        await papercut.getByText(subjectSms).first().click()
        await papercut.waitForTimeout(3000)
        // проверка текста
        //       const regSms = new RegExp(
        //     `${firstName} ${midleName}.
        // Для оплаты ${policyPremium} руб. по полису ${insuranceProgramme}
        // № ${docNumber}, пожалуйста, перейдите по ссылке: https:\/\/lk-stage\.sogaz\.ru\/p\/.*
        // Срок оплаты страховой премии до - ${papercutDate}
        // АО «СОГАЗ»`)

        //       await expect.soft(papercut.locator('#preview-plain.tab-pane.ng-binding.active')).toContainText(regSms)

        await expect(papercut.getByTestId('preview-plain')).toContainText(`${firstName} ${midleName}.`)
        await expect(papercut.getByTestId('preview-plain')).toContainText(
          `Для оплаты ${policyPremium} руб. по договору страхования ${insuranceProgramme}`
        )
        await expect(papercut.getByTestId('preview-plain')).toContainText(
          `№ ${docNumber}, пожалуйста, перейдите по ссылке: `
        )
        await expect.soft(papercut.getByTestId('preview-plain')).toContainText(/https:\/\/lk-stage\.sogaz\.ru\/p\/.*/)
        await expect(papercut.getByTestId('preview-plain')).toContainText(
          `Срок оплаты страховой премии до - ${papercutDate}`
        )
        await expect(papercut.getByTestId('preview-plain')).toContainText('АО «СОГАЗ»')
        // проверка ссылки на оплату и отправка скриншота уведомления в отчет автотеста
        await expect
          .soft(papercut.getByTestId('preview-plain').getByRole('link', { name: 'https://lk-stage.sogaz.ru/p/' }))
          .toHaveAttribute('href', /https:\/\/lk-stage\.sogaz\.ru\/p\/.*/) // проерка ссылки
        const screenshot = await papercut.screenshot()
        await testInfo.attach('Уведомление на оплату по SMS', { body: screenshot, contentType: 'image/png' })
      } else {
        console.log('Ошибка авторизации или papercut не работает')
        await papercut.waitForTimeout(4000)
        const screenshot = await papercut.screenshot()
        await testInfo.attach('Скриншот страницы papercut', { body: screenshot, contentType: 'image/png' })
      }
    })
  }
}
