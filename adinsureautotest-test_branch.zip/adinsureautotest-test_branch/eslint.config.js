import globals from 'globals'
import pluginJs from '@eslint/js'
import { globalIgnores } from 'eslint/config'
import playwright from 'eslint-plugin-playwright'
import jsdoc from 'eslint-plugin-jsdoc'
import prettierPlugin from 'eslint-plugin-prettier'
import eslintConfigPrettier from 'eslint-config-prettier'
// @ts-ignore
import importPlugin from 'eslint-plugin-import'

/** @type {import('eslint').Linter.Config[]} */
export default [
  globalIgnores(['**/node_modules/', '**/test-results/', '**/playwright-report/', '**/jsdoc/', '.git/']),
  {
    languageOptions: {
      globals: {
        ...globals.node,
        ...globals.es2019,
      },
      parserOptions: {
        ecmaVersion: 'latest',
        sourceType: 'module',
      },
    },
    settings: {
      'import/resolver': {
        // node: {
        //   extensions: ['.js', '.json'],
        // },
        alias: {
          map: [
            ['@core', './core'],
            ['@fixtures', './fixtures'],
            ['@framework', './framework'],
            ['@pages', './pages'],
            ['@steps', './test-steps'],
            ['@utils', './utils'],
          ],
          extensions: ['.js', '.json'],
        },
      },
    },
  },
  pluginJs.configs.recommended,
  /**
   * Правила для импортов
   */
  {
    plugins: { import: importPlugin },
    rules: {
      'no-restricted-imports': [
        'error',
        {
          patterns: [
            {
              group: ['../*', './*'],
              message:
                '\n\nОтносительные импорты не используем!\n' + 'Используйте алиасы "@" вместо: "../**" или "./**"\n',
            },
          ],
        },
      ],
      'import/no-unresolved': ['warn'],
      'import/no-relative-parent-imports': 'off',
      'import/no-useless-path-segments': ['error', { noUselessIndex: true }],
    },
  },
  // {
  //   files: ['*.js', '*.mjs', '*.cjs'],
  //   rules: {
  //     // Customize JavaScript rules
  //   },
  // },
  /**
   * Playwright linting
   */
  {
    ...playwright.configs['flat/recommended'],
    files: ['test-steps/**/*.js', 'tests/**/*.spec.js'],
    rules: {
      ...playwright.configs['flat/recommended'].rules,
      // Customize Playwright rules
      'playwright/missing-playwright-await': 'error',
      'playwright/no-wait-for-timeout': 'error',
      'playwright/no-conditional-in-test': 'off',
      'playwright/expect-expect': 'off',
    },
  },
  /**
   * JSDoc linting
   */
  jsdoc.configs['flat/recommended'],
  {
    files: ['**/*.js'],
    plugins: {
      jsdoc,
    },
    rules: {
      'jsdoc/require-description': 'warn',
    },
  },
  /**
   * Prettier
   */
  {
    plugins: { prettier: prettierPlugin },
    rules: {
      'prettier/prettier': ['error', { usePrettierrc: true }],
    },
  },
  eslintConfigPrettier,
]
