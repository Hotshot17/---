import { defineConfig, devices } from '@playwright/test'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'
import { dirname } from 'path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

const launchName = process.env.FOLDER_NAME || 'Local launch'
const version = process.env.CHANGELOG_VERSION || 'not assigned'

const RPconfig = {
  apiKey: process.env.RP_TOKEN,
  endpoint: 'http://10.27.0.82:8082/api/v1',
  project: 'adinsure',
  launch: launchName,
  attributes: [
    {
      key: 'version',
      value: version,
    },
  ],
  includeTestSteps: true,
  extendTestDescriptionWithLastError: true,
}

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// require('dotenv').config();
dotenv.config({ path: path.resolve(__dirname, '.env') })

/**
 * @see https://playwright.dev/docs/test-configuration
 */

export default defineConfig({
  testDir: './tests',
  timeout: 30 * 60 * 1000, //default: 30 seconds
  expect: {
    timeout: 60 * 1000, //default: 5 seconds
    toHaveScreenshot: {
      threshold: 0.6,
      pathTemplate: '{testDir}/{testFileDir}/__screenshots__/{testFileName}/{arg}{ext}',
    },
    toMatchAriaSnapshot: {
      pathTemplate: '{testDir}/{testFileDir}/__snapshots__/{testFileName}/{arg}{ext}',
    },
  },
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 0 : 0,
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 3 : undefined,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  // reporter: process.env.CI ? 'blob' : 'html',
  reporter: [['@reportportal/agent-js-playwright', RPconfig]],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    /* Base URL to use in actions like `await page.goto('/')`. */
    // baseURL: 'http://127.0.0.1:3000',

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    trace: 'off',
    testIdAttribute: 'id',
    ignoreHTTPSErrors: true,
    actionTimeout: 60 * 1000, //default: no timeout
    navigationTimeout: 60 * 1000, //default: no timeout
  },

  /* Configure projects for major browsers */
  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
        channel: 'chromium',
        viewport: { width: 1600, height: 900 },
        headless: true,
        screenshot: {
          mode: 'only-on-failure',
          fullPage: true,
        },
        launchOptions: {
          slowMo: 500,
        },
      },
    },

    {
      name: 'firefox',
      use: {
        ...devices['Desktop Firefox'],
        viewport: { width: 1600, height: 900 },
        headless: true,
        screenshot: {
          mode: 'only-on-failure',
          fullPage: true,
        },
        launchOptions: {
          firefoxUserPrefs: {
            'pdfjs.disabled': false,
          },
          slowMo: 500,
        },
      },
    },

    // // Для тестирования в браузере мобильного устройства
    // {
    //   name: 'mobile',
    //   use: {
    //     userAgent:
    //       'Mozilla/5.0 (Linux; Android 11; Realme Note 50) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Mobile Safari/537.36',
    //     viewport: { width: 480, height: 1066 },
    //     deviceScaleFactor: 1.5,
    //     isMobile: true,
    //     hasTouch: true,
    //     defaultBrowserType: 'chromium',
    //     video: {
    //       mode: 'on',
    //       size: { width: 480, height: 1066 },
    //     },
    //   },
    // },

    // {
    //   name: 'Adinsure_Stage (firefox)',
    //   use: {
    //     ...devices['Desktop Firefox'],
    //     viewport: { width: 1600, height: 900 },
    //     launchOptions: {
    //       firefoxUserPrefs: {
    //         'pdfjs.disabled': false
    //       }
    //     }
    //   }
    // }

    // {
    //   name: "webkit",
    //   use: { ...devices["Desktop Safari"] },
    // },

    /* Test against mobile viewports. */
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: { ...devices['iPhone 12'] },
    // },

    /* Test against branded browsers. */
    // {
    //   name: 'Microsoft Edge',
    //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
    // },
    // {
    //   name: 'Google Chrome',
    //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    // },
  ],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://127.0.0.1:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
})
