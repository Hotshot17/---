import { test as baseTest, expect, errors } from '@playwright/test'
import { StepGeneral } from '@steps/stepGeneral'
import { StepPropertyLegalEntities } from '@steps/StepPropertyLegalEntities/stepPropertyLegalEntities'
import { StepMortgageVTB } from '@steps/StepMortgageVTB/stepMortgageVTB'
import { StepTravelInsurance } from '@steps/StepTravelinsurance/stepTravelInsurance'
import { StepMotorCasco } from '@steps/StepMotorCasco/stepMotorCasco'
import { StepMotorCascoPark } from '@steps/StepMotorCascoPark/stepMotorCascoPark'
import { StepMortgageProperty } from '@steps/StepMortgageProperty/stepMortgageProperty'
import { StepSpecTechnics } from '@steps/StepSpecTechnics/stepSpecTechnics'
import { StepMTPL } from '@steps/StepMTPL/stepMTPL'
import { StepMTPLPark } from '@steps/StepMTPLPark/stepMTPLPark'
import { StepSogazFlat } from '@steps/StepSogazFlat/stepSogazFlat'
import { StepAgentAgreements } from '@steps/StepAgentAgreements/stepAgentAgreements'
import { StepGeneralFunctionality } from '@steps/StepGeneralFunctionality/stepGeneralFunctionality'
import { StepCargo } from '@steps/StepCargo/stepCargo'
import { StepPersonalMedicalInsurance } from '@steps/StepPersonalMedicalInsurance/stepPersonalMedicalInsurance'
import { StepPersonalPropertyFlat } from '@steps/StepPersonalPropertyFlat/stepPersonalPropertyFlat'
import { StepRealEstateProtection } from '@steps/StepRealEstateProtection/stepRealEstateProtection'
import { StepGLI } from '@steps/StepGeneralLiabilityInsurance/stepGLI'
import { StepAcciedent } from '@steps/StepAcciedent/stepAcciedent'
import { DataHandler } from './resultLoader'
import { StepSogazShop } from '@steps/StepSogazShop/stepSogazShop'
import { StepUniversalBoxConfiguration } from '@steps/StepUniversalBoxConfiguration/stepUniversalBoxConfiguration'

/**
 * @typedef MyFixtures
 * @type {object}
 * @property {StepGeneral} stepGeneral - тут должно быть описание
 * @property {StepTravelInsurance} stepTravelInsurance - ВПМЖ
 * @property {StepPropertyLegalEntities} stepPLE - тут должно быть описание
 * @property {StepMotorCasco} stepMotorCasco - СОГАЗ-Авто
 * @property {StepMotorCascoPark} stepMotorCascoPark - СОГАЗ-Авто ПАРКИ
 * @property {StepMortgageVTB} stepMortgageVTB - Ипотека ВТБ
 * @property {StepMortgageProperty} stepMortgageProperty - Преимущество для ипотеки
 * @property {StepSpecTechnics} stepSpecTechnics - Спецтехника
 * @property {StepMTPL} stepMTPL - ОСАГО
 * @property {StepMTPLPark} stepMTPLPark - ОСАГО Парки
 * @property {StepSogazFlat} stepSogazFlat - СОГАЗ-Квартира
 * @property {StepAgentAgreements} stepAgentAgreements - Агентские договоры и КВ
 * @property {StepGeneralFunctionality} stepGeneralFunctionality - Общая функциональность
 * @property {StepCargo} stepCargo - Грузы
 * @property {StepPersonalMedicalInsurance} stepPersonalMedicalInsurance - Спутник здоровья
 * @property {StepPersonalPropertyFlat} stepPersonalPropertyFlat - Имущество ФЛ (Квартира)
 * @property {StepRealEstateProtection} stepRealEstateProtection - Защита Недвижимости
 * @property {StepGLI} stepGLI - Общегражданская ответственность
 * @property {StepAcciedent} stepAcciedent - Несчастный случай
 * @property {StepSogazShop} stepSogazShop - Сайт
 * @property {StepUniversalBoxConfiguration} stepUBC - Коробочный пррдукт
 */

/**
 * @type {import('@playwright/test').TestType<import('@playwright/test').PlaywrightTestArgs & import('@playwright/test').PlaywrightTestOptions & MyFixtures & {forEachWorker:void}, import('@playwright/test').PlaywrightWorkerArgs & import('@playwright/test').PlaywrightWorkerOptions>}
 */

export const test = baseTest.extend({
  stepGeneral: async ({ page }, use) => {
    await use(new StepGeneral(page))
  },

  stepAcciedent: async ({ page }, use) => {
    await use(new StepAcciedent(page))
  },

  stepTravelInsurance: async ({ page }, use) => {
    await use(new StepTravelInsurance(page))
  },

  stepPLE: async ({ page }, use) => {
    await use(new StepPropertyLegalEntities(page))
  },

  stepMotorCasco: async ({ page }, use) => {
    await use(new StepMotorCasco(page))
  },

  stepMotorCascoPark: async ({ page }, use) => {
    await use(new StepMotorCascoPark(page))
  },

  stepMortgageVTB: async ({ page }, use) => {
    await use(new StepMortgageVTB(page))
  },

  stepMortgageProperty: async ({ page }, use) => {
    await use(new StepMortgageProperty(page))
  },

  stepSpecTechnics: async ({ page }, use) => {
    await use(new StepSpecTechnics(page))
  },

  stepMTPL: async ({ page }, use) => {
    await use(new StepMTPL(page))
  },

  stepMTPLPark: async ({ page }, use) => {
    await use(new StepMTPLPark(page))
  },

  stepSogazFlat: async ({ page }, use) => {
    await use(new StepSogazFlat(page))
  },

  stepAgentAgreements: async ({ page }, use) => {
    await use(new StepAgentAgreements(page))
  },

  stepGeneralFunctionality: async ({ page }, use) => {
    await use(new StepGeneralFunctionality(page))
  },

  stepCargo: async ({ page }, use) => {
    await use(new StepCargo(page))
  },

  stepPersonalMedicalInsurance: async ({ page }, use) => {
    await use(new StepPersonalMedicalInsurance(page))
  },

  stepPersonalPropertyFlat: async ({ page }, use) => {
    await use(new StepPersonalPropertyFlat(page))
  },

  stepRealEstateProtection: async ({ page }, use) => {
    await use(new StepRealEstateProtection(page))
  },

  stepGLI: async ({ page }, use) => {
    await use(new StepGLI(page))
  },

  stepSogazShop: async ({ page }, use) => {
    await use(new StepSogazShop(page))
  },
  stepUBC: async ({ page }, use) => {
    await use(new StepUniversalBoxConfiguration(page))
  },

  forEachWorker: [
    async ({ page }, use, testInfo) => {
      await use()

      // let code

      if (testInfo.status === 'passed' || testInfo.status === 'failed' || testInfo.status === 'timedOut') {
        console.log(page.url())
      }
    },
    { auto: true },
  ],
  /*
      if (testInfo.status === testInfo.expectedStatus) return

      const responsePromise = page.waitForResponse(
        (response) => response.url().includes('/get-initial-view-model') && response.status() === 200
      )

      await page.reload()
      const response = await responsePromise
      const json = await response.json()

      const validationResult = json.ValidationResult.schemaValidations || []

      if (validationResult.length === 0) {
        let url = page.url()

        const regex = /configurationCodeName=([^;]+)/
        const match = url.match(regex)

        if (match && match[1]) {
          code = match[1].trim()
        }
        let quoteNumber = await page.getByTestId('ai-info-control').textContent()
        const responsePromise = page.waitForResponse(
          `https://stage.adinsure.sogaz.ru/server/api/pas/internal/contracts/${code}/1/${quoteNumber}`
        )

        await page.reload()
        const response = await responsePromise
        const json = await response.json()

        const validationResult = json.Data.validationResult.schemaValidations || []
        let errors = []

        validationResult.forEach((error) => {
          errors.push({
            message: error.message,
            code: error.code,
            severity: error.severity,
          })
        })

        errors.forEach((error) => {
          console.log(` ${error.message}`)
        })
      } else {
        let errors = []

        validationResult.forEach((error) => {
          errors.push({
            message: error.message,
            code: error.code,
            severity: error.severity,
          })
        })

        errors.forEach((error) => {
          console.log(` ${error.message}`)
        })
      }
    },
    { auto: true },
  ],
  */

  autoWorkerFixture: [
    async ({ request }, use, testInfo) => {
      const dataHandler = new DataHandler(request)
      await use()

      // if (testInfo.status === 'passed' || testInfo.status === 'failed' || testInfo.status === 'timedOut') {
      //   console.log(page.url())
      // }

      // try {
      //   if (testInfo.status === 'failed' || testInfo.status === 'timedOut') {
      //     console.log(page.url())
      //     const text = await page.locator('.modal-body').textContent()

      //     if (text.includes('не разрешено из-за ошибок.')) {
      //       await page.getByRole('button', { name: ' Закрыть' }).click()
      //       await page.getByTestId('tab-Notifications-nav').click()
      //       const elements = await page.getByTestId('RequiredPropertiesValidations').locator('.ai-error-message')

      //       console.log('Ошибки :')
      //       for (let i = 0; i < (await elements.count()); i++) {
      //         const value = await elements.nth(i).textContent()
      //         console.log(`${i + 1}) ${value}`)
      //       }
      //     }

      //     if (text.includes('Укажите страхователя')) {
      //       await page.getByRole('button', { name: ' OK' }).click()
      //       await page.getByTestId('tab-Notifications-nav').click()
      //       const elements = await page.getByTestId('RequiredPropertiesValidations').locator('.ai-error-message')

      //       console.log('Ошибки :')
      //       for (let i = 0; i < (await elements.count()); i++) {
      //         const value = await elements.nth(i).textContent()
      //         console.log(`${i + 1}) ${value}`)
      //       }
      //     }
      //   }
      //   if (testInfo.status === 'passed') {
      //     console.log(page.url())
      //   }
      // } catch (error) {
      //   console.log(`Catched error: ${error}\n Failed to load data from fixure`)
      // }

      try {
        if (process.env.BRANCH_NAME === 'master') {
          const handledTestInfo = await dataHandler.handleTestInfo(testInfo.titlePath, testInfo.title)

          if (handledTestInfo.checkTitle) {
            let tcKey
            let tcTestRunKey
            let tcStatus
            const handledStatus = await dataHandler.handleStatus(
              tcKey,
              tcTestRunKey,
              tcStatus,
              handledTestInfo.testTitle
            )

            if (handledStatus.tcTestRunKey) {
              switch (handledStatus.tcStatus) {
                case 'Pass':
                  if (
                    (testInfo.status !== 'passed' &&
                      typeof handledStatus.responseBody.testScriptResults[0].parameterSetId !== 'undefined') ||
                    (testInfo.status !== 'passed' && handledTestInfo.testDescribeString.length > 2)
                  ) {
                    await dataHandler.setStatus(
                      testInfo.status,
                      handledStatus.responseBody.id,
                      testInfo.duration,
                      handledTestInfo.testTitle
                    )
                  }
                  break
                case 'Fail':
                  if (
                    typeof handledStatus.responseBody.testScriptResults[0].parameterSetId === 'undefined' &&
                    handledTestInfo.testDescribeString.length <= 2 &&
                    testInfo.status === 'passed'
                  ) {
                    await dataHandler.setStatus(
                      testInfo.status,
                      handledStatus.responseBody.id,
                      testInfo.duration,
                      handledTestInfo.testTitle
                    )
                  }
                  break
                case 'Not Executed':
                  await dataHandler.setStatus(
                    testInfo.status,
                    handledStatus.responseBody.id,
                    testInfo.duration,
                    handledTestInfo.testTitle
                  )
                  break
                case 'Замечание':
                  break
                default:
                  // console.log(`Актуальный статус ручного сценария "tcStatus": ${handledStatus.tcStatus}`)
                  break
              }
            } else {
              console.log(
                `Не удалось прочитать данные из tcTestRunKey: ${handledStatus.tcTestRunKey} \n Актуальный тип данных "tcTestRunKey": ${typeof handledStatus.tcTestRunKey}`
              )
            }
          }
        }
      } catch (error) {
        console.log(`Не удалось выгрузить данные в ZS \nТекст ошибки: ${error}`)
      }
    },
    { auto: true },
  ],

  // autoWorkerFixture: [async ({ page }, use, testInfo) => {
  //   await use()

  //   const pageUrl = page.url()
  //   if (!(pageUrl.includes('entity=Contract') || pageUrl.includes('entity=UniversalDocument'))) return

  //   console.log(page.url())

  //   if (testInfo.status === testInfo.expectedStatus) return

  //   const responsePromise = page.waitForResponse(response =>
  //     response.url().includes('/get-initial-view-model') && response.status() === 200
  //   )

  //   await page.reload()
  //   const response = await responsePromise
  //   const json = await response.json()

  //   const errors = getErrorsFromViewModel(json)

  //   console.log('Ошибки валиации документа:')
  //   errors.forEach((error, number) => {
  //     console.log(`Номер ошибки: ${number + 1}`)
  //     console.log(`Сообщение: ${error.message}`)
  //     // console.log(`Code: ${error.code}`)
  //     // console.log(`Строгость: ${error.severity}`)
  //   })
  // }, { auto: true }]
})
export { expect } from '@playwright/test'
