import { expect as expect } from '@playwright/test'

const authTokenSaft = 'Ds23aDFGER1RZR1Z30WaDFGER1qRnYaJkOB__7FDSZB__7FDSaDFGER1T5CMwH*HHN3tH*HHN3'
const baseUrl = 'https://jira.sogaz.ru/rest/tests/1.0/'
const jiraOrigin = 'https://jira.sogaz.ru'
const reportUrl = 'http://10.27.0.82:8082/ui/#adinsure/launches/all/'

const passedStatus = 90
const failedStatus = 91

let response
let responseBody

export class DataHandler {
  /**
   * @param {any} request
   */
  constructor(request) {
    this.request = request
  }

  /**
   * Обработка информации выполненного автотеста
   * @param {string} titlePath - абсолютный путь автотеста
   * @param {string} testTitle - заголовок автотеста
   */
  async handleTestInfo(titlePath, testTitle) {
    let checkTitle = true
    let testDescribeString = JSON.stringify(titlePath).split('","')

    try {
      testTitle = JSON.stringify(titlePath)
      testTitle = testTitle.match(/(ADI-T\d+)/)[0]
    } catch (error) {
      console.log(
        `Не удалось прочитать номер тестового сценария из testInfo.title: ${testTitle} \nАктуальный тип данных "testInfo.title": ${typeof testTitle}`
      )
      checkTitle = false
    }
    return { checkTitle, testDescribeString, testTitle }
  }

  /**
   * Обработка актуального статуса ручного теста в ZephyrScale
   * @param {string} tcKey - уникальный ключ тестового сценария
   * @param {any} tcTestRunKey - уникальный ключ тестового прогона
   * @param {string} tcStatus - статус тестового сценария
   * @param {string} testTitle - заголовок автотеста (для отладки)
   */
  async handleStatus(tcKey, tcTestRunKey, tcStatus, testTitle) {
    response = await this.request.get(`${baseUrl}testcase/${testTitle}?fields=id`, {
      headers: {
        authorization: `Basic ${authTokenSaft
          // @ts-ignore
          .replaceAll('aDFGER1', 'Q')
          .replaceAll('H*HHN3', 'ADM')
          .replaceAll('B__7FDS', 'U')
          .replaceAll('Ds23', '==')
          .split('')
          .reverse()
          .join('')}`,
      },
    })
    try {
      expect(response.status()).toBe(200)
    } catch (error) {
      console.log(
        `Не удалось прочитать заголовок автотеста: ${testTitle} \nТекущий тип данных из "testTitle": ${typeof testTitle}`
      )
      tcTestRunKey = false
      return tcTestRunKey
    }
    responseBody = await response.json()

    response = await this.request.get(
      `${baseUrl}testcase/${responseBody.id}/testresults?fields=testResultStatus(name),key,automated,testRun,testCas&limit=20&offset=0`
    )
    expect(response.status()).toBe(200)
    responseBody = await response.json()
    try {
      tcKey = responseBody.data[0].key
    } catch (error) {
      console.log(
        `Данный сценарий ${testTitle} отсутствует в прогоне. Не удалось прочитать данные из key: ${responseBody.data[0]} \nАктуальный тип данных "key": ${typeof responseBody.data[0].key}`
      )
    }
    try {
      tcTestRunKey = responseBody.data[0].testRun.id
    } catch (error) {
      console.log(
        `Не удалось прочитать данные из testRunID: ${responseBody.data[0]} \nАктуальный тип данных "testRunID": ${typeof responseBody.data[0].testRun.id}`
      )
    }
    try {
      tcStatus = responseBody.data[0].testResultStatus.name
    } catch (error) {
      console.log(
        `Не удалось прочитать данные из testResultStatus: ${responseBody.data[0]} \nАктуальный тип данных "testResultStatus": ${typeof responseBody.data[0].testResultStatus.name}`
      )
    }
    response = await this.request.get(`${baseUrl}testresult/${tcKey}?fields=id,testScriptResults(parameterSetId)`)
    expect(response.status()).toBe(200)
    responseBody = await response.json()
    return { tcKey, tcTestRunKey, tcStatus, responseBody }
  }

  /**
   * Установка статуса в ручной сценарий
   * @param {string} testInfoStatus - актуальный статус выполнения автотеста
   * @param {any} id - id результата ручного сценария
   * @param {any} duration - фактическое время выполнения автотеста
   * @param {string} testTitle - заголовок автотеста (для отладки)
   */
  async setStatus(testInfoStatus, id, duration, testTitle) {
    switch (testInfoStatus) {
      case 'passed':
        try {
          response = await this.request.put(`${baseUrl}testresult`, {
            data: [
              {
                id: id,
                executionTime: duration,
                testResultStatusId: passedStatus,
              },
            ],
            headers: {
              Origin: jiraOrigin,
            },
          })
        } catch (error) {
          console.log(`Не удалось установить статус тестового сценария: ${testTitle}`)
          console.log(error)
        }
        try {
          response = await this.request.post(`${baseUrl}customfieldvalue`, {
            data: {
              customField: {
                archived: false,
                name: 'Report',
                index: 1,
                id: 118,
                type: 'MULTI_LINE_TEXT',
                projectId: 11400,
                required: false,
              },
              stringValue: `<a href="${reportUrl}">${reportUrl}</a>`,
              testResultId: id,
            },
            headers: {
              Origin: jiraOrigin,
            },
          })
        } catch (error) {
          console.log(`Не удалось оставить ссылку на прогон тестового сценария: ${testTitle}`)
          console.log(error)
        }
        expect(response.status()).toBe(200)
        break
      case 'failed':
        try {
          response = await this.request.put(`${baseUrl}testresult`, {
            data: [
              {
                id: id,
                executionTime: duration,
                testResultStatusId: failedStatus,
              },
            ],
            headers: {
              Origin: jiraOrigin,
            },
          })
        } catch (error) {
          console.log(`Не удалось установить статус тестового сценария: ${testTitle}`)
          console.log(error)
        }
        try {
          response = await this.request.post(`${baseUrl}customfieldvalue`, {
            data: {
              customField: {
                archived: false,
                name: 'Report',
                index: 1,
                id: 118,
                type: 'MULTI_LINE_TEXT',
                projectId: 11400,
                required: false,
              },
              stringValue: `<a href="${reportUrl}">${reportUrl}</a>`,
              testResultId: id,
            },
            headers: {
              Origin: jiraOrigin,
            },
          })
        } catch (error) {
          console.log(`Не удалось оставить ссылку на прогон тестового сценария: ${testTitle}`)
          console.log(error)
        }
        expect(response.status()).toBe(200)
        break
      default:
        console.log(
          `Не удалось прочитать актуальный статус автотеста testInfo.status: ${testInfoStatus} \nАктуальный тип данных "testInfoStatus": ${typeof testInfoStatus}`
        )
        break
    }
  }
}
