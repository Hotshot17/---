import { execSync } from 'child_process'
import * as fs from 'fs'

const GIT_URL = 'https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/{hash}'

class CommitParser {
  static parse(rawCommit) {
    try {
      const lines = rawCommit.split('\n').filter((l) => l.trim() !== '')
      if (lines.length < 4) {
        console.log('Invalid commit format:', rawCommit)
        return null
      }

      // Извлекаем хеш, дату
      const hash = lines[0].replace('commit ', '').trim()
      const dateLine = lines.find((l) => l.startsWith('Date:'))
      const date = dateLine ? dateLine.replace('Date:', '').trim() : ''

      // Извлекаем тело коммита
      const bodyStartIndex = lines.findIndex((l) => l.startsWith('Date:')) + 1
      const bodyLines = lines.slice(bodyStartIndex).map((l) => l.replace(/^ {4}/, ''))

      // Парсим subject
      const subject = bodyLines[0]?.trim() || ''
      const subjectRegex = /^(?<type>[a-zA-Zа-яА-Я]+)\((?<context>[^)]+)\):\s+(?<description>.+?)(?<breaking>!?)$/u
      const match = subject.match(subjectRegex)

      if (!match?.groups) {
        console.log('Invalid subject format:', subject)
        return null
      }

      const { type, context, description, breaking } = match.groups

      // Разделяем body и footer с учетом пустой строки
      const [body, footer] = this.splitBodyFooter(bodyLines.slice(1).join('\n'))

      return {
        hash,
        date: this.formatDate(date),
        context: context.trim(),
        type: type.trim().toLowerCase(),
        description: description.trim(),
        breaking: Boolean(breaking || this.hasBreakingChange(footer)),
        body: body?.trim() || null,
        footer: footer?.trim() || null,
      }
    } catch (e) {
      console.error('Error parsing commit:', e.message)
      return null
    }
  }

  static hasBreakingChange(footer) {
    return footer?.includes('BREAKING CHANGE:')
  }

  static splitBodyFooter(body) {
    const lines = body.split('\n')

    // Ищем пустую строку перед сносками
    const emptyLineIndex = lines.findIndex((l) => l.trim() === '')
    if (emptyLineIndex !== -1) {
      return [lines.slice(0, emptyLineIndex).join('\n'), lines.slice(emptyLineIndex + 1).join('\n')]
    }

    // Ищем первую корректную сноску
    const footerStart = lines.findIndex(
      (l) => l.startsWith('BREAKING CHANGE:') || /^[a-z-]+(\s*:\s*|\s+#)/.test(l.trim())
    )

    return footerStart === -1
      ? [body, null]
      : [lines.slice(0, footerStart).join('\n'), lines.slice(footerStart).join('\n')]
  }

  static formatDate(rawDate) {
    try {
      const date = new Date(rawDate)
      return date.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' })
    } catch {
      return rawDate
    }
  }
}

/**
 *
 */
function getGitLog() {
  try {
    const output = execSync('git log --no-merges', { encoding: 'utf-8' })
    return output.split('\ncommit ').map((c) => c.trim()) // Разделяем коммиты
  } catch (error) {
    console.error('Error fetching git log:', error.message)
    process.exit(1)
  }
}

/**
 *
 * @param commit
 */
function formatCommit(commit) {
  // let entry = `- **${commit.type}(${commit.context})${commit.breaking ? '!' : ''}:** ${commit.description}\n`;
  let entry = `- **${commit.description}**\n`
  // let entry = `- **${commit.description}**\n`;
  entry += `  [(${commit.hash.slice(0, 7)})](${GIT_URL.replace('{hash}', commit.hash)})\n`

  if (commit.body) {
    entry += `\n\n  ${commit.body.replace(/\n/g, '\n  ')}`
  }
  if (commit.footer) {
    entry += `\n\n  ${commit.footer.replace(/\n/g, '\n  ')}`
  }
  return entry + '\n'
}

// Остальной код (generateChangelog, запись в файл) остается без изменений, как в предыдущем ответе.

/**
 *
 */
function generateChangelog() {
  const commits = getGitLog()
    .map((raw) => CommitParser.parse(raw))
    .filter(Boolean)

  console.log('Parsed', commits.length, 'valid commits')

  const grouped = commits.reduce((acc, commit) => {
    acc[commit.date] = acc[commit.date] || {}
    acc[commit.date][commit.context] = acc[commit.date][commit.context] || {
      types: new Map(),
      breaking: [],
    }

    const ctxGroup = acc[commit.date][commit.context]
    if (commit.breaking) {
      ctxGroup.breaking.push(commit)
    } else {
      const typeKey = commit.type
      if (!ctxGroup.types.has(typeKey)) {
        ctxGroup.types.set(typeKey, [])
      }
      ctxGroup.types.get(typeKey).push(commit)
    }

    return acc
  }, {})

  let changelog = ''
  for (const [date, contexts] of Object.entries(grouped)) {
    changelog += `## ${date}\n\n`
    for (const [context, data] of Object.entries(contexts)) {
      changelog += `### ${context}\n\n`

      if (data.breaking.length) {
        changelog += `#### BREAKING CHANGES\n`
        data.breaking.forEach((commit) => {
          changelog += formatCommit(commit)
        })
        changelog += '\n'
      }

      for (const [type, commits] of data.types) {
        changelog += `#### ${type}\n`
        commits.forEach((commit) => {
          changelog += formatCommit(commit)
          // changelog += '***'
        })
        changelog += '\n'
      }
    }
  }

  return changelog || '# No valid commits found\n'
}

fs.writeFileSync('CHANGELOG.md', generateChangelog())
console.log('CHANGELOG.md успешно сгенерирован!')
