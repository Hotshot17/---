## 15.08.2025

### ИПОТЕКА ВТБ

#### fix
- **Актуализация**
  [(1f4765c)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1f4765c9419250ccdd68ef81b49d9de8d4d99519)


### НСиБ

#### feat
- **Автоматизация ADI-T18906**
  [(4cf86ad)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/4cf86adb70e93fdc7247ac326e641c148766c73d)


  1. Автоматизирован ТС ADI-T18906
  2. Автоматизирован ТК ADI-T3277
  3. Добавлены локаторы

## 14.08.2025

### НСиБ

#### feat
- **Автоматизация ADI-T18782**
  [(be571fd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/be571fd890eb233ae44bd86161edd9bbb378a390)


  1. Автоматизирован ТС ADI-T18782
  2. Добавлены вложения
- **Автоматизация ADI-T18781**
  [(dbf8972)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/dbf8972a9aac7da9fac023beb9b4357d24ac0bb2)


  1. Автоматизирован ТС ADI-T18781
  2. Автоматизирован ТК ADI_T16979
  3. Добавлены локаторы
  4. Добавлены вложения
- **Автоматизация ADI-T18779**
  [(b4c80e8)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/b4c80e84274c28d75efdb3dc4d3a7cff9bd83971)


## 12.08.2025

### ИПОТЕКА ВТБ

#### fix
- **Актуализация сценариев**
  [(68b3865)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/68b3865adf04a4e7a23dfb123d44c6cc0320d320)


### НСиБ

#### fix
- **Актуализация**
  [(701b1ed)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/701b1edf0655ecb53ee5321e83bcfb97cafe80f9)


  1. Фикс КА для продукта НС
  2. Фикс написания специальной программы

## 11.08.2025

### НСиБ и ВПМЖ

#### fix
- **Актуализация**
  [(efa79ce)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/efa79ce461dd1d199e90aa7a3fcee9cc1ca58cdd)


  1. Добавлен выбор Варианта программы
  2. Добавлен локатор поля Вариант программы

### НСиБ

#### feat
- **Автоматизация ADI-T18907**
  [(38d5339)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/38d5339418c368bfd9f6d0bc38c13df505c0613b)


### ПРС

#### feat
- **Автоматизация ADI-T18900**
  [(10f55bc)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/10f55bcc90af089bfd06bbb4d5792202a06f67c3)

- **Автоматизация ADI-T17283**
  [(12f3f0e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/12f3f0ec2407ea30749447ddac277aed4725b7b0)

- **Автоматизация ADI-T18547**
  [(1224cfc)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1224cfcc739d99f665748b5099b02b31020f898a)


### СОГАЗ-АВТО

#### feat
- **Автоматизация ADI-T18802**
  [(d1ebc0e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d1ebc0e61dfbbdfebefd8c0c929ee0434da600ac)


### ОСАГО

#### fix
- **ADI-21329 Правки по итогам прошлого регресса**
  [(7ab28f0)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/7ab28f0b467c2ce323aac6742e42bac8c1d0d38b)


  - Парки. Обновлены парковые файлы в связи с изменением шаблона загрузки.
  - `ADI-T5211` -Изменен шаг поиска Страхователя на POM. Изменен шаг поиска менеджера договора на POM. Изменены шаги добавления вложений на POM
  - `ADI-T5518` -Правки тестовых данных
  - `ADI-T9106` -Правки тестовых данных

### Cargo, CargoExpress

#### fix
- **Актуализация автотестов в связи с выходом новых доработок (GRZ-69 и GRZ-81)**
  [(b6fbe44)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/b6fbe44f1658455bc2b7c3d3f7767c220698d4d8)


### MotorCasco, MotorCascoPark, SpecTechnics

#### fix
- **Актуализация 7242, 12786, 17394, 15779, 15376, 15781**
  [(cd895a6)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/cd895a617d25e6ca3eaafe7c942c08fc152b5232)


### PLE, SMBRe

#### fix
- **внесение изменений в UserUpdateScript**
  [(ec98759)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ec987597db3d624dacef96813b1917497495cdff)


### ВПМЖ

#### fix
- **Обновлены данные УЗ**
  [(433a2b7)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/433a2b73f284de3ecf154ae60ad55577646a960a)


## 09.08.2025

### НСиБ и ВПМЖ

#### fix
- **Актуализация**
  [(6fa3b7e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/6fa3b7e8c1ef4cc0f2c1c035f978cfdc643956fd)


  1. Актуализированы сценарии по продуктам НС и ВПМЖ
  2. Добавлены новые шаги в stepTravelInsurance
  3. Обновлены локаторы
  4. Добавлены учетные записи

## 08.08.2025

### НСиБ

#### feat
- **Автоматизация ADI-T18897**
  [(07120df)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/07120df653ae8adacacb0946483ca70d2cbccc06)


  1. Автоматизирован ТС ADI-T18897
  2. Обновлены локаторы по НС
- **Автоматизация ADI-T18898**
  [(a1955dd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/a1955dd48814c2b75f9c473421b35d9f1c7c90dd)


  1. Автоматизирован ТС ADI-T18898
  2. Обновлены локаторы по НС
  3. Добавлена УЗ для НС

## 01.08.2025

### ИПОТЕКА ВТБ

#### fix
- **Актуализация сценариев**
  [(2b83f4b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/2b83f4b6cb156f96c075eb1027ee721af185b6ab)


  1. Актуализированы сценарии регресса
  2. Актуализированы скрины ПФ

#### feat
- **Автоматизирован ТС ADI-T14534**
  [(1d19adb)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1d19adb30d45713e1c1092e4a43007b2b614ab57)


  1. Автоматизирован сценарий ADI-T14534

### Cargo

#### fix
- **Актуализация**
  [(cce6dab)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/cce6dabc5fab73f582d22489a570f8d2b0130e01)


  1. Исправлены ошибки в ADI-T17082
  2. Исправлены ошибки в ADI-T17565
  3. Замена ПФ в ADI-T17565

### Коробочный продукт

#### feat
- **Автоматизация ADI-T16288**
  [(c045e7c)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c045e7cd7cc6765688338dc1d303a69e185e63bc)


  - Автоматизация ADI-T16288
  - Раскомментировал итерации в ТС 16546

### Коробки

#### feat
- **Автоматизирован ADI-T16546**
  [(8e5f425)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8e5f425946119c44dba78188f4edeaa2d121e190)


  - Автоматизация ТС 16546 и добавление тестовых данных к нему
  - добавление ТК 16152
  - Корректировка сценариев 16512 и 16510

### MTPL PARK

#### fix
- **Обновление парковых файлов**
  [(00c9095)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/00c909580d73dd736060c2de3c538c1127ce8aa6)


### GLI

#### fix
- **Перенос автотеста ADI-T17089 на pom**
  [(e642e86)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e642e86e3a1952b49a33e56bc7108f0a414556f3)


### ОСАГО

#### fix
- **Исправлен код контрагента (ADI-T10193)**
  [(ada31f5)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ada31f5aced6e2e923767120ba4fe3c54894c011)


### ЗН

#### feat
- **Автоматизация ADI-T15966**
  [(8714f86)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8714f867cab53a8cb59277bcee2b77e53fef4328)


### Cargo, CargoExpress

#### fix
- **Актуализация**
  [(16a45cd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/16a45cd7d9a1a14924f36ea195f26562fcc5abfe)


  1. Актуализация автотестов в связи с выходом доработки

## 31.07.2025

### ИПОТЕКА ВТБ

#### fix
- **Актуализированы ТС**
  [(ebfd50d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ebfd50dd8048e11eb944bf1004cc9658c44f0850)


### ОСАГО

#### fix
- **Актуализация базовых сценариев, замена КА, добавление таймаутов**
  [(8bf0417)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8bf0417e5445d208e842341d16f2f9617b27ffe7)


### Коробки

#### feat
- **Автоматизация ТС ADI-T16510**
  [(d02cec0)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d02cec0accbd541025c3e4968f4fcbbd9458f02f)


### ПРК

#### fix
- **Актуализация сценариев ПРК**
  [(0b6ca75)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0b6ca755873088171c2f7754150476ad5c2f04fa)


## 30.07.2025

### НСиБ

#### fix
- **Актуализация**
  [(47111ca)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/47111ca6d73b2fc7f9b11fa514d686b30aa6d795)


  1. ADI-T18246 - Фикс названия теста
  2. ADI-T18259 - Фикс локатора кнопка Добавить

### GLI

#### fix
- **Автоматизация ТС ADI-Т16293**
  [(3e30f18)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3e30f18d6538931b9e04ee15baccfdced2b8ee96)


  1. Перенос автотеста ADI-Т16293 на pom
- **Перенос автотеста ADI - 16975 на pom + актуализация**
  [(ed5609f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ed5609fbb31bb9be73fc5e2e9c826846ed6fbea2)


### SMBRe

#### fix
- **Актуализация ТС ADI-T18225**
  [(97ed28d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/97ed28d7f04f6898b2f1dab43babda243c7729b8)


  1. ADI-T18225 - замена посредника

### Коробочный продукт

#### new
- **Добавление продукта в структуру и автоматизация ТС ADI-T16512**
  [(417521e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/417521e19f5c9fd8c1505bc92d89b177a209deb6)


  * Добавление продукта UBC в фикстуру
  * Добавление продукта UBC в CI gitlab
  * Тестовые данные ТС 16512 и файл с УЗ
  * Добавление селекторов и степов по продукту UBC
  * Автоматизация сценария 16512
  * Корректировка сценария 3614(добавление условия для локатора кнопки поиска с наименованием по роли)

### PLE, SMBRe

#### fix
- **Актуализация автотестов ИЮЛ+МСБ по итогам регресса**
  [(08ee929)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/08ee92982f83bb238f8782a4dc126d47745ec93a)


  Актуализация автотестов ИЮЛ+МСБ по итогам регресса в связи с выходом новых доработок.

### ОСАГО

#### fix
- **Исправлены и актуализированы базовые сценарии, исправлены КА, посредники, изменены проверки, актуализированы общие шаги**
  [(e033b93)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e033b9311245a77a6884d23097f6bbfbb92ffc2e)


## 29.07.2025

### НСиБ

#### fix
- **Актуализация**
  [(6e1c71f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/6e1c71f281fa7d108cc0b8772e80eebdaeb70546)


  1. Актуализированы ТС по продукту НСиБ
- **Актуализация**
  [(4f1e304)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/4f1e304a6c9b7f0ed12609de670948cbf4d7c45a)


  1. Актуализированы ТС по продукту НСиБ

### ИПОТЕКА ВТБ

#### fix
- **Актуализированы ТС**
  [(e5b330b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e5b330b0d3bb4573dc644ef2bb41d4b5a492ab81)


  1. Актуализированы сценарии
  2. Актуализированы скриншоты ПФ

### ОГО

#### feat
- **Автоматизирован ТС ADI-T16989**
  [(c3bae2a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c3bae2ac74b02c0b70e84ad491d9660c2d862e10)


  1. Автоматизирован сценарий ADI-T16989
  2. Добавлены шаги в stepGLI
  3. Добавлены локаторы в selectorGLI

### ПРС

#### fix
- **Актуализация тестов**
  [(9257f53)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/9257f538683b3cd291ccd368d1a3c1b825df3642)


## 28.07.2025

### ПРС

#### fix
- **Актуализация**
  [(17361ce)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/17361ce8b94e35d7d0ddda76cb1421af6484c56d)

- **Актуализация тестов**
  [(85e2eb7)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/85e2eb798d12d4ea2bf45e51f602bd8ce4144973)


#### feat
- **Автоматизирован сценарий ADI-T17571**
  [(d4cc458)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d4cc45890c974250e9bb793cc61f39a97adac294)


  - Автоматизирован сценарий ADI-T17571

### ПдИ

#### fix
- **ADI-25269 Переведены тесты по ПдИ с CORE на POM**
  [(0926a33)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0926a336055fd30454f9a851a0a68961f3239714)


  * Добавлены селекторы и степы
  * Добавлена проверка памяток на оплату

## 26.07.2025

### ИПОТЕКА ВТБ

#### fix
- **Актуализирован ТС ADI-T4298**
  [(bfc19e0)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/bfc19e0de8936ba79aef665e68cd93e88df1a563)


  1. Актуализирован сценарий ADI-T4298
  2. Добавлены скриншоты ПФ

### НСиБ

#### fix
- **Актуализация ТС по НСиБ**
  [(dc5b38e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/dc5b38e44b1612138d35a6473f1be60bbd1fba6c)


  1. ADI-T18212
  2. ADI-T18246
  3. ADI-T18252
  4. ADI-T18259
  5. ADI-T18262
  6. ADI-T18264
  7. ADI-T18271
  8. ADI-T18304

## 25.07.2025

### SMBRe

#### feat
- **Автоматизирован TC ADI-T18840**
  [(5d15a1d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/5d15a1d932164a20d6f29744591006e6e467b61a)


  1. Автоматизирован TC ADI-T18840

## 24.07.2025

### Согаз-Квартира

#### feat
- **Автоматизация сценария ADI-T18757**
  [(2e45ef2)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/2e45ef2a6f80ff6599f4e04d4c1276bf1a812c65)


  - Автоматизирован ТС ADI-T18757

### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4945 Актуализированы сценарии регресса**
  [(1499dcd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1499dcd3f0c507d75b1d665779ea2e12fd9594a5)


## 23.07.2025

### SMBRe

#### feat
- **Автоматизирован ТС ADI-T18715**
  [(dddd9d1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/dddd9d17a0c72ba2d32b9cb95a35a66df8c9bc18)


  1. Автоматизация нового сценария ADI-T18715

### TCI

#### feat
- **Автоматизированы ТС ADI-T14986 и ADI-T14994**
  [(9c03447)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/9c03447f769b5b84e5791ad5872384041e05f485)


  1. К договору ADI-T14937 автоматизировано два сценария по допсам ADI-T14986 и ADI-T14994
- **Автоматизирован TC ADI-T14937**
  [(1e7c230)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1e7c23040b8e5f7ec25577740035b4286aa80333)


  1. Автоматизирован новый сценарий ADI-T14937 с проверкой ПФ
- **Новый автотест ADI-T14312**
  [(dabbe9b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/dabbe9b1b24762c0f76cd35c4cb19a9438b0189f)


  * Автоматизирован новый сценарий ADI-T14312с проверкой ПФ
  * Правка ошибки в ADI-T15377
  * Локально ок \[firefox\] › tests\\UI\\TradeCreditInsurance\\ADI-T14312.pom.spec.js 1 passed (29.4m)

### ОГО

#### feat
- **Автоматизирован ТС ADI-T18522**
  [(768f7c2)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/768f7c202b89eabb53639f9d777aeb7eea882c1c)


  1. Автоматизирован сценарий ADI-T18522
  2. Добавлены шаги в stepGLI.
  3. Добавлены локаторы в selectorGLI

## 22.07.2025

### Cargo

#### fix
- **Актуализация автотестов по итогу регресса**
  [(1a46e2e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1a46e2e6eb605232624a881e7740b9098066ad2f)


  1. Добавлены новые локаторы и степ
  2. Актуализирован автотест 18237 в связи с ребейзом стейджа
  3. Актуализированы автотесты 17409 и 14516 в связи с новой доработкой по проверке СБ
  4. Актуализированы проверки ПФ в 17409
  5. Локально пройдено

## 18.07.2025

### TCI

#### feat
- **Автоматизирован ADI-T15377**
  [(9e99a6a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/9e99a6accd27a8b845fdbe93fb34d458c7ef3864)


  1. Автоматизирован ADI-T15377
  2. Актуализирован ADI-T14142, ADI-T11442
  3. Добавлены новы файлы для вложений.

### GLI

#### fix
- **Актуализация ADI-T16290**
  [(abd22f9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/abd22f9afec49112d9734e129def9768e488ed22)


### PLE

#### fix
- **Актуализация**
  [(09e5a91)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/09e5a91e6c6af7b0c5b616ae225d7a7a3e3387c5)


  Установлена допустимая разница в пикселях для проверок ПФ

## 17.07.2025

### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4945 Актуализация сценариев регресса**
  [(1119575)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1119575d0a952b5a40033335b4badecbd1d95142)


### ОГО

#### feat
- **LINS-61 Автоматизирован ТС ADI-T17117**
  [(5ba9fce)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/5ba9fce121581ebffda01c657a4a13bd1af37440)


  1. Автоматизирован сценарий ADI-T17117
  2. Добавлены шаги в stepGLI.
  3. Добавлены локаторы в selectorGLI

### Cargo_CargoExpress

#### fix
- **Актуализация автотестов по итогу регресса**
  [(0b4077d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0b4077df65ce2df73cb497daf2cde2354829c873)


### SMBRe

#### fix
- **Актуализация ADI-T18222**
  [(cbd6588)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/cbd65884c2570385482d35014fe0702d5daefa59)


  Актуализация ADI-T18222 в связи с выпуском новой доработки PD-80

## 16.07.2025

### PLE, SMBRe, Cargo

#### fix
- **Актуализация автотестов по продуктам по итогам регресса (новые доработки)**
  [(7b05d95)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/7b05d9533b8f7f5288ba793b1e4e24a24f1ed40e)


### AgentAgreements

#### fix
- **Актуализация тестов**
  [(32475f0)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/32475f044a95104d7babf800801160593823297b)


  * cкорректирован шаг 10904 в stepAgentAgreements
  * измененый тестовые данные в Т6081,
  * скорректировано название чекбокса в Т6493,Т11044,Т11208,Т18720,Т18770,
  * скорректированы шаги 10904 в Т7685,Т8120,
  * скорректированы тестовые данные и доработаны шаги в Т10560,
  * добавлены шаги в Т18702

### НСиБ

#### fix
- **Актуализация тестов**
  [(175e7da)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/175e7da93773da0a4b9b0a10428dccf7e92de91c)


  * Актуализированы ТС по продукту НСиБ
  * Добавлен локатор НС
  * Заменен шаг в сценариях для поиска КА
  * Удалены ожидания
  * Добавлен импорт контекста в ТС 11406

### ИПОТЕКА ВТБ

#### feat
- **Автоматизирован ТС ADI-T15475**
  [(3ce5640)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3ce56405eb558bca1e76a49f0b82735f436844fc)


### ОСАГО

#### fix
- **Актуализация ADI-T14894, ADI-T15194**
  [(9f7652f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/9f7652f33e0989001ad0635e005fba3bf455cce6)


  - ADI-T14894 - заменен шаг с поиском КА, добавлена проверка отображения КА при поиске, изменена дата окончания краткосрочного договора
  - ADI-T15194 - изменен юзер, исправлен шаг с поиском КА, добавлено заполнение чекбокса "АВТОКАСКО ПРОФИ Лайт"

## 14.07.2025

### ПРК

#### fix
- **Актуализация сценария ADI-T17395**
  [(f8fe276)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f8fe2768319ea19fa61323ea3e35f99b729cd048)

- **Актуализация сценариев**
  [(fc24cd2)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/fc24cd2068402c61df0c8375484ba7b8c5e7ed96)


### ОСАГО

#### fix
- **Актуализация ОСАГО**
  [(9f6473b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/9f6473b4ca8661960190386b86a12d3f657fa8e3)


  - ADI-T7697 - добавлен шаг с заполнением чекбокса "АВТОКАСКО ПРОФИ Лайт"
  - ADI-T7695 - Изменен посредник
  - ADI-T7693 - актуализирован id выпадающего списка ADI-T6295 - актуализированы наименования валидаций

### ВПМЖ

#### feat
- **Автоматизирован ТС ADI-T11406**
  [(97da0b1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/97da0b1cea2d4216e9b201e453114cacb5763d89)


  * Автоматизирован ТС ADI-T11406
  * Добавлены локаторы ВПМЖ
  * Добавлены новые, переработаны существующие ТК ВПМЖ

#### fix
- **Актуализация**
  [(ff1c738)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ff1c7382bc4e824b6f7faa56653b6c0b2c96a92a)


  * Актуализированы ТК и ТС по ВПМЖ
  * Добавлена функция insertRevertDate установки даты в вида ГГГГ-ММ-ДД для проверок в papercut. Общая функциональность не затронута
  * Актуализированы локаторы ВПМЖ

### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4940 Актуализированы сценарии регресса**
  [(28c23e7)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/28c23e772d8cc9e1f096836f10d753fd1e65601a)


  1. Актуализированы сценарии регресса после падений на хотфиксе
  2. Актуализированы шаги в stepMortgageVTB.
  3. Актуализированы локаторы в selectorMortgageVTB

### TradeCreditInsurance

#### fix
- **Актуализация ADI-T15215**
  [(8f2ab41)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8f2ab415f10365e4474fcff299e5fb3e391d8a03)


  - Сценарий `ADI-T15215` объединен со сценарием `ADI-T15371`
  - Добавлены новые шаги

### ПРС

#### fix
- **Актуализация сценариев**
  [(811b8a6)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/811b8a6b7ba2ff9f0a4fd1c6d094cb704b1938be)


### AgentAgreements

#### fix
- **Актуализация ADI-21326**
  [(7483d96)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/7483d96d8eb259fb40f937c6604d68e0a0890f0f)


  1. Добавлены данные в selectorAgentAgreements
  2. Расширен шаг Т1143 в stepAgentAgreements
  3. Скорректированы данные и изменены шаги в кейсах: T11044 T6493 T6496 T18744 T18733 T18759 T18770 T18702

### СОГАЗ-АВТО

#### fix
- **Актуализация ADI-T14395**
  [(0f94770)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0f947704f46287f7e31333744462ee7ac4573a7d)


## 11.07.2025

### TradeCreditInsurance

#### feat
- **Автоматизирован новый сценарий ADI-T15215**
  [(806429f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/806429f1965aa07260a954f09a52839f7c7d4300)


## 10.07.2025

### PersonalPropertyBuilding

#### feat
- **Автоматизирован ADI-T18477**
  [(a075268)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/a0752681cb91e4e7236fbea919d370f084930fcc)


### TradeCreditInsurance

#### fix
- **Актуализация автотеста `ADI-T11443`**
  [(e6505b6)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e6505b65df3d52782b44cf24370155a714e7d04a)


  * Сценарий `ADI-T11443` объединен со сценарием `ADI-T11559`
  * Новые шаги автоматизированы и добавлены в автотест `ADI-T11443`
- **Актуализация автотестов**
  [(e9ac914)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e9ac9147b3633cf55d79ae29286a1cceb50286f0)


  - ADI-T11442
  - ADI-T11443
  - ADI-T14142

### CargoExpress

#### fix
- **Актуализация**
  [(d6bc8cd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d6bc8cdb7471d412c1af39ec4845e9302a669249)


  - поправлены скриншоты в ADI-T18509 в связи с доработкой по изменению номера телефона филиала

### Спецтехника

#### feat
- **Автоматизация теста ADI-T15774**
  [(8a44a63)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8a44a6373e8951efbcf8114a69ea15cebfeb8f5c)


### СОГАЗ-АВТО

#### fix
- **Актуализация тестов**
  [(36737d8)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/36737d8df8680276c09a27532d09a75dc059f6ba)


### ОСАГО

#### fix
- **Актуализация**
  [(7354820)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/73548206d294ff35adabd289654e4b61b5f75e10)


### AgentAgreements

#### feat
- **Автоматизирован сценарий ADI-Т18770**
  [(f269f86)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f269f862b5d571c8ded235213418d568f88e9b09)


#### fix
- **Актуализация**
  [(6e276ea)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/6e276eaf95af61331c1b5c2effd57590c47bd936)


  - скорректированы `selectorAgentAgreements`, `stepAgentAgreements` и `ADI-T18759`

### ВПМЖ

#### feat
- **Автоматизирован ТС ADI-T18607**
  [(ec4e44e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ec4e44e6bee3f928c4aa6891cd72fce5c3eb6f6b)

- **Автоматизирован ТС ADI-T18548**
  [(ed755ef)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ed755efbaea312ef449881128440b1d180138d5f)

- **Автоматизирован ТС ADI-T18608**
  [(8ef38bd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8ef38bd016d93f815d4805680b27c0d1ed1e8898)

- **Автоматизирован ТС ADI-T18563**
  [(689a909)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/689a909ae5891f1d0c4387bae37c062b17e86768)


  * Автоматизирован ТС ADI-T18563
  * Фикс шага ADI_T11619 в ТС ADI-T6983
  * Добавлены локаторы ВПМЖ
  * Добавлены новые, переработаны существующие ТК ВПМЖ

### ИПОТЕКА ВТБ

#### feat
- **ADI-25296 Автоматизирован ТС ADI-T15208**
  [(de6730b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/de6730bfd783f881e622cc8622ed0eb9294e54bc)

- **CHANGELOG-4922 Актуализация сценариев регресса**
  [(006b70c)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/006b70c24a527af395b55cc8cbf8f2d285b70f69)


#### fix
- **CHANGELOG-4922 Актуализация сценариев регресса (часть 3)**
  [(ca426e2)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ca426e23d56dc7292d2cdac01ae1fd1578ee53a0)


## 09.07.2025

### ОГО

#### feat
- **Автоматизирован ТС ADI-T16290**
  [(11f76a4)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/11f76a4bcace52a9027a040e600b38006924b996)


## 08.07.2025

### TradeCreditInsurance

#### fix
- **Актуализация ADI-T11442**
  [(f481844)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f48184428430da84b0d9aba96a8b736f32c9833b)


## 04.07.2025

### ВПМЖ

#### feat
- **Автоматизирован ТС ADI-T6983**
  [(ac730f3)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ac730f3525eb880af4f49ab4cd911e889552b55f)

- **Автоматизирован ТС ADI-T10870**
  [(6b52384)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/6b523847df4f9434017c93dc1935b9c67c81b571)


### TCI

#### fix
- **Актуализация ADI-T11443**
  [(8f0e445)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8f0e44587066aa0a02a803d3a41272c518d4558a)


## 03.07.2025

### ОГО

#### feat
- **Автоматизирован ТС ADI-T18234**
  [(5fb5bc0)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/5fb5bc0d15c32aa331ca61f57885e921fde7b689)

- **Автоматизирован ТС ADI-T18234**
  [(62fb661)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/62fb661b077c3684ebeec692bba6f2b448691928)


### SMBRe

#### fix
- **Правка автотестов МСБ**
  [(037c037)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/037c03727da541988885cf513bfeacb5ee873c75)


### AgentAgreements

#### fix
- **Актуализация**
  [(68ffdf2)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/68ffdf2df61ae0190e17b2370ec8cc676f27be90)


  - добавлены селекторы в `selectorAgentAgreements`
  - скорректирован `stepAgentAgreements` шаги `T9556` и `T1127`
  - скорректирован сценарий `T10560`
  - скорректирован сценарий `T18733`

## 02.07.2025

### ИПОТЕКА ВТБ

#### fix
- **Актуализация сценариев**
  [(baf7120)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/baf71206376cdc9873684b98b39e1a468e124ba7)


  1. Актуализированы сценарии `ADI-T11349`, `ADI-T11364`, `ADI-T11433`, `ADI-T13316`, `ADI-T14533`, `ADI-T14557`
  2. Исправлен шаг в `stepMortgageVTB`
  3. Заменены "Эталонные" скриншоты ПФ

### СОГАЗ-АВТО

#### fix
- **Актуализация**
  [(8f6f973)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8f6f973d65d51a6b585f504e8518fbb753b4dae8)


  - в рознице правки связанные с ПФ
  - в парках увеличил таймаут до 2х минут после расчета премии

## 01.07.2025

### НСиБ/ВПМЖ

#### fix
- **Актуализация**
  [(56e716f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/56e716fef8a1306a1ad442b68de9b0a10a0fe194)


### Cargo

#### fix
- **Правка в автоесте ADI-T8339 в связи с исправлением бага GRZ-96**
  [(c706116)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c706116f28a79713f76c8a68e030998fc199a6cd)


### SMBRe

#### fix
- **Правки по итогу регресса**
  [(6b0f6e0)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/6b0f6e0876dcabe00e92909674f65b80a140c284)


#### feat
- **Автоматизация сценария ADI-T18225 на pom**
  [(f5ab696)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f5ab696cd120a2d23cd34d923ecc7ab74ba77207)


## 30.06.2025

### НСиБ/ВПМЖ

#### fix
- **Актуализация**
  [(e14555d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e14555dc2f3148a137c88b2d4787e3b69f42895f)


### СОГАЗ-АВТО

#### fix
- **Актуализация**
  [(ba08561)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ba08561023fd06d3a30c2a214b9480163a9b374d)


### ВПМЖ

#### feat
- **Автоматизирован ТС ADI-T9521**
  [(422a059)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/422a05904053268f38db8692199be7278723432c)


### SMBRe

#### feat
- **Автоматизация на POM автотеста ADI-T18418**
  [(bb8a360)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/bb8a3606dff366dde2b1c561654d79915718c9fb)


### GLI

#### fix
- **Исправление в ADI-T18231**
  [(b250f1e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/b250f1ea2361f801e41cf513ea47dae4fda5b66d)


### AgentAgreements

#### fix
- **Актуализация тестов**
  [(b4a419b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/b4a419b29a9fbffedfa726a842287f2a7760c4b3)


  - Т18702 - исправлены ссылки
  - добавлено сохранение Т18733
  - добавлена проверка Т6320
  - изменен КА stepAgentAgreements
  - скорректирован шаг T1143 и T9556

## 27.06.2025

### СОГАЗ-АВТО

#### fix
- **Фикс копипасты + переименование некоторых КА в тесах**
  [(3b77522)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3b775222daca9d7e91490cabce1ec8f9c64e693a)


## 26.06.2025

### ИФЛ

#### fix
- **Актуализация ADI-T18321**
  [(fe6dc88)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/fe6dc88f0698744e4752838a07055740d5b81311)


  - Актуализация ADI-T18321
- **Актуализация ADI-T18114, ADI-T17410**
  [(c040ece)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c040ece79134e5df483d9fed9d72350461185aa0)


  - Актуализация сценариев ADI-T18114, ADI-T17410, 18321

### AgentAgreements

#### feat
- **Автоматизирован ADI-T18733**
  [(3c2344d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3c2344d392f59bb35353750e21a98c7e12ce63d3)


#### fix
- **Актуализация**
  [(ba2f879)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ba2f87930277233bb62589bf627d8f9044b5b0af)


  - исправлены шаги в `stepAgentAgreements`
  - добавлен id в `selectorAgentAgreements`

### ОГО

#### feat
- **LINS-27 Автоматизирован ТС ADI-T18233**
  [(7d11910)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/7d1191066c9439a4c94b952673cf6ea79004df62)


### Спецтехника

#### fix
- **Актуализация**
  [(36d6411)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/36d6411254afa073ee62e59e926876523df37af8)


  - перевод на pom теста ADI-T10926
  - доработка степов `ADI_T4040`, `ADI_T4164`

### SMBRe

#### feat
- **Автоматизирован новый сценарий ADI-T18200**
  [(6bebdd6)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/6bebdd6cab23713d3526828f6f30bc256191b88d)

- **Автоматизирован новый сценарий ADI-T18222**
  [(8b16b6b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8b16b6bedee61c61da34fd6b85b66af83dfaf4fd)


## 25.06.2025

### Согаз Квартира

#### fix
- **Актуализация ADI-T4752 ,ADI-T3254, ADI-T6423**
  [(344b331)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/344b3310bbd6160606d26b00511c42c56684fcc7)


  - Актуализация сценарии ADI-T4752 ,ADI-T3254, ADI-T6423.

### AgentAgreements

#### fix
- **Актуализация**
  [(171985b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/171985bcffc0538e5da046825c1bc9a959d8b2ee)


  Скорректирован шаг T9556 в `stepAgentAgreements`
- **Актуализация тестов**
  [(f097d2a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f097d2a42e267c6b32edd318690d69cdda34e61e)


  * в selectorAgentAgreements добалены данные
  * в stepAgentAgreements скорректированы шаги в тестах:
  1. 6078 изменены тестовые данные
  2. 11213 добавлены шаги проверок
  3. 18702 добавлен параметр
  4. 18720 изменено название теста

### ИПОТЕКА ВТБ

#### fix
- **Актуализирован ТС ADI-T11433**
  [(17656bb)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/17656bb27720b51421a7faa57a4f5f8aa73a923a)


#### feat
- **ADI-25261 Автоматизирован ТС ADI-T17492**
  [(e8aff5f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e8aff5fff29ec96bdc6e0a03188d67ec78a52809)


  1. Автоматизирован сценарий ADI-T17492
  2. Добавлен шаг в stepMortgageVTB.
  3. Добавлены локаторы в selectorMortgageVTB

### ВПМЖ

#### feat
- **Автоматизирован ТС ADI-T6876**
  [(9cc18a1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/9cc18a1cfcd82d86e3d708a54542b3131506a177)


  * Добавлены локаторы ВПМЖ
  * Добавлены УЗ ВПМЖ
  * Добавлены новые, переработаны существующие ТК ВПМЖ

### Спецтехника

#### fix
- **Актуализация тестов + перенос теста ADI-T4613 на pom**
  [(95f9776)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/95f977672a140ac2ceb25566eb82a49911ddfcd8)


### СОГАЗ-АВТО

#### fix
- **Перенос локаторов из тестов в pages**
  [(f5834c5)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f5834c550c2ec3135e00d23775fca8e0bdd39aac)


### ОГО

#### feat
- **LINS-12 Автоматизирован ТС ADI-T17272**
  [(a56af1e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/a56af1e1407b25682c5a3cf028b838e626242ae0)


  1. Автоматизирован сценарий ADI-T17272
  2. Добавлены шаги в stepGLI.
  3. Добавлены локаторы в stepGLI

## 20.06.2025

### Cargo

#### fix
- **Актуализация автотестов по грузам после исправления багов**
  [(86f5517)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/86f5517e56057bafc63d7f20ee783d74022715c1)


  1. Актуализированы автотесты:
  * ADI-T12919.pom.spec.js
  * ADI-T17409.pom.spec.js
  * ADI-T17565.pom.spec.js
  * ADI-T18089.pom.spec.js
  * ADI-T8339.pom.spec.js
  2. Поправлены проверки ПФ

### AgentAgreements

#### feat
- **Автоматизирован ADI-T18720**
  [(f92a04b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f92a04bb82bb96cea66469b81e532d5c94bd4fe1)

- **Автоматизирован сценарий ADI-T18702**
  [(ba43d27)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ba43d2733dca38489c37974d7fac88b7b177b07c)


  1. Автоматизирован сценарий ADI-T18702
  2. Исправления:
  - корректировка тестовых данных в кейсе 10560
  - дополнения в selectorAgentAgreements
  - добавление новых шагов в StepAgentAgreements

## 19.06.2025

### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4894 актуализация сценариев регресса (часть 3)**
  [(80e4321)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/80e4321c9b70b52a89a7e52cb5cedd9634b438eb)


  1. Актуализирован сценарий ADI-T11658
  2. Актуализирован сценарий ADI-T16523
  3. Актуализирован сценарий ADI-T4509
  4. Актуализированы шаги в `stepMortgageVTB`

### Cargo

#### fix
- **Актуализация тестов Cargo и CargoExpress в связи с выходом новых доработок**
  [(b848622)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/b848622221e7682f93536cad1babf72980c4a4bc)


  1. Актуализированы автотесты, в т.ч. скриншоты для проверки ПФ - ADI-T17082, ADI-T17189, ADI-T17409, ADI-T17565, ADI-T18089, ADI-T18101, ADI-T8339, ADI-T8342, ADI-T17202, ADI-T17203, ADI-T18509, ADI-T17201. Актуализировано в одной ветке, т.к. доработки на два продукта.
  2. Добавлены новые степы и локаторы
  3. Не проверены автотесты ADI-T17409, ADI-T17565 в связи с блокирующей ошибкой. Будут проверены и, при необходимости, исправлены после ее исправления.

## 18.06.2025

### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4894 актуализация сценариев регресса (часть 2)**
  [(67c5c08)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/67c5c0854af9c86978ccbae003df3eacb10ac36e)


  1. Актуализирован сценарий ADI-T5144
  2. Актуализирован сценарий ADI-T6555
  3. Актуализирован сценарий ADI-T8688
  4. Актуализирован сценарий ADI-T8858
  5. Исправлены шаги в stepMortgage

### SMBRe

#### feat
- **Автоматизация на POM нового продукта SMBRe (коробка ИЮЛ)**
  [(82cb798)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/82cb798c8f296343021628bdd5a74c74da9997d1)


  1. Добавлены новые локаторы в `selectorPropertyLegalEntities.js`
  2. Добавлены новые степы в `stepPropertyLegalEntities.js`
  3. В `.gitlab-ci.yml` добавлен продукт МСБ Re для firefox и Chromium
  4. Добавлена утилита `formatDate` для преобразования даты из формата dd.mm.yyyy в формат «dd» month yyyy г. (для проверки оговорок по договору на UI и в дальнейшем в ПФ)
  5. Добавлены новые файлы в папку fixtures
  6. Автоматизация на pom автотеста ADI-T18187 с проверкой печатных форм
  7. Автоматизация на pom автотеста ADI-T18199 с проверкой интеграции СОД и печатной формы

## 17.06.2025

### СОГАЗ-АВТО

#### fix
- **Актуализация тестов**
  [(62da8c9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/62da8c9cd3159d078f662f266b9918e47eb1f187)


  - ADI-T12695
  - ADI-T12700
  - ADI-T13503
  - ADI-T14305
  - ADI-T17864

### ИПОТЕКА ВТБ

#### fix
- **Актуализация сценариев**
  [(c73b7b9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c73b7b9ca943d2280daac80a7044d8877a5e27e4)


  1. Актуализирован сценарий ADI-T11349
  2. Актуализирован сценарий ADI-T11433
  3. Актуализирован сценарий ADI-T14557
  4. Актуализирован сценарий ADI-T15467
  5. Актуализирован сценарий ADI-T4289

## 16.06.2025

### AgentAgreements

#### fix
- **Актуализация тестов**
  [(36eb233)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/36eb23322c113c73380238b09cff298f82d498d1)


  * скорректированы шаги расчетов
  * исправлены тестовые данные в кейсах

### СОГАЗ-АВТО

#### fix
- **Актуализация тестов**
  [(9e1eecf)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/9e1eecf09a78b7de11619ba0e165f0f344de94bb)


### ВПМЖ

#### fix
- **Актуализация тестов**
  [(da5e9f8)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/da5e9f87f2911c67bdfc1f26357169fd427384af)


## 11.06.2025

### ВПМЖ

#### feat
- **Автоматизирован ТС ADI-T5036**
  [(86faef1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/86faef1b61323edd0a1c71542a0fd4408cf8749f)


  * Добавлены локаторы ВПМЖ
  * Добавлена страница с УЗ ВПМЖ
  * Добавлен новый ТК Т4420 ВПМЖ
  * ТС ADI-T5505 - мелкие правки тестовых данных
- **Автоматизирован ТС ADI-T4997**
  [(65202d4)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/65202d4e53ee3c6315089f7f5a508f228503fad8)


  - Добавлены локаторы ВПМЖ
  - Добавлена страница с УЗ ВПМЖ
  - Добавлен новый ТК Т4419 ВПМЖ

### СОГАЗ-АВТО

#### fix
- **Актуализация тестов с проверками ПФ**
  [(d3ff9d7)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d3ff9d7ea5994775f2ad2325378954bcf470f421)


### AgentAgreements

#### fix
- **Актуализация сценариев**
  [(aaf7948)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/aaf794803b26b9eb1d1b208bb7d466d68e62f5a4)


  1. замена своего шага (6748) с выбором актора на общий (2413)
  2. замена тестовых данных
  3. удаление ненужных селекторов
  4. изменение кейса 6081

### ПР Строение

#### feat
- **Автоматизация ADI-T18428**
  [(19b80eb)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/19b80eb4bac71256bd839978c3109d10f8bd89dc)


### Cargo

#### fix
- **Изменения в автотестах ADI-T17082, ADI-T18237, ADI-T8562**
  [(d4c5dfc)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d4c5dfce5793a03684e321d9de982d10c017c350)


  1. Изменения в автотестах ADI-T17082, ADI-T18237 в связи с редактированием справочника оговорок
  2. Новый файл для импорта полномочий
  3. Изменение в автотесте ADI-T8562 в связи с новым файлом импорта полномочий

## 06.06.2025

### PLE

#### fix
- **Изменен статус документа в автотесте ADI-T3377**
  [(01e17b2)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/01e17b2755fcd3e612ab81eb0b2a04e472dc6177)


## 05.06.2025

### ВПМЖ

#### fix
- **Актуализация и рефакторинг тестов**
  [(f3c5c6a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f3c5c6a0d494740428c4b7ef7c9dabfe0df53d50)


  1. Рефакторинг страницы с локаторами
  2. Актуализированы или полностью переработаны тест-кейсы по ВПМЖ
  3. Актуализированы тестовые сценарии
  4. Общие шаги и функционал не затронут

### ПР Квартира

#### feat
- **Автоматизирован сценарий ADI-T18128**
  [(c1916d8)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c1916d8029bc872c35345d7134dd067430afd28f)


## 04.06.2025

### Step General

#### fix
- **Добавлен метод hover в шаг ADI_T1237**
  [(b95c351)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/b95c3516cbe68654c399d43357b9523abe8c0731)


  Всплывающая подсказка перекрывает ссылку на документ.
  Добавлен метод 'hover' для наведения на другой элемент перед нажатием на ссылку

### СОГАЗ-АВТО

#### fix
- **Актуализация тестов**
  [(b198e1e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/b198e1e308437677faadefb437cdc2318874bb62)


  - ADI-T9539, ADI-T5958 - изменен id одного локатора
  - ADI-T14408 - изменен id одного локатора в файле `selectorMTPL`

### ПР Квартира

#### feat
- **Автоматизация ADI-T18118**
  [(3059bfb)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3059bfb5c2fd307bf8b35b4643a99019d23f6de4)


## 03.06.2025

### ОСАГО

#### fix
- **Обновлены парковые файлы**
  [(cc1f112)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/cc1f1126215cc3555c69a8603b22d7c9b8fe686c)


### Спецтехника

#### fix
- **Актуализация и перевод на pom тестов ADI-T6541, ADI-T17582**
  [(e453cf7)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e453cf7ab25ff2e4ec84619ff0dee87b16c58661)


## 02.06.2025

### AgentAgreements

#### fix
- **Актуализация теста ADI-T10560**
  [(acd1eab)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/acd1eabb0739e39f86f9d2c1fee5ce3bb784336b)


### Cargo

#### feat
- **Автоматизирован новый сценарий ADI-T17082**
  [(329c002)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/329c00200dfea99d5897c6c1bd019e791830d9f3)


  1. Автоматизирован новый сценарий ADI-T17082 с проверкой печатных форм
  2. Добавлены новые локаторы
  3. Добавлены новые степы ADI_T18355 и ADI_T18370

### ИПОТЕКА ВТБ

#### feat
- **ADI-25240 Автоматизирован ТС ADI-T6241**
  [(6f97101)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/6f971011b05231e0b677f833be8035b0f8d77242)


### PLE

#### fix
- **Актуализация тестов**
  [(4964c06)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/4964c06679ae58faa677e908bb246e54b2b31898)


  - исправлены автотесты ИЮЛ из-за изменений с ADI_T2413 (в основном только форматирование при сохранении
  - в 2702 переключение на роль Сопровождение заменено на "простынку"

## 30.05.2025

### Спецтехника + КАСКО

#### fix
- **Исправление тестов**
  [(33a9cb9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/33a9cb9a068e9e9c1dfc956e0d2835d7cc5a3143)


  - исправлены тесты каско (из-за изменений с `ADI_T2413`)
  - исправлены тесты спецтехники (из-за изменений с `ADI_T2413`)
  - актуализирован 2ух тестов каско: `ADI-T16660`, `ADI-T18087` (поменяв локатор в `selectorMotorCasco`)
  - исправлен тест спецтехники + приведен к ручному тесту: `ADI-T11322`

### Cargo

#### feat
- **Автоматизация на ADI-T18327**
  [(02f50cf)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/02f50cf63b56b92bc3a5b39448172b2a8cb51799)


## 29.05.2025

### СОГАЗ-Квартира

#### fix
- **Корректировка сценариев СОГАЗ Квартиры после доработок**
  [(0e41810)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0e418102d22a19ea77f38cbbb744b65792822526)


  - Корректировка сценариев СОГАЗ Квартиры после доработок

### СОГАЗ-АВТО

#### fix
- **Актуализация кода тестов**
  [(18940a1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/18940a1aab4acb0ccacb021977ec32aec4ed1b92)


  - Перенос локаторов из тестов каско в `selectorMotorCasco`
  - Увеличен `maxDiffPixels` в `ADI-T17416`
  - Выключен тест `ADI-T18193` - тест ни разу не прошел успешно. ручной тест не актуализирован

### Cargo

#### fix
- **Добавлены проверки ПФ в автотесты ADI-T8339, ADI-T8340, ADI-T8342**
  [(14ea7f9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/14ea7f996eaa7dc2740383aa2a35aa68e4f70822)


### CargoExpress

#### feat
- **Автоматизация нового сценария на POM ADI-T18509**
  [(f44dea0)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f44dea0e2b36578e2b2bcada308aa6f4d81cc9e4)


  Автоматизирован новый сценарий ADI-T18509 с проверками ПФ и интеграции СОД

## 28.05.2025

### StepGeneral

#### feat
- **Рефакторинг шага ADI-T2413**
  [(f791994)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f791994200549862880ffb38e2e77d0be1405f10)


  - Изменен шаг 'ADI-T2413 Переключение и проверка роли': вместо параметра 'value - выбор роли' теперь принимается объект с тремя полями (idElement, buttonName, actorName)
  - Обновлены все вызовы этого шага в соответствии с новый изменением

### AgentAgreements

#### fix
- **Актуализация**
  [(1347051)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1347051879a03c04d58c236c52745fc6b18dc17a)


  1. 6296 - скорректированы данные, добавлен шаг с расчетом
  2. 6081 - скорректированы данные
  3. 6078 - добавлен шаг с расчетом
  4. selector и step незначительные исправления

### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4862 Актуализация сценариев регресса**
  [(e562ca4)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e562ca44062e9ad5c8d9966af3c2d1ab7961a251)


  1. Актуализированы сценарии ADI-T14772, ADI-T13316, ADI-T4509, ADI-T8768, ADI-T8919, ADI-T16523
  2. Исправлен шаг в stepMortgageVTB.
  3. Исправлены эталонные ПФ

### CargoExpress

#### fix
- **Актуализация автотестов в связи с новыми доработками**
  [(bf9bfba)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/bf9bfba409ac2a87f19a5df258adc435f09d2827)


  1. В степ ADI_T16531 добавлены варианты страхования
  2. Исправлена проверка ПФ Полис - ADI-T17201, ADI-T17202, ADI-T17203
  3. Добавлена проверка ПФ Счет на оплату - ADI-T17201, ADI-T17202, ADI-T17203
  4. Добавлены проверки новых вариантов страхования - ADI-T17202, ADI-T17203, ADI-T17204
  5. Внесены правки по подписантам и Банку для оплаты - ADI-T17202

## 27.05.2025

### ВПМЖ

#### fix
- **Актуализация шага**
  [(665c171)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/665c1710567f394644b7fd864bdce545c11f04e3)


  Актуализирован ТК 17891 для сценариев ВПМЖ:
  - удалено действие активации чек-бокса перед выбором радио-кнопки

### Cargo

#### fix
- **Актуализация автотестов в связи с выходом новых доработок**
  [(1b69148)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1b69148fc6d9f701bc251a337b7c8a32bd76cd26)


  1. selectorCargo.js - добавлены новые локаторы
  2. stepCargo.js - исправлен степ ADI_T13009 (степ разбит на два кейса - ЮЛ/ИП)
  3. ADI-T14516.pom.spec.js, ADI-T17409.pom.spec.js - правка ADI_T13009
  4. ADI-T17189.pom.spec.js - исправлены проверки ПФ, удалены шаги активации оговорок о перевозках
  5. ADI-T8339.pom.spec.js - удалена проверка триггера 'Отсутствие вооруженной охраны при перевозке высоколиквидных грузов'
  6. ADI-T8340.pom.spec.js - удалены шаги активации оговорок о перевозках

### PLE

#### fix
- **Актуализация адреса с литерой в автотестах, правка степа ADI_Т2693**
  [(cd1e385)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/cd1e3854511e73e23bf368c49aeaafd11c338a68)


  1. В автотестах исправлен адрес с литерой Д:
  * ADI-T2441.pom.spec.js
  * ADI-T2691.pom.spec.js
  * ADI-T3623.pom.spec.js
  * ADI-T5007.pom.spec.js
  * ADI-T5091.pom.spec.js
  2. В степ ADI\_Т2693 исправлено наименование ключа.

### ИПОТЕКА ВТБ

#### feat
- **ADI-25042 Автоматизирован ТС ADI-T4509**
  [(df3742a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/df3742a89a61627f610faf2afe7d2c9f06f2baa2)


  1. Автоматизирован сценарий ADI-T4509
  2. Добавлены шаги в stepMortgageVTB
  3. Добавлены локаторы в selectorMortgageVTB
  4. Добавлен тестовый файл для добавления вложений

## 26.05.2025

### ИПОТЕКА ВТБ

#### fix
- **ADI-22097 актуализация сценариев регресса, исправление таймаутов**
  [(2545b7b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/2545b7b2987712fcc85ccc29397888c8ed2f9796)


  1. Исправлены ожидания в сценариях
  2. Актуализированы шаги в stepMortgageVTB.
  3. Добавлены локаторы в selectorMortgageVTB

### AgentAgreements

#### fix
- **Актуализация тестов**
  [(dbecf40)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/dbecf40e96dd4aca52a3aacbdbc0a3c818e00805)


  * 10560 - исправлены тестовые данные
  * 10114 - добавлен шаг с ожиданием запроса

## 22.05.2025

### ИФЛ-Квартира

#### feat
- **Автоматизация ADI-T18114**
  [(b76ac2e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/b76ac2e70e6b4b310db53a56d9712935c324021e)


### СОГАЗ-АВТО

#### feat
- **Автоматизирован ТС ADI-T17745**
  [(b8072e1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/b8072e199120ec5566fa43eb793d1e41a00dd646)

- **Автоматизирован сценарий ADI-T17864**
  [(5ed48cc)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/5ed48ccc4a5cb0ad14e4585d17c1fac4f82d1b40)


### ИФЛ-Строение

#### new
- **Автоматизация ТС ADI-T15155**
  [(9b8bea7)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/9b8bea7d4b1717d22fcd77909e0242e47a00ad73)


### АДиКВ

#### fix
- **Исправление шагов, ссылок и данных в кейсах по всему продукту**
  [(7989aa3)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/7989aa333b119526c33d1845bd0d6ddc8c24a5f0)


## 15.05.2025

### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4820 актуализация сценариев регресса**
  [(e565a40)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e565a409b7742eb29a7b4f23875c762458d87acb)


## 14.05.2025

### ИФЛ

#### fix
- **Корректировка тестов по Перс. решению и ЗН 8.12.0**
  [(44e25c6)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/44e25c6aafcfa096f4acf2380da21ce8dc13cd21)


  - Исправление текста уведомлений по СМС(сокращение текста) в связи с доработкой по Перс. решению и ЗН
  - Корректировка тестов по Перс. решению после запуска в версии 8.12.0

### СОГАЗ-АВТО

#### fix
- **Актуализация тестов каско после релиза v8.12**
  [(2604a54)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/2604a5431920ebd23ebdfa9af6e16a5ea14487d7)


### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4820 фикс сценариев после регресса**
  [(12b5ae9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/12b5ae9f677fccce547603eacb6f34c1cfaee6b3)


## 13.05.2025

### ИФЛ-Строение

#### feat
- **Автоматизация ADI-T18426**
  [(d2834f1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d2834f14b9dee12b8ed79a9548591f569c0414c3)

- **Автоматизация ADI-T18425**
  [(1243cbb)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1243cbba7987f0aaabc45c1ce0d4b0c557bbd502)


## 12.05.2025

### НСиБ и ВПМЖ

#### fix
- **Актуализация тестов**
  [(400e3d8)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/400e3d846c3e71c282cc019a0a1a04308dda9601)


## 07.05.2025

### Несчастный случай

#### feat
- **Автоматизирован ADI-T18304**
  [(2d32035)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/2d320350e701815f88df071ba7fe8a9bb886d8a1)


### Acciedent

#### feat
- **Автоматизирован ADI-T18264**
  [(4aed0ac)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/4aed0ac5e4ba7038ac3040469afb042c21ee5daa)

- **Автоматизирован ADI-T18271**
  [(ed84fcd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ed84fcd0eeefdfceda24b3abb45476f245e8d72d)


## 06.05.2025

### PLE

#### feat
- **Переведен на POM автотест ADI-T15184**
  [(c8730c1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c8730c1bddbb36b03da1f094391eab0a6d007789)

- **Переведен на POM автотест ADI-T4495**
  [(79c3c0a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/79c3c0ae4bf8a7f97fd49005846bba8cfcb3cec5)

- **Переводен на POM автотест ADI-T4475**
  [(256b79e)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/256b79e0344749b9942c1de01e30e05ce15fc8f0)

- **Переведен на POM автотест ADI-T4918**
  [(8802769)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/88027690420fe0d6fa92126acf97649233d9bae1)

- **Переведен на POM автотест ADI-T3048**
  [(00d7fe3)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/00d7fe3fd3a270ff7d1a634f08933dd23812b317)

- **Переведен на POM автотест ADI-T15183**
  [(84faf38)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/84faf38b5c68c6598540abee52300a135e65eb18)

- **Переведен на POM автотест ADI-T4810**
  [(5898140)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/5898140aebbc8b2dd8fc9071212eb45f6103b6c6)


### Cargo

#### fix
- **Актуализация автотестов Cargo в связи с предстоящим выходом новых доработок**
  [(a7c898a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/a7c898a931fca83b38cb42e4e9e32bf31daa7397)

- **Актуализация проверок ПФ в автотесте ADI-T17189**
  [(aa07211)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/aa072118c72f4b5782dfdc9bcf50224d060503dc)


### ИПОТЕКА ВТБ

#### feat
- **Автоматизирован ТС ADI-T5144**
  [(14d29ee)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/14d29ee215d89d12e6631bdad9b396967b190c45)

- **Автоматизирован ТС ADI-T13316**
  [(7a6fb12)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/7a6fb12b785a08f5b5af83853e9cd7bff95dc68d)


### PLE, Cargo

#### fix
- **Добавлены таймауты для продолжительных автотестов (более 30 мин)**
  [(521696a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/521696ab722616a74e08c5769346fd5b6c829813)


### ОСАГО

#### feat
- **Актуализирован и переведен на pom ТС ADI-Т4678**
  [(c804840)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c8048401eb06d019de25df6bd77cb23a8e5fe619)

- **Перевод сценария на pom ADI-T10407. Обновление парковых файлов**
  [(74bf847)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/74bf847ea877b0e8556bbc1329fbd03ffe98958c)


### ИФЛ-Строение

#### feat
- **Автоматизация ТС ADI-T18321**
  [(c3ea24f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c3ea24f3eb432f03e09ad1b9248cd0cd73bf5c69)


### Спецтехника

#### fix
- **Актуализация теста ADI-T10926**
  [(3658d46)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3658d46eb3c735653eb366c8af0169a60afe5ac9)


### НС

#### feat
- **Автоматизирован ADI-T18246**
  [(4e4b294)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/4e4b294769e90ab4a7524a29928cdaa0c9e1443e)


## 25.04.2025

### PLE

#### feat
- **Переведен на POM автотест ADI-T4700**
  [(4751aff)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/4751aff02c95ef8f84159060d1efe4480bd9ef00)


### ИПОТЕКА ВТБ

#### feat
- **Автоматизирован ТС ADI-T11364**
  [(3b1f3d6)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3b1f3d6f864b6fb6b3535d0b83bd0ad2e2e3c61c)


  1. Автоматизирован сценарий ADI-T11364
  2. Добавлены локаторы в selectorMortgageVTB
  3. Добавлены "эталонные" скриншоты ПФ

### Cargo

#### fix
- **Актуализация автотестов по Грузам с добавлением проверок ПФ**
  [(f62a9eb)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f62a9eb0b6b4ed65b0e502842f904925be54588b)


  1. Добавлены проверки ПФ Лист согласования в автотесты ADI-T17409 и ADI-T17565
  2. Обновлен файл с локаторами и степами
  3. В автотестах изменен запрос, ожидаемы при сохранении документа
  - ADI-T14516
  - ADI-T17409
  - ADI-T17565
  - ADI-T18089
  - ADI-T18101

## 24.04.2025

### СОГАЗ-Квартира

#### fix
- **Корректировка ТС 4766  и добавление метки FIXME**
  [(0111ca7)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0111ca709c7e52deeb7d467f4ae2aab42f6ec3d3)


  * Корректировка ТС 4766
  * Исправление названия кнопки "Поиск страхователя" ПдИ

### Step general

#### fix
- **Фикс шагов с Витриной задач**
  [(c111871)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c1118718f48589aefda4e52ace98db77a37a4cc5)


### ИПОТЕКА ВТБ

#### fix
- **Актуализация сценария ADI-T14633**
  [(dcfab87)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/dcfab877c8155149cc20467427a71aba785ca264)


  1. Актуализирован сценарий ADI-T14633
  2. Заменены "эталонные" скриншоты

### НС

#### feat
- **Автоматизирован ADI-T18212**
  [(57da756)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/57da7565c8773772826e31828c09b6068697e368)


  - Автоматизирован ADI-T18212

## 23.04.2025

### Agent agreements

#### fix
- **Актуализация тестов**
  [(915aa1f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/915aa1faec7742bb59e8ae29beca4d6847c0b8a0)


  - Изменены значения КВ

### ИПОТЕКА ВТБ

#### feat
- **Автоматизирован ТС ADI-T14633**
  [(24c94ef)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/24c94eff380066a9f53fe13fadca0601dd5be637)


  1. Автоматизирован сценарий ADI-T14633
  2. Добавлены "эталонные" скриншоты пф

### Step General

#### fix
- **Исправление Группы в 'Витрина Задач' (ADI_T1241)**
  [(aac1e20)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/aac1e20385d172031f9d4a0abaa1125d48f9e1ae)


  Правка комбобокса 'Группа' в Витрина задач, добавлен `${stepArguments.group}`

### PLE

#### fix
- **Актуализация поиска в Витрине задач в автотестах ИЮЛ**
  [(06c9ed7)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/06c9ed7aa149cde9b9a375ab244eb2c3fa081734)


  1. Исправлен степ 3954 (поиск задач по группе)
  2. В автотестах, не переведенных на pom, исправлен поиск в витрине задач:
  - ADI-T15183
  - ADI-T15184
  - ADI-T15456
  - ADI-T3048
  - ADI-T3377
  - ADI-T4475
  - ADI-T4495
  - ADI-T4700
  - ADI-T4918
  3. Убраны во всех сценариях дублирующие действия `await page.getByTestId('my-tasks-table_search-button').click()`

### СОГАЗ-АВТО

#### fix
- **Рефакторинг в тестах каско**
  [(d1e7fb3)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d1e7fb30d4a9e41d05cb27c9eb4dcc322ce5e915)


  Вынес id действий (из меню Действия) в `selectorMotorCasco`, `selectorMotorCascoPark` (для степов `ADI_T2399`, `ADI_T3458`)

## 22.04.2025

### ИФЛ-Строение

#### feat
- **Автоматизация ADI-T18346**
  [(f3fa7e9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f3fa7e9652acad6de1499884650fd79c3beeebe7)


### СОГАЗ-Квартира

#### fix
- **Корректировка ТС 12472, 12486, 13749,**
  [(fe0e2cf)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/fe0e2cf4191dbb81422c244aed3b19d93ce45a02)


### Step General

#### fix
- **Исправление Группы в 'Витрина Задач'**
  [(d72b16f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d72b16ffea0ea69fc9dc4dd8c2360048fc6c3a79)


### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4793 Актуализированы сценарии после регресса**
  [(09cfd72)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/09cfd723e0ceaf78132d35f223ddef82b35bfc8d)


## 21.04.2025

### ОСАГО

#### feat
- **Актуализирован и переведен на pom ТС ADI-Т4025**
  [(e1fad0f)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e1fad0feeec09ecae251e4d56e25d52f822e229f)


### Cargo

#### feat
- **Автоматизирован на POM новый сценарий ADI-T8562**
  [(d54ba4b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/d54ba4b95eb5c4c19846c3d2fb2abf2416d49517)


### ИПОТЕКА ВТБ

#### feat
- **Автоматизирован ТС ADI-T14060**
  [(ccf5ab9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ccf5ab983ca46ca64423f3ae0604673506fcd40f)


## 18.04.2025

### ОСАГО

#### fix
- **Перенесен сценарий ADI-T14889 на POM**
  [(779a0c6)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/779a0c66bf7e635cbe81166ba0c9c001ebb20e4d)

- **Актуализирован и переведен на pom ТС ADI-Т14894**
  [(2653da1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/2653da1528d3399d15a8a8a698885f71d41e2534)


#### feat
- **Переведен сценарий ADI-T5518 в POM**
  [(fbf667c)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/fbf667c3279123598ba4c6d98ebbf301cb315493)


### НС

#### fix
- **Автоматизированный сценарий ADI-T18252**
  [(bc32860)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/bc328607c3f69103150c74df8f2bc7cf74f26044)


  - Автоматизированный сценарий ADI-T18252

### Cargo

#### feat
- **Автоматизирован новый сценарий ADI-T17189 на POM**
  [(bc2c4da)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/bc2c4da58588b70873d476e83a6b22a7bacb9b3d)


### ИФЛ-Строение

#### feat
- **Автоматизация ADI-T17571**
  [(e33587c)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e33587c6701297454732ab4957ccf1d649bcd1d8)


### ОСАГО-Парки

#### fix
- **Убраны шаги с выбором "поиск в системе Адакта"**
  [(abf122d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/abf122d882037764724f773c9acbe3d6f449e7ee)


  - ADI-T13966
  - ADI-T5187
  - ADI-T5192
  - ADI-T5518

### Спецтехника

#### feat
- **Перенос тестов на pom**
  [(89642d2)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/89642d26b942cc785a4c834dd569b5c52eeb9553)


  перенос тестов на pom по спецтехнике:
  * ADI-T13785
  * ADI-T14744
  * ADI-T5006
  * ADI-T6329
  Починка (опечатки) теста ADI-T3598 по каско

### CargoExpress

#### feat
- **Автоматизирован на POM новый сценарий ADI-T17605**
  [(dd3d403)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/dd3d403685b5f7a318344d5681a4eae4b8a0da16)


### СОГАЗ-Авто

#### feat
- **Автоматизирован тест ADI-T18193**
  [(0c851b2)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0c851b213a1f58776e40b4786b8956b37db787bb)


## 17.04.2025

### НС

#### feat
- **Автоматизация сценария ADI-T18259**
  [(bd7a50a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/bd7a50af2e53df322f512daa3290c10c4b1298fd)


  - Автоматизация сценария ADI-T18259

## 16.04.2025

### ОСАГО

#### feat
- **ADI-21329 переведен на POM ADI-T13966**
  [(3ee5caf)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3ee5caf691b98d52c3afe52fcf79a1f68f3e58e9)


### ИФЛ-Строение

#### feat
- **Автоматизация сценария ADI-T17271**
  [(acc29b4)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/acc29b4e3bd0982a0bf1504608834015cdab3c2b)


  - Автоматизирован ТС ADI-T17271
  - Добавлены селекторы
  - Добавлена УЗ пользователя "Отмахова"

### ИПОТЕКА ВТБ

#### fix
- **Changelog-4777 Актуализация сценариев после регресса**
  [(7637e48)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/7637e48f0a43a18f475c10066e88cba79d736760)


### ИЮЛ

#### fix
- **Актуализация автотестов ADI-T13036, ADI-T13038, ADI-T17468, ADI-T5051**
  [(91f4a77)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/91f4a77e7dc4bd0f57d029d38bc552e83869d01a)


  1. Исправлены запросы, ожидаемые при сохранении документа:
  - ADI-T13036.pom.spec.js
  - ADI-T13038.pom.spec.js
  2. Исправлен запрос, ожидаемый при переходе на вкладку документа - ADI-T17468.pom.spec.js
  3. Исправлен индекс страницы с проверяемой печатной формой - ADI-T5051.pom.spec.js

#### feat
- **Автоматизирован новый сценарий ADI-T18343 на POM**
  [(4dc350c)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/4dc350c5272761b1f4b46de61571ee43fcbd22e0)

- **Переведен на POM автотест ADI-T15041 с проверкой ПФ**
  [(fe3aa33)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/fe3aa33df3219ad2cdf6094e40f4b75033071ef8)

- **Переведен на POM автотест ADI-T10576 с проверкой ПФ**
  [(ec0ef9c)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ec0ef9c0cb8c15d9d2beca73703e7c7873f52395)


### CargoExpress

#### feat
- **Автоматизирован на POM новый сценарий ADI-T17616**
  [(cfd26b0)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/cfd26b08c06c3da7d51f01ef2e65fcd1b87fb8c9)


## 15.04.2025

### Проект

#### fix
- **Убраны секреты в переменные Gitlab CI**
  [(133d5bd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/133d5bd37ebf8631709881c38dae29e1aaa37697)


### НС

#### feat
- **Добавление нового продукта НС в master**
  [(907a6bb)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/907a6bbeddf5eeb5252bfefb06d02a7d6e31ab75)


  - Созданы папки с продуктом в UI,test-step,pages,testDataSuit.
  - Добавление продукта в Fixtures
  - Добавление продукта в ci.yml
  - Создан автотест по сценарию ADI-T18262, добавлены новые шаги по продукту.

### BasePage

#### feat
- **добавление метода viewingNetwork в basePage**
  [(86cd817)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/86cd817e7ef170e059672bda84863f58322b50f3)


  - Метод по прослушиванию сетевых запросов и извлечения тела запроса либо тело ответа, который на вход принимает response/request, url и возвращает тела запроса либо тело ответа в виде объекта
  - Используется для проверки уведомлений PaperCut

### StepGeneral

#### fix
- **Добавлен новый шаг ADI_T3614**
  [(a56961d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/a56961dc32f835969f9ae6ab06f9c5cbf1a4e497)


  ADI-T3614 Поиск и выбор в форме "Поиск контрагентов - по параметрам" по ФИО и коду в системе Адакта (по кнопке "Поиск страхователя")

## 14.04.2025

### КАСКО

#### fix
- **Рефакторинг**
  [(f6bd793)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/f6bd79319d84a1d5baa5fccf27adb5f91c9b0113)


  1. Для использования в ТК (1990, 2641) id вкладок и элементов меню вынесены в selectorMotorCasco
  2. Для использования в ТК 2607 в selectorMotorCasco вынесены логин и пароль

### ИФЛ-Квартира

#### fix
- **fix test personal property flat 17398 and 17410**
  [(c73969d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c73969de7e983d2f3eb1fefcd2969e00ed780ad8)


  - Корректировка сценариев 17398 и 17410 после падений на регрессе

## 11.04.2025

### ИЮЛ

#### feat
- **Переведены на POM автотесты ADI-T2528 и ADI-T5073**
  [(0315ada)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0315adace78a8c71e0f858a62a3462ce0913537d)


  1. Перевод на POM автотестов ADI-T2528 + к нему Допс.поглашение ADI-T5073
  2. ADI-T2528.spec.js и ADI-T5073.spec.js - skip
  3. Добавлены новые локаторы
  4. stepPropertyLegalEntities:
  * добавлены новые степы - ADI_T3710, ADI_T12077, ADI_T7870, ADI_T15028, ADI_T11211, ADI_T15030, ADI_T15037, ADI_T9371, ADI_T3954, ADI_T5016
  * отредактированы степы - ADI_T8002, ADI_T14870, ADI_T3852, а также сокращены таймауты в степах по работе с триггерами, которые пока невозможно убрать.
  5. В ADI-T5073.pom.spec.js добавлены проверки ПФ

### СОГАЗ-Квартира

#### fix
- **ADI-22097 исправление ТС 17398 и 17410**
  [(574da29)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/574da29d3f897be96263acbbd2afc0e6d601bb28)


  - Исправлены ТС после падения 17398 и 17410

## 10.04.2025

### Имущество ФЛ - Строение

#### feat
- **Автоматизация ТС ADI-T17275**
  [(a9cf751)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/a9cf751ad24a66ddaf7e79ffb7f03a3c4de61c79)


  - Автоматизация сценария ADI-T17275
  - Добавление степов и селекторов
  - Скип неактуальных тестов

### СОГАЗ-Квартира

#### fix
- **Корректировка автотестов после актуализации ТС**
  [(9fdfc35)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/9fdfc35a1386456eb44c09a4896f197cb28119ef)


  Корректировка ТС 6720, 3435, 11218

### ИПОТЕКА ВТБ

#### fix
- **Актуализация автотестов**
  [(6291599)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/629159938219e17f00dad36ed540dbc016537277)


  1. Добавлены локаторы в selectorMortgageVTB
  2. Добавлены "эталонные" скриншоты пф
  3. Актуализация stepsMortgage
  4. Добавление @ в импорты
  5. Актуализация сценариев исходя из корректировок в зефире

## 09.04.2025

### Cargo

#### fix
- **Актуализация ADI-T17409**
  [(da53a35)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/da53a35a2ec118a55f91022cf8a6c12e132290de)


  1. Актуализирован контрагент-перевозчик в ADI-T17409
  2. Исправлено наименование триггера в связи с заменой КА

#### feat
- **Автоматизирован TC ADI-T17409**
  [(971ec1b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/971ec1b0a13e47cb70a0e2d78774b7315fa0acb0)


  1. Автоматизирован ТС ADI-T17409
  2. Добавлены новые локаторы
  3. Исправлены незначительные опечатки в автотестах ADI-T17565, ADI-T18089, ADI-T18101
- **Автоматизирован ТС ADI-T17565**
  [(3b14634)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3b1463450f4269925959d264aadacd8a5e3b06bb)


  1. Автоматизирован на POM новый ADI-T17565
  2. Добавлены новые локаторы для блока ручных триггеров и для нового документа "Декларации за период"
  3. Добавлены новые степы ADI_T15252, ADI_T5959, ADI_T15624, ADI_T17465
  4. Поправлены степы ADI_T13141 и ADI_T5364
  5. Добавлен новый файл для вложений Declaratsiya.txt

### fixtures

#### fix
- **Зашифрован токен авторизации**
  [(c41f1c1)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c41f1c13492d5efedd310bfdd641506f3bb90f7d)


  1. Изменения, связанные с требованиями безопасности: зашифрован токен авторизации в файле resultLoader.js

### СОГАЗ-АВТО

#### fix
- **Актуализация ТС ADI-T18000**
  [(1e50385)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/1e5038557850c11ca7b57da7b51f66d25b04ff4d)


  1. Изменения в части проверки поля "Способ подписания договора" в связи с доработкой ADI-24540

## 08.04.2025

### СОГАЗ-Квартира

#### fix
- **ADI-22097 Исправление автотестов после падения в 8.10.0**
  [(0983117)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0983117d5f2b9fa136b79b7d5681115ffcf4ee5e)


  - Актуализация ТС после падения ADI-T3402 ,ADI-T5297, ADI-T7243, ADI-T11456, ADI-T8848, ADI-T6610
  - Skip неактуальных тестов с котировкой и андеррайтингом которые убрали в продукте ADI-T12434 , ADI-T12445 ,ADI-T12453 , ADI-T12455 ,ADI-T12472

### ИПОТЕКА ВТБ

#### feat
- **Автоматизирован ТС ADI-T7738**
  [(8f4bb0c)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8f4bb0c5161bbdb3741d7315121a556afb536b02)


  1. Автоматизирован сценарий ADI-T7738
  2. Добавлены локаторы в selectorMortgageVTB
  3. Добавлены "эталонные" скриншоты пф

### ВПМЖ

#### fix
- **Актуализация теста ADI-T5288**
  [(630f17d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/630f17d79c879bdb689cd233b5d99618f76a4c4b)


  * Исправлен шаг ADI_T11767
- **Актуализация тестов ВПМЖ**
  [(310a46b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/310a46b7f322b072f3e0c3c21167f6f418f122f7)


  * Исправлен шаг ADI_4273
  * Исправлен шаг ADI_T4597
  * Исправлен шаг ADI_T4273

### ИФЛ-Квартира

#### feat
- **Автоматизирован ADI-T17398**
  [(3e941ca)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3e941ca0956b15cb82074122fd0ec3490c0a2617)


  * Автоматизирован ТС ADI-T17398
  * Добавлены степы
  * Добавлены селекторы

### СОГАЗ-АВТО

#### fix
- **Актуализация автотестов**
  [(aa85cfd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/aa85cfd9f42b1b39f4e58e9d695d84b14b0f05ef)


  * ADI-T1130 - замена 1ой страницы ПФ
  * ADI-T12563 - убраны кавычки в наименовании триггера
  * ADI-T12827 - замена 3ёх страниц ПФ
  * ADI-T14395 - перезалив 1ой страницы ПФ
  * ADI-T17416 - замена 2 страницы ПФ

### ИЮЛ

#### fix
- **Актуализация автотестов**
  [(73db6c8)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/73db6c89a85cac70d236c38ffe0edb128a06793e)


  * ADI-T2528 - удалено лишнее сохранение. Добавлен таймаут на общее время прохождения автотеста, чтобы не править в конфигах. Т.к. тест может длиться более 30мин.
  * ADI-T2702 - откат степа переключения роли в Новом договоре до POM и добавлено сохранение с ожиданием запроса.
  * ADI-T17468 - добавлено ожидание запросов при переходах по статусам, перенесен шаг сохранения номера договора, удалено лишнее сохранение, оформлены имеющиеся таймауты
  * Допсы ADI-T5091, ADI-T5007, ADI-T5076, ADI-T5038 - одинаковые правки: исправлена опечатка в запросах (GeneralAmendment --\> CancellationAmendment), добавлены ожидания запросов при подписании и активации

## 07.04.2025

### ИЮЛ

#### feat
- **Перевод тестов ADI-T2599 и ADI-T5051 на POM**
  [(4e579be)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/4e579be3b62c1941b6cffb8317e68fa206b612db)


  * Перевод тестов ADI-T2599 и ADI-T5051 на POM (догоовр и допс к нему).
  * В сценарий ADI-T5051.pom добавлены проверки ПФ
  * skip - ADI-T2599.spec.js и ADI-T5051.spec.js
  * Новые степы ADI_T6347

### Cargo

#### feat
- **Автоматизирован на POM новый сценарий ADI-T18101**
  [(ad82867)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ad82867fe376902c553275765e8f6595a434e99d)


  * Автоматизирован на POM новый сценарий ADI-T18101.
  * Добавлена скриншотная проверка печатной формы + скриншот.
  * Добавлен новый степ ADI_T12656.
  * Добавлены новые локаторы.

## 04.04.2025

### ИЮЛ

#### fix
- **Актуализация автотестов**
  [(8004328)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8004328c2171db1e41a5b88b4eb6444b41d17e4e)


  * ADI-T13962 - добавлен таймаут на время прохождения автотеста;
  * ADI-T10576 и ADI-T2528 добавлено два таймаута ДО перевода на pom.

### Cargo

#### fix
- **Актуализация автотестов в связи с доработкой GRZ-9**
  [(ec99b36)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ec99b36403edca7374c3b0e2e6fec0cd70338714)


  * Актуализация всех автотестов папки Cargo, **кроме ADI-T12553** .
  * Актуализация степов ADI_T9356, ADI_T6200, ADI_T12363, ADI_T7145, ADI_T7146.
  * Добавлен новый степ ADI_T18242.
  * Добавлены локаторы.

#### feat
- **Автоматизирован TC ADI-T18089**
  [(0a7b95d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0a7b95d2ca1f0c8883ac3baee49ffcc1422bdf80)


  1. Автоматизирован на pom новый сценарий ADI-T18089 с проверкой ПФ
  2. Созданы новые степы - ADI_T14127, ADI_T18230, ADI_T16043, ADI_T16042, ADI_T13008
  3. Добавлены новые локаторы
  4. Добавлено новое вложение

## 03.04.2025

### ИПОТЕКА ВТБ

#### fix
- **Актуализация автотестов**
  [(7020f2b)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/7020f2b7737cb6ed21e9cbe7789c329976c375fd)


  1. Актуализированы сценарии регресса
  2. Исправлены шаги в stepMortgageVTB.
  3. Удалены шаги deprecated
  4. Добавлены локаторы в selectorMortgageVTB

### СОГАЗ-Квартира

#### fix
- **Автоматизация adi t17410**
  [(0179bd9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/0179bd9684ce431462357796b7a03e6ddd02998e)


  - Автоматизирован сценарий ADI-T17410
  - Добавлены степы
  - Добавлены селекторы

### АДиКВ

#### fix
- **ADI-21326(agent agreements)**
  [(ec897d0)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ec897d0be083d84d08309780a81a2f43a8369b5d)


  ADI-11214 изменились шаги и ссылки проверки
  ADI-T10114 добавление шагов по установке чекбоксов, убрал неактуальный шаг
  ADI-T10616 изменение и добавление шагов + добавление ссылок на ожидание
  ADI-T11043 добавление шагов из-за изменения в продуктах, убрал проставления чекбокса
  ADI-T11044 убрал установку чекбокса
  ADI-T11213 добавление шагов из-за изменений в шагах
  ADI-T6320 добавление шагов из-за изменения в продукте
  ADI-T8101 убрал проставление чекбоксов из-за изменения в продукте
  ADI-T9429 добавление шагов из-за изменения в продукте

## 02.04.2025

### ИЮЛ

#### feat
- **Автоматизирован TC ADI-T18019**
  [(a083616)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/a083616e7a38e9bf9d714562677ca3eebe82bf3c)


  1. Автоматизирован сценарий ADI-T18019

### ОСАГО

#### fix
- **ADI-21329 Обновление парковых файлов**
  [(660bc97)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/660bc9729ea8b6e656d3c3576a90274f9513deb9)


### ИФЛ-Квартира

#### feat
- **Автоматизирован сценарий ADI-T17332**
  [(99843be)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/99843bea888bc55f54088de6d991cfa2d18a691b)


  - Автоматизирован сценарий ADI-T17332
  - Добавлены степы в stepPersonalPropertyFlat
  - Добавлены селекторы

### СОГАЗ-АВТО

#### feat
- **Автоматизирован сценарий ADI-T8000**
  [(6621c34)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/6621c34e9b329e933df6027a432e6d51152d7b00)


## 01.04.2025

### ИЮЛ

#### feat
- **Перевод тестов ADI-T8760 и ADI-T13692 на POM**
  [(21dc81c)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/21dc81c4333eee49c2bd09bc3b3e67f3efe04b1a)


## 28.03.2025

### ИЮЛ

#### feat
- **Автоматизация сценария. Актуализация**
  [(fb268dd)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/fb268dd70b9a10658a6b54667f14e06c75a86da2)


  - автоматизация на pom нового сценария ADI-T18026
  - созданы новые степы ADI_T4518, ADI_T17597, ADI_T18027, ADI_T18028, ADI_T18031
  - правки в сценариях ADI-T2528, ADI-T5073, ADI-T13962, ADI-T8760, ADI-T5091, ADI-T4475, ADI-T13036 по итогам регрессионного тестирования v8.9
  - работа над сценарием ADI-T13692. Откат на предыдущую версию

## 27.03.2025

### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4719 Актуализация**
  [(621fbaa)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/621fbaa954f3d25dc1c77ca1a5da7249cefc8980)


  1. Актуализированы сценарии после падений на регрессе
  2. Добавлены шаги в `stepMortgageVTB` и их использование

## 26.03.2025

### СОГАЗ-Квартира

#### fix
- **Исправлены тесты по новому процессу оформления документа**
  [(73d3125)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/73d31254262c0cfaaa341f6ea73c2aeb894fa7fe)


  - Исправлены все тесты по новому процессу без котировки - сразу договор
  - Исправлены селекторы
  - Добавлено временное решение по включению чекбокса "Плательщик совпадает со страхователем" пока не исправят ошибку
  Issue: #ADI-24341

### ИЮЛ

#### fix
- **Актуализация тестов**
  [(cad9122)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/cad912283a94fd6bbc5a93002d939c42157a0eba)


  - новый степ `ADI-T6402`
  - часть степов переделана под `stepArguments` (степы, которые используются на текущий момент не более 10 раз в разных сценариях / по остальным долгая работа, есть степы, которые используются более 100 раз). Поправлены сценарии, где эти шаги используются
  - добавлены ссылки на степы в ZS `@see {@link}`, были не везде
  - внесены правки в сценарии по результатам прохождения v8.9.0 (исправлены некоторые недочеты/ошибки, внесены правки)

## 25.03.2025

### ИПОТЕКА ВТБ

#### fix
- **CHANGELOG-4713 Актуализация тестов**
  [(ed3073d)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ed3073d1753ac9c3c419a7e20a5b170b0d9095d9)


  - актуализированы сценарии после падений на регресса
  - исправлены шаги в stepMortgageVTB.
  - добавлены локаторы в selectorMortgageVTB

### ГРУЗЫ

#### fix
- **Правка сценариев**
  [(30e0ad9)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/30e0ad924896fe9d94c53e73fdbfed02fed8cde3)


  - исправлена ссылка на импорт во всех сценариях Грузы и Карго-экспресс.
  - правка в сценариях Карго-экспресс ADI-T17202 и ADI-T17203 в связи с резким изменением курса валюты
  - правка в степе ADI_T7145 + автоматические исправления при сохранении

### ОГО

#### fix
- **Фикс по всем сценариям в связи с новыми доработками**
  [(48a13cf)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/48a13cf8ea52341abfafdb89510f7db9e6a4318d)


  - ADI-T16975 добавлено сохранение перед проверкой валидаций

### ИЮЛ

#### feat
- **Перевод теста ADI-T15494 на POM**
  [(a695108)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/a695108214387778808bef289a22eb83a0c430af)


  - Переведен на pom автотест ADI-T15494
  - Два новых степа - `ADI-T15029` и `ADI-T18130`
  - Правки в степах - `ADI-T3400` и `ADI-T15496`

## 24.03.2025

### Спецтехника

#### fix
- **Перенос тестов на pom**
  [(6be1bb4)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/6be1bb4b95d41877c523f9701c0dd277864ea435)


  1. новые степы: ADI_T7260, ADI_T7264, ADI_T7265, ADI_T4163, ADI_T4083
  2. только перенос на pom:
   - ADI-T16984
   - ADI-T4225
   - ADI-T4665
   - ADI-T4907
   - ADI-T5113
  3. перенос на pom и актуализация по ручным тестам в зефире (автотест и ручной тест были не одинаковые):
   - ADI-T4919
   - ADI-T6539
   - ADI-T8490

### ИЮЛ

#### fix
- **Корректировка сценариев**
  [(fd45808)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/fd45808df8b389726f657bed7de0d6fe205d0d56)


  - обновлен файл с локаторами, чтобы было понятно какой локатор из какого блока/вкладки, в файле было проблематично ориентироваться
  - добавлены новые локаторы
  - добавлены новые степы для допсов
  - переведены на pom 4 допса - ADI-T5091, ADI-T5038, ADI-T5076, ADI-T5007
  - в сценарии ADI-T5076, ADI-T5007 добавлены проверки ПФ
  - по итогам ХФ v8.8.6 внесены правки в сценарии - ADI-Т17468, ADI-Т14300, ADI-Т4495, ADI-Т4475, ADI-Т3048, ADI-Т2691, ADI-Т10576, ADI-Т8760, степ ADI-Т15252
  Локально ОК.

#### feat
- **Перевод на pom сценария ADI-T2520**
  [(ce71e34)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/ce71e347c308c7e123af7085e533c0c24cb71893)


### ИФЛ-Квартира

#### feat
- **Автоматизирован ТС ADI-T17395**
  [(3ca1590)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/3ca15902715fc68bf09ab53fa400fa6144c30421)


  - добавлены селекторы
  - добавлены степы в stepPersonalPropertyFlat

## 19.03.2025

### ИПОТЕКА ВТБ

#### fix
- **ADI-24342 Автоматизирован ТС ADI-T9835 на пом**
  [(c61253a)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/c61253ae495e18ecbdf7004501370772e6153481)


  1. Автоматизирован сценарий ADI-T9835 на pom
  2. Добавлены шаги в stepMortgageVTB
  3. Добавлены локаторы в selectorMortgageVTB

#### feat
- **ADI-24302 Автоматизирован ТС ADI-T16960**
  [(8aa3883)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/8aa388370c621859e511c3b2c9a15e6e697cd637)


  1. Автоматизирован сценарий ADI-T16960
  2. Исправлены шаги в stepMortgageVTB.
  3. Добавлены локаторы в selectorMortgageVTB

### СОГАЗ-АВТО

#### fix
- **ADI-22097 Актуализация тестов каско**
  [(e80b2be)](https://gitlab.sogaz.ru/testing/autotest/adinsureautotest/-/commit/e80b2be604dcb2334848abf4ef2fc7721002bf33)


