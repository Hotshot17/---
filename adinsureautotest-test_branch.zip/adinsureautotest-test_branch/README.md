# AdinsureAutoTest


1. Клонировать проект
2. После клонирования в терминале VS Code выполнить команду `npm install`
3. Создать отдельную ветку
4. Установить плагин **Playwright Test for VS Code** (только от Microsoft)
5. Архив **ms-playwright.zip** содержит файлы браузеров. Архив необходимо распаковать в папку: %USERPROFILE%\AppData\Local

v7.x.x

