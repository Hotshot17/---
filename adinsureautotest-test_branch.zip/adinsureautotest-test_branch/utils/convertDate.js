export function convertDate(day, month, year) {
  const D = new Date()
  D.setDate(D.getDate() + day)
  D.setMonth(D.getMonth() + month + 1)
  D.setFullYear(D.getFullYear() + year)
  let curDate
  let curMonth
  const curYear = D.getFullYear()
  if (D.getDate() < 10) {
    curDate = '0' + D.getDate()
  } else {
    curDate = D.getDate()
  }

  if (D.getMonth() < 10) {
    curMonth = D.getMonth()
    curMonth = '0' + curMonth
  } else {
    curMonth = D.getMonth()
  }
  const newDate = curDate + '.' + curMonth + '.' + curYear
  return newDate
}
