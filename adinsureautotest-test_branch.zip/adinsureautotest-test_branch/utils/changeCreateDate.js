/** Обновление дат в JSON */

// Обновление CreateDate
const fs = require('fs')
let application = require('./../tests/API/ADI-T1607/json_document/create_and_safe_application.json')
let quote = require('./../tests/API/ADI-T1607/json_document/create_and_safe_quote.json')
let policy = require('./../tests/API/ADI-T1607/json_document/safe_policy.json')
// Предрасчет
// createDate
// conclusionDate
// purchaseDate

// Предрасчет. Дата создания. Текущая дата. createDate
const createDate = new Date().toISOString().slice(0, 10)
application.Data.generalData.createDate = createDate
quote.Data.generalData.createDate = createDate
policy.Data.generalData.createDate = createDate

console.log('Дата создания: ' + createDate)

// Предрасчет. Дата заключения. Текущая дата. conclusionDate
const conclusionDate = new Date().toISOString().slice(0, 10)
application.Data.terms.conclusionDate = conclusionDate
quote.Data.terms.conclusionDate = conclusionDate
policy.Data.terms.conclusionDate = conclusionDate

console.log('Дата заключения: ' + conclusionDate)

// дата начала. текущая дата + 5 дней
let startDate = new Date()
startDate.setDate(startDate.getDate() + 5)
startDate = startDate.toISOString().slice(0, 10)
application.Data.terms.startDate = startDate
quote.Data.terms.startDate = startDate
policy.Data.terms.startDate = startDate

console.log('Дата начала: ' + startDate)

// дата окончания. дата начала + 365
let endDate = new Date()
endDate.setDate(endDate.getMonth() + 367)
endDate = endDate.toISOString().slice(0, 10)
application.Data.terms.endDate = endDate
quote.Data.terms.endDate = endDate
policy.Data.terms.endDate = endDate

console.log('Дата окончания: ' + endDate)

// Предрасчет. Дата приобретения ТС = текущей дате
let purchaseDate = new Date()
purchaseDate = purchaseDate.toISOString().slice(0, 10)
console.log('Дата приобретения ТС: ' + purchaseDate)

// Предрасчет. Дата окончания предыдущего полиса. текщая дата - 5 дней
let previousPolicyEndDate = new Date()
previousPolicyEndDate.setDate(previousPolicyEndDate.getDate() - 5)
previousPolicyEndDate = previousPolicyEndDate.toISOString().slice(0, 10)
application.Data.previousInsuranceData.previousPolicyEndDate = previousPolicyEndDate
console.log('Дата окончания предыдущего полиса: ' + previousPolicyEndDate)

// дата выдачи ПТС. текщая дата - 2 дня
let ptsIssueDate = new Date()
ptsIssueDate.setDate(ptsIssueDate.getDate() - 2)
ptsIssueDate = ptsIssueDate.toISOString().slice(0, 10)
console.log('Дата выдачи ПТС: ' + ptsIssueDate)

// дата выдачи СТС. текущая дата
const stsIssueDate = new Date().toISOString().slice(0, 10)
console.log('Дата выдачи СТС: ' + stsIssueDate)

application = JSON.stringify(application, null, 2)
quote = JSON.stringify(quote, null, 2)
policy = JSON.stringify(policy, null, 2)
fs.writeFileSync('./tests/API/ADI-T1607/json_document/create_and_safe_application.json', application)
fs.writeFileSync('./tests/API/ADI-T1607/json_document/create_and_safe_quote.json', quote)
// fs.writeFileSync('./tests/API/ADI-T1607/json_document/safe_quote.json')
fs.writeFileSync('./tests/API/ADI-T1607/json_document/safe_policy.json', policy)
