/**
 * преобразование даты из формата dd.mm.yyyy в формат «dd» month yyyy г.
 * @param dateStr - принимает значение в формате: dd.mm.yyyy
 */
export function formatDate(dateStr) {
  const [day, month, year] = dateStr.split('.')

  const months = [
    'января',
    'февраля',
    'марта',
    'апреля',
    'мая',
    'июня',
    'июля',
    'августа',
    'сентября',
    'октября',
    'ноября',
    'декабря',
  ]

  if (month < 1 || month > 12) {
    throw new Error('Неверный месяц')
  }

  let curDay
  let curMonth
  let curYear

  curDay = day
  curMonth = months[parseInt(month) - 1]
  curYear = year

  const newDate = '«' + curDay + '»' + ' ' + curMonth + ' ' + curYear + ' ' + 'г.'
  return newDate
}

// const dateStr = insertDate(-5, 0, 0)
// или
// const dateStr = '05.06.2025'
// const formattedDate = formatDate(dateStr)
// console.log(formattedDate) // «05» июня 2025 г.

// await stepGeneral.ADI_T3231(
//     'toHaveValue',
//     'textbox',
//     `Застрахованное имущество является предметом обеспечения исполнения обязательств по Кредитному договору от ${formatDate(dateStr)}`,
//     policyPLE.beneficiaryTypicalConditions
//   )
