/**
 * преобразование номера телефона с символами в числовое значение, и замена кода 8 на 7
 *@param phone - принимает значение в формате: 8(999)999-99-99
 *@param cleanNumber - очищает символы
 */

export function convertNumber(phone) {
  let cleanNumber = phone.replace(/\D/g, '')
  if (cleanNumber.startsWith('8')) {
    cleanNumber = '7' + cleanNumber.slice(1)
  }
  return cleanNumber
}
