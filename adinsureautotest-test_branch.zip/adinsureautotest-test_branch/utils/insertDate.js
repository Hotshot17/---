/**
 *
 * @param days
 * @param months
 * @param years
 */
export function insertDate(days, months, years) {
  const currentDate = new Date()

  currentDate.setDate(currentDate.getDate() + days)
  currentDate.setMonth(currentDate.getMonth() + months)
  currentDate.setFullYear(currentDate.getFullYear() + years)

  const options = { year: 'numeric', month: 'numeric', day: 'numeric' }
  return currentDate.toLocaleDateString('ru-RU', options)
}

/*
Метод расчета даты от заданной даты. Дата (date) передается в формате ДД.ММ.ГГГГ
*/
/**
 *
 * @param date
 * @param days
 * @param months
 * @param years
 */
export function insertCustomDateFromString(date, days, months, years) {
  date = date.split('.')
  const currentDate = new Date()

  currentDate.setFullYear(Number(date[2]) + years, Number(date[1]) + months - 1, Number(date[0]) + days)

  const options = { year: 'numeric', month: 'numeric', day: 'numeric' }
  return currentDate.toLocaleDateString('ru-RU', options)
}

/*
Метод расчета даты в формате ГГГГ-ММ-ДД. Такой формат используется в papercut
*/
/**
 *
 * @param days
 * @param months
 * @param years
 */
export function insertRevertDate(days, months, years) {
  const currentDate = new Date()

  currentDate.setDate(currentDate.getDate() + days)
  currentDate.setMonth(currentDate.getMonth() + months)
  currentDate.setFullYear(currentDate.getFullYear() + years)

  const year = currentDate.getFullYear()
  const month = String(currentDate.getMonth() + 1).padStart(2, '0')
  const day = String(currentDate.getDate()).padStart(2, '0')

  return `${year}-${month}-${day}`

  // return currentDate.toLocaleDateString('ru-RU', options)
}

/*
Считает +/- к текущей дате
*/

// exports.insertDate = function (days) {
//   const result = new Date()
//   result.setDate(result.getDate() + days)

//   let day = result.getDate()
//   let month = result.getMonth() + 1
//   const year = result.getFullYear()

//   day = day < 10 ? '0' + day : day
//   month = month < 10 ? '0' + month : month

//   return day + '.' + month + '.' + year
// }

// const myDate = new Date().toISOString().slice(0, 10)

// const newDate = addDate(0)
// console.log(newDate)
