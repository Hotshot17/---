/* eslint-disable jsdoc/require-returns */
// @ts-check

/**
 * **Объект. Содержит типы локаторов**
 * @param {string} LocatorType.byRole - *тип локатора по роли элемента*
 * @param {string} LocatorType.byTestId - *тип локатора по id элемента*
 * @param {string} LocatorType.byTestIdByRole - *тип локатора по id и роли элемента*
 * @param {string} LocatorType.byTestIdByText - *тип локатора по id и тексту элемента*
 * @param {string} LocatorType.byTestIdAndLocator - *тип локатора. составной id и дополнительному локатору*
 * @param {string} LocatorType.byTestIdAndLocatorName - *тип локатора. составной из id и локатора*
 * @param {string} LocatorType.byRoleAndLocator - *тип локатора. составной из роли и локатора*
 */
export const LocatorType = {
  byRole: 'byRole',
  byTestId: 'byTestId',
  byTestIdByRole: 'byTestIdByRole',
  byTestIdByText: 'byTestIdByText',
  byTestIdAndLocator: 'byTestIdAndLocator',
  byTestIdAndLocatorName: 'byTestIdAndLocatorName',
  byRoleAndLocator: 'byRoleAndLocator',
}

/**
 * @class
 */
export class LocatorHandler {
  /**
   * @typedef {import('playwright-core').Page} Page
   * @param {Page} page - супер коммент
   */
  constructor(page) {
    this.page = page
  }

  /**
   * **getByRoleLocator**
   * @param {any} role - роль элемента
   * @param {object} options - опции
   * @param {string} [options.name] имя элемента
   * @param {boolean} [options.exact] строгое соответствие
   */
  #getByRoleLocator(role, options) {
    return this.page.getByRole(role, options)
  }

  /**
   * **getByTestIdLocator**
   * @param {string | RegExp} testId - id элемента
   */
  #getByTestIdLocator(testId) {
    return this.page.getByTestId(testId)
  }

  /**
   * **getByTestIdByRoleLocator**
   * @param {string | RegExp}  testId         - id элемента
   * @param {any}              role           - роль элемента
   * @param {object}           options        - опции
   * @param {string}         [ options.name ] - имя элемента
   * @param {boolean}        [ options.exact] - строгое соответствие
   * @param {number}           nth            - параметр nth
   */
  #getByTestIdByRoleLocator(testId, role, options, nth = null) {
    //return this.page.getByTestId(testId).getByRole(role, options)

    let locator = this.page.getByTestId(testId).getByRole(role, options)

    if (nth !== null) {
      return locator.nth(nth)
    }

    return locator
  }

  /**
   * **getByTestidByText**
   * @param {string | RegExp}  testId         - id элемента
   * @param {string}           text           - текст элемента
   * @param {object}           options        - опции
   * @param {boolean}        [ options.exact] - строгое соответствие
   */
  #getByTestidByText(testId, text, options) {
    return this.page.getByTestId(testId).getByText(text, options)
  }

  /**
   * **getByTestIdAndLocator**
   * @param {string | RegExp} testId - id элемента
   */
  #getByTestIdAndLocator(testId) {
    return this.page.getByTestId(testId).locator('i')
  }

  /**
   * **getByRoleAndLocator**
   * @param {any}              role           - роль элемента
   * @param {object}           options        - опции
   * @param {string}         [ options.name ] - имя элемента
   * @param {boolean}        [ options.exact] - строгое соответствие
   */
  #getByRoleAndLocator(role, options) {
    return this.page.getByRole(role, options).locator('i')
  }

  /**
   * **getByTestIdAndLocatorName**
   * @param {string | RegExp}  testId      - id элемента
   * @param {string}           locatorName - наименование локатора
   * @param {any}              role        - роль элемента
   * @param {{ name: any }}    options     - опции
   */
  #getByTestIdAndLocatorName(testId, locatorName, role = null, options = null) {
    let locator = this.page.getByTestId(testId).locator(locatorName)

    //Если роль и опции переданы, добавляем их
    if (role && options) {
      return locator.getByRole(role, options)
    }

    return locator
  }

  /**
   * @param {string}  type              - тип локатора
   * @param {object}  options           - опции
   * @param {string} [options.role]     - роль элемента
   * @param {string} [options.roleName] - название/имя элемента
   * @param {string | RegExp} [options.testId] - id элемента
   * @param {string}  [options.text]        - текст элемента
   * @param {boolean} [options.exact]       - строгое соответствие
   * @param {number}  [options.index]       - индекс локатора
   * @param {string}  [options.locatorName] - имя локатора
   * @param {number}  [options.nth]         - параметр nth
   */
  getLocator(type, options) {
    switch (type) {
      case LocatorType.byRole:
        return this.#getByRoleLocator(options.role, {
          name: options.roleName,
          exact: options.exact,
        })
      case LocatorType.byTestId:
        return this.#getByTestIdLocator(options.testId)
      case LocatorType.byTestIdByRole:
        return this.#getByTestIdByRoleLocator(
          options.testId,
          options.role,
          {
            name: options.roleName,
            exact: options.exact,
          },
          options.nth
        )
      case LocatorType.byTestIdByText:
        return this.#getByTestidByText(options.testId, options.text, {
          exact: options.exact,
        })
      case LocatorType.byTestIdAndLocator:
        return this.#getByTestIdAndLocator(options.testId)
      case LocatorType.byTestIdAndLocatorName:
        return this.#getByTestIdAndLocatorName(options.testId, options.locatorName, options.role, {
          name: options.roleName,
        })
      case LocatorType.byRoleAndLocator:
        return this.#getByRoleAndLocator(options.role, {
          name: options.roleName,
          exact: options.exact,
        })
      default:
        throw new Error('Не удалось сформировать локатор')
    }
  }
}
