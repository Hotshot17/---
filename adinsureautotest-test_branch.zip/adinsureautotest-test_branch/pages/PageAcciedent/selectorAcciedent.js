const acciedent = {
  /**combobox Канал продаж */
  salesChannel: '-ng-select',
  /**combobox Зона ответственности */
  responsibilityZone: 'responsibilityZone',
  /**button Поиск страхователя */
  findpolicyHolder: 'policyholder-search-button',
  /**вкладка 'Данные о застрахованных лицах' */
  insuredPersons: 'Tab-InsuredPersons-nav',
  /**combobox Дата начала действия страхования */
  validFrom: 'start-date-input',
  /**combobox Дата окончания действия страхования*/
  validUntil: 'end-date-input',
  /**combobox Срок действия договора (в днях)*/
  duration: 'duration',
  /**button 'Добавить' в Данные о застрахованных лицах*/
  buttonAdd: 'navigator-insured-persons-list',
  /**combobox 'Род деятельности' */
  activity: 'activity',
  /**блок 'Информация о роде деятельности' */
  activities: 'AccidentProfession-profession',
  /**combobox 'Порядок установления страховых сумм по рискам'*/
  sumInsuredOrder: 'sumInsured-order',
  /**combobox 'Общая страховая сумма'*/
  mainSumInsured: 'mainSumInsured',
  /**combobox  'Период страхового покрытия'*/
  coveragePeriod: 'coverage-period',
  /**textbox 'Страховая сумма' */
  sumInsured: 'AccidentMainRisks-risks',
  /**combobox 'Вариант выплаты'*/
  payoutOption: 'payoutOption',
  /**вкладка 'Выпуск договора' */
  policyIssue: 'policy-issue-nav',
  /**checkbox 'Плательщик совпадает со страхователем' */
  payerPolicyholder: 'payer-policyholder',
  /**combobox 'Способ уведомления' */
  payerData: 'payer-data',
  /**button 'Выход из аккаунта'*/
  out: 'header-user-dropdown-menu',
  /**button 'Направить на согласование' */
  agreement: 'ai-transitions-relations-control-Draft_SendToHigherLevel',
  /**button 'Продолжить согласование внутри ГО' */
  UW2ToUW3: 'ai-transitions-relations-control-UW2_to_UW3',
  /**button 'Согласовать'*/
  toApprove: 'ai-transitions-relations-control-UW3_SendToHigherLevel',
  /**button 'Направить исполнительному директору по андеррайтингу'*/
  UW3ToUW4: 'ai-transitions-relations-control-UW3_to_UW4',
  /**button 'На согласование ДЭБ'*/
  approvalDEB: 'ai-transitions-relations-control-UW3_to_ApprovalDEB',
  /**button 'На корректировку'*/
  forCorrection: 'ai-transitions-relations-control-UW3_to_ForCorrection',
  /**button 'Отказать' */
  rejected: 'ai-transitions-relations-control-UW3_to_Rejected',
  /**вкладка'Триггеры и комментарии'*/
  constraintsComments: 'constraints-comments-nav',
  /** блок 'Дополнительные Покрытия' */
  accidentAdditionalRisks: 'AccidentAdditionalRisks-additionalRisks',
  /**combobox 'Способы установления страховых сумм' */
  insuranceAmounts: 'sumInsured-type-ng-select',
  /**button 'Направить Исполнительному директору по андеррайтингу' */
  UW2toUW4: 'ai-transitions-relations-control-UW2_to_UW4',
  /**вкладка 'На корректировку'*/
  forCorrectionUW4: 'ai-transitions-relations-control-UW4_to_ForCorrection',
  /**button 'Отказать' */
  rejectedUW4: 'ai-transitions-relations-control-UW4_to_Rejected',
  /**button 'Согласовать'*/
  toApproveUW4: 'ai-transitions-relations-control-UW4_SendToHigherLevel',
}

export { acciedent }

export const selectorAcciedent = {
  /*-----------------------------------------------------------------------Селекторы элементов главного меню-------------------------------------------------------*/
  /** @description Папка  "Страховые продукты"' */
  contracts: 'Contracts_menu_1',

  /** @description Папка  продукта "Несчастный случай"' */
  acciedent: 'Accident_1_2',

  /** @description Элемент создания документа "Договор"' */
  acciedentPolicy: 'AccidentPolicy_1_3',

  /** @description Элемент создания документа "Коробочный договор"' */
  acciedentPolicyBox: 'AccidentBox_1_3',

  /** @description Папка  "Импорт бордеро"' */
  importBordero: 'Importdocuments_menu_1',

  /** @description Элемент меню  "Импорт НС"' */
  accidentImport: 'AccidentImport_1_2',

  /*-----------------------------------------------------------------------Селекторы элементов бокового информационного меню(сайдбар)-------------------------------------------------------*/

  /*-----------------------------------------------------------------------Селекторы вкладок документа-------------------------------------------------------*/
  /** @description  id вкладки "Данные о застрахованных лицах" */
  insuredPersons: 'Tab-InsuredPersons-nav',

  /** @description  id вкладки "Общая информация" */
  generalData: 'tab-General-nav',

  /** @description  id вкладки "Расчет тарифов" */
  tabCalculateTariffnav: 'Tab-CalculateTariff-nav',

  /** @description  id вкладки "Проверка СБ" */
  securityVerificationNav: 'security-verification-nav',

  /** @description  id вкладки "Параметры объекта" */
  objectParameters: 'tab-Object-nav',

  /** @description  id вкладки "Андеррайтинг" */
  underwriting: 'tab-Underwriting-nav',

  /** @description  id вкладки "Вложения" */
  attachedDocuments: 'tab-Attached-documents-nav',

  /** @description  id вкладки "Выпуск договора" */
  policyIssue: 'policy-issue-nav',

  /** @description  id вкладки "Триггеры и комментарии" */
  constraintsCommentsNav: 'constraints-comments-nav',

  /** @description  id вкладки "История документа" */
  contractActivityAndTransitionHistory: 'tab-Contract-activity-nav',

  /** @description  id вкладки "Информация о загрузке" */
  tabLoadedDataNav: 'tab-LoadedData-nav',

  /** @description  id вкладки "Бордеро" */
  tabBordereauNav: 'tab-Bordereau-nav',
  /*-----------------------------------------------------------------------Селекторы вкладок инфоменю-------------------------------------------------------*/
  /** @description  id вкладки "Общая информация" */
  tabSummary: 'tab-Summary-nav',

  /** @description  id вкладки "Проверки и ошибки" */
  tabNotification: 'tab-Notifications-nav',

  /** @description  id вкладки "Всего проблем" */
  validations: 'RequiredPropertiesValidations',

  /** @description  id поля "Премия, руб" */
  premiumRubles: 'premium-rubles',

  /*-----------------------------------------------------------------------Селекторы вкладок Витрины задач-------------------------------------------------------*/
  /** @description  id вкладки "Задачи группы" */
  tabGroupTasks: 'tab-Group-tasks-nav',

  /*-----------------------------------------------------------------------Селекторы списка действий документа-------------------------------------------------------*/
  /** @description Button 'Кнопка действия "К оплате"' */
  draftToPaymentWaiting: 'ai-transitions-relations-control-Draft_to_PaymentWaiting',

  /** @description Button 'Кнопка действия "К оплате"' */
  approvedToPaymentWaiting: 'ai-transitions-relations-control-Approved_to_PaymentWaiting',

  /** @description Button 'Кнопка действия "Отказаться от оформления"' */
  draftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',

  /** @description Button 'Кнопка действия "Копировать документ"' */
  copyAccidentPolicy: 'ai-transitions-relations-control-CopyAccidentPolicy',

  /** @description Button 'Кнопка действия "Копировать документ. Коробка"' */
  copyAccidentBox: 'ai-transitions-relations-control-CopyAccidentBox',

  /** @description Button 'Кнопка действия "Вернуть на предыдущий статус"' */
  annulledSendToHigherLevel: 'ai-transitions-relations-control-Annulled_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Вернуть на редактирование"' */
  paymentWaitingSendToLowerLevel: 'ai-transitions-relations-control-PaymentWaiting_SendToLowerLevel',

  /** @description Button 'Кнопка действия "Направить на согласование"' */
  draftSendToHigherLevel: 'ai-transitions-relations-control-Draft_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Оформить"' */
  paymentWaitingToActivated: 'ai-transitions-relations-control-PaymentWaiting_to_Activated',

  /** @description Button 'Кнопка действия "Согласовать"' */
  uw2SendToHigherLevel: 'ai-transitions-relations-control-UW2_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Аннулировать"' */
  approvedToAnnulled: 'ai-transitions-relations-control-Approved_to_Annulled',

  /** @description Button 'Кнопка действия "Начать загрузку файла"' */
  startLoading: 'ai-transitions-relations-control-StartLoading',

  /** @description Button 'Кнопка действия "Начать перезагрузку файла"' */
  startReloading: 'ai-transitions-relations-control-StartReloading',

  /** @description Button 'Кнопка действия "Начать импорт договоров"' */
  startImport: 'ai-transitions-relations-control-StartImporting',

  /*-----------------------------------------------------------------------Селекторы вкладки "Общая информация"-------------------------------------------------------*/

  /*-------------------------Селекторы блока "Общее" */

  // /** @description id секции "Общее" */
  // generalInformation: 'general-section',

  /** @description сombobox 'Канал продаж' */
  salesChannel: '-ng-select',

  /** @description combobox Зона ответственности */
  responsibilityZone: 'responsibilityZone',

  // /** @description Combobox 'Акция' */
  // promotion: 'promotion',

  /** @description поле Дата загрузки */
  bordereauDateSelection: 'bordereau-date-selection',

  /** @description поле Программа страхования */
  insuranceProgramBordero: 'insuranceProgram',

  /** @description поле Вариант программы */
  insuranceVariantBordero: 'insuranceVariant',

  /** @description поле Файл для загрузки */
  fileSelection: 'file-selection',

  /*-------------------------Селекторы блока "Условия страхования" */

  /** @description button 'Поиск страхователя' */
  insuranceVariant: 'insuranceVariant',

  /*-------------------------Селекторы блока "Страхователь" */

  /** @description button 'Поиск страхователя' */
  findpolicyHolder: 'policyholder-search-button',

  /** @description link 'Страхователь (ФИО/Наименование)' */
  policyholderLink: 'policyholder-link',

  /*-----------------------------------------------------------------------Селекторы вкладки "Данные о застрахованных лицах"-------------------------------------------------------*/

  /*--------------------------Селекторы блока "Страховые риски и покрытия"*/

  /** @description combobox 'Способы установления страховых сумм' */
  insuranceAmounts: 'sumInsured-type-ng-select',

  /*--------------------------Селекторы блока "Данные о застрахованных лицах"*/

  /** @description button 'Поиск Застрахованного лица' */
  personSearchButton: 'person-search-button',

  /** @description link 'ФИО' */
  personLink: 'person-link',

  /*-----------------------------------------------------------------------Селекторы вкладки "Выпуск договора"-------------------------------------------------------*/

  /*--------------------------Селекторы блока "Плательщик"*/

  /** @description combobox 'Способ уведомления' */
  notificationMethod: 'notification-method',

  /*--------------------------Селекторы блока "Поступление взносов"*/

  /** @description button 'Добавить взнос' */
  addPaymentButton: 'PaymentDataGrid-add-button',

  /** @description button 'ОК. Взносы' */
  okPaymentButton: 'PaymentDataGrid-ok-button',

  /*-----------------------------------------------------------------------Селекторы вкладки "Триггеры и комментарии"-------------------------------------------------------*/

  /*--------------------------Селекторы блока "Триггеры"*/

  /** @description combobox 'Статус' */
  quoteState: 'quote-state',
}
