/* eslint-disable camelcase */
// @ts-check

const sogazShop = {
  /** id поля "Дата начала страхования" */
  dateStart: 'date-start',
  firstDateTaxi: 'firstDate',
  /** id поля "Дата начала страхования" */
  dateStartSber: 'date_start',
  //** id поля "Количество сотрудников" */
  numberOfEmployees: 'number-of-employees',
  /** id поля "Наименование организации" */
  companyName: 'company-name',
  /** id поля "ИНН" */
  companyTin: 'company-tin',
  InnTaxi: 'Inn',
  /** id поля "Должность" */
  jobTitle: 'job-title',
  /** id поля "Имя" */
  firstName: 'firstname',
  firstnameDoctorLike: 'firstname0',
  firstnameDoctorLikeOne: 'firstname1',
  firstnameDoctorLikeTwo: 'firstname2',
  fioO: 'fio_o',
  firstNameOnlineSber: 'firstname_online',
  nameTaxi: 'name',
  firstname_1: 'firstname_1',
  /** id поля "Фамилия" */
  surname: 'surname',
  surNameTaxi: 'surName',
  /** id поля "Фамилия" */
  lastNameOnlineSber: 'lastname_online',
  surnameDoctorLike: 'surname0',
  surnameDoctorLikeOne: 'surname1',
  surnameDoctorLikeTwo: 'surname2',
  surnameDoctorLikeThree: 'lastname2',
  surname_1: 'surname_1',
  lastname_1: 'lastname_1',
  surname_2: 'surname_2',

  /** id поля "Отчество" */
  patronymic: 'patronymic',
  middleNameOnlineSber: 'middlename_online',
  lastNameTaxi: 'lastName',
  /** id поля "Телефон" */
  phone: 'phone',
  phoneOnlineSber: 'phone_online',
  phoneDoctorLike: 'phone0',
  phoneDoctorLikeOne: 'phone1',
  phoneTaxi: 'telephone',
  /** id поля "Почта" */
  email: 'email',
  emailDmsForStudent: 'email0',
  emailOnlineSber: 'email_online',
  emailDoctorLike: 'email1',
  /** id страницы "Заявка отправлена" */
  step4: 'step4',
  /** id поля "Процент по кредиту"  */
  PERCENT: 'PERCENT',
  /** id поля "Сумма кредита"  */
  AMOUNT: 'AMOUNT',
  /** id поля "Срок кредита"  */
  TERM: 'TERM',
  /** id поля "Отчество"  */
  lastname: 'lastname',
  lastName: 'lastname0',
  lastNameOne: 'lastname1',
  /** id поля "Дата рождения"  */
  birthday: 'birthday',
  birthdayExtreme: 'birthday1',
  birthdayTaxi: 'Birthday',
  healthBirthdaySber: 'health-birthday',
  birthdayOwner: 'birthday_owner_1',
  birthdayOwnerSecond: 'birthday_owner_2',
  birthdayDoctorLike: 'birthday0',
  birthdayTwo: 'birthday2',
  insuredBirthdayExtreme: 'insured-birthday0',
  birthday_1: 'birthday_1',
  /** id поля "Кем выдан"  */
  pass_who_giveVtb: 'pass_who_give',
  pass_who_giveDoctorLike: 'pass_who_give0',
  pass_who_giveDoctorLikeOne: 'pass_who_give1',
  passWhoTaxi: 'who',
  /** id поля "Серия и номер"  */
  pass: 'pass',
  passDoctorLike: 'pass0',
  passDoctorLikeOne: 'pass1',
  /** id поля "Код подразделения"  */
  divisionVtb: 'division',
  divisionDoctorLike: 'division0',
  divisionDoctorLikeOne: 'division1',
  divisionTaxi: 'code',
  /** id поля "Стоимость имущества"  */
  propertyValue: 'property-value',
  /** id поля "Адрес обьекта"  */
  objectAddress: 'object-address',
  /** id линк "Декларация об имуществе"  */
  propertyDeclaration: 'property-declaration',
  /** id линк "Декларация об имуществе"  */
  titleDeclaration: 'title-declaration',
  /** id линк "Декларация об имуществе"  */
  healthDeclaration: 'health-declaration',
  /** id поля "Номер кредитного договора"  */
  agreementNumber: 'agreement-number',
  /** id поля "Номер кредитного договора"  */
  insNumber: 'ins_number',
  /** id поля "Номер кредитного договора"  */
  dateOfIssue: 'date-of-issue',
  /** id поля "Место выдачи кредита"  */
  select2CityCodeContainer: 'select2-CITY_CODE-container',
  /** id поля "Место выдачи кредита"  */
  select2CityCodeContainerSber: 'select2-city_code-container',
  /** id поля "Город населенный пункт"  */
  select2Сity1СontainerMortgage: 'select2-city1-container',
  selectСityСontainerPersonaExtreme: 'select2-city0-container',
  cityOne: 'city1',
  /** id поля "Место выдачи кредита"  */
  select2CityCodeContainerVtb: 'select2CityCodeContainer',
  select2PurposeContainer: 'select2-PURPOSE-container',
  select2Сity1СontainerOncology: '#select2-city1-container',
  /** id поля "Город населенный пункт"  */
  select2CityContainerRussia: 'select2-city-container',
  select2СityСontainerDoctorLike: 'select2-city0-container',
  select2СityСontainerOncologyOne: '#select2-city11-container',
  /** id поля "Место рождения"  */
  birthPlaceVtb: 'birth-place',
  /** id поля "Место рождения"  */
  birth_placeTravelRussia: 'birth_place',
  birth_placeDoctorLike: 'birth_place0',
  birth_placeDoctorLikeOne: 'birth_place1',
  /** id поля "Дата выдачи"  */
  dateStartVtb: 'date_start',
  dateStartDoctorLike: 'date_start0',
  dateStartDoctorLikeOne: 'date_start1',
  dateStartTaxi: 'start',
  /** id поля "Адрес регистрации"  */
  registrationAddressVtb: 'registration-address',
  registrationAddressTaxi: 'addressFl',
  registrationAddressTaxiSecond: 'addressUl',
  /** id поля "Проставление чекбокса Выбрать все"  */
  selectAll: 'selectAll',
  /** id полей"заполнения данными платежной карты на странице эквайринга и оплаты полиса"  */
  pan: 'pan',
  expiry: 'expiry',
  cvc: 'cvc',
  submitBtn: 'submitBtn',
  /** id поля "заполнение поля Остаток долга по кредиту"  */
  creditAmount: 'credit_amount',
  /** id поля "заполнение поля Рост*, см.'"  */
  height: 'height',
  /** id поля "заполнение поля Вес*, кг."  */
  weight: 'weight',
  /** id поля "заполнение поля Год постройки"  */
  constructionYear: 'construction_year',
  /** id поля "заполнение поля Площадь*, кв.м."  */
  area: 'area',
  /** id поля "заполнение поля Площадь*, кв.м."  */
  marketPrice: 'market-price',
  /** id поля "Номер кредитного договора"  */
  contractNumberSber: 'contract-number',
  /** id поля "Дата заключения кредитного договора"  */
  conclusionDate: 'conclusion-date',
  /** id поля "Страховая премия"  */
  insPremium: 'ins_premium',
  /** id поля "Срок вашей поездки"  */
  dateFrom: 'date_from',
  dateTo: 'date_to',
  /** id поля "Возраст"  */
  age1: 'age1',
  age2: 'age2',
  age3: 'age3',
  /** id кнопки "Рассчитать" Путешествие по России  */
  stepRussia: 'step_1_1',
  /** id страницы "с выбором Полисов"  */
  travelDataRussia: 'travel_data',
  /** id поля "Улица"  */
  streetTravelRussia: 'street',
  streetDoctorLike: 'street0',
  streetDoctorLikeOne: 'street1',
  streetTwo: 'street2',
  streetTwelve: 'street12',
  /** id поля "Дом"  */
  houseTravelRussia: 'house',
  houseDoctorLike: 'house0',
  houseDoctorLikeOne: 'house1',
  houseTwo: 'house2',
  houseTwelve: 'house12',
  /** id поля "Корпус"  */
  korpusTravelRussia: 'korpus',
  korpusDoctorLike: 'korpus0',
  korpusDoctorLikeOne: 'korpus1',
  korpusTwo: 'korpus2',
  /** id поля "Экран успешной оплаты Ипотека ВТБ"  */
  stepVtb: 'step4',
  /** id поля "Экран Внесение  данных для оформления полиса */
  step2: 'step2',
  /** id поля "Строение"  */
  buildingTravelRussia: 'building',
  buildingDoctorLike: 'building0',
  buildingDoctorLikeOne: 'building1',
  buildingTwo: 'building2',
  /** id поля "Квартира"  */
  flatTravelRussia: 'flat',
  flatDoctorLike: 'flat0',
  flatDoctorLikeOne: 'flat1',
  flatTwo: 'flat2',
  /** id поля "Экран успешной оплаты Ипотека Сбербанк"  */
  payProgram: 'pay-program',
  /** id поля "Страны пребывания"  */
  formTravel: 'form_travel',
  /** id поля "Количество собственников"  */
  count: 'count',
  title: 'title',
  /** id поля "Дата получения  права собственности"  */
  dateEntitlemenFirst: 'date-entitlemen1',
  dateEntitlemenSecond: 'date-entitlemen2',
  /** id полей "Загранпаспорта"  */
  surnamez: 'surnamez_1',
  firstnamez: 'firstnamez_1',
  zagran_seriya: 'zagran_seriya_1',
  /** id поля "Регистрационный знак "  */
  bigInputTaxi: 'bigInput',
  /** id поля "Наименование юр лица "  */
  companyTaxi: 'company',
  /** id поля "КПП"  */
  kppTaxi: 'kpp',
  /** id поля "ОГРН"  */
  ogrnTaxi: 'ogrn',
  /** id поля "Сумма FlatOptimal, "  */
  sum: '#fsum-a09063bf',
}

export { sogazShop }
