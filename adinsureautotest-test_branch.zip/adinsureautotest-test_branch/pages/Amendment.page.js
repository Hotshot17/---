import { AgentAgreementPage } from './AgentAgreement.page'

/**
 * @deprecated
 */
export class AmendmentPage extends AgentAgreementPage {
  constructor(page) {
    super(page)
    // this.page = page

    // Вкладка "Доп. соглашения к договору"
    this.conclusionDate = page.locator('[id="-input"]').first()
    this.startDate = page.locator('[id="-input"]').nth(1)
    this.endDate = page.locator('[id="-input"]').nth(2)
    this.retroactiveStartDate = page.locator('[id="-input"]').nth(3)
    this.amendmentReason = page.getByRole('combobox').first()
    this.amendmentChangeSubject = page.getByRole('combobox').nth(1)
    this.basicForModification = page.getByRole('combobox').nth(2)
    this.shortApprovalCycleCheckbox = page.locator('.ai-boolean-icon').nth(1)
    this.unlimitedCheckbox = page.locator('.ai-boolean-icon').first()

    // Вкладка "Полномочия поставщика"
    // this.commissionRulesAddButton = page.getByRole('button', { name: '+ Добавить' })
    // this.commissionRulesFormAdd = page.locator('.pt-2')

    // this.commissionRulesStartDate = page.getByTestId('AACommissionRules-#').locator('input[name="dp"]').first()
    // this.commissionRulesEndDate = page.getByTestId('AACommissionRules-#').locator('input[name="dp"]').nth(1)
    // this.commissionRulesRegistrationNumber = page.locator('app-text-input').filter({ hasText: 'Регистратор --' }).getByRole('textbox')
    // this.commissionRulesisuranceRule = page.locator('ng-component > div > div:nth-child(4)').first().getByRole('combobox')
    // this.commissionRulesInsuranceProduct = page.locator('div:nth-child(6) > ng-component > .ai-group-bootstrap > .row > div').first().getByRole('combobox')
    // this.commissionRulesInsuranceProgram = page.locator('div:nth-child(7) > ng-component > .ai-group-bootstrap > .row > div').first().getByRole('combobox')
    // this.commissionRulesMaxKv = page.locator('.ai-numeric-input').nth(2)
    // this.commissionRulesDefaultKv = page.locator('.ai-numeric-input').nth(1)
    // this.commissionRulesMinKv = page.locator('.ai-numeric-input').first()
    // this.commissionRulesOkButton = page.getByRole('button', { name: ' OK' })
  }
}
