export const selectorContract = {
  /** @description Папка  "Страховые продукты"' */
  contracts: 'Contracts_menu_1',

  /** @description Папка  продукта "Защита недвижимости"' */
  realEstateProtection: 'RealEstateProtection_1_2',

  /** @description Элемент создания документа   "Договор"' */
  znPolicy: 'REProtectionPolicy_1_3',

  /*-----------------------------------------------------------------------Селекторы списка действий документа-------------------------------------------------------*/
  /** @description  действие "К оплате"' */
  draftToPaymentWaiting: 'ai-transitions-relations-control-Draft_to_PaymentWaiting',

  /** @description  действие "Отказаться от оформления"' */
  draftToRejected: 'ai-transitions-relations-control-Draft_to_Rejected',

  /*-----------------------------------------------------------------------Селекторы списка печатных форм-------------------------------------------------------*/
  /** @description  button  "Печать" */
  printButton: 'ai-printouts-control',

  /** @description  элемент ПФ  "Полис-оферта" */
  realEstateProtectionPolicyPrintout: 'ai-printouts-control-RealEstateProtectionPolicyPrintout',

  /** @description  элемент  "ОСО" ПФ  "Полис-оферта" */
  realEstateProtectionOSOPolicyPrintout: 'ai-printouts-control-RealEstateProtectionOSOPolicyPrintout',

  /** @description  элемент ПФ  "Условия страхования" */
  realEstateProtectionConditionsPrintout: 'ai-printouts-control-RealEstateProtectionConditionsPrintout',

  /** @description  элемент ПФ  "Памятка" */
  realEstateProtectionMemoPrintout: 'ai-printouts-control-RealEstateProtectionMemoPrintout',

  /** @description  элемент ПФ  "КИД" */
  realEstateProtectionKeyInformationPaper: 'ai-printouts-control-RealEstateProtectionKeyInformationPaper',

  /** @description  элемент ПФ "ОСО" "КИД" */
  realEstateProtectionOSOKeyInformationPaper: 'ai-printouts-control-RealEstateProtectionOSOKeyInformationPaper',

  /*-----------------------------------------------------------------------Селекторы вкладок документа-------------------------------------------------------*/
  /** @description  id вкладки "Условия страхования" */
  tabInsuranceConditions: 'tab-Insurance-conditions-nav',

  /** @description  id вкладки "Расчет" */
  tabCalculatedObjects: 'tab-CalculatedObjects-nav',

  /** @description  id вкладки "Параметры договора" */
  tabContractParameters: 'tab-Object-nav',

  /** @description  id вкладки "Выпуск договора" */
  tabIssueOfContract: 'tab-Issue-contract-nav',

  /** @description  id вкладки "Вложения" */
  tabAttachedDocuments: 'tab-policy-attributes-nav',

  /** @description  id вкладки "История документа" */
  tabContractActivityAndTransitionHistory: 'tab-Contract-activity-nav',

  /* ---------------------------------------------------------Вкладка "Параметры договора" -------------------------------------------------- */
  // ------------------Элементы блока "Объект"

  /** @description  id  секции  "Общее" */
  sectionObject: 'object-section',

  /** @description  button   "По адресу страхователя" */
  policyHolderAddress: 'policyholder-address-button',

  /** @description   id поля  "Адрес объекта" */
  fullAddress: 'AddressAutocomplete',

  /** @description   combobox  "Тип объекта" */
  objectType: 'object-type',

  // ------------------Элементы блока "Орг.структура"

  /** @description  id  секции  "Организационная структура" */
  sectionOrganisationStructure: 'organisation-structure-section',

  /** @description   link  "Инициатор" */
  initiator: 'initiator-link',

  /** @description   link  "Менеджер договора" */
  policyManager: 'manager-link',

  /** @description   combobox  "Профильная программа" */
  profileProgram: 'profile-program',

  /** @description   combobox  "Филиал СОГАЗ" */
  branchNameAi: 'branch-name',

  /** @description   combobox  "Подразделение СОГАЗ" */
  departmentNameAi: 'department-name',

  // ------------------Элементы блока "Агенты и КВ"

  /** @description    таблица "Агенты и КВ" */
  tableAgentComissions: 'agent-commission-table',

  /** @description   поле в таблице  "Агент" */
  agent: 'agent-name-link',

  /** @description   поле в таблице  "Агентский договор" */
  agentAgreement: 'agent-agreement-link',

  // ------------------Элементы блока "Даты и срок страхования"

  /** @description   textbox  "Дата начала действия договора" */
  startDate: 'policy-start-date',
  /** @description   textbox  "Дата окончания действия договора" */
  endDate: 'policy-end-date',

  /* ---------------------------------------------------------Вкладка "Выпуск договора" -------------------------------------------------- */
  // ------------------Элементы блока "Подписание"

  /** @description   textbox  "Вариант заключения" */
  conclusionType: 'conclusion-type',

  /** @description   textbox  "Способ подписания" */
  signingType: 'signing-type',

  /** @description   textbox  "Ссылка на подписанта" */
  signingLink: 'signer-link',

  /** @description   textbox  "Номер доверенности" */

  proxyNumber: 'proxy-number',
  /** @description   textbox  "Дата доверенности" */
  proxyDate: 'proxy-date',

  // ------------------Элементы блока "График платежей"

  /** @description   id секции   "График платежей" */
  sectionPaymentPlan: 'REPPaymentData-#',

  /** @description   button    "Уведомление" */
  sendNotification: 'button-send-notification',
}
