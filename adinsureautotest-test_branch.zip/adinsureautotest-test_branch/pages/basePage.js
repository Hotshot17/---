// @ts-check

import { test, expect } from '@playwright/test'
import { LocatorHandler, LocatorType } from '../framework/locatorHandler'
/**
 * **Класс предоставляет методы для взаимодействия с элементами страниц**
 * @class
 */
export class BasePage extends LocatorHandler {
  /**
   * **Переход по ссылке. Загрузка страницы**
   * @param {string} url ссылка
   */
  async goToPage(url) {
    await test.step('Загружена страница', async () => {
      await this.page.goto(url)
    })
  }

  /**
   * **Работа с комбобокс без ввода данных**
   *
   * В методе есть проверка для больших шагов, таких как 'ADI_11698'. Если поле пусто, то оператор break выходит из метода и переходит на следующий метод в шаге.
   * @param {any} type - тип локатора
   * @param {string} nameElement - имя элемента. выводится в отчет
   * @param {string | RegExp} id - id элемента на странице
   * @param {string} roleName - пункт выпадающего списка. тестовые данные. выводится в отчет
   * @param {boolean} [exact] - условие строгого соответствия roleName
   * @param {number} [nth] - парметр nth
   * @example
   * await this.fillCombobox1('Валюта', quotePLE.сurrency, this.roleName)
   */
  async fillCombobox(type, nameElement, id, roleName, exact, nth) {
    await test.step(`Комбобокс "${nameElement}" заполнен значением "${roleName}"`, async () => {
      switch (type) {
        case LocatorType.byTestId:
          if (!roleName) {
            break
          }
          await this.getLocator(LocatorType.byTestId, { testId: id }).click()
          await this.getLocator(LocatorType.byRole, {
            role: 'option',
            roleName,
            exact,
          }).click()
          await expect(this.getLocator(LocatorType.byTestId, { testId: id })).toContainText(roleName, {
            ignoreCase: true,
            useInnerText: false,
          })
          break
        case LocatorType.byTestIdByRole:
          if (!roleName) {
            break
          }
          await this.getLocator(LocatorType.byTestIdByRole, {
            testId: id,
            role: 'combobox',
            nth: nth,
          }).click()
          await this.getLocator(LocatorType.byRole, {
            role: 'option',
            roleName,
            exact,
          }).click()
          break
      }
    })
  }

  // /**
  //  * Работа с комбобокс с вводом данных
  //  * @param {string} nameElement - наименование элемента
  //  * @param {string | RegExp} id - id элемента на странице
  //  * @param {string} fillText - данные для заполнения текстового поля
  //  * @param {string} roleName - пункт выпадающего списка
  //  * @param {{ exact?: boolean }} exact - условие строгого соответствия roleName
  //  * @example
  //  * await this.fillComboboxText('Адрес целиком', quotePLE.full_address, this.fillText, this.roleName, this.exact)
  //  */
  // async fillComboboxText (nameElement, id, fillText, roleName, exact) {
  //   await test.step(`Поле "${nameElement}" заполнен значением "${roleName}"`, async () => {
  //     await this.getLocator(LocatorType.byTestIdByRole, { testId: id, role: 'textbox' }).fill(fillText)
  //     // @ts-ignore
  //     await expect(this.getLocator(LocatorType.byRole, { roleName, exact })).toBeVisible()
  //     // @ts-ignore
  //     await this.getLocator(LocatorType.byRole, { role: 'option', roleName, exact: true }).click()
  //   })
  // }

  /**
   * **Комбобокс с вводом данных**
   * @param {string} testData - данные для заполнения текстового поля
   * @param {object} locatorOptions - Опции для формирования локаторов
   * @param {string} [locatorOptions.nameElement] - наименование элемента
   * @param {string | RegExp} [locatorOptions.idElement] - id элемента на странице
   * @param {string} [locatorOptions.roleName] - пункт выпадающего списка
   * @param {boolean} [locatorOptions.exact] - условие строгого соответствия roleName
   * @example
   * await this.fillComboboxText('Адрес целиком', quotePLE.full_address, this.fillText, this.roleName, this.exact)
   */
  async fillComboboxText(testData, locatorOptions) {
    await test.step(`Поле "${locatorOptions.nameElement}" заполнен значением "${locatorOptions.roleName}"`, async () => {
      await this.getLocator(LocatorType.byTestIdByRole, {
        testId: locatorOptions.idElement,
        role: 'textbox',
      }).fill(testData)
      await expect(
        this.getLocator(LocatorType.byRole, {
          role: 'option',
          roleName: locatorOptions.roleName,
          exact: locatorOptions.exact,
        })
      ).toBeVisible()
      await this.getLocator(LocatorType.byRole, {
        role: 'option',
        roleName: locatorOptions.roleName,
        exact: locatorOptions.exact,
      }).click()
    })
  }

  /**
   * **Текстовое поле**
   *
   * В методе есть проверка для больших шагов, таких как 'ADI_11698'. Если поле пусто, то оператор break выходит из метода и переходит на следующий метод в шаге.
   * @param {string} type - тип локатора
   * @param {string} nameElement - имя элемента. Выводится в отчет
   * @param {string | RegExp} idElement - id элемента
   * @param {any} testData - тестовые данные для ввода
   * @param {number} [nth] - парметр nth
   */
  async fillTextbox(type, nameElement, idElement, testData, nth) {
    await test.step(`Поле "${nameElement}" заполнено значением "${testData}"`, async () => {
      switch (type) {
        case LocatorType.byTestIdByRole:
          if (!testData) {
            break
          }
          await this.getLocator(LocatorType.byTestIdByRole, {
            testId: idElement,
            role: 'textbox',
            nth: nth,
          }).fill(testData)
          break
        case LocatorType.byTestId:
          if (!testData) {
            break
          }
          await this.getLocator(LocatorType.byTestId, {
            testId: idElement,
          }).fill(testData)
          break
      }
    })
  }

  /**
   * **Открытие блока (контейнера)**
   *
   * Метод проверяет статус блока, если закрыт - открывает
   * @param {string} nameElement - название блока
   * @param {string | RegExp} idElement - id блока
   * @example
   * await this.openContainer('Отрасль', quotePLE.industry)
   */
  async openContainer(nameElement, idElement) {
    const container = this.getLocator(LocatorType.byTestId, {
      testId: idElement,
    })
    await test.step(`Блок "${nameElement}" расскрыт`, async () => {
      const classAttributeValue = await container.getAttribute('class')
      if (classAttributeValue?.includes('container-collapsed')) {
        await container.click()
      }
    })
  }

  // /**
  //  * Кнопка поиска (лупа)
  //  * @param {string | RegExp} id
  //  * @example
  //  * await this.clickSearchButton(applicationPLE.atr_deal_department_name_search_button)
  //  */
  // async clickSearchButton (type, id) {
  //   await test.step('Нажата кнопка "Сохранить"', async () => {
  //   })
  // }

  // /**
  //  * **Нажатие на кнопку**
  //  * @param {any} type - тип локатора
  //  * @param {{nameElement?: string, id?: string | RegExp, roleName?: string}} locatorOptions - опции для формирования локаторов
  //  *
  //  * **byRole принимает опции:**
  //  * - roleName - название кнопки
  //  *
  //  * **byTestId принимает опции:**
  //  * - nameElement - название кнопки
  //  * - id - id кнопки
  //  *
  //  * **byTestIdByRole принимает опции:**
  //  * - nameElement - название кнопки
  //  * - id - id кнопки
  //  */
  // async clickButton (type, locatorOptions) {
  //   switch (type) {
  //     case LocatorType.byRole:
  //       await test.step(`Нажата кнопка "${locatorOptions.roleName}"`, async () => {
  //         await this.getLocator(LocatorType.byRole, { role: 'button', roleName: locatorOptions.roleName }).click()
  //       })
  //       break
  //     case LocatorType.byTestId:
  //       await test.step(`Нажата кнопка "${locatorOptions.nameElement}"`, async () => {
  //         await this.getLocator(LocatorType.byTestId, { testId: locatorOptions.id }).click()
  //       })
  //       break
  //     case LocatorType.byTestIdByRole:
  //       await test.step(`Нажата кнопка "${locatorOptions.nameElement}"`, async () => {
  //         await this.getLocator(LocatorType.byTestIdByRole, { testId: locatorOptions.id, role: 'button' }).click()
  //       })
  //       break
  //   }
  // }
  /**
   *
   */

  /**
   * **Нажатие на кнопку**
   * @param {string} type - Тип локатора. Возможные значения:
   * - byRole
   * - byTestId
   * - byTestIdByRole
   * @param {object} locatorOptions - Опции для формирования локаторов.
   * @param {string} [locatorOptions.nameElement] - Название элемента.
   * @param {string | RegExp} [locatorOptions.idElement] - ID элемента.
   * @param {string} [locatorOptions.roleName] - Название роли элемента.
   * @param {string} [locatorOptions.role]     - роль элемента
   * @param {number} [locatorOptions.nth]     - номер локатора
   * @example
   * // byRole
   * // Кнопка "ОК"
   * await this.clickButton(LocatorType.byRole, { roleName: 'OK' })
   *
   * // byTestId
   * // Кнопка "Войти"
   * await this.clickButton(LocatorType.byTestId, { idElement: generalSelectors.кнопкаВойти, nameElement: 'Войти' })
   *
   * // byTestIdByRole
   * // Кнопка поиска сотрудников (лупа)
   * await this.clickButton(LocatorType.byTestIdByRole, { idElement: generalSelectors.кнопкаПоискПодразделенияСделки, roleName: '' })
   */
  async clickButton(type, locatorOptions) {
    switch (type) {
      case 'byRole':
        /**
         * Нажатие на кнопку по роли.
         */
        await test.step(`Нажата кнопка "${locatorOptions.roleName}"`, async () => {
          await this.getLocator(LocatorType.byRole, {
            role: 'button',
            roleName: locatorOptions.roleName,
          }).click()
          await this.page.waitForTimeout(1000)
        })
        break
      case 'byTestId':
        /**
         * Нажатие на кнопку по ID.
         */
        await test.step(`Нажата кнопка "${locatorOptions.nameElement}"`, async () => {
          await this.getLocator(LocatorType.byTestId, {
            testId: locatorOptions.idElement,
          }).click()
          await this.page.waitForTimeout(1000)
        })
        break
      case 'byTestIdByRole':
        /**
         * Нажатие на кнопку по ID и роли.
         */
        await test.step(`Нажата кнопка "${locatorOptions.roleName}"`, async () => {
          await this.getLocator(LocatorType.byTestIdByRole, {
            testId: locatorOptions.idElement,
            role: 'button',
            roleName: locatorOptions.roleName,
            nth: locatorOptions.nth,
          }).click()
          await this.page.waitForTimeout(1000)
        })
        break
      case 'byTestIdByText':
        /**
         * Нажатие на кнопку по ID и text.
         */
        await test.step(`Нажата кнопка "${locatorOptions.roleName}"`, async () => {
          await this.getLocator(LocatorType.byTestIdByText, {
            testId: locatorOptions.idElement,
            text: locatorOptions.nameElement,
          }).click()
          await this.page.waitForTimeout(1000)
        })
        break
      case 'byRoleAndLocator':
        await test.step(`Нажата кнопка "${locatorOptions.roleName}"`, async () => {
          await this.getLocator(LocatorType.byRoleAndLocator, {
            role: locatorOptions.role,
            roleName: locatorOptions.roleName,
          }).click()
          await this.page.waitForTimeout(1000)
        })
    }
  }

  // /**
  //  * Нажатие на кнопку (по ID)
  //  * @param {string} name - название кнопки
  //  * @param {string | RegExp } id - название кнопки
  //  */
  // async clickButton1 (type, name, id) {
  //   await test.step(`Нажата кнопка "${name}"`, async () => {
  //   })
  // }

  /**
   * **Переход на вкладку**
   * @param {string} type - тип локатора
   * @param {string} nameElement - название элемента
   * @param {string | RegExp } idElement - id элемента
   * @example
   * await this.changeTab(LocatorType.byTestId, name, tab)
   */
  async changeTab(type, nameElement, idElement) {
    switch (type) {
      case LocatorType.byTestId:
        await test.step(`Активная вкладка "${nameElement}"`, async () => {
          await this.getLocator(LocatorType.byTestId, {
            testId: idElement,
          }).click()
        })
        break
    }
  }

  // /**
  //  * **Выбор checkbox в строке таблицы**
  //  * @param {string} type - тип локатора
  //  * @param {string} rowName - строка таблицы
  //  * @example
  //  * await this.checkCheckboxInTable('Добывающие отрасли')
  //  */
  // async checkCheckboxInTable(type, rowName) {
  //   switch (type) {
  //     case LocatorType.byRole:
  //       await test.step(`В таблице выбрана строка "${rowName}"`, async () => {

  //         await this.page.waitForTimeout(5000) // для полной загрузки страницы
  //         let number = Infinity

  //         while (number > 0) {
  //           const tableRow = await this.page
  //             .getByTestId(/^.*-table/)
  //             .getByRole('row', { name: rowName })
  //             .isVisible()

  //           console.log(tableRow)

  //           if (tableRow) {
  //             await this.page.getByRole('row', { name: rowName }).getByRole('checkbox').first().click()
  //             break
  //           } else {
  //             const forwardButton = this.page
  //               .getByTestId(/^.[a-zA-Z]*-search-table-paginator-next-page-button/)
  //               .getByRole('button')
  //             if (!(await forwardButton.isVisible()) || (await forwardButton.isDisabled())) {
  //               throw new Error('Данные не найдены')
  //             }
  //             await forwardButton.click()
  //           }
  //         }
  //       })
  //       break
  //   }
  // }

  /**
   * **Выбор checkbox в строке таблицы**
   * @param {string} type - тип локатора
   * @param {string} rowName - строка таблицы
   * @example
   * await this.checkCheckboxInTable('Добывающие отрасли')
   */
  async checkCheckboxInTable(type, rowName) {
    switch (type) {
      case LocatorType.byRole:
        await test.step(`В таблице выбрана строка "${rowName}"`, async () => {
          await this.getLocator(LocatorType.byRole, {
            role: 'row',
            roleName: rowName,
          })
            .getByRole('checkbox')
            .first()
            .click()
        })
        break
    }
  }

  /**
   * **Активация checkbox на странице**
   * В методе есть проверка. Если поле пусто, то оператор return выходит из метода и переходит на следующий метод в шаге.
   * @param {string}          type        - тип локатора
   * @param {string | RegExp} idElement   - id элемента
   * @param {string}          nameElement - текст рядом с checkbox
   * @param {number}          [nth]       - параметр nth
   * @example
   * await this.checkCheckbox( type:LocatorType.byTestIdByRole, id:quotePLE.сover_general_deductible, nameElement:'Не применяется', nth: 1)
   */
  async checkCheckbox(type, idElement, nameElement, nth) {
    if (!idElement) {
      return // пропускаем если данные не указаны
    }
    await test.step(`Установлен chekbox "${nameElement}"`, async () => {
      switch (type) {
        case LocatorType.byTestIdByRole:
          await this.getLocator(LocatorType.byTestIdByRole, {
            testId: idElement,
            role: 'checkbox',
            nth: nth,
          }).click()
          await expect(
            this.getLocator(LocatorType.byTestIdByRole, {
              testId: idElement,
              role: 'checkbox',
              nth: nth,
            })
          ).toBeChecked()
          break
      }
    })
  }
  /**
   * **Снятие checkbox на странице**
   * @param {string}          type        - тип локатора
   * @param {string | RegExp} idElement   - id элемента
   * @param {string}          nameElement - текст рядом с checkbox
   * @param {number}          nth         - параметр nth
   * @example
   * await this.uncheckCheckBox( type:LocatorType.byTestIdByRole, id:quotePLE.сover_general_deductible, nameElement:'Не применяется', nth: 1)
   */
  async uncheckCheckBox(type, idElement, nameElement, nth) {
    await test.step(`Установлен chekbox "${nameElement}"`, async () => {
      switch (type) {
        case LocatorType.byTestIdByRole:
          await this.getLocator(LocatorType.byTestIdByRole, {
            testId: idElement,
            role: 'checkbox',
            nth: nth,
          }).uncheck({ force: true })
          await expect(
            this.getLocator(LocatorType.byTestIdByRole, {
              testId: idElement,
              role: 'checkbox',
              nth: nth,
            })
          ).not.toBeChecked()
          break
      }
    })
  }

  /**
   * **Снятие фокуса с элемента**
   * @param {string} type - тип локатора
   * @param {string | RegExp} idElement - id элемента
   * @param {string} [roleElement] - тип элемента
   * @example
   * // Локатор элемента по id:
   * await this.blurElement(type, idElement)
   *
   * // Локатор элемента по id и role:
   * await this.blurElement(type, idElement, roleElement)
   */
  async blurElement(type, idElement, roleElement) {
    // await test.step(`Снят фокус с элемента "${nameElement}"`, async () => {
    switch (type) {
      case LocatorType.byTestIdByRole:
        await this.getLocator(LocatorType.byTestIdByRole, {
          testId: idElement,
          role: roleElement,
        }).blur()
        break
      case LocatorType.byTestId:
        await this.getLocator(LocatorType.byTestId, {
          testId: idElement,
        }).blur()
        break
    }
    // })
  }

  // Проверки

  /**
   * **Проверка заполнения поля. Поле не пустое**
   * @param {any} type - тип локатора
   * @param {string} nameElement - наименование поля
   * @param {string | RegExp} idElement - id поля
   * @param {any} roleElement - роль элемента
   * @example
   * await this.expectNoToBeEmpty(LocatorType.byTestIdByRole, 'Индекс', quotePLE.postalCode, 'textbox')
   */
  async expectNoToBeEmpty(type, nameElement, idElement, roleElement) {
    switch (type) {
      case LocatorType.byRole:
        await test.step(`Check_ Поле "${nameElement}" заполнено`, async () => {
          await expect(this.getLocator(LocatorType.byRole, { role: roleElement })).not.toBeEmpty()
        })
        break
      case LocatorType.byTestId:
        await test.step(`Check_ Поле "${nameElement}" заполнено`, async () => {
          await expect(this.getLocator(LocatorType.byTestId, { testId: idElement })).not.toBeEmpty()
        })
        break
      case LocatorType.byTestIdByRole:
        await test.step(`Check_ Поле "${nameElement}" заполнено`, async () => {
          await expect(
            this.getLocator(LocatorType.byTestIdByRole, {
              testId: idElement,
              role: roleElement,
            })
          ).not.toBeEmpty()
        })
        break
      default:
        throw new Error(`Поле "${nameElement}" пустое`)
    }
  }

  /**
   * **Проверка значения в поле**
   * @param {any} type - тип локатора
   * @param {string} nameElement - наименование поля
   * @param {string | RegExp} idElement -id поля
   * @param {any} value - проверяемое значение
   * @param {string} [roleElement] - роль элемента
   * @example
   * // byTestId
   * await this.expectToHaveValue(LocatorType.byTestId, 'Дата окончания', quotePLE.insuranceEnd, (this.value = value))
   *
   * // byTestIdByRole
   * await this.expectToHaveValue(LocatorType.byTestIdByRole, 'Срок действия', quotePLE.insuranceDuration, (this.value = value1), 'textbox')
   */
  async expectToHaveValue(type, nameElement, idElement, value, roleElement) {
    switch (type) {
      // case LocatorType.byRole:
      //   await test.step(`Поле "${name}" заполнено`, async () => {
      //     await expect(this.getLocator(LocatorType.byRole, { option })).not.toBeEmpty()
      //   })
      //   break
      case LocatorType.byTestId:
        await test.step(`Check_ Поле "${nameElement}" заполнено значенением "${value}"`, async () => {
          await expect(this.getLocator(LocatorType.byTestId, { testId: idElement })).toHaveValue(value)
        })
        break
      case LocatorType.byTestIdByRole:
        await test.step(`Check_ Поле "${nameElement}" заполнено значением "${value}"`, async () => {
          await expect(
            this.getLocator(LocatorType.byTestIdByRole, {
              testId: idElement,
              role: roleElement,
            })
          ).toHaveValue(value)
        })
        break
      default:
        throw new Error(`Check_ Поле "${nameElement}" пустое`)
    }
  }

  /**
   * **Метод по прослушиванию сетевых запросов и извлечения тела запроса либо тело ответа, который на вход принимает response/request, url 
    и возвращает тела запроса либо тело ответа в виде объекта**
   * @param {'request'| 'response'} event - событие response или request
   * @param {object} param - объект с параметрами
   * @param {string} param.url - url запроса
   * @description - Данный метод обязательно нужно вызывать до действия при совершении которого мы ожидаем извлечь либо тело запроса либо тело ответа. 
   * Для удобства метод можно вызвать в начале теста, так как page.on() прослушивает все сетевые запросы на странице
   * @example
   * // Вызов метода (можно вызвать в начале теста)
   * const getResponseBody = stepGeneral.viewingNetwork('request', { url: '/server/api/sogaz/accounting/shared/v1/online-payment/email'})
   * // Действие при котором отправляется запрос который мы хотим выловить
   * await stepGeneral.ADI_T3269(selectorQuote.draftToPaymentWaiting, 'К Оплате', 'Договор:', '(Ожидает оплаты)')
   * // Ожидание тела запроса
   * const requestBody = await getRequesteBody(возвращает тело запроса в виде объекта)
   */

  async viewingNetwork(event, param) {
    // let bodyPaymentEmail
    switch (event) {
      case 'request':
        return new Promise((resolve) => {
          this.page.on('request', async (request) => {
            const url = request.url() // const method = request.method()
            if (url.includes(param.url) && (await request.response()).status() === 200) {
              const requestBody = await request.postDataJSON()
              // console.log('Тело запроса в переменной', requestBody)
              if (requestBody) {
                resolve(requestBody)
              }
            }
          })
        })

      case 'response':
        return new Promise((resolve) => {
          this.page.on('response', async (response) => {
            const url = response.url()
            if (response.status() === 200 && url.includes(param.url)) {
              const responseBody = await response.json()

              if (responseBody) {
                resolve(responseBody)
              }
            }
          })
        })
    }
  }
}
