// @ts-check

const applicationSpecTechnics = {
  /*---------------------------Селекторы элементов главного меню--------------------------*/
  /** @description Папка "Страховые продукты" */
  contracts: 'Contracts_menu_1',

  /** @description Папка продукта "Спецтехника" */
  specTechnics: 'SpecTechnics_1_2',

  /** @description Элемент создания документа "СТ ПРЕДРАСЧЕТ" */
  specTechnicsApplication: 'SpecTechnicsApplication_1_3',

  /*---------------------------Селекторы вкладок документа СТ ПРЕДРАСЧЕТ --------------------------*/
  /** @description id бокового меню "Общая информация" */
  tabSummaryNav: 'tab-Summary-nav',

  /** @description id вкладки "Проверки и ошибки" */
  tabNotification: 'tab-Notifications-nav',

  /** @description id вкладка "Общее" */
  tabApplicationNav: 'tab-Application-nav',

  /** @description id вкладка "Условия страхования" */
  tabInsuranceConditionsNav: 'tab-InsuranceConditions-nav',

  /** @description id вкладка "История согласования" */
  tabContractActivityAndTransitionHistoryNav: 'tab-Contract-activity and transition history-nav',

  /*-----------------------------------------------------------------------Селекторы вкладки "Общее"-------------------------------------------------------*/
  /** id combobox "Тип обременения" */
  burden: 'burden-ng-select',

  /** id button Финансовая организация */
  financialOrganisation: 'financial-organisation-button',

  /** id field Наименование (финансовой организации) */
  organisationName: 'organisation-name',

  /** id field ИНН (финансовой организации) */
  inn: 'inn',

  /** id field КПП (финансовой организации) */
  kpp: 'kpp',

  /** id button Кнопки поиска */
  searchButton: 'DetailedPartySearchView_SearchButton',

  /**  блок "Оплата" */
  /** id combobox "Лица, допущенные к управлению" */
  paymentFrequency: 'payment-frequency',

  /**  блок "Данные о водителях" */
  /** id combobox "Лица, допущенные к управлению" */
  allowedDrive: 'allowed-drive-ng-select',

  /**  блок "ОСНОВНЫЕ ДАННЫЕ ПО СТ" */
  /** id combobox "Назначение" */
  specTechnicsType: 'spec-technics-type-ng-select',

  /** id combobox "Вид спецтехники" */
  specTechnicsSubtype: 'spec-technics-subtype-ng-select',

  /** id combobox "Тип документа" */
  specDocType: 'spec-doc-type-ng-select',

  /** id field "VIN" */
  vin: 'vin',

  /** id combobox "Шасси марка" */
  make: 'make-ng-select',

  /** id combobox "Шасси модель" */
  model: 'model-ng-select',

  /** id combobox "Год выпуска" */
  productionYear: 'production-year-ng-select',

  /** id field "Год выпуска" */
  STyearOfProduction: 'ai-input-STyearOfProductionManual-input',

  /** id field "Пробег, км." */
  mileage: 'mileage-input',

  /** id field "Моточасы" */
  engineHours: 'engine-hours-input',

  /** id field "Действительная стоимость" */
  actualValue: 'actual-value-input',

  /** id field "Страховая сумма" */
  insuredAmount: 'insured-amount-input',

  /** id checkbox "Спутниковая противоугонная система" */
  hasAntitheftSystem: 'has-antitheft-system',

  /** id field "Место хранения СТ" */
  storageArea: 'storage-area-ng-select',

  /*-----------------------------------------------------------------------Селекторы вкладки "Условия страхования"-------------------------------------------------------*/
  /** id combobox "Набор рисков" */
  setRisks: 'set-risks-ng-select',

  /** id checkbox риска "Доп. оборудование" */
  additionalEquipmentCheckbox: 'additional-equipment-checkbox',

  /** id field "Страховая сумма" риска "Доп. оборудование" */
  equipmentSum: 'equipment-sum',

  /** id checkbox риска "Несчастный случай" */
  risksAccidentCheckbox: 'risks-accident-checkbox',

  /** id combobox "Программа страхования" риска "Несчастный случай" */
  risksAccidentProgram: 'risks-accident-program',

  /** id field "Количество мест" риска "Несчастный случай" */
  risksAccidentSeats: 'risks-accident-seats',

  /** id combobox "Тип страховой суммы" риска "Несчастный случай" */
  accidentSumType: 'accident-sum-type',

  /** id field "Страховая сумма" риска "Несчастный случай" */
  risksAccidentSum: 'risks-accident-sum',

  /** id checkbox риска "Гражданская ответственность" */
  civilLiabilityCheckbox: 'civil-liability-checkbox',

  /** id field "Страховая сумма" риска "Гражданская ответственность" */
  civilLiabilitySum: 'civil-liability-sum',
}

const quoteSpecTechnics = {
  /*---------------------------Селекторы вкладок документа СТ КОТИРОВКА --------------------------*/
  /** @description id вкладки "Спецтехника" */
  tabVehicle: 'tab-Vehicle-nav',

  /** @description id вкладки "Субъекты" */
  tabSubjects: 'tab-Subjects-nav',

  /** @description id вкладки "Общее" */
  tabApplication: 'tab-Application-nav',

  /** @description id вкладки "Программы и риски" */
  tabInsuranceConditions: 'tab-InsuranceConditions-nav',

  /** @description id вкладки "Расчет" */
  tabUnderwriting: 'tab-Underwriting-nav',

  /** @description id вкладки "График платежей и оплаты" */
  tabPayments: 'tab-Payments-nav',

  /** @description id вкладки "Осмотры" */
  tabInspections: 'tab-Inspections-nav',

  /** @description id вкладки "Вложения" */
  tabAttachedDocuments: 'tab-Attached-documents-nav',

  /** @description id вкладки "История согласования" */
  tabTransitionHistory: 'tab-Contract-activity and transition history-nav',

  /** @description id вкладки "Групповая печать" */
  tabPrintingDocuments: 'tab-Printing-documents-nav',
  /*-----------------------------------------------------------------------Селекторы вкладки "Спецтехника"-------------------------------------------------------*/
  /** id combobox Тип кузова */
  bodyType: 'body-type',

  /** id combobox Мощность */
  enginePowerComboBox: 'engine-power',

  /** id combobox Модификация */
  modification: 'modification',

  /** id combobox Производитель марки СТ */
  manufacturerType: 'manufacturer-type-ng-select',

  /** id field Мощность */
  enginePower: 'engine-power-manual-input',

  /** id field Марка СТ */
  makeST: 'make-st',

  /** id field Модель СТ */
  modelST: 'model-st',

  /** id field Разрешенная максимальная масса, кг */
  maxWeight: 'maxWeight-input',

  /** id field Регистрационный знак */
  regNum: 'reg-num',

  /** id checkbox Регистрационный знак отсутствует */
  regNumAbsent: 'reg-num-absent',

  /** id combobox Тип ПТС/ПСМ/Паспорта механизма/Техпаспорта */
  ptsDocType: 'pts-doc-type-ng-select',

  /** id field Номер ПТС/ПСМ/Паспорта механизма/Техпаспорта */
  ptsNumber: 'pts-number',

  /** id field Дата выдачи ПТС/ПСМ/Паспорта механизма */
  ptsIssueDate: 'pts-issue-date-input',

  /** id field Номер СТС/СРМ */
  stsNumber: 'sts-number',

  /** id field Дата выдачи СТС/СРМ */
  stsIssueDate: 'sts-issue-date-input',

  /** id block Доп. оборудование */
  optionalEquipmentSection: 'optional-equipment-section',

  /** id button Добавить */
  equipmentTableAddButton: 'equipment-table-add-button',

  /** id field Наименование */
  equipmentName: 'equipment-name',

  /** id field Количество */
  equipmentAmount: 'equipment-amount',

  /** id field Стоимость за единицу */
  equipmentValue: 'equipment-value',

  /** id button OK */
  equipmentTableOKButton: 'equipment-table-ok-button',

  /*-----------------------------------------------------------------------Селекторы вкладки "Расчет"-------------------------------------------------------*/
  /** id button Кнопка поиска посредника */
  brokerSearchButton: 'broker-search-dialog-button',

  /** id field Поиск по подстроке (в модальном окне) */
  agentSearch: 'agent-search-input',
  /** id field Номер доверенности */
  attorneyNumber: 'attorney-number',

  /** id field Дата доверенности */
  attorneyDate: 'attorney-date-input',
}

const policySpecTechnics = {
  /*-----------------------------------------------------------------------Селекторы вкладки "График платежей и оплаты"-------------------------------------------------------*/
  /** id field Способ оплаты */
  paymentsMethod: 'payments-method-ng-select',
}

export { applicationSpecTechnics, quoteSpecTechnics, policySpecTechnics }
