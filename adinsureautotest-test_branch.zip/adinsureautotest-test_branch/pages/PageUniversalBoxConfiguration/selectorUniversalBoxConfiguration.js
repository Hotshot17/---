export const selectorContract = {
  /*-----------------------------------------------------------------------Селекторы элементов главного меню-------------------------------------------------------*/
  /** @description Папка  "Страховые продукты"' */
  contracts: 'Contracts_menu_1',

  /** @description Папка  продукта "Коробочный продукт"' */
  folderUBC: 'UniversalBoxConfiguration_1_2',

  /** @description Элемент создания документа   "Договор"' */
  ubcPolicy: 'UniversalBoxConfigurationPolicy_1_3',

  /*-----------------------------------------------------------------------Селекторы вкладок документа-------------------------------------------------------*/
  /** @description  id вкладки "Общая информация" */
  tabGeneralInformation: 'tab-insurance-conditions-nav',

  /** @description  id вкладки "Параметры договора" */
  tabPolicyAttributes: 'tab-policy-attributes-nav',

  /** @description  id вкладки "Выпуск договора" */
  tabIssueOfContract: 'tab-Issue-contract-nav',

  /** @description  id вкладки "История документа" */
  tabContractActivityAndTransitionHistory: 'tab-Contract-activity-nav',

  /** @description  id вкладки "Вложения" */
  tabAttachedDocuments: 'tab-Attached-documents-nav',

  /** @description  id вкладки "Расчет" */
  tabCalculations: 'tab-calculations-nav',

  /* ---------------------------------------------------------Селекторы действий документа -------------------------------------------------- */

  /** @description  действие "Оплатить" */
  draftToPaymentWaiting: 'ai-transitions-relations-control-Draft_to_PaymentWaiting',

  /** @description  действие "Jnrfpfnmcz jn jajhvktybz" */
  draftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',

  /* ---------------------------------------------------------Вкладка "Общая информация" -------------------------------------------------- */
  /** @description  поле "Программа страхования" */
  program: 'program',

  /** @description  поле "Дополнительные свойства" */
  insuranceRule: 'insuranceRule',

  /** @description  id секции "Вариант коробки" */
  sectionBoxVariants: 'general-section',

  /** @description  id секции "Страхователь" */
  sectionPolicyHolder: 'policy-holder-section',

  /** @description  id секции "История страхования" */
  sectionInsuranceHistory: 'insurance-history-section',

  /* ---------------------------------------------------------Вкладка "Параметры договора" -------------------------------------------------- */

  /** @description  id секции "Объект страхования" */
  sectionInsuredObject: 'insured-objects-section',
}
