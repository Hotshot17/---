// @ts-check

const quotePark = {
  /** id field Выбор файла */
  inputFile: "input[type='file']",

  /** id Вкладка Информация о загрузке (после загрузки парка) */
  motorCascoParkQuoteVehiclesImportLoadedTab: 'tab-MotorCascoParkQuoteVehiclesImportLoaded-nav',

  /** id Вкладка Информация о загрузке (после импорта парка) */
  motorCascoParkQuoteVehiclesImportImportedTab: 'tab-MotorCascoParkQuoteVehiclesImportImported-nav',

  /** id link Номер котировки (в правом меню) */
  contractLink: 'contract-link',

  /** id table Описание ошибки (в модальном окне Детали) */
  errorsInDetails: 'tab-loading-errors',

  /** id Вкладка Расчет */
  paymentsTab: 'tab-Payments-nav',

  /** id Вкладка Андеррайтинг */
  underwritingDataTab: 'tab-underwriting-data-nav',

  /** id checkbox Выбрать все (в таблице на вкладке Андеррайтинг) */
  underwritingDataTableCheckboxSelectAll: 'table#underwriting-data-table > thead > tr > th > div > input',

  /** id field САУ */
  sau: '[id="-input"]',

  /** id field ЧТ */
  cht: 'div:nth-child(2) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /** id field ЧХ */
  chh: 'div:nth-child(3) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /** id field К5 */
  k5: 'div:nth-child(2) > ng-component > .ai-group-bootstrap > .row > div > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /** id field К6 */
  k6: 'div:nth-child(2) > ng-component > .ai-group-bootstrap > .row > div:nth-child(2) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /** id field К10 */
  k10: 'div:nth-child(2) > ng-component > .ai-group-bootstrap > .row > div:nth-child(3) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /** id field К13 */
  k13: 'div:nth-child(3) > ng-component > .ai-group-bootstrap > .row > div > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /** id field К28 */
  k28: 'div:nth-child(3) > ng-component > .ai-group-bootstrap > .row > div:nth-child(2) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /** id field К30 */
  k30: 'div:nth-child(3) > ng-component > .ai-group-bootstrap > .row > div:nth-child(3) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /** id field К34 */
  k34: 'div:nth-child(4) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /** id field К36 */
  k36: 'div:nth-child(5) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',

  /*---------------------------Локаторы действий в меню Действия (Загрузка списка транспортных средств)--------------------------*/
  /** id Начать загрузку */
  startLoading: 'ai-transitions-relations-control-StartLoading',

  /** id Начать импорт */
  startImporting: 'ai-transitions-relations-control-StartImporting',

  /*---------------------------Локаторы действий в меню Действия (Котировка Парк)--------------------------*/
  /** id Загрузка списка транспортных средств */
  createMotorCascoParkQuoteVehiclesImport: 'ai-transitions-relations-control-CreateMotorCascoParkQuoteVehiclesImport',

  /** id Редактировать таблицу ТС */
  draftToEditVehicles: 'ai-transitions-relations-control-Draft_to_EditVehicles',

  /** id Продолжить оформление */
  editVehiclesToDraft: 'ai-transitions-relations-control-EditVehicles_to_Draft',

  /** id Проверить и рассчитать премию */
  draftToPremiumCalculating: 'ai-transitions-relations-control-Draft_to_PremiumCalculating',

  /** id На предварительное согласование Уровень 2*/
  draftToOnPriorConfirmationL2: 'ai-transitions-relations-control-Draft_to_OnPriorConfirmationL2',

  /** id Предварительно согласовать*/
  onPriorConfirmationL2ToPriorConfirmed: 'ai-transitions-relations-control-OnPriorConfirmationL2_to_PriorConfirmed',

  /** id Отказать */
  onPriorConfirmationL2ToRejected: 'ai-transitions-relations-control-OnPriorConfirmationL2_to_Rejected',

  /** id Предварительно согласована -> На окончательное согласование Уровень 2 */
  priorConfirmedToOnFinalConfirmationL2: 'ai-transitions-relations-control-PriorConfirmed_to_OnFinalConfirmationL2',

  /** id На окончательное согласование Уровень 2 */
  draftToOnFinalConfirmationL2: 'ai-transitions-relations-control-Draft_to_OnFinalConfirmationL2',

  /** id На корректировку */
  onFinalConfirmationL2ToCorrection: 'ai-transitions-relations-control-OnFinalConfirmationL2_to_ToCorrection',

  /** id На корректировку -> На окончательное согласование Уровень 2 */
  toCorrectionToOnFinalConfirmationL2: 'ai-transitions-relations-control-ToCorrection_to_OnFinalConfirmationL2',

  /** id На согласование ДЭБ */
  onFinalConfirmationL2ToOnDEBConfirmation:
    'ai-transitions-relations-control-OnFinalConfirmationL2_to_OnDEBConfirmation',

  /** id На согласовании ДЭБ -> На окончательное согласование Уровень 2 */
  onDEBConfirmationToOnFinalConfirmationL2:
    'ai-transitions-relations-control-OnDEBConfirmation_to_OnFinalConfirmationL2',

  /** id Согласовать */
  onFinalConfirmationL2ToFinallyConfirmed: 'ai-transitions-relations-control-OnFinalConfirmationL2_to_FinallyConfirmed',

  /** id Согласовать с изменениями */
  onFinalConfirmationL2ToFinallyConfirmedWithChanges:
    'ai-transitions-relations-control-OnFinalConfirmationL2_to_FinallyConfirmedWithChanges',

  /** id Отказаться от оформления */
  finallyConfirmedToCancelled: 'ai-transitions-relations-control-FinallyConfirmed_to_Cancelled',

  /** id Выпустить котировку */
  finallyConfirmedToPolicyNumberCreating: 'ai-transitions-relations-control-FinallyConfirmed_to_PolicyNumberCreating',

  /** id Согласовать с изменениями -> Выпустить котировку */
  finallyConfirmedWithChangesToPolicyNumberCreating:
    'ai-transitions-relations-control-FinallyConfirmedWithChanges_to_PolicyNumberCreating',
}

const party = {
  /** id row Строка в таблице ТС */
  vehiclesListTableRow: 'vehicles-list-table-row',

  /** id Вкладка Вложения (в модальном окне Детали) */
  attachmentsTab: 'tab-attachments-nav',

  /** id row Строка в таблице История работы с партией */
  stateHistoryTableRow: 'state-history-table-row',

  /*---------------------------Локаторы действий в меню Действия--------------------------*/
  /** id Сформировать графики⁠ */
  draftToCreatingPaymentSchedule: 'ai-transitions-relations-control-Draft_to_CreatingPaymentSchedule',

  /** id Создать договоры⁠ */
  paymentScheduleToCreatingPolicies: 'ai-transitions-relations-control-PaymentSchedule_to_CreatingPolicies',
}

export { quotePark, party }
