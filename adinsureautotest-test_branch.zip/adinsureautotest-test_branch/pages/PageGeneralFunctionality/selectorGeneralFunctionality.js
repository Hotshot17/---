const GeneralFunctionality = {
  /*-----------------------------------------------------------------------Селекторы элементов главного меню-------------------------------------------------------*/
  /** @description Папка Рабочий стол */
  DashboardsMenu: 'Dashboards_menu_1',

  /** @description Папка Орг. структура */
  OrganisationMenu: 'Organisation_menu_1',
  /** @description Папка Поставщики услуг */
  ServiceProviders: 'ServiceProviders_1_2',
  /** @description Папка Агенты */
  createAgent: 'Agent_1_3',
  /** @description Меню Доверенность */
  PowerOfAttorney: 'PowerOfAttorney_1_3',
  /** @description Меню Поиск агентов */
  AgentSearchView: 'AgentSearchView_1_3',
  /** @description Меню Поиск сотрудников */
  EmployeeSearchView: 'EmployeeSearchView_1_3',
  /** @description Меню Поиск сотрудников агента */
  EmployeeExtSearchView: 'EmployeeExtSearchView_1_3',
  /** @description Меню + Сотрудник агента */
  EmployeeExt: 'EmployeeExt_1_3',

  /** @description Меню Пользователи */
  Users: 'Users_1_2',
  /** @description Меню Создание пользователя */
  Newuser: 'Newuser_1_3',
  /** @description Меню Поиск пользователя */
  UserSearch: 'ApplicationUserSearchView_1_3',
  /** @description Меню Массовые изменения */
  Userutilities: 'Userutilities_1_3',

  /** @description Папка Договоры с поставщиками услуг */
  AgentAgreementsMenu: 'AgentAgreements_menu_1',
  /** @description Меню Договор с поставщиками услуг */
  AgentAgreement: 'AgentAgreement_1_2',
  /** @description Меню Поиск договоров с поставщиками */
  AADocumentSearchView: 'AADocumentSearchView_1_2',
  /** @description Меню Настройки автоопределения */
  ComissionSettings: 'ComissionSettings_1_2',

  /** @description Меню Контрагенты */
  PartiesMenu: 'Parties_menu_1',
  /** @description Меню Физ.лицо */
  NaturalPerson: 'NaturalPerson_1_2',
  /** @description Меню ИП */
  IndividualEntrepreneur: 'IndividualEntrepreneur_1_2',
  /** @description Меню ЮЛ */
  LegalEntity: 'LegalEntity_1_2',
  /** @description Меню Агенты куратора */
  AACuratorView: 'AACuratorView_1_2',

  /** @description Папка  "Страховые продукты"' */
  ContractsMenu: 'Contracts_menu_1',

  /** @description продукт: СогазАвто/Каско */
  Motor: 'Motor_1_2',
  /** @description предрасчет */
  MotorCascoApplication: 'MotorCascoApplication_1_3',
  /** @description пролонгация полиса */
  GenericProlongation: 'GenericProlongation_1_3',

  /** @description продукт: ОСАГО */
  MTPL: 'MTPL_1_2',
  /** @description предрасчет */
  MTPLApplication: 'MTPLApplication_1_3',
  /** @description котировка */
  MTPLQuote: 'MTPLQuote_1_3',

  /** @description продукт: ВПМЖ */
  TravelInsurance: 'TravelInsurance_1_2',
  /** @description предрасчет */
  TravelApplication: 'TravelApplication_1_3',
  /** @description котировка */
  TravelQuote: 'TravelQuote_1_3',

  /** @description продукт: Квартира */
  SogazFlat: 'SogazFlat_1_2',
  /** @description договор */
  SogazFlatPolicy: 'SogazFlatPolicy_1_3',

  /**-----------------------------------------------------------------------Селекторы элементов Роли-----------------------------------------------------------------------*/
  /** @description Роль: Администратор */
  AAAdministrator: 'ai-actor-selection-control-AAAdministrator',
  /** @description Роль: Продавец */
  Agent: 'ai-actor-selection-control-Agent',
  /** @description Роль: Андеррайтер */
  Underwriter: 'ai-actor-selection-control-Underwriter',

  /**-----------------------------------------------------------------------Блок Орг.структура---------------------------------------------------------------------------------*/
  /** @description вкладка Детали доверенности */
  PowerOfAttorneyDetails: 'tab-inform-details-nav',
  /** @description вкладка Список сотрудников поставщика */
  tabAgentEmployees: 'tab-agent-employees-nav',
  /** @description вкладка Проверки и ошибки */
  Notifications: 'tab-Notifications-nav',

  /** @description selector блок Основная информация */
  GeneralData: 'poadata-info-section',
  /** @description selector поиска агента */
  poadataAgentSearch: 'poadata-agent-search-dialog-button',
  /** @description selector поиска сотрудника */
  poadataEmployeeSearch: 'poadata-employee-search-dialog-button',
  employeeSearch: 'employee-search-input',
  /** @description selector поиска сотрудника агента */
  poadataExtemployeeSearch: 'poadata-extemployee-search-dialog-button',
  extSearch: 'ext-search-input',
  /** @description selector поиска в таблице агента */
  extSearchTableExt: 'ext-search-table_ext-code-link',
  extemployeeAgentSection: 'extemployee-agent-section',
  agentSearchTable: 'agent-search-table',
  /** @description selector поиска агента */
  extemployeeAgentSearch: 'extemployee-agent-search',
  /** @description selector Инициатор */
  poaGeneralSection: 'poa-general-section',
  poadataAgentLink: 'poadata-agent-link',
  poadataEmployeeLink: 'poadata-employee-link',
  poadataExtemployeeLink: 'poadata-extemployee-link',
  /** @description selector Пользователь, отозвавший доверенность */
  poadataTerminatedLink: 'poadata-terminated-link',
  /** @description вкладка Всего проблем */
  Validations: 'RequiredPropertiesValidations-error-count',

  /**-----------------------------------------------------------------------Селекторы элементов header документов -----------------------------------------------------------------------*/
  /** @description selector header документов */
  headerDocumentName: 'header-document-name',
  /** @description selector header документов */
  headerDocumentState: 'header-document-state',
  /** @description selector header документов */
  headerDocument: 'header-document',
  /** @description selector header документов */
  documentTypeHeader: 'documentTypeHeader',
  /** @description selector header документов */
  AADocumentHeader: 'AADocumentHeader-#',
  /** @description selector header документов */
  DocumentHeader: 'DocumentHeader-#',
  /** @description поле Перейти к документу */
  byNumber: 'navbar-redirect-by-number',
  /** @description поле Код агента*/
  byCode: 'agent-code-input',

  /**----------------------------------------------------------------------- Селекторы элементов для всех продуктов -----------------------------------------------------------------------*/
  agent: 'agent',
  searchHeader: 'search-header',
  agentSection: 'agent-section',
  agentTable: 'agent-table',
  broker: 'broker-search-dialog-button',
  agentSearch: 'agent-search-input',
  appTextInput: 'app-text-input',
  businessNumber: 'businessNumber',
  userSearch: 'user-search-input',
  userSearchTable: 'user-search-table',
  informationSection: 'npgeneral-information-section',
  documentsSection: 'np-documents-section',
  emails: 'np-emails-section',
  phones: 'np-phones-section',
  party: 'party-search',
  partyApi: 'partyapi-search',
  searchParams: 'party-search-params',
  branch: 'branch-name',
  email: 'email',
  department: 'department-name',
  ieInformationSection: 'iegeneral-information-section',
  ieDocumentsSection: 'ie-documents-section',
  ieEmailsSection: 'ie-emails-section',
  iePhonesSection: 'ie-phones-section',
  ieAccountsSection: 'ie-accounts-section',
  accountsSearch: 'accounts-search',
  bankLookupParam: 'bank-lookup-param',
  fullName: 'full-name',
  legeneral: 'legeneral-information-section',
  leDocuments: 'le-documents-section',
  leEmailsSection: 'le-emails-section',
  lePhonesSection: 'le-phones-section',
  leAccountsSection: 'le-accounts-section',
  extemployeeStart: 'extemployee-start-section',
  extemployeeSearch: 'extemployee-party-search',

  /*-----------------------------------------------------------------------кнопки-------------------------------------------------------*/
  Add: 'Добавить',
  Search: 'Поиск',
  Select: 'Выбрать',
  ОК: 'OK',
  Save: 'Сохранить',
  Calculate: 'Рассчитать',
  Actions: 'Действия',
  GoToRegistration: 'Перейти к оформлению',
  disabled: 'disabled',
  Close: 'Закрыть',
  Cancel: ' Oтменить',
  searchUsers: 'Найти пользователей',
  reset: 'Сбросить пароль',
  action: 'Действует',
  goSearch: 'Искать',
  create: 'Создать сотрудника',

  /*-----------------------------------------------------------------------LINK----------------------------------------------------------------------*/
  baseUrl: 'https://stage.adinsure.sogaz.ru/',
  auth: 'auth/connect/token',
  GetApplicationUserDataSource: 'server/api/entity-infrastructure/shared/datasource/GetApplicationUserDataSource',
  management: 'server/api/organisation/public/user-management/',
  recentDocuments: 'server/api/shell/internal/documents/recent-documents/',
  DepartmentsDataSource:
    'server/api/entity-infrastructure/shared/datasource/execute?configurationCodeName=DepartmentsDataSource',

  /*-----------------------------------------------------------------------Данные для авторизации----------------------------------------------------------------------*/
  password: 'Test_12345',
  loginDavidenkoEA: 'davidenko.evgenii.a',
  loginDavidenkoTV: 'davidenko.tatiana.v',
  loginTereshchenko: 'Tereshchenko.Maxim',
  loginUsova: 'Usova.Elena',
  loginSevidova: 'Sevidova.Nadezda',
  loginZueva: 'Zueva.Yana.G⁠',
  loginAliullova: 'Aliullova.Yulia',
  loginKozlova: 'Kozlova.Inna.E',
}
export { GeneralFunctionality }
