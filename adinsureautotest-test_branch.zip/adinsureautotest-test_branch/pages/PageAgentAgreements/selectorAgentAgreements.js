// @ts-check
const AgentAgreements = {
  /*-----------------------------------------------------------------------Селекторы элементов главного меню-------------------------------------------------------*/
  /** @description Папка Рабочий стол */
  DashboardsMenu: 'Dashboards_menu_1',

  /** @description Папка Орг. структура */
  OrganisationMenu: 'Organisation_menu_1',
  /** @description Папка Поставщики услуг */
  ServiceProviders: 'ServiceProviders_1_2',
  /** @description Меню Доверенность */
  PowerOfAttorney: 'PowerOfAttorney_1_3',
  /** @description Меню Поиск агентов */
  AgentSearchView: 'AgentSearchView_1_3',
  /** @description Меню Поиск сотрудников */
  EmployeeSearchView: 'EmployeeSearchView_1_3',
  /** @description Меню Поиск сотрудников агента */
  EmployeeExtSearchView: 'EmployeeExtSearchView_1_3',

  /** @description Меню Пользователи */
  Users: 'Users_1_2',
  /** @description Меню Создание пользователя */
  Newuser: 'Newuser_1_3',
  /** @description Меню Поиск пользователя */
  UserSearch: 'ApplicationUserSearchView_1_3',
  /** @description Меню Массовые изменения */
  Userutilities: 'Userutilities_1_3',

  /** @description Папка Договоры с поставщиками услуг */
  AgentAgreementsMenu: 'AgentAgreements_menu_1',
  /** @description Меню Договор с поставщиками услуг */
  AgentAgreement: 'AgentAgreement_1_2',
  /** @description Меню Поиск договоров с поставщиками */
  AADocumentSearchView: 'AADocumentSearchView_1_2',
  /** @description Меню Настройки автоопределения */
  ComissionSettings: 'ComissionSettings_1_2',

  /** @description Меню Контрагенты */
  PartiesMenu: 'Parties_menu_1',
  /** @description Меню Физ.лицо */
  NaturalPerson: 'NaturalPerson_1_2',
  /** @description Меню ИП */
  IndividualEntrepreneur: 'IndividualEntrepreneur_1_2',
  /** @description Меню Агенты куратора */
  AACuratorView: 'AACuratorView_1_2',

  /** @description Папка  "Страховые продукты"' */
  ContractsMenu: 'Contracts_menu_1',

  /** @description продукт: СогазАвто/Каско */
  Motor: 'Motor_1_2',
  /** @description предрасчет */
  MotorCascoApplication: 'MotorCascoApplication_1_3',
  /** @description пролонгация полиса */
  GenericProlongation: 'GenericProlongation_1_3',

  /** @description продукт: ОСАГО */
  MTPL: 'MTPL_1_2',
  /** @description предрасчет */
  MTPLApplication: 'MTPLApplication_1_3',
  /** @description котировка */
  MTPLQuote: 'MTPLQuote_1_3',

  /** @description продукт: ВПМЖ */
  TravelInsurance: 'TravelInsurance_1_2',
  /** @description предрасчет */
  TravelApplication: 'TravelApplication_1_3',
  /** @description котировка */
  TravelQuote: 'TravelQuote_1_3',

  /** @description продукт: Квартира */
  SogazFlat: 'SogazFlat_1_2',
  /** @description договор */
  SogazFlatPolicy: 'SogazFlatPolicy_1_3',

  /**-----------------------------------------------------------------------Селекторы элементов Роли-----------------------------------------------------------------------*/
  /** @description Роль: Администратор */
  AAAdministrator: 'ai-actor-selection-control-AAAdministrator',
  /** @description Роль: Продавец */
  Agent: 'ai-actor-selection-control-Agent',
  /** @description Роль: Андеррайтер */
  Underwriter: 'ai-actor-selection-control-Underwriter',

  /**-----------------------------------------------------------------------Блок Орг.структура---------------------------------------------------------------------------------*/
  /** @description вкладка Детали доверенности */
  PowerOfAttorneyDetails: 'tab-inform-details-nav',
  /** @description вкладка Список сотрудников поставщика */
  tabAgentEmployees: 'tab-agent-employees-nav',
  /** @description вкладка Проверки и ошибки */
  Notifications: 'tab-Notifications-nav',

  /** @description selector блок Основная информация */
  GeneralData: 'poadata-info-section',
  /** @description selector поиска агента */
  poadataAgentSearch: 'poadata-agent-search-dialog-button',
  /** @description selector поиска сотрудника */
  poadataEmployeeSearch: 'poadata-employee-search-dialog-button',
  employeeSearch: 'employee-search-input',
  /** @description selector поиска сотрудника агента */
  poadataExtemployeeSearch: 'poadata-extemployee-search-dialog-button',
  extSearch: 'ext-search-input',
  /** @description selector поиска в таблице агента */
  extSearchTableExt: 'ext-search-table_ext-code-link',
  extemployeeAgentSection: 'extemployee-agent-section',
  agentSearchTable: 'agent-search-table',
  /** @description selector поиска агента */
  extemployeeAgentSearch: 'extemployee-agent-search',
  /** @description selector Инициатор */
  poaGeneralSection: 'poa-general-section',
  poadataAgentLink: 'poadata-agent-link',
  poadataEmployeeLink: 'poadata-employee-link',
  poadataExtemployeeLink: 'poadata-extemployee-link',
  /** @description selector Пользователь, отозвавший доверенность */
  poadataTerminatedLink: 'poadata-terminated-link',
  /** @description вкладка Всего проблем */
  Validations: 'RequiredPropertiesValidations-error-count',

  /**-----------------------------------------------------------------------Блок Поиск договоров с поставщиками---------------------------------------------------------------------------------*/
  /** @description секция Поиск договоров с поставщиками */
  lookupParam: 'lookup-param-section',

  /**-----------------------------------------------------------------------Блок ДОГОВОР С ПОСТАВЩИКОМ УСЛУГ---------------------------------------------------------------------------------*/
  /** @description вкладка Детали договора */
  PolicyDetails: 'AAPolicyDetails-nav',
  /** @description вкладка Реквизиты и подписи */
  RequisitesSignatures: 'AARequisitesSignatures-nav',
  /** @description вкладка Техническая информация */
  technicalInfoTab: 'technicalInfoTab-nav',
  /** @description вкладка Полномочия поставщика */
  CommissionRules: 'AACommissionRules-nav',

  /** @description секция Основная информация */
  MainAttributes: 'AAMainAttributes-#',
  /** @description Селектор Организация */
  department: 'organizationUnit',
  /** @description Селектор Вид договора */
  documentType: 'documentType',
  /** @description Селектор Тип договора */
  agentAgreement: 'Агентский договор',
  /** @description Селектор Номер приказа */
  orderNumber: 'orderNumber',

  /** @description секция Дополнительно */
  extraInformation: 'AAExtraInformation-extraInformation',
  /** @description селектор Зоны ответственности */
  responsibilityZones: 'responsibilityZones',
  /** @description селектор Макет печатной формы акта КВ */
  caPrintFormLayout: 'caPrintFormLayout',

  /** @description секция Сторона СК - Подписант */
  SideSigner: 'sogazSigner',
  /** @description блок Подписант со стороны Общества, ФИО  */
  SignerPartyCode: 'signerPartyCode',
  /** @description Должность подписанта */
  SignerPosition: 'signerPosition',
  /** @description  Документ-основание номер */
  PowerOfAttorneyNumber: 'powerOfAttorney',
  /** @description дата начала */
  powerOfAttorneyStartDate: 'powerOfAttorneyStartDate-input',
  /** @description дата окончания */
  powerOfAttorneyEndDate: 'powerOfAttorneyEndDate-input',
  /** @description блок Сторона – Подписант Агента */
  sideAgent: 'AASignatureAgent-signatureAgent',
  /** @description Подписант Агента, ФИО */
  signerFullName: 'signerFullName',
  /** @description Секция Срок действия договора */
  AAValidityValidity: 'AAValidity-validity',
  /** @description Дата заключения */
  conclusionDateInput: 'conclusionDate-input',
  /** @description Дата начала действия */
  startDateInput: 'startDate-input',
  /** @description Дата окончания действия */
  endDateInput: 'endDate-input',
  /** @description Секция История изменения порядка налогообложения */
  TaxHistory: 'AATaxHistory-taxHistory',
  /** @description Дата начала применения порядка налогообложения */
  startTaxDate: 'startTaxDate-input',
  /** @description Дата окончания порядка налогообложения */
  endTaxDate: 'endTaxDate-input',

  /** @description секция Банковские реквизиты */
  BankAccounts: 'bankDetails',
  /** @description адрес */
  addresses: 'addresses',
  /** @description Эл. адрес */
  email: 'emails',
  /** @description Телефон */
  phone: 'phones',

  /** @description Техническая информация */
  TechnicalInfo: 'AATechnicalInfo-#',
  /** @description Полномочия поставщика */
  SupplierCompetencies: 'AACommissionRules-#',
  inputName: 'input[name="dp"]',
  ValiditySummary: 'AAValiditySummary-validity',

  /**-----------------------------------------------------------------------Блок ДС НА ИЗМЕНЕНИЕ---------------------------------------------------------------------------------*/
  /** @description доп. соглашение к договору */
  amenmdentConditions: 'AmendmentData',
  /** @description  Основание для внесения изменений */
  basisForModification: 'basisForModification',

  /**-----------------------------------------------------------------------Блок доп. соглашение к договору---------------------------------------------------------------------------------*/
  /** @description доп. соглашение к договору */
  documentAmendments: 'amendmentsTab-nav',

  /**----------------------------------------------------------------------Блок Настройки автоопределения-----------------------------------------------------------------------*/
  /** @description Селектор Настройки автоопределения */
  auto: 'json-view span',

  /**----------------------------------------------------------------------Блок СОГАЗ-АВТО предрасчет-----------------------------------------------------------------------*/
  /** @description вкладка Общее */
  tabApplication: 'tab-Application-nav',
  /** @description вкладка Условия страхования */
  tabInsuranceConditions: 'tab-InsuranceConditions-nav',

  /** @description Секция Информация по лизингу/кредитованию */
  CreditInfo: 'credit-info-section',

  /** @description Секция Страхователь */
  PolicyHolder: 'select-policyholder',

  /** @description Кнопка Страхователь */
  policyholderButton: 'select-policyholder-button',

  /** @description Секция Данные о водителях */
  Drivers: 'drivers-section',

  /** @description Секция Основные данные по ТС */
  VehicleGeneralData: 'vehicle-data-section',

  /** @description Секция Орг. структура */
  OrgStructureData: 'org-structure-section',
  /** @description блок Тип обременения */
  burden: 'burden',
  /** @description кнопка Орг. структура */
  departmentSearch: 'department-search-dialog-button',
  /** @description кнопка Финансовая организация */
  financialOrganisation: 'financial-organisation-button',
  /** @description блок Юр. лицо */
  legalEntity: 'legal-entity-section',
  /** @description блок Наименование */
  OrganisationName: 'organisation-name',
  /** @description блок ИНН */
  inn: 'inn',
  /** @description кнопка Поиск КА */
  SearchButton: 'DetailedPartySearchView_SearchButton',
  /** @description ссылка Финансовая организация */
  financialOrganisationLink: 'financial-organisation-link',
  /** @description марка */
  make: 'make-ng-select',
  /** @description Модель */
  model: 'model-ng-select',
  /** @description Год выпуска */
  production: 'production-year-ng-select',
  /** @description Тип ТС */
  vehicleType: 'vehicle-type-ng-select',
  /** @description Категория ТС */
  vehicle: 'vehicle-category-ng-select',
  /** @description Дата последней регистрации ТС */
  last: 'last-registration-date-input',
  /** @description Пробег, км. */
  mileageInput: 'mileage-input',
  /** @description Действительная стоимость */
  actualValue: 'actual-value-input',
  /** @description Дата приобретения ТС */
  purchaseDate: 'purchase-date-input',

  /** @description ВИН */
  vin: 'vin',

  /** @description Менеджер Поиск Сотрудников */
  managerFullName: 'employee-search-dialog-button',
  /** @description Менеджер */
  managerName: 'manager-name',

  /** @description Канал продаж */
  salesChannel: 'salesChannel',

  /** @description АВТОКАСКО ПРОФИ Лайт */
  cascoMiniCheckbox: 'casco-mini-checkbox',

  /** @description поиск посредника */
  brokerSearch: 'broker-search',

  /**----------------------------------------------------------------------Блок Каско котировка-----------------------------------------------------------------------*/
  /** @description вкладка Транспортное средство */
  tabVehicle: 'tab-Vehicle-nav',
  /** @description вкладка Расчет */
  tabUnderwriting: 'tab-Underwriting-nav',
  /** @description Регистрационный знак */
  regNum: 'reg-num',
  /** @description Цель использования */
  usagePurpose: 'usage-purpose',
  /** @description Тип ПТС */
  ptsDocType: 'pts-doc-type',
  /** @description Номер ПТС */
  ptsNumber: 'pts-number',
  /** @description Номер СТС */
  stsNumber: 'sts-number',
  /** @description Дата выдачи ПТС */
  ptsIssueDate: 'pts-issue-date-input',
  /** @description Дата выдачи СТС */
  stsIssueDate: 'sts-issue-date-input',
  /** @description номер доверенности */
  attorneyNumber: 'attorney-number',
  /** @description дата доверенности */
  attorneyDate: 'attorney-date-input',
  /** @description Кнопка Каско лизинг страхователь */
  lesseeSearchButton: 'lessee-search-button',
  /** @description Количество ДТП */
  lastClaimAmount: 'last-claim-amount-input',
  /** @description Размер парка */
  parkSize: 'park-size',
  /** @description Агентский договор */
  AA: 'aa-group',

  /**----------------------------------------------------------------------Селекторы ОСАГО-----------------------------------------------------------------------*/
  /** @description вкладка общая информация */
  tabPolicyConditions: 'tab-Policy-conditions-nav',
  /** @description вкладка данные о ТС и водителях */
  tabVehicleData: 'tab-Vehicle-data-nav',
  /** @description вкладка программа страхования и расчет премии */
  tabMTPLProgramNav: 'tab-MTPLProgram-nav',

  /** @description блок общая информация */
  generalData: 'general-data-section',

  /** @description Тип БСО */
  typeBSO: 'bso-type',
  /** @description Серия БСО */
  seriasBSO: 'bso-series',
  /** @description locatorBSO */
  locatorBSO: 'input-label-bootstrap',
  /** @description Номер БСО */
  numberBSO: 'bso-number',
  /** @description лица, допущенные к управлению */
  people: 'allowed-input',

  /** @description тип документа ТС */
  vehicleDocType: 'vehicle-doc-type',
  /** @description серия документа ТС */
  vehicleDocSeries: 'vehicle-doc-series',
  /** @description номер документа ТС */
  vehicleDocNumber: 'vehicle-doc-number',
  /** @description дата выдачи документа ТС */
  vehicleDocDate: 'vehicle-doc-date-input',

  /** @description код агента */
  agentCodeInput: 'agent-code-input',

  /** @description Марка  */
  Make: 'make',
  /** @description Модель  */
  Model: 'model',
  /** @description Год Выпуска  */
  productionYear: 'production-year',
  /** @description Тип ТС  */
  vehicleTypeTS: 'vehicle-type',
  /** @description Категория ТС  */
  vehicleCategory: 'vehicle-category',
  /** @description Мощность  */
  powerHP: 'power-hp',
  /** @description Кодмодификации  */
  modificationCode: 'modification-code',
  /** @description Модификация  */
  modificationName: 'modification-name',
  /** @description Код РСА  */
  rsaCode: 'rsa-code',
  /** @description Модификация  */
  modification: 'modification',

  /** @description Сегмент  */
  segment: 'segment',
  /** @description Правило  */
  rule: 'br',
  /** @description селектор акция  */
  insuranceConditionsSection: 'insurance-conditions-section',

  /** @description Посредники  */
  agentData: 'agent-data',

  /** @description Кем создан документ  */
  createdBy: 'created-by',

  /**----------------------------------------------------------------------Селекторы Согаз-Квартира-----------------------------------------------------------------------*/
  /** @description вкладка Программы и риски */
  tabInsuranceConditionsNav: 'tab-Insurance-conditions-nav',
  /** @description вкладка Общая информация */
  tabGeneralNav: 'tab-General-nav',
  /** @description вкладка Параметры объекта */
  tabObjectNav: 'tab-Object-nav',
  /** @description Гражданская Ответственность */
  civilResponsibility: 'package-variant-table-option',
  /** @description срок Действия Страхования */
  insuranceDuration: 'insurance-duration-input',
  /** @description дата Заключения */
  insuranceDate: 'insurance-date-input',
  /** @description датаНачалаДействияСтрахования */
  validFromInput: 'valid-from-input',
  /** @description датаОкончанияДействияСтрахования */
  dateToInput: 'date-to-input',
  /** @description кнопка СОГАЗ-Квартира */
  searchPolicyholder: 'search-policyholder-button',
  /** @description поиск Менеджера */
  managerSearch: 'manager-search',
  /** @description Тип объекта */
  objectType: 'object-type',
  /** @description Год постройки */
  buildingYear: 'building-year-input',
  /** @description Точка продаж */
  salesOutletSearch: 'sales-outlet-search',
  /** @description Агенты и КВ */
  agentCommissionTable: 'agent-commission-table',
  /** @description подтверждение */
  confirm: 'confirm-edit-icon',
  /** @description отмена подтверждения  */
  cancel: 'cancel-edit-icon',
  /** @description выпуск договора */
  tabIssueContractNav: 'tab-Issue-contract-nav',
  /** @description чекбокс Плательщик совпадает со страхователем */
  payerPolicyholder: 'payer-policyholder',
  /** @description КВ, % */
  commissionShare: 'ai-control-commissionShare-input',
  /** @description акции % */
  action: 'promotions-table',
  /** @description Специальная программа */
  specialProgram: 'special-program',
  /** @description Зона ответственности % */
  responsibility: 'responsibility-zone',
  /** @description кнопка Поиск агента % */
  agentSearchButton: 'agent-search-button',
  /** @description Вложения */
  Attached: 'tab-Attached-documents-nav',
  /** @description чекбокс Согласие не приложено */
  consent: 'consent-personal-data',
  /** @description дата рождения */
  birthday: 'party-birthday',
  /** @description серия */
  serial: 'party-document-series',
  /** @description тип документа */
  type: 'party-document-type',
  /** @description Специальная программа */
  generalSection: 'general-section',

  /**----------------------------------------------------------------------Селекторы ВПМЖ-----------------------------------------------------------------------*/
  /** @description вкладка Предрасчет */
  tabPrecalculateNav: 'tab-precalculate-nav',
  /** @description вкладка Общая Информация */
  tabGeneralInformationNav: 'Tab-GeneralInformation-nav',

  /** @description ВПМЖ Посредники */
  agentCommissionSection: 'agent-commission-section',
  /** @description посредники АД */
  agentContract: 'agent-contract',
  /** @description Поиск Посредника */
  agentLookup: 'agent-lookup',
  /** @description кнопка Поиск Посредника */
  agentLookupButton: 'agent-lookup-dialog-button',

  /** @description Дата Создания */
  giCreateDate: 'gi-create-date',
  /** @description Сервисная Компания */
  giServiceCompany: 'gi-service-company',
  /** @description Цель Поездки */
  giTripPurpose: 'gi-trip-purpose',
  /** @description Порядок Оплаты Премии */
  giPaymentFrequency: 'gi-payment-frequency',
  /** @description Местонахождение Страхователя */
  locationOutRF: 'locationOutRF',
  /** @description Направление Поездки */
  travelDestination: 'travelDestination',
  /** @description Вариант Продукта */
  productType: 'product-type',
  /** @description Программа Страхования */
  insuranceProgramme: 'insurance-programme',
  /** @description Дата Поездки */
  tsTravelDuration: 'ts-travel-duration',
  /** @description Активные Виды Отдыха И Спорта */
  activity: 'activity',
  /** @description Дополнительные Опции */
  otherOptionsElement: 'otherOptionsElement',
  /** @description Продолжительность Поездки */
  travelDurationInput: 'travel-duration-input',
  /** @description МедРасходы Страховая Сумма */
  medicalExpensesSum: 'medical-expenses-sum',
  /** @description МедРасходы Валюта */
  medicalExpensesCurrency: 'medicalExpensesCurrency',
  /** @description Несчастный Случай */
  accidentCheckBox: 'accidentCheckBox',
  /** @description Несчастный Случай Страховая Сумма */
  accidentSum: 'accident-sum',
  /** @description Несчастный Случай Валюта */
  accidentCurrency: 'accidentCurrency',
  /** @description Гражданская Ответственность */
  civilResponsibilityCheckBox: 'civilResponsibilityCheckBox',
  /** @description Гражданская Ответственность Страховая Сумма */
  civilResponsibilitySum: 'civil-responsibility-sum',
  /** @description Гражданская Ответственность Валюта */
  civilResponsibilityCurrency: 'civilResponsibilityCurrency',
  /** @description Возраст Туриста */
  listAgeTraveler: 'list-age-traveler-input',
  /** @description Профессиональный Спорт */
  activityProSport: 'TravelActivityProSelection-activityProSport',
  /** @description Менеджер Договора */
  lookupPolicyManager: 'lookup-policy-manager',
  /** @description Агент */
  TravelMediators: 'TravelMediators-mediators',
  /** @description Страхователь */
  btnPolicyHolderSearch: 'btn-policy-holder-search',
  /** @description Посредники и КВ */
  agentAddButton: 'agent-commission-table-add-button',
  /** @description Наименование точки продаж */
  adSection: 'ad-section',
  /** @description Точка Продаж */
  salesOutletName: 'sales-outlet-name',
  /** @description кнопка Точка Продаж */
  salesSearchButton: 'sales-outlet-search-dialog-button',
  /** @description название компании */
  serviceCompany: 'gi-service-company-ng-select',
  /** @description тип оплаты */
  payment: 'gi-payment-frequency-ng-select',
  /** @description цель поездки */
  target: 'gi-trip-purpose-ng-select',

  /** @description кем создан документ */
  summaryСreatedBy: 'summary-createdBy',

  /** @description тип программы Универсальная */
  universalProgramm: 'Универсальная',
  /** @description тип программы Коробочная */
  boxProgramm: 'Коробочная',

  /** @description тип действия */
  value: 'dropdown-item',

  /**----------------------------------------------------------------------Селекторы элементов Действия-----------------------------------------------------------------------*/
  /* Действия с АД */
  /** @description Действие Создать заявку на АД */
  CreateProjectForSimplifiedApproval: 'ai-transitions-relations-control-CreateProjectForSimplifiedApproval',
  /** @description Действие Активировать АД */
  ActivateProjectWithSimplifiedApproval: 'ai-transitions-relations-control-ActivateProjectWithSimplifiedApproval',
  /** @description Действие Копировать АД */
  CopyAgentAgreement: 'ai-transitions-relations-control-CopyAgentAgreement',
  /** @description Действие Отменить создание заявки АД */
  CancelDraftDocument: 'ai-transitions-relations-control-CancelDraftDocument',
  /** @description Действие Отменить заявку АД */
  SendRequestToCancelled: 'ai-transitions-relations-control-SendRequestToCancelled',
  /** @description Действие Приостановить действие АД */
  SuspendDocument: 'ai-transitions-relations-control-SuspendDocument',
  /** @description Действие Распровести АД */
  DeactivateDocument: 'ai-transitions-relations-control-DeactivateDocument',
  /** @description Действие Отменить распроведенный АД */
  CancelDeactivatedDocument: 'ai-transitions-relations-control-CancelDeactivatedDocument',
  /** @description Действие Вернуть документ в действующий АД */
  ReactivateDocument: 'ai-transitions-relations-control-ReactivateDocument',
  /** @description Действие Расторгнуть приостановленный АД */
  CloseDocumentAfterSuspension: 'ai-transitions-relations-control-CloseDocumentAfterSuspension',
  /** @description Действие Провести АД */
  ActivateDeactivatedDocument: 'ai-transitions-relations-control-ActivateDeactivatedDocument',
  /** @description Действие Создать ДС на изменение */
  CreateChangeAmendment: 'ai-transitions-relations-control-CreateChangeAmendment',

  /* Действия с доверенностью */
  /** @description Действие Зарегистрировать */
  NewToRegistered: 'ai-transitions-relations-control-New_to_Registered',
  /** @description Действие Распровести */
  RegisteredToDeactivated: 'ai-transitions-relations-control-Registered_to_Deactivated',
  /** @description Действие Провести */
  DeactivatedToRegistered: 'ai-transitions-relations-control-Deactivated_to_Registered',
  /** @description Действие Отменить */
  RegisteredToCancelled: 'ai-transitions-relations-control-Registered_to_Cancelled',

  /* Действия с договором */
  /** @description Действие Создать Котировку */
  CreateTravelQuote: 'ai-transitions-relations-control-CreateTravelQuote',
  /** @description Создать котировку ОСАГО */
  CreateMTPLQuoteFromMotorCasco: 'ai-transitions-relations-control-CreateMTPLQuoteFromMotorCasco',
  /** @description Действие Запросить КБМ */
  WaitingForKBM: 'ai-transitions-relations-control-Draft_to_WaitingForKBM',
  /** @description Действие Направить на согласование */
  SendToHigherLevel: 'ai-transitions-relations-control-Draft_SendToHigherLevel',
  /** @description Действие Выпустить Котировку */
  CreateSogazFlatPolicy: 'ai-transitions-relations-control-CreateSogazFlatPolicy',
  /** @description Действие Перейтик оформлению КАСКО*/
  CreateMotorCascoQuote: 'ai-transitions-relations-control-CreateMotorCascoQuote',
  /** @description Действие Перейтик оформлению ОСАГО*/
  CreateMTPLQuote: 'ai-transitions-relations-control-CreateMTPLQuote',
  /** @description Действие К оплате */
  DraftToPaymentWaiting: 'ai-transitions-relations-control-Draft_to_PaymentWaiting',

  //Выход из аккаунта
  out: 'header-user-dropdown-menu',

  /**-----------------------------------------------------------------------Селекторы элементов header документов -----------------------------------------------------------------------*/
  /** @description selector header документов */
  headerDocumentName: 'header-document-name',
  /** @description selector header документов */
  headerDocumentState: 'header-document-state',
  /** @description selector header документов */
  headerDocument: 'header-document',
  /** @description selector header документов */
  documentTypeHeader: 'documentTypeHeader',
  /** @description selector header документов */
  AADocumentHeader: 'AADocumentHeader-#',
  /** @description selector header документов */
  DocumentHeader: 'DocumentHeader-#',
  /** @description поле Перейти к документу */
  byNumber: 'navbar-redirect-by-number',
  /** @description поле Код агента*/
  byCode: 'agent-code-input',

  /**----------------------------------------------------------------------- Селекторы расчетов агентских вознаграждений -----------------------------------------------------------------------*/
  /** @description премия Каско */
  calculatedPremiumCASCO: 'premium',
  /** @description премия USD */
  summaryPremiumUSD: 'summary-premium',
  /** @description КВ USD */
  agentTotalPremiumUSD: 'summary-agentTotalPremium',
  /** @description премия RUB */
  summaryPremiumRUB: 'summary-premiumRUB',
  /** @description КВ RUB */
  agentTotalPremiumRUB: 'summary-agentTotalPremiumRUB',
  /** @description премия осаго */
  calculatedPremiumOSAGO: 'calculated-premium-input',
  /** @description премия Согаз-квартира */
  premiumRubles: 'premium-rubles',

  /**----------------------------------------------------------------------- Селекторы элементов для всех продуктов -----------------------------------------------------------------------*/
  agent: 'agent',
  searchHeader: 'search-header',
  agentSection: 'agent-section',
  agentTable: 'agent-table',
  broker: 'broker-search-dialog-button',
  agentSearch: 'agent-search-input',
  appTextInput: 'app-text-input',
  businessNumber: 'businessNumber',
  userSearch: 'user-search-input',
  userSearchTable: 'user-search-table',

  /*-----------------------------------------------------------------------локаторы-------------------------------------------------------*/
  КВmin:
    'div:nth-child(1) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',
  KVdefault:
    'div:nth-child(2) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',
  KVmaxAD:
    'div:nth-child(3) > ng-component > .ai-number-input-bootstrap-container > .form-group > .ai-numeric-input > [id="-input"]',
  number:
    'div:nth-child(2) > app-text-input > .ai-text-input-bootstrap-container > .form-group > .position-relative > .form-control',
  dateStart: '[id="-input"]',
  date: 'div:nth-child(3) > ng-component > .ai-datetime-input-bootstrap-container > .form-group > .input-group > [id="-input"]',
  ПравилоCтрахования:
    'div:nth-child(4) > ng-component > .ai-dropdown-input-bootstrap-container > .form-group > [id="-ng-select"] > .ng-select-container',
  Продукт:
    'div:nth-child(6) > ng-component > .ai-group-bootstrap > .row > div > ng-component > .ai-dropdown-input-bootstrap-container > .form-group > [id="-ng-select"]',

  /*-----------------------------------------------------------------------Ссылки-------------------------------------------------------*/
  baseUrl: 'https://stage.adinsure.sogaz.ru/',
  recentDocuments: 'server/api/shell/internal/documents/recent-documents/',
  AADocumentESDataSource:
    'server/api/entity-infrastructure/shared/datasource/execute?configurationCodeName=AADocumentESDataSource',
  contractsGetInitialViewModel: 'server/api/pas/internal/contracts/get-initial-view-model',
  GetTransdekraVehicleDataSource: 'server/api/entity-infrastructure/shared/datasource/GetTransdekraVehicleDataSource',
  GetPolicySignatoriesDataSource: '/server/api/entity-infrastructure/shared/datasource/GetPolicySignatoriesDataSource',
  MTPLQuote1: 'server/api/pas/internal/contracts/MTPLQuote/1/',
  agentAgreementsGetInitialViewModelIncludes: 'server/api/pas/internal/agent-agreements/get-initial-view-model',
  GetTransdekraVehicleDataSourceIncludes:
    'server/api/entity-infrastructure/shared/datasource/GetTransdekraVehicleDataSource',
  executeIncludes: 'server/api/entity-infrastructure/shared/datasource/execute',
  MatchedAgentAgreementDataSourceIncludes:
    'server/api/entity-infrastructure/shared/datasource/MatchedAgentAgreementDataSource',
  GetPartnerProgramsByBranchDataSourceIncludes:
    'server/api/entity-infrastructure/shared/datasource/GetPartnerProgramsByBranchDataSource',
  CommissionCalculationSettingsDataSourceIncludes:
    'server/api/entity-infrastructure/shared/datasource/CommissionCalculationSettingsDataSource',
  SalesOutletsDataSourceIncludes: 'server/api/entity-infrastructure/shared/datasource/SalesOutletsDataSource',
  evaluationIncludes: 'server/api/pas/internal/contracts/MTPLQuote/1/evaluation',
  GetRegionDataSourceIncludes:
    'server/api/entity-infrastructure/shared/datasource/execute?configurationCodeName=GetRegionDataSource',
  CommissionCalculation: 'server/api/core/shared/integration-services/CommissionCalculation/1',
  AAResponsibilityZoneDataSourceIncludes:
    'server/api/entity-infrastructure/shared/datasource/execute?configurationCodeName=AAResponsibilityZoneDataSource',
  GetAATaxOrderDataSourceIncludes:
    'server/api/entity-infrastructure/shared/datasource/execute?configurationCodeName=GetAATaxOrderDataSource',
  GetApplicationUsersDataSourceIncludes:
    'server/api/entity-infrastructure/shared/datasource/GetApplicationUsersDataSource',
  GetPromotionsByBranchDataSource:
    '/server/api/entity-infrastructure/shared/datasource/GetPromotionsByBranchDataSource',
  /*-----------------------------------------------------------------------СОСТОЯНИЕ АВТООПРЕДЕЛЕНИЯ-------------------------------------------------------*/
  enableAll: 'Включено для всех агентов',
  oneRole: 'Включено для роли',
  disableAll: 'Выключено для всех агентов',

  /*-----------------------------------------------------------------------чекбоксы-------------------------------------------------------*/
  /** @description запрещено ручное редактирование КВ */
  AACommissionRules: 'AACommissionRules',
  /** @description Скидка/надбавка на КВ */
  commission: 'commission-group',

  /*-----------------------------------------------------------------------кнопки-------------------------------------------------------*/
  Add: 'Добавить',
  Search: 'Поиск',
  Select: 'Выбрать',
  ОК: 'OK',
  Save: 'Сохранить',
  Calculate: 'Рассчитать',
  Actions: 'Действия',
  GoToRegistration: 'Перейти к оформлению',
  disabled: 'disabled',
  Close: 'Закрыть',
  Cancel: ' Oтменить',

  /*-----------------------------------------------------------------------проверка текстов-------------------------------------------------------*/
  /** @description проверка текстов */
  TextCheck:
    'КВ посредника фактическое, %: значение не может быть меньше 0,1% и не может быть больше КВ макс (из АД),%',
  /** @description проверка текстов */
  TextCheck1:
    "Строки с ID '2' и '3' в Полномочиях поставщика неконсистентны. Необходимо скорректировать набор атрибутов в одной из строк.",
  /** @description проверка текстов */
  riskProgramA: 'Премия не является числом для оцениваемого объекта страхования traveler@2027089@riskProgramA',
  riskProgramB: 'Премия не является числом для оцениваемого объекта страхования traveler@2027089@riskProgramB',
  riskProgramC: 'Премия не является числом для оцениваемого объекта страхования traveler@2027089@riskProgramC',
  riskDamageThirdPartyHealth:
    'Премия не является числом для оцениваемого объекта страхования traveler@2027089@riskDamageThirdPartyHealth',
  riskDamageThirdPartyProperty:
    'Премия не является числом для оцениваемого объекта страхования traveler@2027089@riskDamageThirdPartyProperty',

  /*-----------------------------------------------------------------------данные для тестов---------------------------------------------------------------------------*/
  prolongFlat: 'SGZF-0000183281',
  prolongOsago: 'ТТТ 7069556109',
  prolongKasko: 'SGZA0001799784',
  vin1: 'XW8ZZZ5NZLG019880',
  vin2: 'W0L000085N1015535',
  vin3: 'XWEJ3813DM0020818',

  /*-----------------------------------------------------------------------Данные для авторизации----------------------------------------------------------------------*/
  password: 'Test_12345',
  loginDavidenkoEA: 'davidenko.evgenii.a',
  loginDavidenkoTV: 'davidenko.tatiana.v',
  loginTereshchenko: 'Tereshchenko.Maxim',
  loginUsova: 'Usova.Elena',
  loginSevidova: 'Sevidova.Nadezda',
  loginZueva: 'Zueva.Yana.G⁠',
  loginAliullova: 'Aliullova.Yulia',
  loginKozlova: 'Kozlova.Inna.E',
}
export { AgentAgreements }
