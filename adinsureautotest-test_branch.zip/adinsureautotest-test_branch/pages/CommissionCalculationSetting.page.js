/**
 * @deprecated
 */
export class CommissionCalculationSettingPage {
  constructor(page) {
    this.page = page
    this.documentTypeHeader = page.getByTestId('search-header')
    this.stateCombobox = page.getByRole('combobox').nth(1)
    this.roleArea = page.locator('app-text-input').getByRole('textbox')
    this.okButton = page.getByRole('button', { name: ' OK' })
    this.saveButton = page.getByRole('button', { name: 'Сохранить' })
  }

  async checkState(productName) {
    const result = await this.page.getByRole('row', { name: productName }).getByRole('cell').nth(1).textContent()
    return result
  }

  async checkRole(productName) {
    const result = await this.page.getByRole('row', { name: productName }).getByRole('cell').nth(2).textContent()
    return result
  }

  async settingState(productName, stateName, roleName) {
    await this.page.getByRole('row', { name: productName }).locator('i').click()
    await this.stateCombobox.click()
    await this.page.getByRole('option', { name: stateName }).click()
    if (roleName != null) {
      await this.roleArea.fill(roleName)
    }
    await this.okButton.click()
    await this.saveButton.click()
  }
}
