/**
 * @deprecated
 */
export class AgentAgreementPage {
  constructor(page) {
    this.page = page

    // Страница агентского договора, общие элементы
    this.documentTypeHeader = page.getByTestId('documentTypeHeader')
    this.documentNumberHeader = page.getByTestId('ai-info-control')
    this.documentStatus = page.getByTestId('AADocumentHeader-#').locator('.ai-whitespace')
    this.AAPolicyDetailsTab = page.locator('#AAPolicyDetails-nav')
    this.AARequisitesSignaturesTab = page.locator('#AARequisitesSignatures-nav')
    this.AACommissionRulesTab = page.locator('#AACommissionRules-nav')
    this.amendmentsTab = page.locator('#amendmentsTab-nav')
    this.technicalInfoTab = page.locator('#technicalInfoTab-nav')
    this.saveButton = page.getByRole('button', { name: ' Сохранить' })

    // Вкладка "Детали договора"
    this.documentTypeCombobox = page.getByTestId('documentType').getByRole('combobox')
    this.checkDocumentType = page.getByTestId('documentType').locator('.ng-value-label')

    this.orderNumberCombobox = page.getByTestId('orderNumber').getByRole('combobox')
    this.checkOrderNumber = page.getByTestId('orderNumber').locator('.ng-value-label')

    this.searchAgentButton = page.getByTestId('agent').getByRole('button', { name: '' })
    this.searchAgentField = page.getByTestId('agent-search-input').getByRole('textbox')
    this.selectButton = page.getByRole('button', { name: ' Выбрать' })
    this.searchButton = page.getByRole('button', { name: ' Поиск' })

    this.businessNumber = page.getByTestId('businessNumber').getByRole('textbox')

    this.departmentCombobox = page.getByTestId('organizationUnit').getByRole('combobox')
    this.clearDepartmentCombobox = page.getByTestId('organizationUnit-ng-select').getByTitle('Clear all')
    this.checkDepartment = page.getByTestId('salesBranches').getByRole('row').nth(1).getByRole('cell').nth(0)

    this.responsibilityZonesCombobox = page.getByTestId('responsibilityZones').getByRole('combobox')
    this.checkResponsibilityZones = page.getByTestId('responsibilityZones').locator('.ng-value-label')

    this.caPrintFormLayoutCombobox = page.getByTestId('caPrintFormLayout').getByRole('combobox')
    this.checkCaPrintFormLayout = page.getByTestId('caPrintFormLayout').locator('.ng-value-label')

    this.shortApprovalCycleCheckbox = page
      .getByTestId('AAExtraInformation-extraInformation')
      .locator('ng-component')
      .filter({ hasText: 'Использовать в договоре страхования до утверждения Краткий цикл согласования' })
      .getByRole('checkbox')
      .nth(1)

    this.searchSideSignerButton = page.getByTestId('signerPartyCode').getByRole('button', { name: '' })
    this.signerPowerOfAttorneyNumber = page.getByTestId('powerOfAttorney').locator('.ai-text-span')
    this.searchSideSignerField = page.getByTestId('employee-search-input').getByRole('textbox')
    this.signerPosition = page.getByTestId('signerPosition').getByRole('textbox')
    this.signerPowerOfAttorneyStartDate = page.locator('#powerOfAttorneyStartDate-input')
    this.signerPowerOsAttorneyEndDate = page.locator('#powerOfAttorneyEndDate-input')

    this.sideAgentName = page.getByTestId('signerFullName').getByRole('textbox')
    this.sideSignerAgentName = page.locator('app-text-input').filter({ hasText: 'Агент --' }).getByRole('textbox')
    this.sideAgentCounterPartyName = page.getByTestId('AASignatureAgent-signatureAgent').locator('.ai-text-span')

    this.validityConclusionDate = page.getByTestId('AAValidity-validity').locator('#conclusionDate-input')
    this.validityStartDate = page.locator('#startDate-input')
    this.validityEndDate = page.locator('#endDate-input')

    this.taxOrder = page.getByTestId('AATaxHistory-taxHistory').locator('.ng-value-label')
    this.startTaxDate = page.locator('#startTaxDate-input')
    this.endTaxDate = page.locator('#endTaxDate-input')

    // Вкладка "Реквизиты и подписи"
    this.accountType = page.getByTestId('bankDetails').getByRole('row').nth(1).getByRole('cell').nth(0)
    this.accountNumber = page.getByTestId('bankDetails').getByRole('row').nth(1).getByRole('cell').nth(1)
    this.bankName = page.getByTestId('bankDetails').getByRole('row').nth(1).getByRole('cell').nth(2)
    this.bic = page.getByTestId('bankDetails').getByRole('row').nth(1).getByRole('cell').nth(3)
    this.correspondentAccount = page.getByTestId('bankDetails').getByRole('row').nth(1).getByRole('cell').nth(4)
    this.currencyCode = page.getByTestId('bankDetails').getByRole('row').nth(1).getByRole('cell').nth(5)
    this.beneficiary = page.getByTestId('bankDetails').getByRole('row').nth(1).getByRole('cell').nth(6)

    this.address = page.getByTestId('addresses').getByRole('row').nth(1).getByRole('cell').nth(1)

    this.email = page.getByTestId('emails').getByRole('row').nth(1).getByRole('cell').nth(1)

    this.phone = page.getByTestId('phones').getByRole('row').nth(1).getByRole('cell').nth(1)

    // Вкладка "Техническая информация"
    this.documentId = page.getByTestId('AATechnicalInfo-#').locator('.ai-text-span')
    this.technicalIdField = page.getByTestId('AATechnicalInfo-#').getByRole('textbox')

    // Вкладка "Полномочия поставщика"
    this.commissionRulesAddButton = page.getByRole('button', { name: '+ Добавить' })
    this.commissionRulesFormAdd = page.locator('.pt-2')

    this.commissionRulesStartDate = page
      .getByTestId('AACommissionRules-#')
      .locator('.ai-datetime-input-bootstrap-container')
      .getByRole('textbox')
      .first()
    this.commissionRulesEndDate = page
      .getByTestId('AACommissionRules-#')
      .locator('.ai-datetime-input-bootstrap-container')
      .getByRole('textbox')
      .nth(1)
    this.commissionRulesRegistrationNumber = page
      .locator('app-text-input')
      .filter({ hasText: 'Регистратор --' })
      .getByRole('textbox')
    this.commissionRulesisuranceRule = page.locator('ng-component > div > div:nth-child(4)').getByRole('combobox')
    this.commissionRulesInsuranceProduct = page
      .locator('div:nth-child(6) > ng-component > .ai-group-bootstrap > .row > div')
      .getByRole('combobox')
    this.commissionRulesInsuranceProgram = page
      .locator('div:nth-child(7) > ng-component > .ai-group-bootstrap > .row > div')
      .getByRole('combobox')
    this.commissionRulesMaxKv = page.locator('.ai-numeric-input').nth(2).getByRole('textbox')
    this.commissionRulesDefaultKv = page.locator('.ai-numeric-input').nth(1).getByRole('textbox')
    this.commissionRulesMinKv = page.locator('.ai-numeric-input').first().getByRole('textbox')
    this.banDiscountCheckbox = page.locator(
      'div:nth-child(3) > ng-component > div > div:nth-child(6) > ng-component > .ai-boolean-input-bootstrap-container > .form-group > .ai-boolean-icon-wrapper > .ai-boolean-icon'
    )
    this.banManualEditCheckbox = page.locator(
      'div:nth-child(7) > ng-component > .ai-boolean-input-bootstrap-container > .form-group > .ai-boolean-icon-wrapper > .ai-boolean-icon'
    )
    this.commissionRulesOkButton = page.getByRole('button', { name: ' OK' })

    this.tableId = page.getByRole('row').nth(1).getByRole('cell').nth(1)
    this.tableStartDate = page.getByRole('row').nth(1).getByRole('cell').nth(2)
    this.tableEndDate = page.getByRole('row').nth(1).getByRole('cell').nth(3)
    this.tableRegistrationNumber = page.getByRole('row').nth(1).getByRole('cell').nth(4)
    this.tableInsuranceRule = page.getByRole('row').nth(1).getByRole('cell').nth(5)
    this.tableInsuranceRuleCode = page.getByRole('row').nth(1).getByRole('cell').nth(6)
    this.tableInsuranceProduct = page.getByRole('row').nth(1).getByRole('cell').nth(8)
    this.tableMinKv = page.getByRole('row').nth(1).getByRole('cell').nth(10)
    this.tableDefaultKv = page.getByRole('row').nth(1).getByRole('cell').nth(11)
    this.tableMaxKv = page.getByRole('row').nth(1).getByRole('cell').nth(12)
    this.tableProgramName = page.getByRole('row').nth(1).getByRole('cell').nth(19)

    // Вкладка "Доп. соглашения"
  }

  // Общие методы
  async selectValueCombobox(nameValue) {
    await this.page.getByRole('option', { name: nameValue }).click()
  }

  async editValueTextboxField(locatorField, value) {
    await locatorField.clear()
    await locatorField.fill(value)
  }

  // Методы работы с элементами страницы "Агентский договор"
  async getDocumentTypeHeader() {
    const docTypeHeader = await this.documentTypeHeader.textContent()
    return docTypeHeader
  }

  async getDocumentStatus() {
    const docStatus = await this.documentStatus.textContent()
    return docStatus
  }

  async goToTab(tab) {
    await tab.click()
  }

  async toSave() {
    await this.saveButton.click()
  }

  // Методы для работы с элементами на вкладке "Детали логовора"

  async selectDocumentType(docName) {
    await this.documentTypeCombobox.click()
    await this.selectValueCombobox(docName)
  }

  async selectAgent(agentName, agentCode) {
    await this.searchAgentButton.click()
    await this.searchAgentField.fill(agentName)
    await this.searchButton.click()
    await this.page.getByRole('row', { name: agentCode }).getByRole('checkbox').check()
    await this.selectButton.click()
  }

  async selectOrder(orderNumber) {
    await this.orderNumberCombobox.click()
    await this.selectValueCombobox(orderNumber)
  }

  async selectDepartment(departmentName) {
    await this.departmentCombobox.click()
    await this.selectValueCombobox(departmentName)
  }

  async checkSalesBranches() {
    const result = await this.page
      .getByTestId('salesBranches')
      .getByRole('row')
      .nth(1)
      .getByRole('cell')
      .nth(0)
      .textContent()
    return result
  }

  async selectResponsibilityZones(responsibilityZonesName) {
    await this.responsibilityZonesCombobox.click()
    await this.selectValueCombobox(responsibilityZonesName)
  }

  async selectCaPrintFormLayout(caPrintFormLayoutName) {
    await this.caPrintFormLayoutCombobox.click()
    await this.selectValueCombobox(caPrintFormLayoutName)
  }

  async checkCheckbox(checkbox) {
    const classAttribute = await checkbox.getAttribute('class')
    const result = classAttribute == 'ai-boolean-icon fa-solid fa-square-check ai-blue-checkbox-icon'
    return result
  }

  async searchSideSigner(sideSignerName, sideSignerCode) {
    await this.searchSideSignerButton.click()
    await this.searchSideSignerField.fill(sideSignerName)
    await this.searchButton.click()
    await this.page.getByRole('row', { name: sideSignerCode }).getByRole('checkbox').check()
    await this.selectButton.click()
  }

  async selectSideAgentFullName(signerAgentName) {
    await this.sideAgentName.fill(signerAgentName)
  }

  async selectValidity(date) {
    await this.validityConclusionDate.fill(date)
    await this.validityStartDate.fill(date)
    await this.validityStartDate.blur()
  }

  // Методы работы с элементами страницы "Полномочия поставщика"
  async selectRule(ruleName) {
    await this.commissionRulesisuranceRule.click()
    await this.selectValueCombobox(ruleName)
  }

  async selectProduct(productName) {
    await this.commissionRulesInsuranceProduct.click()
    await this.selectValueCombobox(productName)
  }

  async selectProgram(programName) {
    await this.commissionRulesInsuranceProgram.click()
    await this.selectValueCombobox(programName)
  }

  async setCommissionRulesMaxKv(maxKv) {
    await this.commissionRulesMaxKv.fill(maxKv)
    await this.commissionRulesMaxKv.blur()
  }

  async saveRule() {
    await this.commissionRulesOkButton.click()
  }

  async checkAmountRowTable(amountRow) {
    let row = await this.page.getByRole('row').count()
    row -= 1
    let result
    if (amountRow == row) {
      result = true
    } else {
      result = false
    }
    console.log(result)
    return result
  }

  async checkLastAddRule() {
    let row = await this.page.getByRole('row').count()
    row -= 1
    const result = await this.page.getByRole('row').nth(row).getByRole('cell').nth(8).textContent()
    return result
  }

  async deleteRowRule(rowNumber) {
    await this.page.getByRole('row').nth(rowNumber).getByRole('cell', { name: '  ' }).locator('i').nth(2).click()
  }

  // Методы работы с элементами страницы "Доп. соглашения"
  async getAmendmentNumber(typeAmendment) {
    const amendmentNumber = await this.page
      .getByRole('row')
      .filter({ hasText: typeAmendment })
      .getByRole('cell')
      .nth(0)
      .getByRole('link')
      .textContent()
    return amendmentNumber
  }

  async getPath(docNumber) {
    const path = await this.page.getByRole('link', { name: docNumber }).nth(1).getAttribute('href')
    return path
  }
}
