import { test, expect } from 'playwright/test'
import { RegisterMortgageVTB } from './PageMortgageVTB'

let currectDate
let values
// let currectDate1

export class MortgageVTB extends RegisterMortgageVTB {
  super() {}

  /**
   * Авторизация
   * @param testEnvironment  тестовая среда
   * @param UserName  логин
   * @param Password  пароль
   */
  async ADI_T2607(testEnvironment, UserName, Password) {
    await test.step('Блок "Авторизация".', async () => {
      await this.goto(testEnvironment)
      await this.clickEnterButton()
      await this.fillUserNameLable(UserName)
      await this.fillPasswordLable(Password)
      await this.clickLoginTypeRadioBox()
      await this.clickLoginButton()
    })
  }

  /**
   * Переход по главному меню
   * @param firstLevel родительская_папка
   * @param secondLevel дочерняя_папка
   * @param thirdLevel элемент_меню
   */
  async ADI_T1990(firstLevel, secondLevel, thirdLevel) {
    await test.step('Блок "Переход по главному меню".', async () => {
      await this.SwitchingToTheMainMenu(firstLevel, secondLevel, thirdLevel)
    })
  }

  /**
   * Поиск и выбор в форме "Поиск контрагента - по параметрам" ФЛ в системе Адакта (Если блок "Страхователь", в вкладке "Общее")
   * @param LastName фамилия_контрагента
   * @param FirstName имя_контрагента
   * @param MiddleName отчество_контрагента
   * @param partyCode код_контрагента
   */
  async ADI_T3007General(LastName, FirstName, MiddleName, partyCode) {
    await test.step('Блок "Поиск и выбор в форме "Поиск контрагента - по параметрам" ФЛ в системе Адакта".', async () => {
      await this.clickPhLookupButton()
      await this.clickCounterpartyTypeCombobox()
      await this.clickIndividualOption()
      await this.clickSystemSelectionDropdownCombobox()
      await this.clickAdaktaSystem()
      await this.fillPartyLastName(LastName)
      await this.fillPartyFirstName(FirstName)
      await this.fillPartyMiddleName(MiddleName)
      await this.clickSearchButton()
      await this.FindingTheValue(partyCode)
      await this.clickChoiceButton()
    })
  }

  /**
   * Заполнение доп информации по Страхователю (категория, сем.положение, тел, почта)
   * @param value1 номер_телефона
   * @param value3 семейное_положение
   */
  async ADI_T3272(value1, value3) {
    await test.step('Блок "Заполнение доп информации по Страхователю".', async () => {
      await this.clickMaritalStatusCombobox()
      await this.SelectingAValue(value3)
      await this.clickSelectedPhoneCombobox()
      await this.SelectingAValue(value1)
      await this.clickCategoryCombobox()
      await this.clickBorrowerOption()
      await this.clickNoEmailCheck()
    })
  }

  /**
   * Заполнение блока "Кредитный договор" (ОСЗ/валюта/даты/срок/% ставка/цель/% увел СС/порядок определения СС/фикс. сумма)
   * @param OSZ осз
   * @param MonthsInput оставшийся_срок_кредита_(в_мес.)
   * @param CreditPercentage текущая_ставка_по_кредиту
   */
  async ADI_T2365(OSZ, MonthsInput, CreditPercentage) {
    await test.step('Блок "Заполнение блока "Кредитный договор"".', async () => {
      await this.fillOSZInputLable(OSZ)
      currectDate = await this.insertDate(0)
      await this.fillCreditDateInputLable(currectDate)
      await this.fillRemainingMonthsInputLable(MonthsInput)
      await this.clickCreditPurposeCombobox()
      await this.clickBuyingHousingOption()
      await this.clickSumInsuredCombobox()
      await this.clickOSZPercentOption()
      await this.fillCreditPercentageInputLable(CreditPercentage)
    })
  }

  /**
   * Блок Договор страхования. Заполнение полей (дата начала, дата закл, прогр. стр)
   * @param ProgramOption Программа страхования
   */
  async ADI_T3843(ProgramOption) {
    await test.step('Блок "Договор страхования".', async () => {
      currectDate = await this.insertDate(0)
      await this.fillIssueDateInputLable(currectDate)
      await this.clickInsuranceProgram()
      await this.SelectingAValue(ProgramOption)
    })
  }

  /**
   * Заполнение блока "Орг структура"
   * @param NameSection подразделение
   */
  async ADI_T2367(NameSection) {
    await test.step('Блок "Заполнение блока "Орг структура"".', async () => {
      await this.clickDepartmentSearch()
      await this.fillDepartmentNameSection(NameSection)
      await this.clickStandartSearchButton()
      await this.clickStantartCheckbox()
      await this.clickChoiceButton()
    })
  }

  /**
   * Переход на вкладку документа (Написать название вкладки)
   * @param tab Вкладка
   */
  async ADI_T2641(tab) {
    await test.step('Блок "Переход на вкладку документа.', async () => {
      switch (tab) {
        case 'Застрахованные':
          await this.clickPersonsNav()
          break
        case 'Застрахованное имущество':
          await this.clickPropertyNav()
          break
        case 'Задачи группы':
          await this.clickButtonTabGroupTasks()
          break
        case 'Договор':
          await this.clickTabPolicyNav()
          break
        case 'График платежей':
          await this.clickTabpaymentPlan()
          break
        case 'График тарифов':
          await this.clickTabPremiumGraph()
          break
        case 'Андеррайтинг':
          await this.clickUnderwriting()
          break
      }
    })
  }

  /**
   *  Нажатие кнопки Добавить в блоке "Список застрахованных"
   */
  async ADI_T3097() {
    await test.step('Блок "Нажатие кнопки Добавить в блоке "Список застрахованных".', async () => {
      await this.clickInsuredPersonsList()
    })
  }

  /**
   *  Выбор страхователя и проверка автозаполненных полей
   * @param NumberOption телефон_зл
   * @param value3 e-mail
   */
  async ADI_T2371(NumberOption, value3) {
    await test.step('Блок "Выбор страхователя и проверка автозаполненных полей".', async () => {
      await this.clickSelectPolicyholder()
      await this.clickSelectedPhone()
      await this.SelectingAValue(NumberOption)
    })
  }

  /**
   *  Выбор страхователя и проверка автозаполненных полей
   * @param NumberOption телефон_зл
   * @param value3 e-mail
   */
  async ADI_T2371Email(NumberOption, value3) {
    await test.step('Блок "Выбор страхователя и проверка автозаполненных полей".', async () => {
      await this.clickSelectPolicyholder()
      await this.clickSelectedPhone()
      await this.SelectingAValue(NumberOption)
      await this.clickSelectedEmail()
      await this.SelectingAValue(value3)
    })
  }

  /**
   *  Установка, снятие чек-бокса в блоке
   */
  async ADI_T3194() {
    await test.step('Блок "Установка, снятие чек-бокса в блоке".', async () => {
      await this.clickIpDataSection()
    })
  }

  /**
   * Заполнение блока "Тарификация"
   * @param ParticipationInTheLoan %участия_зл_в_кредите
   */
  async ADI_T2959(ParticipationInTheLoan) {
    await test.step('Блок "Заполнение блока "Тарификация"".', async () => {
      await this.fillPercentageParticipationInput(ParticipationInTheLoan)
    })
  }

  /**
   * Заполнение одного поля в блоке (универсальное)
   * @param ParticipationInTheLoan %участия_зл_в_кредите
   */
  async ADI_T3165(ParticipationInTheLoan) {
    await test.step('Блок "Заполнение одного поля в блоке (универсальное)".', async () => {
      await this.fillPercentageParticipationInput(ParticipationInTheLoan)
    })
  }

  /**
   * Заполнение блока "Информация о профессии" / Раздела "ПРОФЕССИЯ"
   * @param HiringOption настоящее_место_работы
   * @param OrganizationLable наименование_организации
   * @param SkillsLable должностные_обязанности
   * @param IndustryLable отрасль
   * @param NameLable профессия
   */
  async ADI_T2408(HiringOption, OrganizationLable, SkillsLable, IndustryLable, NameLable) {
    await test.step('Блок "Заполнение блока "Информация о профессии" / Раздела "ПРОФЕССИЯ"".', async () => {
      await this.clickTypeEmploymentCombobox()
      await this.SelectingAValue(HiringOption)
      await this.fillOrganizationLable(OrganizationLable)
      await this.fillProfessionSkillsLable(SkillsLable)
      await this.clickProfessionSearchLable()
      await this.fillProfessionIndustryLable(IndustryLable)
      await this.fillProfessionNameLable(NameLable)
      await this.clickStandartSearchButton()
      switch (NameLable) {
        case 'Директор':
          await this.clickManagersText()
          break
        case 'Менеджер':
          await this.clickRowEconomicsFinance()
          break
        case 'повар':
          await this.clickServiceSector()
      }
      await this.clickChoiceButton()

      // clickServiceSector
    })
  }

  /**
   * Заполнение разделов "Рост/Вес/Давление", "Заболевания" в блоке "Медицинская информация"
   * @param HeightInput рост_в_см
   * @param WeightInput вес_в_кг
   * @param UpInput артериальное_давление_верхнее
   * @param LowInput артериальное_давление_нижнее
   */
  async ADI_T2776(HeightInput, WeightInput, UpInput, LowInput, OpionNo) {
    await test.step('Блок "Заполнение разделов "Рост/Вес/Давление", "Заболевания" в блоке "Медицинская информация""', async () => {
      await this.fillIpHeightInput(HeightInput)
      await this.fillIpWeightInput(WeightInput)
      await this.fillBloodPressureUpInput(UpInput)
      await this.fillBloodPressureLowInput(LowInput)
      await this.clickMedicationGroupCombobox()
      await this.clickDontTakeMedicationOption()
      await this.clickDisabilityGroupCombobox()
      await this.SelectingAValue(OpionNo)
    })
  }

  /**
   * Заполнение разделов "Рост/Вес/Давление", "Заболевания" в блоке "Медицинская информация"
   * @param HeightInput рост_в_см
   * @param WeightInput вес_в_кг
   * @param UpInput артериальное_давление_верхнее
   * @param LowInput артериальное_давление_нижнее
   * @param DisabilityGroup Описание
   */
  async ADI_T2776Inval(HeightInput, WeightInput, UpInput, LowInput, OpionNo, DisabilityGroup) {
    await test.step('Блок "Заполнение разделов "Рост/Вес/Давление", "Заболевания" в блоке "Медицинская информация""', async () => {
      await this.fillIpHeightInput(HeightInput)
      await this.fillIpWeightInput(WeightInput)
      await this.fillBloodPressureUpInput(UpInput)
      await this.fillBloodPressureLowInput(LowInput)
      await this.clickMedicationGroupCombobox()
      await this.clickDontTakeMedicationOption()
      await this.clickDisabilityGroupCombobox()
      await this.SelectingAValue(OpionNo)
      await this.fillDisabilityGroup(DisabilityGroup)
    })
  }

  /**
   * Заполнение разделов "Рост/Вес/Давление", "Заболевания" в блоке "Медицинская информация"
   * @param GroupName группа_заболеваний
   * @param DiseaseName заболевание
   * @param InputLable описание_заболевания
   * @param AdditionLable доп_информация
   */
  async ADI_T2783(GroupName, DiseaseName, InputLable, AdditionLable) {
    await test.step('Блок "Заполнение раздела "Заболевания""', async () => {
      await this.clickPresenceOfDiseases()
      await this.clickAddDiseaseTableButton()
      await this.clickDiseaseSearchButton()
      await this.fillDiseaseGroupNameText(GroupName)
      await this.fillDiseaseName(DiseaseName)
      switch (DiseaseName) {
        case 'Ревмокардит':
          await this.clickDisease()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Пурпура':
          await this.clickPurpura()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Панкреатит':
          await this.clickOrganВiseasesRow()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'СПИД':
          await this.ClickSpidOption()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Диабет 2 типа':
          await this.ClickOptionDiabet()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Цирроз печени':
          await this.ClickOptionServal()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Гломерулонефрит':
          await this.ClickOptionGlomerulonefrit()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Болезнь Бехтерева':
          await this.ClickOptionbehter()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Высокая степень миопии':
          await this.ClickOptionMiopiy()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Псориаз (тяжелая степень - 3 степень), псориатический артрит':
          await this.ClickOptionPsoriaz()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Саркоидоз':
          await this.ClickOptionSarkoidoz()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Полиомиелит':
          await this.ClickOptionPoliomielit()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
        case 'Доброкачественные опухоли головного мозга и спинного мозга':
          await this.ClickOptionOnkologi()
          await this.clickChoiceButton()
          await this.fillAppTextInputLable(InputLable)
          await this.clickOkButton()
          await this.fillDiseaseAdditionLable(AdditionLable)
          break
      }
    })
  }

  /**
   * Сохранить / Рассчитать
   */
  async ADI_T2044() {
    await test.step('Блок "Сохранить / Рассчитать"', async () => {
      await this.clickSaveButton()
      await this.page.waitForTimeout(1000)
    })
  }

  /**
   * Поиск и выбор в форме "Поиск контрагента - по параметрам" ФЛ в системе Адакта (Если блок "Личная информация", в вкладке "Застрахованные")
   * @param LastName фамилия_контрагента
   * @param FirstName имя_контрагента
   * @param MiddleName отчество_контрагента
   * @param partyCode код_контрагента
   */
  async ADI_T3007Insured(LastName, FirstName, MiddleName, partyCode) {
    await test.step('Блок "Поиск и выбор в форме "Поиск контрагента - по параметрам" ФЛ в системе Адакта"', async () => {
      await this.clickSelectIpButton()
      await this.clickSystemSelectionDropDown()
      await this.clickAdaktaSystem()
      await this.fillPartyLastName(LastName)
      await this.fillPartyFirstName(FirstName)
      await this.fillPartyMiddleName(MiddleName)
      await this.clickSearchButton()
      await this.FindingTheValue(partyCode)
      await this.clickChoiceButton()
    })
  }

  /**
   * Поиск и выбор в форме "Поиск контрагента - по параметрам" ФЛ в системе Адакта (Если блок "Личная информация", в вкладке "Застрахованные")
   * @param GeneralCategory категория
   * @param MaritalStatus семейное_положение
   * @param SelectedPhone номер
   * @param SelectedEmail email
   */
  async ADI_T12639(GeneralCategory, MaritalStatus, SelectedPhone, SelectedEmail) {
    await test.step('Блок "Заполнение полей в блоке "Личная информация" (категория, сем.положение, телефон, email)"', async () => {
      await this.clickIpGeneralCategory()
      await this.SelectingAValue(GeneralCategory)
      await this.clickIpDataSectionMaritalStatus()
      await this.SelectingAValue(MaritalStatus)
      await this.clickIpDataSectionSelectedPhone()
      await this.SelectingAValue(SelectedPhone)
      await this.clickIpDataSectionSelectedEmail()
      if (SelectedEmail === 'lazareva@mail.ru') {
        await this.SelectingAValue(SelectedEmail)
      }
    })
  }

  /**
   *  Заполнение раздела "Вопрос для женщин" в блоке "Медицинская информация"
   */
  async ADI_T3288() {
    await test.step('Блок "Заполнение раздела "Вопрос для женщин" в блоке "Медицинская информация""', async () => {
      await this.clickDiseaseSectionNgComponent()
      await this.clickExactNoOption()
    })
  }

  /**
   * Заполнение блока "Основная информация" (наименование, тип, стоимость, адрес)
   * @param LableObject наименование_обьекта_страхования
   * @param SectionLable ОС_объекта
   * @param AddressAutocomplete адрес_целиком
   * @param EvaluationReport документ_оценки
   * @param InputFact факт.оцен_стоимость
   */
  async ADI_T2788(LableObject, ApartmentsOption, SectionLable, AddressAutocomplete, EvaluationReport, InputFact) {
    await test.step('Блок "Заполнение блока "Основная информация" (наименование, тип, стоимость, адрес)"', async () => {
      await this.clickAddButton()
      await this.fillAppTextInputLableObject(LableObject)
      await this.clickGeneralInformationSection()
      await this.SelectingAValue(ApartmentsOption)
      await this.fillGeneralInformationSectionLable(SectionLable)
      await this.fillAddressAutocomplete(AddressAutocomplete)
      await this.clickAdressNumber()
      await this.clickStandardizationButton()
      const currectDate = await this.insertDate(0)
      await this.fillGeneralInformationSectionDates(currectDate)
      await this.clickNgComponentGeneral()
      await this.SelectingAValue(EvaluationReport)
      await this.fillInputFact(InputFact)
    })
  }

  /**
   * Заполнение блока "Имущественное страхование" (площадь, отопление, год поcтройки + характер использования)
   * @param TotalArea общая_площадь
   * @param AreaComponent кол-во_комнат
   * @param CentralHeating вид_отопления
   * @param NumberOfFloors кол-во_этажей
   * @param NumberOfFloorsnhs этаж_расположения
   * @param NumberOfFloorsnhs2 %_износа
   * @param NumberOfFloorsFirst год_постройки
   * @param VisibleDamage внутр_внешн_дефекты
   * @param DescriptionSection характер_использования
   */
  async ADI_T2789(
    TotalArea,
    AreaComponent,
    CentralHeating,
    NumberOfFloors,
    NumberOfFloorsnhs,
    NumberOfFloorsnhs2,
    NumberOfFloorsFirst,
    VisibleDamage,
    DescriptionSection
  ) {
    await test.step('Блок "Заполнение блока "Имущественное страхование" (площадь, отопление, год поcтройки + характер использования)"', async () => {
      await this.clickPropertyInsurance()
      await this.fillTotalArea(TotalArea)
      await this.fillTotalAreaComponent(AreaComponent)
      await this.clickTotalAreaComponentCombobox()
      await this.SelectingAValue(CentralHeating)
      await this.fillNumberOfFloors(NumberOfFloors)
      await this.fillNumberOfFloorsnhs(NumberOfFloorsnhs)
      await this.fillNumberOfFloorsnhs2(NumberOfFloorsnhs2)
      await this.fillNumberOfFloorsFirst(NumberOfFloorsFirst)
      await this.clickComboboxInfomation()
      await this.SelectingAValue(VisibleDamage)
      await this.ClickUsageDescriptionSection()
      await this.SelectingAValue(DescriptionSection)
    })
  }

  /**
   *  Заполнение чекбоксов раздела "Источники повышенной пожарной опасности"
   */
  async ADI_T3211() {
    await test.step('Блок "Заполнение чекбоксов раздела "Источники повышенной пожарной опасности""', async () => {
      await this.clickFireSourceSection()
    })
  }

  /**
   *  Заполнение чекбоксов раздела "Внешние стены"
   */
  async ADI_T2880() {
    await test.step('Блок "Заполнение чекбоксов раздела "Внешние стены""', async () => {
      await this.clickWallSection()
    })
  }

  /**
   *  Заполнение чекбоксов раздела "Межэтажные перекрытия"
   */
  async ADI_T3195() {
    await test.step('Блок "Заполнение чекбоксов раздела "Межэтажные перекрытия""', async () => {
      await this.clickDeckSection()
    })
  }

  /**
   *  Заполнение разделов "Пожарная/Охранная безопасность"
   */
  async ADI_T2887() {
    await test.step('Блок "Заполнение разделов "Пожарная/Охранная безопасность""', async () => {
      await this.clickFireProtectionSection()
      await this.clickSecuritySystemsSection()
    })
  }

  /**
   *  Выбор вида страхования, проверка и заполнение разделов "Тарификация" "Риски ТИТ " (срок, пакет рисков, Кпрод, чекбокс андер)
   * @param LossSection срок_страхования_в_мес.
   */
  async ADI_T2794(LossSection) {
    await test.step('Блок "Выбор вида страхования, проверка и заполнение разделов "Тарификация" "Риски ТИТ " (срок, пакет рисков, Кпрод, чекбокс андер)"', async () => {
      await this.clickGeneralPropertyInsurance()
      await this.fillOwnershipLossSection(LossSection)
    })
  }

  /**
   *  Заполнение блока "Cобственник имущества" (собств., вид владения)
   * @param InsuredOption ос_в_собственности
   * @param IndividuallyOption вид_владения
   */
  async ADI_T2797(InsuredOption, IndividuallyOption) {
    await test.step('Блок "Заполнение блока "Cобственник имущества" (собств., вид владения)"', async () => {
      await this.clickOwnerShipLossCombobox()
      await this.SelectingAValue(InsuredOption)
      await this.clickOwnerShipLossComboboxTwo()
      await this.SelectingAValue(IndividuallyOption)
    })
  }

  /**
   *  Заполнение и проверка полей в блоке "Собственник имущества" (таблица: доля, сем.полож, чекбоксы)
   * @param Tablelable доля_владения
   * @param MarriedOption семейное_положение
   */
  async ADI_T2904(Tablelable, MarriedOption) {
    await test.step('Блок "Заполнение и проверка полей в блоке "Собственник имущества" (таблица: доля, сем.полож, чекбоксы)"', async () => {
      await this.clickOwnesTableButton()
      await this.clickAiGroupBootstraps()
      await this.fillOwnersTablelable(Tablelable)
      await this.clickOwersTableCombobox()
      await this.SelectingAValue(MarriedOption)
    })
  }

  /**
   *  Заполнение и проверка полей в блоке "Собственник имущества" (таблица)
   * @param IndividualOption тип_контрагента
   * @param LastName фамилия
   * @param FirstName имя
   * @param MiddleName отчество
   * @param partyCode код_контрагента
   */
  async ADI_T2908(IndividualOption, LastName, FirstName, MiddleName, partyCode) {
    await test.step('Блок "Заполнение и проверка полей в блоке "Собственник имущества" (таблица)"', async () => {
      await this.clickButtonSearch()
      await this.clickComboboxPartyType()
      await this.SelectingAValue(IndividualOption)
      await this.fillLableLastName(LastName)
      await this.fillLableFirstName(FirstName)
      await this.fillLableMiddleName(MiddleName)
      await this.clickSearchButton()
      await this.FindingTheValueAnother(partyCode)
      await this.clickChoiceButton()
      await this.clickOkButton()
    })
  }

  /**
   *  Выбор значения из выпадающего списка
   * @param NotOption значение_в_списке
   */
  async ADI_T4966(NotOption) {
    await test.step('Блок "Выбор значения из выпадающего списка"', async () => {
      await this.clickEncumbrancesSection()
      await this.SelectingAValue(NotOption)
    })
  }

  /**
   *   Заполнение количества переходов прав
   * @param TransferOfRights значение_в_списке
   */
  async ADI_T2799(TransferOfRights) {
    await test.step('Блок "Заполнение количества переходов прав"', async () => {
      await this.clickComboboxOwnershipHistorySection()
      await this.SelectingAValue(TransferOfRights)
    })
  }

  /**
   *  Заполнение и проверка полей в блоке "Собственник имущества" (таблица)
   * @param ContractOfSale документ_основание
   */
  async ADI_T1997(ContractOfSale) {
    await test.step('Блок "Заполнение истории переходов прав"', async () => {
      await this.clickOwnershipHistory()
      await this.clickComboboxOwnershipHistory()
      await this.SelectingAValue(ContractOfSale)
      const currectDate = await this.insertMonth(5)
      await this.fillLableOwnerDateOneы(currectDate)
      await this.fillLableOwnerDateTwo(currectDate)
      await this.clickButtonOwnerOk()
    })
  }

  /**
   *   Нажатие кнопки Добавить в Имущественном страховании
   */
  async ADI_T3674() {
    await test.step('Блок "Нажатие кнопки Добавить в Имущественном страховании"', async () => {
      await this.clickApartmentsAddButton()
    })
  }

  /**
   *    Заполнение блока "Основная информация" (наименование, тип, стоимость, адрес)
   * @param AppTextInput наименование_обьекта_страхования
   * @param LandPlot тип_объекта
   * @param GeneralInformation ОС_объекта
   * @param AssessedValue факт.оцен_стоимость
   * @param Autocomplete адрес_целиком
   * @param CadastralNumber кадастровый_номер
   * @param EvaluationReport документ_оценки
   */
  async ADI_T2788Expanded(
    AppTextInput,
    LandPlot,
    GeneralInformation,
    AssessedValue,
    Autocomplete,
    CadastralNumber,
    EvaluationReport
  ) {
    await test.step('Блок "Заполнение блока "Основная информация" (наименование, тип, стоимость, адрес)"', async () => {
      await this.fillAppTextInput(AppTextInput)
      await this.clickComboboxGeneralSection()
      await this.SelectingAValue(LandPlot)
      await this.fillLableGeneralInformation(GeneralInformation)
      await this.fillLableAssessedValue(AssessedValue)
      await this.fillLableAssressAutocomplete(Autocomplete)
      await this.clickClickOptionAdress()
      await this.clickStandardization()
      await this.fillLableCadastralNumber(CadastralNumber)
      const currectDate = await this.insertDate(0)
      await this.fillLableGeneralDate(currectDate)
      await this.clickComboboxGeneralDate()
      await this.SelectingAValue(EvaluationReport)
    })
  }

  /**
   *  Заполнение раздела "Охранная безопасность" для объекта "Земельный участок"(чекбоксы)
   */
  async ADI_T5248() {
    await test.step('Блок "Заполнение раздела "Охранная безопасность" для объекта "Земельный участок"(чекбоксы)"', async () => {
      await this.clickPropertyInsuranceTrue()
      await this.clickSecuritySystems()
    })
  }

  /**
   *  Сохранить уникальный номер в заголовке (документа/контрагента)
   */
  async ADI_T2987() {
    await test.step('Блок "Сохранить уникальный номер в заголовке (документа/контрагента)"', async () => {
      values = await this.getDocumentNumber()
      return values
    })
  }

  /**
   *  Выполнение действия (с выбором исполнителя)
   * @param OptionName имя_исполнителя
   */
  async ADI_T2387(OptionName) {
    await test.step('Блок "Выполнение действия (с выбором исполнителя)"', async () => {
      await this.page.reload()
      await this.clickButtonDo()
      await this.clickSendForApproval()
      await this.clickComboboxClick()
      await this.SelectingAValue(OptionName)
      await this.clickOkButton()
    })
  }

  /**
   *  Выполнение действия (с выбором исполнителя)
   * @param OptionName имя_исполнителя
   */
  async ADI_T2607WithExit(UserName, PasswordLable) {
    await test.step('Блок "Авторизация"', async () => {
      await this.clickButtonWelcom()
      await this.clickButtonExit()
      await this.clickButtonHere()
      await this.clickEnterButton()
      await this.fillUserNameLable(UserName)
      await this.fillPasswordLable(PasswordLable)
      await this.clickLoginTypeRadioBox()
      await this.clickLoginButton()
    })
  }

  /**
   *  Выполнение действия (с выбором исполнителя)
   * @param OptionName имя_исполнителя
   */
  async ADI_T3954(OptionUnderwritingGO) {
    await test.step('Блок "Поиск, назначение задачи в группе и переход к документу"', async () => {
      await this.clickComboboxGroupTasks()
      await this.SelectingAValue(OptionUnderwritingGO)
      await this.fillLableDocumentNumber(values)
      await this.clickStandartSearchButton()
      await this.clickGroupTabeRow()
      await this.clickButtonAssignATaskToYourself()
      await this.clickGroupTasksTableDoc()
      await this.page.waitForTimeout(5000)
    })
  }

  /**
   *  Переключение и проверка роли
   *  @param ButtonUnderwriter наименование_роли
   */
  async ADI_T2413(ButtonUnderwriter) {
    await test.step('Блок "Переключение и проверка роли"', async () => {
      switch (ButtonUnderwriter) {
        case 'Андеррайтер':
          await this.clickButtonP()
          await this.clickButtonUnderwriter()
          break
        case 'Продавец':
          await this.clickAiActorControl()
          await this.clickOptionSalesman()
          await this.page.waitForTimeout(20000)
          await this.page.reload()
          break
      }
    })
  }

  /**
   *   Выполнение действия (без выбора исполнителя)
   * @param Underwriter действие
   */
  async ADI_T2399(Underwriter) {
    await test.step('Блок "Выполнение действия (без выбора исполнителя)"', async () => {
      await this.clickButtonDo()
      await this.SelectingAButton(Underwriter)
      await this.clickButtonYes()
      await this.page.waitForTimeout(5000)
    })
  }

  /**
   *    Согласование триггеров
   */
  async ADI_T2802() {
    await test.step('Блок "Согласование триггеров"', async () => {
      await this.clickTabUnderwrightOverview()
      await this.clickRowKlass()
      await this.clickComboboxObjectsOfInsurance()
      await this.clickOptionAgreed()
      await this.clickButtonChoice()
      await this.page.waitForTimeout(20000)
    })
  }

  /**
   * Заполнение блока "Кредитный договор"
   * @param CreditDocument №_кредит_дог
   * @param AppTextInput место_заключения
   * @param PeriodPay действие
   */
  async ADI_T2923(CreditDocument, AppTextInput, PeriodPay) {
    await test.step('Блок "Заполнение блока "Кредитный договор"")', async () => {
      await this.fillLableCreditDocument(CreditDocument)
      await this.fillLableAppTextInput(AppTextInput)
      await this.fillLablePeriodPay(PeriodPay)
      const currectDate = await this.insertDate(0)
      await this.fillLableDateCreadit(currectDate)
    })
  }

  /**
   *  Проверка и заполнение полей в блоке "Личная информация"
   */
  async ADI_T3117() {
    await test.step('Блок "Проверка и заполнение полей в блоке "Личная информация""', async () => {
      await this.clickIpSmsMessages()
      await this.clickProcessingPersonalData()
    })
  }

  /**
   *  Переключение карточек застрахованных лиц
   * @param PersonsList ФИО Застрахованного
   */
  async ADI_T3075(PersonsList) {
    await test.step('Блок "Переключение карточек застрахованных лиц"', async () => {
      switch (PersonsList) {
        case 'Лазарева Елена Геннадьевна':
          await this.clickInsuredPersonsListTrue()
          break
        case 'Сидоров Юрий Николаевич':
          await this.clickInsuredPersonslistTrue1()
          break
      }
    })
  }

  /**
   *  Заполнение блока "Порядок оплаты премии
   */
  async ADI_T2926() {
    await test.step('Блок "Заполнение блока "Порядок оплаты премии""', async () => {
      await this.clickButtonPaymentMethod()
      await this.clickOptionPayMo()
    })
  }

  /**
   *  Заполнение блока "Плательщик" (способ уведомления)
   * @param PersonsList способ_уведомл_плательщик
   */
  async ADI_T3301(OptionSMS) {
    await test.step('Блок "Заполнение блока "Плательщик" (способ уведомления)"', async () => {
      await this.clickPaymentNotification()
      await this.SelectingAValue(OptionSMS)
    })
  }

  /**
   *  Заполнение блока "Порядок оплаты премии"
   * @param LableEmail тип_документа
   * @param DocumentNumber номер_платеж_документа
   */
  async ADI_T3302(LableEmail, DocumentNumber) {
    await test.step('Блок Заполнение блока "Порядок оплаты премии"', async () => {
      await this.fillLableEmail(LableEmail)
      await this.fillLablePaymentDocumentNumber(DocumentNumber)
      const currectDate = await this.insertDate(0)
      await this.fillLablePaymentDocumentData(currectDate)
    })
  }

  /**
   *  Заполнение полей в блоке "Страхователь" (категория, сем.положение, телефон, email)
   * @param value1 тип_документа
   * @param value2 номер_платеж_документа
   * @param value3 e-mail
   */
  async ADI_T3071(value1, value2, value3) {
    await test.step('Блок Заполнение полей в блоке "Страхователь" (категория, сем.положение, телефон, email)', async () => {
      await this.clickMaritalStatusCombobox()
      await this.SelectingAValue(value2)
      await this.clickSelectedPhoneCombobox()
      await this.SelectingAValue(value1)
      await this.clickCategoryCombobox()
      await this.clickBorrowerOption()
      await this.clickSelectedEmail()
      await this.SelectingAValue(value3)
    })
  }

  /**
   *  Выбор чекбокса
   * @param PersonsList наименование чекбокса
   */
  async ADI_T5242(PersonsList) {
    await test.step('Блок "Выбор чекбокса "', async () => {
      switch (PersonsList) {
        case 'Были обращения к психиатру/наркологу; состоит на учете/лечится/прошел курс лечения':
          await this.clickPsychologicalGroup()
          break
        case 'Проводимые ранее или планируемые операции в связи с болезнями, травмами':
          await this.clickSurgeryExists()
          break
      }
    })
  }

  /**
   *  Заполнение поля значением (универсальный)
   * @param Psychological значение
   */
  async ADI_T3972(Psychological) {
    await test.step('Блок "Заполнение поля значением (универсальный)"', async () => {
      switch (Psychological) {
        case 'обращение к психиатру':
          await this.fillPsychological(Psychological)
          break
        case 'Планируется операция':
          await this.ClickDiseaseSection()
          await this.SelectingAValue(Psychological)
          break
        case 'описание':
          await this.fillAppTextInputO(Psychological)
          break
      }
    })
  }

  /**
   * Проверка отображения триггеров в блоке "Андертриггеры и стопфакторы
   * @param object Триггер Фио обьекта
   * @param object1 Тригггер_назв_триггера
   * @param object2 Триггер класс_триггера
   */

  async ADI_T3382(object, object1, object2) {
    await test.step('Блок "Проверка отображения триггеров в блоке "Андертриггеры и стопфакторы""', async () => {
      await this.Examination(object, object1, object2)
    })
  }
}
