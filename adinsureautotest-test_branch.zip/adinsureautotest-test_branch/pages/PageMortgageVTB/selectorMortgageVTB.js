// @ts-check

const applicationMGVTB = {
  /** id поля "Пакет рисков" */
  risksPackageNgSelect: 'risks-package-ng-select',
  /** id таблицы */
  table: '-table',
  /** url для шага сохранения */
  urlForSave: '/server/api/shell/internal/documents/recent-documents/',
  /** id действия "Отказ от оформления" */
  transitionsDraftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',
  /** id подраздела меню "Ипотека ВТБ" */
  mortgageVtb: 'MortgageVTB_1_2',
  /** id раздела меню "Страховые продукты" */
  contractsMenu: 'Contracts_menu_1',
  /** класс неактивного действия */
  notPossibleTransition: 'dropdown-item ai-not-possible-transition-relation',
  /** id кнопки Поиска*/
  phLookupButton: 'phLookupButton',
  /** id бокового меню "Предрасчет ВТБ" */
  mgVtbApplication: 'MGvtbApplication_1_3',
  /** id вкладки "Застрахованные" */
  insuredPersonsNav: 'Insured persons-nav',
  /** id вкладки "Имущество" */
  insuredPropertyNav: 'Insured property-nav',
  /** id чекбокса "Страхование имущества" */
  propertyInsured: 'property-insured',
  /** id действия "Перейти к оформлению" */
  transitionsVtbCreateQuote: 'ai-transitions-relations-control-VtbCreateQuote',
  /** id поля "Дата предрасчета" */
  requestDateInput: 'request-date-input',
  /** id поля "Дата выдачи кредита Предрасчет" */
  creditDateInput: 'credit-date',
  /** id поля "Порядок определения Страховой суммы " */
  mGEnumInsSumCalcMethod: 'MGEnumInsSumCalcMethod-ng-select',
  /** id поля "Банк " */
  bank: 'bank',
  /** id поля "Остаток ссудной задолженности (ОСЗ)" */
  osz: 'OSZ',
  /** id поля "Программа страхования " */
  insuranceProgram: 'insuranceProgram',
  /** id поля "Комментарий" */
  comment: 'comment',
  /** id чекбокса "Отказ от предоставления телефона" */
  noPhone: 'no-phone',
  /** id поля "Контактный телефон" */
  selectedPhoneSelect: 'selected-phone-ng-select',
  /** id чекбокса "Отказ от предоставления e-mail" */
  noEmail: 'no-email',
  /** id поля "Контактный e-mail" */
  selectedEmailSelect: 'selected-email-ng-select',
  /** id кнопки "Выбрать страхователя" */
  policyholderSearch: 'policyholder-search',
  /** id поля "ФИО застрахованного" */
  ipNameLink: 'ip-name-link',
  /** id поля "Дата рождения " */
  bitrhDate: 'ip-bitrh-date',
  /** id поля "Возраст" */
  ipAge: 'ip-age',
  /** id поля "Пол" */
  ipGender: 'ip-gender',
  /** id поля "Рост в см" */
  ipHeightInput: 'ip-height-input',
  /** id поля "Вес в кг" */
  ipWeightInput: 'ip-weight-input',
  /** id поля "Настоящее место работы" */
  ipEmployment: 'ip-employment',
  /** id кнопки "Поиск" */
  professionSearchButton: 'profession-search-dialog-button',
  /** id модального окна */
  lookupDialogId: 'lookupDialogId',
  /** id поля "Отрасль" */
  professionIndustry: 'profession-industry',
  /** id поля "Профессия" */
  professionName: 'profession-name',
  /** id кнопки "Поиск" в модальном окне */
  searchProfessionButton: 'search-profession-button',
  /** id кнопки "Выбрать" в модальном окне */
  dialogConfirmButton: 'lookup-dialog-confirm-button',
  /** id поля "Отрасль деятельности"*/
  professionView: 'profession-view',
  /** id чекбокса "Занимается спортом"*/
  doSports: 'do-sports',
  /** id раздела "Занимается спортом"*/
  doSportsSection: 'do-sports-section',
  /** id кнопки "Добавить"*/
  doSportsTableAddButton: 'do-sports-table-add-button',
  /** id кнопки "Поиск" спорт*/
  sportsSearch: 'sports-search',
  /** id поля "Спорт"*/
  sportsName: 'sports-name',
  /** id кнопки "Поиск"*/
  searchSportsButton: 'search-sports-button',
  /** id кнопки пагинации в таблице результата спорта*/
  sportNameTablePaginatorResult: 'sport-name-table-paginator-result',
  /** id поля "Занятия спортом"*/
  sportName: 'sport-name',
  /** id чекбокса "Более 3-х раз в год"*/
  sport3times: 'sport-3times',
  /** id кнопки "Ок" */
  doSportsTableOkButton: 'do-sports-table-ok-button',
  /** id таблицы "Занятия спортом" */
  doSportsTableTable: 'do-sports-table-table',
  /** id первой строки таблицы "Занятия спортом" */
  doSportsTableRow0: 'do-sports-table-row-0',
  /** id поля "Наименование объекта" */
  imovableObjectName: 'imovable-object-name',
  /** id поля "Тип предмета ипотеки " */
  imovableObjectDetailedNgSelect: 'imovable-object-detailed-ng-select',
  /** id поля "Действительная (оценочная) стоимость предмета ипотеки " */
  imovableObjectValue: 'imovable-object-value',
  /** id заполненного поля "Действительная (оценочная) стоимость предмета ипотеки " */
  imovableObjectValueInput: 'imovable-object-value-input',
  /** id поля "Год постройки" */
  constructionYear: 'construction-year',
  /** id поля "Материалы стен / перекрытий" */
  wallMaterialNgSelect: 'wall-material-ng-select',
  /** id поля "Тип отопления" */
  heatingSystemNgSelect: 'heating-system-ng-select',
  /** id блока "Имущество" */
  propertyInformation: 'property-information',
  /** id поля "Срок страхования в месяцах" */
  insuranceDurationInput: 'insurance-duration-input',
  /** id чекбокса "Источники открытого огня (печи, камины, сауны, бани)" */
  openFireSources: 'open-fire-sources',
  /** id поля "Коэффициент продавца" */
  salesPersonCoefficientInput: 'sales-person-coefficient-input',
  /** id заполненного поля "Год постройки" */
  constructionYearInput: 'construction-year-input',
  /** id чекбокса "Страхование титула" */
  ownershipLossInsured: 'ownership-Loss-insured',
  /** id блока "Титул" */
  ownershipLossSection: 'ownership-loss-section',
  /** id поля "Количество переходов права собственности" */
  ownershipLossTransfersNgSelect: 'ownership-loss-transfers-ng-select',
  /** id поля "Количество переходов права собственности за посл. 12 мес" */
  lastYearTransfersNgSelect: 'last-year-transfers-ng-select',
  /** id чекбокса "В числе собственников приобретаемого объекта недвижимости имеются несовершеннолетние или недееспособные лица" */
  ownershipLossMinors: 'ownership-loss-minors',
  /** id поля "Сделка по доверенности" */
  ownershipLossProxy: 'ownership-loss-proxy',
  /** id поля "В течение посл. 12 мес. правоустанавливающим документом на объект страхования являлось свидетельство о праве на наследство по закону или по завещанию, решение (определение) суда" */
  ownershipLossInheritance: 'ownership-loss-inheritance',
  /** id поля "Срок страхования в месяцах" */
  ownershipLossDurationInput: 'ownership-loss-duration-input',
  /** id ссылки на Контрагента*/
  name_link: 'ip-name-link',
  /** id вкладки "Расчет тарифов и премии" */
  tariff_calculation_tab: 'tab-Tariff-calculation-overview-nav',
  /** id блока "Список застрахованных" */
  insured_persons_list: 'insured-persons-list',
  /** id поля "Итоговый тариф по пакету рисков (в %)" */
  riskTariffInsPerson: 'risk-tariff',
  /** id поля "Страховая премия" */
  riskPremiumInsPerson: 'risk-premium',
  /** id поля "Страховая сумма" */
  riskSumInputInsPerson: 'risk-sum-input',
  /** id поля "Срок страхования в месяцах " */
  monthsPeriodInsPerson: 'months-period-input',
  /** id таблицы "Расчет премии" */
  aiArrayTable: 'ai-array-table',
  /** id первой строки таблицы "Расчет премии" */
  aiArrayRow0: 'ai-array-row-0',
  /** id строки таблицы "Расчет премии" */
  aiArrayRow: 'ai-array-row-',
  /** id кнопки "Поиск" в блоке застрахованный */
  selectIp: 'select-ip',
  /** id поля "Поиск контрагента в системах"  */
  systemSelectionDropdownNgSelect: 'system-selection-dropdown-ng-select',
  /** id поля "Фамилия"  */
  partyLastName: 'party-last-name',
  /** id поля "Имя"  */
  partyFirstName: 'party-first-name',
  /** id поля "Отчество"  */
  partyMiddleName: 'party-middle-name',
  /** id кнопки "Поиск" блока "Поиск контрагентов по параметрам"*/
  party_search_button: 'DetailedPartySearchView_SearchButton',
  /** id таблицы контрагентов*/
  policyholderSearchTable: 'policyholder-search-table',
  /** id блока застрахованные*/
  vtbInsuredPersonDataInsuredPersonData: 'VtbInsuredPersonData-insuredPersonData',
  /** id блока "Расчет премии"*/
  premiumCalculationSection: 'premium-calculation-section',
  /** id поля "Итоговый тариф"*/
  totalObjectTariff: 'total-object-tariff',
  /** id поля "Страховая премия по объекту"*/
  totalObjectPremium: 'total-object-premium',
  /** id поля "Страховая сумма по объекту"*/
  sumInsuredInput: 'sum-insured-input',
  /** id поля "Итоговый тариф" ТИТ*/
  totObjectTariff: 'tot-object-tariff',
  /** id поля "Страховая премия по объекту" ТИТ*/
  totObjectPremium: 'tot-object-premium',
  /** id поля "Страховая сумма по объекту" ТИТ*/
  lossSumInsuredInput: 'loss-sum-insured-input',
  /** id Действия "Создать Копию"*/
  transitionsRelationsControlVtbCopyApplication: 'ai-transitions-relations-control-VtbCopyApplication',
  /** id вкладки "История" */
  historyTab: 'tab-Contract-activity and transition history-nav',
  /** id первой таблицы вкладки "История" */
  stateHistoryTable: 'state-history-table-table',
  /** id строки таблицы на вкладке "История" */
  stateHistoryTableRow: 'state-history-table-row-',
  /** id блока "ИСТОРИЯ СОГЛАСОВАНИЯ ДОКУМЕНТА" на вкладке "История" */
  documentActivityHistorySection: 'document-activity-history-section',
  /** id таблицы блока "ИСТОРИЯ СОГЛАСОВАНИЯ ДОКУМЕНТА" на вкладке "История" */
  activityHistoryTable: 'activity-history-table-table',
  /** id строки таблицы "ИСТОРИЯ СОГЛАСОВАНИЯ ДОКУМЕНТА" */
  activityHistoryTableRow: 'activity-history-table-row-',
  /** id блока "СВЯЗАННЫЕ ДОКУМЕНТЫ" на вкладке "История" */
  relatedDocumentsSection: 'related-documents-section',
  /** id таблицы в блоке "СВЯЗАННЫЕ ДОКУМЕНТЫ" на вкладке "История" */
  relatedDocumentsTable: 'related-documents-table',
  /** id строки в таблице */
  row: '-row-',
  /** id номера документа */
  aiInfoControl: 'ai-info-control',

  // Было до
  /** id combobox Канал продаж */
  atr_deal_sales_channel: 'sales-channel-ng-select',

  /** id combobox Зона ответственности */
  atr_deal_sales_zone: 'sales-zone-ng-select',

  /** id combobox Профильная программа */
  atr_deal_programme: 'atrDealProgram-ng-select',

  /** id кнопки поиска "Подразделение сделки" */
  atr_deal_department_name_search_button: 'application-branch-search-dialog-button',

  /** id текстового поля "Подразделение" */
  atr_deal_department: 'department-name',
}

const quoteMGVTB = {
  /** id блока "Вложения"*/
  attachedDocumentsSection: 'attached-documents-section',
  /** id таблицы "Вложения"*/
  attachmentsTableRow0: 'attachments-table-row-0',
  /** id таблицы "Вложения"*/
  // attachmentsTable: 'AttachmentsInlineView',
  /** id поля "Пакет Рисков" */
  risksNgSelect: 'ip-risks-ng-select',
  /** id действия "На андеррайтинг" */
  transitionsSalesLevel2ToWaitingForUnderwriting:
    'ai-transitions-relations-control-SalesLevel2_to_WaitingForUnderwriting',
  /** id строки таблицы "Расчет премии" */
  aiArrayRow: 'ai-array-row-',
  /** id таблицы "Расчет премии" */
  aiArrayTable: 'ai-array-table',
  /** id блока "Расчет премии"*/
  premiumCalculationSection: 'premium-calculation-section',
  /** id поля "Адрес"*/
  AddressAutocompleteAddressKLADR: 'AddressAutocomplete-addressKLADR',
  /** id первой строки таблицы "Участники кредитной сделки"*/
  creditParticipantsRow0: 'credit-participants-row-0',
  /** id таблицы "Участники кредитной сделки"*/
  creditParticipantsTable: 'credit-participants-table',
  /** id раздела "Характер использования"*/
  usageDescriptionSection: 'usage-description-section',
  /** id таблицы "Триггеры"*/
  aiDataGridRow: 'ai-data-grid-row-',
  /** id таблицы "Триггеры"*/
  aiDataGrid: 'ai-data-grid-table',
  /** id действия "Завершить проверку СБ" андеррайтером*/
  transitionsRelationsControlSecurityVerificationUW: 'ai-transitions-relations-control-SecurityVerification_UW',
  /** id действия "Проверка СБ" андеррайтером*/
  transitionsRelationsControlUnderwritingToWaitingAutoSecurityVerification:
    'ai-transitions-relations-control-Underwriting_to_WaitingAutoSecurityVerification',
  /** id действия "Вернуть на оформление" продавцом 2го уровня*/
  transitionsRelationsControlSalesLevel2ToDraft: 'ai-transitions-relations-control-SalesLevel2_to_Draft',
  /** id действия "Завершить проверку СБ" продавцом 2го уровня*/
  transitionsRelationsControlAutoSecurityVerificationToSalesLevel2:
    'ai-transitions-relations-control-AutoSecurityVerification_to_SalesLevel2',
  /** id блока "Проверка СБ"*/
  svUiDataGridPersons: 'SvUiDataGridPersons-#',
  /** id действия "Проверка СБ" продавцом 2го уровня*/
  transitionsRelationsControlSalesLevel2ToWaitingAutoSecurityVerification:
    'ai-transitions-relations-control-SalesLevel2_to_WaitingAutoSecurityVerification',
  /** id блока андеррайтинга для страхователя */
  vtbPolicyHolderDataQuotePolicyHolder: 'VtbPolicyHolderDataQuote-policyHolder',
  /** id четвертой строки таблицы "Результаты проверки" */
  svUiDataGridResultsRow3: 'SvUiDataGridResults-#-row-3',
  /** id третьей строки таблицы "Результаты проверки" */
  svUiDataGridResultsRow2: 'SvUiDataGridResults-#-row-2',
  /** id второй строки таблицы "Результаты проверки" */
  svUiDataGridResultsRow1: 'SvUiDataGridResults-#-row-1',
  /** id первой строки таблицы "Результаты проверки" */
  svUiDataGridResultsRow0: 'SvUiDataGridResults-#-row-0',
  /** id вкладки "Детали" */
  tabDetailsNav: 'tab-details-nav',
  /** id таблицы "Проверка объектов недвижимости" */
  preInsuranceCheckPropertySection: 'preInsurance-check-property-section',
  /** id строки в таблице "Контрагенты" */
  SvUiDataGridPersonsRow: 'SvUiDataGridPersons-#-row-',
  /** id таблицы "Контрагенты" */
  svUiDataGridPersonsTable: 'SvUiDataGridPersons-#-table',
  /** id блока "Данные для проверки" */
  svUiGroupGeneralData: 'SvUiGroupGeneralData-#',
  /** id действия "Завершить Проверку СБ" */
  transitionsAutoSecurityVerificationToDraft: 'ai-transitions-relations-control-AutoSecurityVerification_to_Draft',
  /** id блока Проверки СБ */
  svUiTabVerification: 'SvUiTabVerification-#',
  /** id действия "Проверка СБ" */
  transitionsDraftToWaitingAutoSecurityVerification:
    'ai-transitions-relations-control-Draft_to_WaitingAutoSecurityVerification',
  /** id действия "Отказ от оформления" */
  transitionsDocsRequestToClientRefuse: 'ai-transitions-relations-control-DocsRequest_to_ClientRefuse',
  /** id Наименования документа */
  headerDocumentName: 'header-document-name',
  /** id ссылки на документ на вкладке "Мои задачи" */
  myTasksTableDocNumberLink: 'my-tasks-table_doc-number-link',
  /** id кнопки "Поиск" на вкладке "Мои задачи" */
  myTasksTableSearchButton: 'my-tasks-table_search-button',
  /** id поля "Тип документа" */
  documentTypengSelect: 'document-type-ng-select',
  /** id действия 'Отказаться от оформления' (из статуса "Согласовано")' */
  transitionsApprovedToClientRefuse: 'ai-transitions-relations-control-Approved_to_ClientRefuse',
  /**Артериальное давление (последнее измерение, нижнее, мм. рт. ст.) */
  bloodPressureLowInput: 'blood-pressure-low-input',
  /** id поля "Вес в кг" */
  ipWeightInput: 'ip-weight-input',
  /** id кнопки 'Отправить уведомление' */
  buttonOnlinepayment: 'ai-button-online-payment',
  /** id секции 'Содержание вложений' */
  attachmentContentSection: 'attachment-content-section',
  /** id секции 'Адрес' */
  vtbAddressInformationAddressData: 'VtbAddressInformation-addressData',
  /** id кнопки 'Отменить' в секции 'История переходов права собственности' */
  ownershipHistoryTableCancelButton: 'ownership-history-table-cancel-button',
  /** id таблицы 'История переходов права собственности' */
  ownershipHistoryTable: 'ownership-history-table',
  /** id секции 'Страховая стоимость объекта' */
  insuranceValueSection: 'insurance-value-section',
  /** id поля 'Имя' ИП */
  ieFirstName: 'ie-first-name',
  /** id поля 'Фамилия' ИП */
  ieLastName: 'ie-last-name',
  /** id поля 'Отчество' ИП */
  ieMiddleName: 'ie-middle-name',
  /** id блока 'ИП' */
  individualEntrepreneur: 'individual-entrepreneur-section',
  /** id поля 'Тип контрагента' */
  partyTypeDropdown: 'party-type-dropdown-ng-select',
  /** id поля Кпрофессии */
  kProff: 'k-proff',
  /** id кнопки "Выбрать" в модальном окне */
  dialogConfirmButton: 'lookup-dialog-confirm-button',
  /** id поля "Код точки продажи" */
  salesOutletCode: 'sales-outlet-code',
  /** id поля "Наименование точки продажи банка" */
  salesOutletName: 'sales-outlet-name',
  /** id таблицы в блоке "Поиск точки продаж" */
  curatorSearchTableable: 'curator-search-table-table',
  /** id кнопки "Поиск" в окне "Поиск точки продаж" */
  curatorSearchButton: 'curator-search-button',
  /** id поля "ФИО куратора" */
  сuratorFullName: 'сurator-full-name',
  /** id кнопки "Поиск" в блоке "Куратор Банка-Кредитора" */
  creditorSearchDialogButton: 'creditor-search-dialog-button',
  /** id чекбокса "Сотрудник банка участвовал в продаже" */
  creditorBankCuratorSection: 'creditor-bank-curator-section',
  /** id блока "История переходов права собственности"*/
  ownershipHistorySection: 'ownership-history-section',
  /** id пагинатора при поиске контрагента */
  policyholderSearchTablePaginator: 'policyholder-search-table-paginator',
  /** id поля "Причина отказа" */
  cancelReasonNgSelect: 'cancel-reason-ng-select',
  /** id чекбокса Проводимые ранее или планируемые операции в связи с болезнями, травмами */
  surgeryExists: 'surgery-exists',
  /** блок заболеваний */
  psychologicalGroup: 'psychological-group',
  /** id чекбокса "Внешняя пролонгация" */
  outsideProlongation: 'outside-prolongation',
  /** класс неактивного действия */
  notPossibleTransition: 'dropdown-item ai-not-possible-transition-relation',
  /** id кнопки пагинации таблицы поиска контрагента*/
  paginatorNextPageButton: 'parti-search-table-paginator-next-page-button',
  /** url для смены роли */
  urlForChangeRole: '/server/api/configurator/shared/runtime/view/view-helper/get-initial-view-model',
  /** url для шага сохранения */
  urlForSave: '/server/api/shell/internal/documents/recent-documents/',
  /** url для действия */
  urlForAction: '/server/api/pas/internal/contracts/get-initial-view-model',
  // Вкладка Общее
  /** id combobox "Семейное положение" */
  marital_status: 'marital-status-ng-select',
  /** id combobox "Контактный телефон" */
  phone: 'selected-phone-ng-select',
  /** id combobox "Контактный e-mail" */
  email: 'selected-email-ng-select',
  /** id combobox "Категория" */
  category: 'category-ng-select',
  /** id textbox "Остаток ссудной задолженности (ОСЗ)" */
  osz_input: 'OSZ-input',
  /** id combobox "Дата выдачи кредита" */
  credit_date: 'credit-date-input',
  /** id textbox "Оставшийся срок кредита (в мес.)" */
  remaining_months: 'remaining-months-input',
  /** id combobox "Цель кредита" */
  credit_purpose: 'credit-purpose-ng-select',
  /** id combobox "Порядок определения Страховой суммы" */
  ins_sum_calc_method: 'MGEnumInsSumCalcMethod-ng-select',
  /** id textbox "Процент увеличения Страховой суммы " */
  fix_percent: 'fixPercent-input',
  /** id textbox "Текущая ставка по кредиту" */
  credit_percent: 'creditPercentage-input',
  /** id combobox "Дата начала" */
  start_date: 'start-date-input',
  /** id combobox "Дата заключения" */
  conclusion_date: 'issue-date-input',
  /** id combobox "Программа страхования" */
  insurance_program: 'insuranceProgram-ng-select',
  /** id combobox "Ипотечный партнёр" */
  mortgagePartner: 'mortgagePartner-ng-select',
  /** id combobox "Партнёрская программа" */
  partnerProgram: 'partnerProgram-ng-select',
  /** id combobox "Дата окончания" */
  end_date: 'end-date-input',
  /** id checkbox "Автоматическое определение даты окончания договора" */
  automatic_end_date_chbx: 'automatic-end-date',
  /** id button Поиск подразделения заключения */
  department_search: 'department-search-dialog-button',
  /** id textbox "Подразделение" */
  department_name: 'department-name',
  /** id button "Поиск" */
  department_search_button: 'department-search-button',
  /** id  Форма выбора подразделения */
  department_form: 'lookupDialogId',
  /** id button "Выбрать" */
  dapartment_confirm_button: 'lookup-dialog-confirm-button',
  /** id textbox "Подразделение заключения" */
  department_name_field_locator: '#department-name input.form-control',
  /** id секции в блоке "Личная информация" */
  data_section: 'ip-data-section',
  /** id чекбокса "Отказ от предоставления e-mail" */
  no_email: 'no-email',
  /** id чекбокса "Сотрудник группы ВТБ" */
  vtb_group_person: 'vtb-group-person',
  /** id поля "Тип выгодоприобретателя" */
  beneficiaryType: 'beneficiary-type-ng-select',
  /** id поля "Наименование" */
  beneficiaryName: 'beneficiary-name',
  /** id поля "ФИО инициатора " */
  currentUserName: 'current-user-name',
  /** id поля "Филиал заключения" */
  currentUserBranch: 'current-user-branch',
  /** id поля "Продукт " */
  insProduct: 'insProduct',
  /** id поля "Правила страхования" */
  insRule: 'insRule',
  /** id первой строки окна "Поиск подразделения"*/
  departmentSearchTableRow: 'department-search-table-row-0',
  /** id диалогового окна*/
  confirmationDialogId: 'confirmationDialogId',
  /** id поля "Гражданство"*/
  regCountryDescription: 'reg-country-description',
  /** id хедера документа*/
  headerDocument: 'header-document',
  /** id поля "Поиск контрагента в системах"  */
  systemSelectionDropdownNgSelect: 'system-selection-dropdown-ng-select',
  /** id поля "Фамилия"  */
  partyLastName: 'party-last-name',
  /** id поля "Имя"  */
  partyFirstName: 'party-first-name',
  /** id поля "Отчество"  */
  partyMiddleName: 'party-middle-name',
  /** id вкладки "Общее" */
  general_tab: 'General infromation-nav',
  /** id вкладки "Застрахованные" */
  persons_tab: 'Insured persons-nav',
  /** id вкладки "Застрахованное имущество" */
  property_tab: 'Insured property-nav',
  /** id вкладки "Посредники" */
  partners_tab: 'Partners-nav',
  /** id вкладки "Андеррайтинг" */
  underwriting_tab: 'tab-underwriting-overview-nav',
  /** id вкладки "Расчет тарифов и премии" */
  tariff_calculation_tab: 'tab-Tariff-calculation-overview-nav',
  /** id вкладки "Комментарии" */
  comments_tab: 'tab-Comments-nav',
  /** id вкладки "Вложения" */
  attachedDocuments_tab: 'tab-Attached-documents-nav',
  /** id вкладки "История" */
  history_tab: 'tab-Contract-activity and transition history-nav',
  /** id вкладки  */
  tab_group_tasks: 'tab-Group-tasks-nav',
  /** id пагинатора при поиске контрагента */
  policyholderSearchTablePaginatorNextPageButton: 'policyholder-search-table-paginator-next-page-button',
  /** id таблицы контрагентов*/
  policyholderSearchTable: 'policyholder-search-table',
  /** id номера документа */
  aiInfoControl: 'ai-info-control',
  /** id выпадающего списка хедера */
  headerUserDropdownMenu: 'header-user-dropdown-menu',
  /** id кнопки "Вход" */
  enterButton: 'enter-button',
  /** id чекбокса "Внешний сотрудник (по логину/паролю)" */
  loginTypeAdinsure: 'login-type-adinsure',
  /** id поля "Имя пользователя" */
  username: 'Username',
  /** id поля "Пароль" */
  password: 'Password',
  /** id кнопки "Войти" */
  loginButton: 'login-button',
  /** id поля "Группа" */
  userGroupsSelectNgSelect: 'userGroupsSelect-ng-select',
  /** id кнопки "Поиск" в витрине задач */
  groupTasksTableSearchButton: 'group-tasks-table_search-button',
  /** id кнопки "Назначить задачу на себя" в витрине задач */
  groupTasksTableAssignActivityButton: 'group-tasks-table_assign-activity-button',
  /** id ссылки номера документа */
  groupTasksTableDocNumberLink: 'group-tasks-table_doc-number-link',
  /** id кнопки "Поиск документов" */
  contractSearchButton: 'contract-search-button',
  /** id ссылки номера документа */
  contractSearchTableDocNumberLink: 'contract-search-table_doc-number-link',
  /** id кнопки "Печать" */
  printouts_control: 'ai-printouts-control',
  /** id ПФ  "Анкета "Лёгкие"" */
  printouts_VTBblankLungs: 'ai-printouts-control-VTBblankLungs',
  /** id ПФ  " План "МЕДО" " */
  printouts_VTBMedo: 'ai-printouts-control-VTBMedo',
  /** id ПФ  " Анкета "Астма" " */
  printouts_VTBblankAsthma: 'ai-printouts-control-VTBblankAsthma',
  /** id ПФ  " Анкета "Давление" " */
  printouts_VTBblankBloodPressure: 'ai-printouts-control-VTBblankBloodPressure',
  /** id ПФ  " Анкета "Гастро" " */
  printouts_VTBblankGastro: 'ai-printouts-control-VTBblankGastro',
  /** id ПФ  " Письмо-Заключение " */
  printouts_VTBLetterOfConclusion: 'ai-printouts-control-VTBLetterOfConclusion',
  /** id ПФ  " Лист согласования " */
  printoutsControlVtbApprovalSheet: 'ai-printouts-control-VTBApprovalSheet',
  /** id ПФ  " Заявление комплексного ипотечного страхования (PDF) " */
  printouts_VtbApplicationPrintoutPDF: 'ai-printouts-control-VtbApplicationPrintoutPDF',
  /** id ПФ  " Ключевой информационный документ (ИС/ТИТ) " */
  printoutsControlVTBKeyInformationPaperProperty: 'ai-printouts-control-VTBKeyInformationPaperProperty',
  /** id блока "Основная информация" */
  general_information_section: 'general-information-section',
  /** id блока "Титульное страхование" */
  ownership_loss_section: 'ownership-loss-section',
  /** id выпадающего списка "Тип контрагента" */
  party_type: 'party-type-ng-select',
  /** id поля "Фамилия" блока "Поиск контрагентов по параметрам" */
  last_name: 'last-name',
  /** id поля "Имя" блока "Поиск контрагентов по параметрам" */
  first_name: 'first-name',
  /** id поля "Отчество" блока "Поиск контрагентов по параметрам"*/
  middle_name: 'middle-name',
  /** id кнопки "Поиск" блока "Поиск контрагентов по параметрам"*/
  party_search_button: 'DetailedPartySearchView_SearchButton',
  /** id вкладки "ПРОВЕРКИ И ОШИБКИ"*/
  notifications_nav: 'Notifications-nav',
  /** id списка "ПРОВЕРКИ И ОШИБКИ"*/
  validations: 'RequiredPropertiesValidations',
  /** id кнопки "Добавить" раздела "Собственник имущества"*/
  owners_add_button: 'owners-table-add-button',
  /** id кнопки "ОК" раздела "Собственник имущества"*/
  owners_ok_button: 'owners-table-ok-button',
  /** id кнопки "Добваить" раздела "История переходов права собственности"*/
  ownership_history_add_button: 'ownership-history-table-add-button',
  /** id кнопки "ОК" раздела "История переходов права собственности"*/
  ownership_ok_button: 'ownership-history-table-ok-button',
  /** id таблицы "История переходов права собственности"*/
  ownership_history_table: 'ownership-history-table-table',
  /** id раздела "Источники повышенной пожарной опасности"*/
  fire_source_section: 'fire-source-section',
  /** id раздела "Внешние стены"*/
  wall_section: 'wall-section',
  /** id раздела "Межэтажные перекрытия"*/
  deck_section: 'deck-section',
  /** id раздела "Пожарная безопасность"*/
  fire_protection_section: 'fire-protection-section',
  /** id раздела "Охранная безопасность"*/
  security_systems_section: 'security-systems-section',
  /** id чекбокса "СМС-Уведомления для ЗЛ"*/
  sms_messages: 'ip-sms-messages',
  /** id чекбокса "Обработка персональных данных"*/
  processing_personal_data: 'processing-personal-data',
  /** id блока "Тарификация" ИС*/
  tariffication_section: 'tariffication-section',
  /** id блока "Имущественное страхование" */
  propertyInformationSection: 'property-information-section',
  /** id секция "Проводилась ли перепланировка объекта" */
  vtbRedevelopmentRedevelopments: 'VtbRedevelopment-redevelopments',
  /** id кнопки "Добавить" */
  addButton: '-add-button',
  /** id кнопки "Поиска" */
  dialogButton: '-dialog-button',
  /** id Таблицы */
  table: '-table',
  /** id кнопки Ок */
  okButton: '-ok-button',
  /** id первой строки */
  row0: '-row-0',
  /** id раздела Кумуляция */
  cumulationSection: 'cumulation-section',
  /** id блока с разделом Кумуляция */
  vtbActiveInsurancePactiveInsuranceExists: 'VtbActiveInsurance-pactiveInsuranceExists',
  /** id поля "Наличие обременения имущества"*/
  encumbrancesSection: 'encumbrances-section',
  /** id поля "Наименование"*/
  organisationName: 'organisation-name',
  /** id поля "ИНН"*/
  inn: 'inn',
  /** id поля "КПП"*/
  kpp: 'kpp',
  /** id кнопки пагинатора*/
  partiSearchTablePaginator: 'parti-search-table-paginator',
  /** id кнопки количества страниц*/
  pageSizes: 'page-sizes',
  /** id таблицы Собственник имущества*/
  ownersTable: 'owners-table',
  /** id поля "Адрес"*/
  AddressAutocompleteNgSelect: 'AddressAutocomplete-ng-select',
  /** id кнопки "Стандартизация"*/
  standardizeButton: 'standardize-button',
  /** id первой строки таблицы "Собственники недвижимого имущества за последние 12 месяцев"*/
  ownersTableRowFirst: 'owners-table-row-0',
  /** id первой строки поиска контрагентов*/
  partiSearchTableRow: 'parti-search-table-row-0',
  /** id кнопки Поиска*/
  phLookupButton: 'phLookupButton',
  /** id ссылки на Контрагента*/
  name_link: 'ip-name-link',
  /** id поля Дата рождения*/
  birth_date: 'ip-birth-date-input',
  /** id поля Возраст*/
  age: 'ip-age-input',
  /** id поля Дополнительная информация*/
  disease_addition: 'disease-addition',
  /** id поля Гражданство*/
  citizenship: 'citizenship-ng-select',
  /** id поля Гражданство*/
  beneficiary: 'beneficiary-name-link',
  /** id поля Контактный телефон*/
  selected_phone: 'selected-phone',
  /** id поля Контактный e-mail*/
  selected_email: 'selected-email',
  /** id поля Процент участия застрахованного в кредите */
  percentage_participation: 'percentage-participation-input',
  /** id чекбокса Требуется андеррайтинг */
  uw_needed: 'uw-needed',
  /** id поля Причина направления на андеррайтинг */
  uw_reason: 'uw-reason',
  /** id поля Дата начала */
  life_start_date: 'life-start-date-input',
  /** id поля Дата окончания */
  life_end_date: 'life-end-date-input',
  /** id поля Кпрод1 */
  ip_ksales: 'ip-ksales-input',
  /** id поля Кпрод2 */
  sales_coefficient2: 'sales-coefficient2-input',
  /** id поля Настоящее место работы */
  type_employment: 'type-employment',
  /** id поля Наименование организации */
  organization: 'organization',
  /** id поля Должностные обязанности */
  profession_skills: 'profession-skills',
  /** id кнопки поиск профессии */
  profession_search_button: 'profession-search-dialog-button',
  /** id поля Отрасль */
  profession_industry: 'profession-industry',
  /** id поля Профессия*/
  profession_name: 'profession-name',
  /** id кнопки Поиск*/
  search_profession_button: 'search-profession-button',
  /** id поля Отрасль деятельности */
  ip_profession_industry: 'ip-profession-industry',
  /** id поля Занимаемая должность */
  ip_profession_name: 'ip-profession-name',
  /** id поля Рост в см */
  height: 'ip-height',
  /** id поля Вес в кг */
  weight: 'ip-weight',
  /** id поля Артериальное давление верхнее*/
  blood_pressure_up: 'blood-pressure-up',
  /** id поля Артериальное давление нижнее*/
  blood_pressure_low: 'blood-pressure-low',
  /** id чекбокса Изменился ли Ваш вес более чем на 4 кг за последний год*/
  weight_change: 'weight-change',
  /** id поля Причина изменения веса */
  weight_change_description: 'weight-change-description',
  /** id чекбокса Изменялось ли Ваше артериальное давление */
  pressure_change: 'pressure-change',
  /** id поля Причина изменения давления */
  pressure_change_reason: 'pressure-change-reason',
  /** id группы полей в блоке Медицинская информация*/
  medication_group: 'medication-group',
  /** id группы полей Инвалидность в блоке Медицинская информация*/
  disability_group: 'disability-group',
  /** id секции Заболевания*/
  disease_section: 'disease-section',
  /** id чекбокса "Занимается спортом"*/
  do_sports: 'do-sports',
  /** id блока "Занимается спортом"*/
  sports_table: 'ip-sports-table',
  /** id кнопки "Добавить"*/
  sports_table_add_button: 'ip-sports-table-add-button',
  /** id кнопки "Поиск спорта"*/
  sport_search_button: 'sport-search-table-dialog-button',
  /** id поля "Спорт"*/
  sports_name: 'sports-name',
  /** id кнопки "Поиск"*/
  search_sports_button: 'search-sports-button',
  /** id кнопки "Выбрать"*/
  dialog_confirm_button: 'lookup-dialog-confirm-button',
  /** id поля "Занятия спортом"*/
  sport_name: 'sport-name',
  /** id поля "Вид спорта или хобби"*/
  other_sport_name: 'other-sport-name',
  /** id чекбокса "Более 3-х раз в год"*/
  sport_frequency_3times: 'sport-frequency-3times',
  /** id кнопки "Ок" */
  sports_table_ok_button: 'ip-sports-table-ok-button',
  /** id строки таблицы "Занятия спортом" */
  sports_table_row: 'ip-sports-table-row-0',
  /** id чекбокса "Курите ли Вы" */
  smoking_chbx: 'smoking',
  /** id поля "Количество сигарет в день (шт.)" */
  cigarettes_day: 'cigarettes-day-input',
  /** id поля "Стаж курения (лет)" */
  smoking_years: 'smoking-years-input',
  /** id чекбокса "Употребление алкоголя" */
  alcohol: 'alcohol',
  /** id коэфициента Заболевания*/
  disease_coefficient: 'disease-coefficient-input',
  /** id таблицы "Заболевания"*/
  disease_table: 'disease-table',
  /** id таблицы "Заболевания"*/
  disease_add_button: 'disease-table-add-button',
  /** id кнопки поска Заболевания*/
  disease_search_button: 'disease-search-dialog-button',
  /** id  диалогового окна*/
  lookup_dialog: 'lookupDialogId',
  /** id поля "Группа заболеваний"*/
  disease_group_name: 'disease-group-name',
  /** id поля "Заболевание"*/
  disease_name: 'disease-name',
  /** id таблицы в окне "Заболевания"*/
  disease_data_table: 'disease-data-table',
  /** id кнопки "Выбрать" заболевание*/
  dis_confirm_button: 'lookup-dialog-confirm-button',
  /** id кнопки "Ок" в разделе "Заболевания"*/
  disease_ok_button: 'disease-table-ok-button',
  /** id поля "Текущий год" */
  current_year: 'income-current-year',
  /** id поля "Сумма" */
  current_year_sum: 'income-current-sum-input',
  /** id поля "Прошлый год" */
  last_year: 'income-last-year',
  /** id поля "Сумма" */
  last_year_sum: 'income-last-sum-input',
  /** id поля "Позапрошлый год" */
  blast_year: 'income-blast-year',
  /** id поля "Сумма" */
  blast_year_sum: 'income-blast-sum-input',
  /** id поля "Укажите размер Вашего годового дохода от собственной профессиональной деятельности:" */
  income_proffesion_year: 'income-proffesion-year-input',
  /** id поля "Укажите размер Вашего годового дохода от дополнительных источников дохода (инвестиции, банковские вклады или иные источники дохода)" */
  income_other_year: 'income-other-year-input',
  /** id поля "Оцените размер разницы между имеющимися у Вас активами (недвижимость, средства на банковских счетах и пр.) и принятыми обязательствами (займы, кредиты и пр.)" */
  leverige_input: 'leverige-input',
  /** id блока "Личная информация" */
  ip_general: 'ip-general',
  /** id поля "Канд1" */
  underwriting_coefficient1: 'underwriting-coefficient1-input',
  /** id поля "Канд2" */
  underwriting_coefficient2: 'underwriting-coefficient2-input',
  /** id блока "Информация о страховой истории" */
  insuranceHistorySection: 'insurance-history-section',
  /** id кнопки "Добавить" */
  activeInsuranceTableAddButton: 'active-insurance-table-add-button',
  /** id таблицы "Информация о страховой истории" */
  activeInsuranceTable: 'active-insurance-table',
  /** id кнопки "Ок" таблицы "Информация о страховой истории" */
  activeInsuranceTableOkButton: 'active-insurance-table-ok-button',
  /** id таблицы в таблице "Информация о страховой истории" */
  activeInsuranceTableTable: 'active-insurance-table-table',
  /** id первой строки в таблице "Информация о страховой истории" */
  activeInsuranceTableRow: 'active-insurance-table-row-0',
  /** id раздела "Было ли ранее отказано в заключении договора страхования по рискам жизни, здоровья и/или трудоспособности" */
  denialInsurance: 'denial-insurance',
  /** id раздела "Наличие полисов добровольного медицинского страхования (ДМС), заключенных с АО «СОГАЗ»" */
  denialInsuranceReason: 'denial-insurance-reason',
  /** id поля "Описание" */
  hasDescription: 'has-description',
  /** id чекбокса "Наличие полисов добровольного медицинского страхования (ДМС), заключенных с АО «СОГАЗ»" */
  hasDms: 'has-dms',
  /** id блока "Тарификация" */
  ipTariffication: 'ip-tariffication',
  /** id блока "Список застрахованных" */
  insuredPersonsList: 'insured-persons-list',
  /** id первой строки поиска профессии */
  professionIndustryRow: 'ip-profession-industry-row-0',
  /** id таблицы "Андертриггеры и Стопфакторы" */
  triggers_section: 'triggers-section',
  /** id блока "Триггеры" */
  constraintsSection: 'constraints-section',
  /** id таблицы "Триггеры" */
  dataGridTable: 'ai-data-grid-table',
  /** id строки в таблице "Триггеры" */
  dataGridRow: 'ai-data-grid-row-',
  /** id поля "Акция" */
  marketingCampaignSelect: 'marketing-campaign-ng-select',
  /** id поля "Порядок оплаты" */
  paymentFrequencySelect: 'payment-frequency-ng-select',
  /** id кнопки "Добавить" */
  comments_add_button: 'comments-section-add-button',
  /** id поля "Комментарии" */
  comments_text_area: 'comments-text-area',
  /** id кнопки "Ок" */
  comments_ok_button: 'comments-section-ok-button',
  /** id строки Комментария */
  comments_row: 'comments-section-row-',
  /** id блока первой таблицы */
  attachmentsTable: 'attachments-table',
  /** id таблицы Вложения */
  attachmentsTableTable: 'attachments-table-table',
  /** id строки таблицы вложений */
  attachmentsTableRow: 'attachments-table-row-',
  /** id кнопки Добавить */
  attachmentsTableAddButton: 'attachments-table-add-button',
  /** id поля "Тип вложения" */
  attachmentTypeSelect: 'attachment-type-ng-select',
  /** id таблицы "Тип документа" */
  vtbAttachmentTable: 'vtb-attachment-table',
  /** id кнопки "Добавить" раздела "Тип документа" */
  vtbAttachmentTableAddButton: 'vtb-attachment-table-add-button',
  /** id кнопки поиска раздела "Тип документа" */
  attachmentSearchDialogButton: 'attachment-search-dialog-button',
  /** id кнопки ОК раздела "Тип документа" */
  vtbAttachmentTableOkButton: 'vtb-attachment-table-ok-button',
  /** id таблицы "Тип документа" */
  vtbAttachmentTableTable: 'vtb-attachment-table-table',
  /** id первой строки таблицы "Тип документа" */
  vtbAttachmentTableRow0: 'vtb-attachment-table-row-0',
  /** id второй строки таблицы "Тип документа" */
  vtbAttachmentTableRow1: 'vtb-attachment-table-row-1',
  /** id строки таблицы "ИСТОРИЯ ИЗМЕНЕНИЯ СТАТУСОВ ДОКУМЕНТА" */
  transition_history_table_row: 'transition-history-table-row-',
  /** id строки таблицы "ИСТОРИЯ СОГЛАСОВАНИЯ ДОКУМЕНТА" */
  activity_history_table_row: 'activity-history-table-row-',
  /** id блока Посредники */
  vtb_agents_block: 'VtbAgents-#',
  /** id обеих таблиц Посредников */
  table_partners: '-table',
  /** id строк в таблицах Посредников */
  row_partners: '-row-',
  /** id кнопки "Роль" */
  role_button: 'ai-actor-selection-control',
  /** id роли "Продавец" */
  sales_manager_role: 'ai-actor-selection-control-Agent',
  /** id роли "Андеррайтер" */
  underwriter_role: 'ai-actor-selection-control-Underwriter',
  /** id роли "Перестрахование" */
  reinsurance_role: 'ai-actor-selection-control-Reinsurance',
  /** id роли "Продавец 2 уровня" */
  sales_manager_two: 'ai-actor-selection-control-SalesManager',
  /** id роли "СБ" */
  security_role: 'ai-actor-selection-control-KZ',
  /** id кнопки "Действия" */
  actions: 'ai-transitions-relations-control',
  /** id действия "Взять в работу андеррайтером" */
  take_underwriting_action: 'ai-transitions-relations-control-WaitingForUnderwriting_to_Underwriting',
  /** id действия "Продолжить согласование" */
  continue_approval_action: 'ai-transitions-relations-control-ContinueApprovalProcess',
  /** id действия "Продолжить оформление" */
  control_draft_to_for_approval: 'ai-transitions-relations-control-Draft_to_ForApproval',
  /** id действия "Выпустить котировку" */
  release_quote_action: 'ai-transitions-relations-control-VtbCreatePolicyFromQuote',
  /** id действия "Отправить продаву 2го уровня" */
  transitions_draft_to_sales2: 'ai-transitions-relations-control-Draft_to_WaitingForSales2',
  /** id действия "Взять в работу" продавцом 2го уровня */
  take_sales2_action: 'ai-transitions-relations-control-WaitingForSales2_to_SalesLevel2',
  /** id действия "Направить на согласование Андеррайтеру ГО" */
  waiting_underwriting_action: 'ai-transitions-relations-control-Draft_to_WaitingForUnderwriting',
  /** id действия "Продолжть оформление" продавцом 2го уровня */
  sales_continue_approval_action: 'ai-transitions-relations-control-SalesContinueApproval',
  /** id действия "Отказаться от оформления" */
  transitions_to_cancelled: 'ai-transitions-relations-control-Draft_to_Cancelled',
  /** id действия "Отказаться от оформления" после Андеррайтинга */
  transitionsToCancelledAfterUnderwriting: 'ai-transitions-relations-control-Draft_to_ClientRefuse',
  /** id действия "Отказаться от оформления" после Андеррайтинга (Согласовано при условии)*/
  transitionsApprovedWithCommentsToClientRefuse:
    'ai-transitions-relations-control-ApprovedWithComments_to_ClientRefuse',
  /** id действия "Создать Копию" */
  transitionVstbCopyQuote: 'ai-transitions-relations-control-VtbCopyQuote',
  /** id действия "Создать Копию" из несогласованной Котировки */
  transitionVstbCopyVtbCopyUnconfirmedQuote: 'ai-transitions-relations-control-VtbCopyUnconfirmedQuote',
  /** id действия "Вернуть на оформление" */
  transitionsToDraft: 'ai-transitions-relations-control-DocsRequest_to_Draft',
  /** id действия "Вернуть на оформление" после Андеррайтера */
  transitionsToDraftAfterUnderwriting: 'ai-transitions-relations-control-Underwriting_to_Draft',
  /** id статуса документа */
  document_status: 'header-document-state',
  /** id кнопки "Выбрать" статус триггера */
  select_trigger_status_btn: 'update-constraints-button',
  /** id раздела меню "Страховые продукты" */
  contractsMenu: 'Contracts_menu_1',
  /** id подраздела меню "Ипотека ВТБ" */
  mortgageVtb: 'MortgageVTB_1_2',
  /** id подраздела меню "Котировка ВТБ" */
  mgVtbQuote: 'MGvtbQuote_1_3',
  /** id поля "перейти к документу" */
  navbarRedirectByNumber: 'navbar-redirect-by-number',
  /** id раздела "Витрина задач" */
  workflow12: 'Workflow_1_2',
  /** id строки в таблице */
  row: '-row-',
  /** id подраздела меню "Поиск Документов" */
  ContractSearchByCurrentUserBranch: 'ContractSearchByCurrentUserBranch_1_2',
  /** id кнопки "Поиск Документов" */
  searchContractButton: 'search-contract-button',
  /** id блока "Поиск Документов" */
  contractSearchArea: 'contract-search-area',
  /** id пагинатора поиска профессии */
  professionIndustryPaginator: 'ip-profession-industry-paginator',
  /** id таблицы профессии*/
  professionIndustryTable: 'ip-profession-industry-table',
  /** id кнопки поиска КА*/
  selectIpButton: 'select-ip-button',
  /** id поля системы поиска КА*/
  systemSelectionDropdown: 'system-selection-dropdown',
  /** id поля даты рождения КА*/
  partyBirthdayInput: 'party-birthday-input',
  /** id номера документа */
  aiInfoСontrol: 'ai-info-control',

  // было до:
  /** id текстовое поле "Реальное количество локаций по котировке" */
  atr_rqs_locations_number: 'locations-number',
  /** id combobox "Валюта" */
  сurrency: 'currency-ng-select',
  /** id combobox "Страховое покрытие" */
  сover_type: 'ins-cover-type-ng-select',
  /** id checkbox "Не применяется" */
  сover_general_deductible: 'general-deductible',
  /** id textbox "Локация" */
  location_description: 'location-name',
  /** id combobox "Адрес целиком" */
  full_address: 'AddressAutocomplete',

  /** id textbox "Наименование" */
  search_criteria: 'lookupDialogId',
  /** id textbox "Индекс" */
  postalCode: 'postal-code',
  /** id textbox "Страна" */
  country: 'country',
  /** id textbox "Регион" */
  region: 'region',
  /** id textbox "Город" */
  city: 'city',
  /** "Улица" */
  //
  /** "Дом" */
  //
  /** id блока "Отрасль" */
  industry: 'industry-section',
  /** id кнопки поиска. Форма "Виды деятельности" */
  search: 'activity-search-button',
  /** id кнопки "Выбрать". Форма "Виды деятельности" */
  select: 'lookup-dialog-confirm-button',
  /** id поля "Код риска" */
  riskCode: 'industry-risk-code',
  /** id блока "Объекты страхования" */
  insuredObjects: 'insured-objects-section',
  /** id checkbox "Имущественный комплекс" */
  objectPropertyComplex: 'object-property-complex',
  /** id textbox "Имущественный комплекс" */
  objectPropertySumInput: 'object-property-sum-input',
  /** id checkbox "Страхование оборудования от поломок (по правилам страхования машин и механизмов 065)" */
  risks_065_mb: '065mb066-risk',
  /**
   * Лимит ответственности
   */
  // machineryBreakdownRisksLimit: '065mb066-risk-limit-input',
  лимитОтветственности: '065mb066-risk-limit-input',
  /**
   * **Франшиза**
   * id textbox
   */
  франшиза: '065mb066-deductible-input',
  /**
   * **Ошибки в проектировании, конструкции и расчетах**
   * id combobox
   */
  ошибкиВПроектировании: '065mb066-errors-construction',
  /**
   * **Ошибки при изготовлении и монтаже**
   * id combobox
   */
  ошибкиПриИзготовлении: '065mb066-errors-production',
  /**
   * **Дефекты литья или использованного материала**
   * id combobox
   */
  дефектыЛитья: '065mb066-casting-defects',
  /**
   * **Непреднамеренные ошибки персонала страхователя (выгодоприобретателя) при использовании и обслуживании застрахованного имущества**
   * id combobox
   */
  непреднамеренныеОшибки: '065mb066-negligence',
  /**
   * **Энергетическая перегрузка, помпаж, перегрев, вибрация, разладка, заклинивание, засор посторонними предметами, воздействие центробежных сил**
   * id combobox
   */
  энергетическаяПерегрузка: '065mb066-overheating',
  /**
   * **Воздействие электроэнергии в виде короткого замыкания электрического тока, перегрузка электросети, падение напряжения, атмосферный разряд (кроме удара молнии) и прочие подобные явления (включая возгорание, если ущерб причинен непосредственно тем предметам, в которых возникло возгорание)**
   * id combobox
   */
  воздействиеЭлектроэнергии: '065mb066-circuit',
  /**
   * **Гидравлический удар или недостаток жидкости в котлах, парогенераторах, других аппаратах, действующих с помощью пара или жидкости**
   * id combobox
   */
  гидравлическийУдар: '065mb066-hydraulic-shock',
  /**
   * **Взрыв паровых котлов (разрыв или деформация стенок котла вследствие расширения газа или пара), двигателей внутреннего сгорания, других источников энергии**
   * id combobox
   */
  взрывПаровыхКотлов: '065mb066-explosion-boilers',
  /**
   * **Действие низких температур**
   * id combobox
   */
  действиеНизкихТемператур: '065mb066-low-temperature',
  /**
   * **Разрыв тросов и цепей, падение застрахованных предметов, удар их о другие предметы**
   * id combobox
   */
  разрывТросов: '065mb066-breakage-wires',
  /** id вкладки "Общая информация" */
  tabGeneralInformation: 'tab-General-information-nav',
  /**
   * Блок "Срок страхования & история страхования"
   * id поля "Дата начала"
   */
  insuranceStart: 'insurance-start-input',
  /**
   * Блок "Срок страхования & история страхования"
   * id поля "Дата окончания"
   */
  insuranceEnd: 'insurance-end-input',
  /**
   * Блок "Срок страхования & история страхования" <br>
   * id combobox "История страхования"
   */
  insuranceHistory: 'claims-5years',
  /**
   * Блок "Срок страхования & история страхования"
   * id поля "Скрок действия"
   */
  insuranceDuration: 'insurance-duration',
}

const policyMGVTB = {
  /** id ПФ "Согласие на обработку ПД" */
  printoutsControlVtbPersonalDataConsent: 'ai-printouts-control-VtbPersonalDataConsent',
  /** id ПФ "Согласие на обработку спец категории ПД" */
  printoutsControlVtbPersonalDataSpecialCategoriesConsent:
    'ai-printouts-control-VtbPersonalDataSpecialCategoriesConsent',
  /** id ПФ "Согласие на получение сведений о состоянии здоровья" */
  printoutsControlVtbMedicalDataConsent: 'ai-printouts-control-VtbMedicalDataConsent',
  /** id ПФ " Ключевой информационный документ (ЛС) " */
  printoutsControlVTBKeyInformationPaperPerson: 'ai-printouts-control-VTBKeyInformationPaperPerson',
  /** id первой таблицы */
  attachmentsTableTable: 'attachments-table-table',
  /** id строки в таблице "СПИСОК ПЛАТЕЖЕЙ ПО КРЕДИТНОМУ ДОГОВОРУ" */
  graphRow0: 'graph-row-0',
  /** id таблицы "СПИСОК ПЛАТЕЖЕЙ ПО КРЕДИТНОМУ ДОГОВОРУ" */
  graph: 'graph',
  /** id поля Аннуитет */
  annuityAmount: 'annuity-amount',
  /** id ПФ  " Ключевой информационный документ (ИС/ТИТ) " */
  printoutsControlVTBKeyInformationPaperProperty: 'ai-printouts-control-VTBKeyInformationPaperProperty',
  /** url для шага сохранения */
  urlForSave: '/server/api/shell/internal/documents/recent-documents/',
  /** id вкладки "Договор" */
  policy_tab: 'tab-Policy-nav',
  /** id вкладки "История" */
  history_tab: 'tab-Contract-activity-and-transition-history-nav',
  /** id действия "Оформить договор" */
  draft_to_signing_action: 'ai-transitions-relations-control-Draft_to_Signing',
  /** id действия "Подписать договор" */
  to_signed: 'ai-transitions-relations-control-Signing_to_Signed',
  /** id вкладки "График платежей" */
  payment_plan_tab: 'tab-Payment-plan-nav',
  /** id вкладки "График тарифов" */
  premium_graph_tab: 'tab-premium-graph-nav',
  /** id вкладки "Общее" */
  general_tab: 'General infromation-nav',
  /** id вкладки "Застрахованные" */
  persons_tab: 'Insured persons-nav',
  /** id вкладки "Застрахованное имущество" */
  insuredPropertyNav: 'Insured property-nav',
  /** id поля "Дата заключения кредита" */
  credit_document_number: 'credit-document-number',
  /** id поля "Номер кредитного договора" */
  credit_conclusion_date: 'credit-conclusion-date-input',
  /** id поля "День платежа по кредиту" */
  day_of_pay: 'period-pay-input',
  /** id поля "Дата окончания кредита" */
  credit_end_date: 'credit-end-date-input',
  /** id поля "Аннуитет " */
  annuity_amount: 'annuity-amount-input',
  /** id поля "Остаток ссудной задолженности" */
  osz_input_polisy: 'osz-input',
  /** id combobox "Дата выдачи кредита" */
  credit_date: 'credit-date-input',
  /** id textbox "Оставшийся срок кредита (в мес.)" */
  remaining_months: 'remaining-months-input',
  /** id textbox "Текущая ставка по кредиту" */
  credit_percent: 'creditPercentage-input',
  /** id combobox "Цель кредита" */
  credit_purpose: 'credit-purpose-ng-select',
  /** id combobox "Порядок оплаты" */
  payment_frequency: 'payment-frequency-ng-select',
  /** locator поля "Сумма документа" */
  policy_premium_locator: '#policy-premium input',
  /** id combobox "Способ оплаты" */
  payment_method: 'payment-method-ng-select',
  /** id поля "ФИО" */
  payer_link: 'payer-link',
  /** id поля "E-mail плательщика" */
  email_locator: '#email input',
  /** id combobox "Способ уведомления" */
  payment_notification_method: 'payment-notification-method-ng-select',
  /** id combobox "Мобильный телефон плательщика" */
  mobile_phone_number: 'mobile-phone-number-ng-select',
  /** id combobox "Тип документа" */
  payment_document_type: 'payment-document-type-ng-select',
  /** id поля "Первый платёж премии" */
  first_installment_premium: 'first-installment-premium-input',
  /** id поля "Сумма документа" */
  policy_premium: 'policy-premium-input',
  /** id поля "Номер документа" */
  payment_document_number: 'payment-document-number',
  /** id поля "Дата документа" */
  payment_document_date: 'payment-document-date-input',
  /** id блока "График тарифов" */
  premium_graph_section: 'premium-graph-section',
  /** id раздела таблицы "График тарифов" */
  premiumGraphRiskGroupToShow: 'premiumGraphRiskGroupToShow',
  /** id таблицы "График тарифов" */
  premium_graph_risk_table: 'premiumGraphRiskGroupToShow-table',
  /** id первой строки таблицы "График тарифов" */
  premiumGraphRiskGroupToShowRow0: 'premiumGraphRiskGroupToShow-row-0',
  /** id строки "График тарифов" */
  premium_graph_risk_row: 'premiumGraphRiskGroupToShow-row-',
  /** id таблицы Первой таблицы  */
  history_table_row: 'state-history-table-row-',
  /** id заполненного поля "Дата начала договора "  */
  start_date_policy: 'startDatePolicy-input',
  /** id поля "Дата начала договора "  */
  startDatePolicy: 'startDatePolicy',
  /** id поля "Дата заключения договора "  */
  conclusionDate: 'conclusion-date',
  /** id поля "Дата окончания договора "  */
  endDatePolicyInput: 'endDatePolicy-input',
  /** id поля "Дата заключения договора"  */
  conclusion_date: 'conclusion-date-input',
  /** id чекбокса "Кредит уже выдан"  */
  credit_already_issued: 'credit-already-issued',
  /** id поля "Дата выдачи кредит"  */
  credit_date_policy: 'credit-date',
  /** id кнопки "Печать" */
  printouts_control: 'ai-printouts-control',
  /** id ПФ  "  Дубликат ПФ «Полис c логотипом и факсимиле» типа «Дубликат»  " */
  printoutsControlVtbPolicyCertificateLogoFacsimileDuplicatePrintout:
    'ai-printouts-control-VtbPolicyCertificateLogoFacsimileDuplicatePrintout',
  /** id ПФ  " Письмо-Заключение " */
  printoutsControlVTBLetterOfConclusion: 'ai-printouts-control-VTBLetterOfConclusion',
  /** id ПФ  "Форма «Полис c логотипом и факсимиле»" */
  printouts_vtb_policy_facsimile: 'ai-printouts-control-VtbPolicyCertificateLogoFacsimilePrintout',
  /** id ПФ  " Памятка получателю страховых услуг " */
  printoutsControlVTBReminderToRecipientPrintout: 'ai-printouts-control-VTBReminderToRecipientPrintout',
  /** id ПФ  "Форма «Полис c логотипом»" */
  printouts_vtb_policy: 'ai-printouts-control-VTBPolicyCertificateLogoPrintout',
  /** id ПФ  " Лист согласования " */
  printoutsControlVTBApprovalSheet: 'ai-printouts-control-VTBApprovalSheet',
  /** id ПФ  " Счет на оплату премии " */
  printoutsControlVTBInvoicePrintout: 'ai-printouts-control-VTBInvoicePrintout',
  /** id ПФ " Заявление комплексного ипотечного страхования (PDF) " */
  printouts_VtbApplicationPrintoutPDF: 'ai-printouts-control-VtbApplicationPrintoutPDF',
  /** id поля "Подписание со стороны страховщика" */
  signing_insurer_select: 'signing-insurer-ng-select',
  /** id блока "Подписание со стороны страховщика" */
  insurer_signatory_section: 'insurer-signatory-section',
  /** id блока "Список застрахованных" */
  insured_persons_list: 'insured-persons-list',
  /** id поля "ФИО" */
  insurance_signatory_name: 'insurance-signatory-name',
  /** id поля "ФИО (род. падеж)" */
  signatory_name_genitive: 'signatory-name-genitive',
  /** id блока "График платежей" */
  planOverviewSection: 'plan-overview-section',
  /** id таблицы "График платежей" */
  paymentPlanTable: 'payment-plan-table',
  /** id строки таблицы "График платежей" */
  paymentPlanTableRow: 'payment-plan-table-row-',
  /** id поля "Причина отказа" */
  cancelReason: 'cancel-reason',
  /** id вкладки "Комментарии" */
  comments_tab: 'tab-Comments-nav',
  /** id действия "Отказаться от оформления" */
  transitions_to_cancelled: 'ai-transitions-relations-control-Draft_to_Cancelled',
  /** id кнопки "Действия" */
  actions: 'ai-transitions-relations-control',
  /** id номера документа */
  aiInfoСontrol: 'ai-info-control',
  /** id сслыки на котировку на вкладке "Общая информация" */
  quoteNumberLink: 'quote-number-link',
  /** id чекбокса "Подписывается по доверенности" */
  phConfidantExists: 'ph-confidant-exists',
  /** id кнопки "Поиск" */
  confidantSearchButton: 'confidant-search-button',
  /** id поля "Поиск контрагента в системах" */
  SystemNgSelect: 'system-ng-select',
  /** id поля "Фамилия" */
  lastName: 'last-name',
  /** id поля "Имя" */
  firstName: 'first-name',
  /** id поля "Отчество" */
  middleName: 'middle-name',
  /** id кнопки "Поиск" */
  DetailedPartySearchViewSearchButton: 'DetailedPartySearchView_SearchButton',
  /** id таблицы поиска доверенного лица */
  partiSearchTable: 'parti-search-table',
  /** id поля "Дата доверенности"*/
  confidantDocDate: 'confidant-doc-date',
  /** id поля "Дата окончания доверенности"*/
  confidantEndDateInput: 'confidant-end-date-input',
  /** id поля "ФИО доверенного лица (род. падеж)"*/
  confidantNameGenitive: 'confidant-name-genitive',
  /** id поля "Номер доверенности"*/
  confidantDocNumber: 'confidant-doc-number',
  /** id кнопки "Сохранить"*/
  saveBtn: 'ai-operations-control',
  /** id combobox "Контактный телефон" */
  phone: 'selected-phone-ng-select',
  /** id выпадающего списка "Контактный телефон" */
  mobilePhoneNumber: 'mobile-phone-number',
  /** id combobox "Контактный e-mail" */
  email: 'selected-email-ng-select',
  /** id чекбокса "Отказ от предоставления e-mail" */
  noEmail: 'no-email',
  /** id поля "ФИО"*/
  fullName: 'full-name',
  /** id поля "Дата рождения"*/
  phDateBirth: 'ph-date-birth',
  /** id поля "Возраст"*/
  phAge: 'ph-age',
  /** id поля "Гражданство"*/
  regCountryDescription: 'reg-country-description',
  /** id combobox "Семейное положение" */
  maritalStatus: 'marital-status-ng-select',
  /** id чекбокс "Резидент" */
  resident: 'resident',
  /** id combobox "Категория" */
  category: 'category-ng-select',
  /** id блока "Страхователь" */
  policyholderSection: 'policyholder-section',
  /** id ссылки на Контрагента*/
  nameLink: 'ip-name-link',
  /** id вкладки "Посредники" */
  partnersTab: 'Partners-nav',
  /** id вкладки "ГПК" */
  tabCreditGraphNav: 'tab-Credit-graph-nav',
  /** класс неактивного действия */
  notPossibleTransition: 'dropdown-item ai-not-possible-transition-relation',
}

const prolongationVtb = {
  /** id вкладки "Результаты обработки" */
  tabResultNav: 'tab-result-nav',
  /** id действия "Оплачено" */
  transitionsRelationsControlPaymentWaitingToPayed: 'ai-transitions-relations-control-PaymentWaiting_to_Payed',
  /** id действия "Ожидается оплата" */
  transitionsRelationsControlPaymentToPaymentWaiting: 'ai-transitions-relations-control-Payment_to_PaymentWaiting',
  /** id блока "Платежи" */
  vtbPaymentProlongation: 'VtbPaymentProlongation-#',
  /** id вкдадки "Оплата" */
  tabPaymentNav: 'tab-payment-nav',
  /** id действия "Оплата" */
  transitionsRelationsControlDocumentReceivedToPayment: 'ai-transitions-relations-control-DocumentReceived_to_Payment',
  /** id второй строки */
  row1: '-row-1',
  /** id действия "Подготовка документов" */
  transitionsRelationsControlReceivedScenarioToPreparingDocument:
    'ai-transitions-relations-control-ReceivedScenario_to_PreparingDocument',
  /** id вкладки "Результаты обработки" */
  general: 'general',
  /** id статуса документа */
  documentStatus: 'header-document-state',
  /** id действия "Запрос сценария" */
  transitionsRelationsControlDraftToSendScenario: 'ai-transitions-relations-control-Draft_to_SendScenario',
  /** id таблицы */
  table: '-table',
  /** id поля "Контактный e-mail" */
  selectedEmailSelect: 'selected-email-ng-select',
  /** id поля "Контактный телефон" */
  selectedPhoneSelect: 'selected-phone-ng-select',
  /** id ссылки на КА таблицы поиска контрагентов*/
  phNameLink: 'ph-name-link',
  /** id таблицы поиска контрагентов*/
  policyholderSearchTable: 'policyholder-search-table-table',
  /** id кнопки "Поиск" блока "Поиск контрагентов по параметрам"*/
  partySearchButton: 'DetailedPartySearchView_SearchButton',
  /** id поля "Номер"  */
  partyDocumentNumber: 'party-document-number',
  /** id поля "Серия"  */
  partyDocumentSeries: 'party-document-series',
  /** id поля "Вид документа"  */
  partyDocumentTypeNgSelect: 'party-document-type-ng-select',
  /** id поля "Дата рождения"  */
  partyBirthday: 'party-birthday',
  /** id поля "Фамилия"  */
  partyLastName: 'party-last-name',
  /** id поля "Имя"  */
  partyFirstName: 'party-first-name',
  /** id поля "Отчество"  */
  partyMiddleName: 'party-middle-name',
  /** id поля "Поиск контрагента в системах"*/
  systemSelectionDropdownNgSelect: 'system-selection-dropdown-ng-select',
  /** id поля "Тип контрагента"*/
  partyTypeDropdown: 'party-type-dropdown',
  /** id раздела "Поиск контрагентов по параметрам"*/
  overviewHeader: 'OverviewHeader-#',
  /** id кнопки Поиска*/
  phLookupButton: 'phLookupButton',
  /** id вкладки "Страхователь" */
  tabPolicyHolderNav: 'Tab-PolicyHolder-nav',
  /** id textbox "Подразделение" */
  department_name: 'department-name',
  /** id кнопки Ок */
  okButton: '-ok-button',
  /** id диалогового окна*/
  confirmationDialogId: 'confirmationDialogId',
  /** id кнопки "Запросить ОСЗ" */
  getOszButton: 'get-osz-button',
  /** id кнопки "Выбрать" в модальном окне */
  dialogConfirmButton: 'lookup-dialog-confirm-button',
  /** id первой строки */
  row0: '-row-0',
  /** id кнопки "Поиск"  */
  mgVtbprolongationSearchButton: 'mg-vtb-prolongation-search-button',
  /** id поля "Номер договора страхования"  */
  policyNumber: 'policyNumber',
  /** id окна "Поиск Договоров"  */
  searchHeader: 'search-header',
  /** id диалогового окна  */
  lookupDialogId: 'lookupDialogId',
  /** id кнопки "Поиск Договор страхования" */
  policySearchDialogButton: 'policy-search-dialog-button',
  /** id раздела "Договор страхования" */
  vtbProlongationPoliciesPolicies: 'VtbProlongationPolicies-policies',
  /** id раздела "Пролонгация графичного портфеля" */
  MGvtbProlongation: 'MGvtbProlongation_1_4',
  /** id раздела "Договоры с графиком СС и СП" */
  MortgageProlongation1: 'MortgageProlongation_1_3',
}

const preInsuranceVerification = {
  /** id бокового меню "Проверки" */
  verificationsMenuOne: 'Verifications_menu_1',
  /** id бокового меню "Проверка контрагентов" */
  securityVerificationOneTwo: 'SecurityVerification_1_2',
  /** id бокового меню "Проверка СБ" */
  securityVerificationOneThree: 'SecurityVerification_1_3',
  /** id блока "Данные для проверки" */
  svUiSectionVerificationData: 'SvUiSectionVerificationData-#',
  /** id кнопки "Добавить" */
  svUiDataGridPersonsAddButton: 'SvUiDataGridPersons-#-add-button',
  /** id кнопки "Поиск" блока "Поиск контрагентов по параметрам"*/
  partySearchButton: 'DetailedPartySearchView_SearchButton',
  /** id таблицы поиска КА */
  partiSearchTableTable: 'parti-search-table-table',
  /** id поля "Фамилия" блока "Поиск контрагентов по параметрам" */
  lastName: 'last-name',
  /** id поля "Имя" блока "Поиск контрагентов по параметрам" */
  firstName: 'first-name',
  /** id поля "Отчество" блока "Поиск контрагентов по параметрам"*/
  middleName: 'middle-name',
  /** id поля "Поиск контрагента в системах" */
  systemNgSelect: 'system-ng-select',
  /** id блока "Проверка СБ"*/
  svUiDataGridPersons: 'SvUiDataGridPersons-#',
  /** id кнопки Ок в разделе "Проверка СБ"*/
  svUiDataGridPersonsOkButton: 'SvUiDataGridPersons-#-ok-button',
  /** id блока "Данные для проверки" */
  svUiGroupGeneralData: 'SvUiGroupGeneralData-#',
  /** id действия "Запросить" */
  transitionsRelationsControlDraftToRequest: 'ai-transitions-relations-control-Draft_to_Request',
  /** id блока Проверки СБ */
  svUiTabVerification: 'SvUiTabVerification-#',
  /** id таблицы "Контрагенты" */
  svUiDataGridPersonsTable: 'SvUiDataGridPersons-#-table',
  /** id строки в таблице "Контрагенты" */
  SvUiDataGridPersonsRow: 'SvUiDataGridPersons-#-row-',
  /** id роли "Андеррайтер" */
  underwriterRole: 'ai-actor-selection-control-Underwriter',
  /** id вкладки "Детали" */
  tabDetailsNav: 'tab-details-nav',
  /** id таблицы "Результаты проверки" */
  svUiDataGridResultsTable: 'SvUiDataGridResults-#-table',
  /** id диалогового окна*/
  confirmationDialogId: 'confirmationDialogId',
  /** id вкладки "История"*/
  tabHistoryNav: 'tab-history-nav',
  /** id страницы "История"*/
  tabHistory: 'tab-history',
  /** id таблицы "История изменения статусов документа"*/
  stateHistoryTable: 'state-history-table',
  /** id строки таблицы "История изменения статусов документа"*/
  stateHistoryTableRow: 'state-history-table-row-',
  /** id вкладки "Проверка"*/
  tabVerificationNav: 'tab-verification-nav',
  /** id кнопки пагинации таблицы поиска контрагента*/
  paginatorNextPageButton: 'parti-search-table-paginator-next-page-button',
  /** id второй строки таблицы "Результаты проверки" */
  svUiDataGridResultsRow1: 'SvUiDataGridResults-#-row-1',
  /** id третьей строки таблицы "Результаты проверки" */
  svUiDataGridResultsRow2: 'SvUiDataGridResults-#-row-2',
  /** id четвертой строки таблицы "Результаты проверки" */
  svUiDataGridResultsRow3: 'SvUiDataGridResults-#-row-3',
  /** id бокового меню "Поиск проверок СБ" */
  securityVerificationSearchViewOneThree: 'SecurityVerificationSearchView_1_3',
  /** id таблицы */
  table: '-table',
  /** id первой строки */
  row0: '-row-0',
}

export { applicationMGVTB, quoteMGVTB, policyMGVTB, prolongationVtb, preInsuranceVerification }
