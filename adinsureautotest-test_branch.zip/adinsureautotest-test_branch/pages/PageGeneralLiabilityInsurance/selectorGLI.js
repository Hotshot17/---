// @ts-check

const policyGLI = {
  /** id текстового поля "Дата документа-основания Страхователя" */
  partyDocDateInput: 'party-doc-date-input',
  /** id кнопки поиска (значок лупы) "Наименование" в блоке Страхователь */
  GLIPolicyHolderDataPolicyHolder: 'GLIPolicyHolderData-policyHolder',
  /** id combobox "Тип контрагента" в блоке Поиск контрагентов по параметрам */
  partyTypeDropdown: 'party-type-dropdown-ng-select',
  /** id текстового поля "Наименование" в блоке Поиск контрагентов по параметрам */
  partyName: 'party-name',
  /** id combobox "Канал продаж" */
  salesChannel: 'sales-channel-ng-select',
  /** id combobox "Зона ответственности" */
  salesZone: 'sales-zone-ng-select',
  /** id combobox "Профильная программа" */
  dealProgramme: 'dealProgramme-ng-select',
  /** id combobox "Филиал сделки" */
  departmentSearch: 'department-search',
  /** id combobox "Характеристики" */
  tabPolicyCharacteristics: 'tab-policy-characteristics-nav',
  /** id combobox "Укажите, поступала/отправлялась ли данная котировка ранее на согласование:" */
  policyCharacteristics: 'policy-characteristics-section',
  /** id текстового поля "Наименование" территории */
  locationName: 'location-name',
  /** id текстового поля "Адрес целиком" */
  addressAutocomplete: 'AddressAutocomplete-ng-select',
  /** id кнопки "Стандартизация" */
  standardizeSize: 'standardize-size',
  /** id блока "Отрасль" */
  industrySection: 'industry-section',
  /** id кнопки "Определить вид деятельности" */
  defineIndustryDialogButton: 'define-industry-dialog-button',
  /** id текстового поля "Наименование" в блоке Виды деятельности " */
  activityName: 'activity-name',
  /** id combobox "Объект (группа объектов недвижимости)" */
  estateObjectType: 'estateObject-type-ng-select',
  /** id combobox "Страхователь является" */
  policyHolderType: 'policyHolder-type-ng-select',
  /** id combobox "Эксплуатация здания (помещения) в т.ч. коммуникаций осуществляется" */
  buildingExploitationType: 'building-exploitation-type-ng-select',
  /** id combobox "Год постройки здания" */
  buildingYear: 'building-year',
  /** id combobox "Год последнего капитального ремонта" */
  buildingRenovationYear: 'building-renovation-year-ng-select',
  /** id combobox "- Площадь здания (помещения, занимаемого Страхователем), кв.м" */
  buildingSquare: 'building-square',
  /** id combobox "Этаж/Этажность" */
  buildingFlat: 'building-flat',
  /** id combobox "Материал стен" */
  wallMaterialType: 'wall-material-type-ng-select',
  /** id combobox "Материал перекрытий" */
  deckMaterialType: 'deck-material-type-ng-select',
  /** id combobox "Охрана имущества" */
  propertySecurity: 'property-security-ng-select',
  /** id combobox "Наличие и тип АПС (автоматическая пожарная сигнализация)" */
  fireAlarmSystem: 'fire-alarm-system-ng-select',
  /** id combobox "Наличие и тип АСПТ (автоматическая система пожаротушения)" */
  fireExtinguisherSystem: 'fire-extinguisher-system-ng-select',
  /** id combobox "Проверка предписаний пожарных служб на сайте" */
  fireDepartmentRegulations: 'fire-department-regulations-ng-select',
  /** id combobox "Тип предписаний пожарных служб" */
  fireDepartmentRegulationsType: 'fire-department-regulations-type-ng-select',
  /** id combobox "Численность штатных сотрудников" */
  employeesNumber: 'employees-number',
  /** id блока "Страховая сумма" */
  sumIinsuredSection: 'sum-insured-section',
  /** id текстового поля "Страховая сумма" */
  input: '-input',
  /** id блока "Сводная информация" */
  generalSummarySection: 'general-summary-section',
  /** id не редактируемого поля "Общая страховая сумма по договору" */
  generalSiLocation: 'general-si-location',
  /** id чекбокса "На один страховой случай" */
  oneInsuredEvent: 'one-insured-event',
  /** id текстового поля "Укажите" (появляется после активации чекбокса: На один страховой случай) */
  oneInsuredEventValueInput: 'one-insured-event-value-input',
  /** id чекбокса "На одного пострадавшего" */
  oneVictim: 'one-victim',
  /** id текстового поля "Укажите" (появляется после активации чекбокса: На одного пострадавшего) */
  oneVictimValueInput: 'one-victim-value-input',
  /** id чекбокса "Не применяется" */
  deductibleNotApplied: 'deductible-not-applied',
  /** id чекбокса "Жизнь, здоровье третьих лиц" */
  lifeOfThirdPartiesRisk: 'life-of-third-parties-risk',
  /** id combobox "Возмещается вред, причиненный" */
  harmType: 'harm-type-ng-select',
  /** id блока "Триггеры котировки" и "Триггеры договора" */
  constraintsSection: 'constraints-section',
  /** id таблиц "Триггеры котировки" и "Триггеры договора" */
  dataGridTable: 'ai-data-grid-table',
  /** id раздела "Триггеры котировки" */
  constraintsViewGLIQuote: 'ConstraintsViewGLIQuote',
  /** id таблицы */
  dataGrid: 'ai-data-grid',
  /** id combobox "Статус" в разделе Триггеры котировки */
  quoteState: 'quote-state-ng-select',
  /** id кнопки "Выбрать" в разделе Триггеры котировки */
  quoteStateButton: 'quote-state-button',
  /** id combobox "Требуется факультативное перестрахование" */
  GLIReinsuranceAttributes: 'GLIReinsuranceAttributes-reinsuranceAttributes',
  /** id combobox "Статус" в разделе Триггеры договора */
  policyState: 'policy-state-ng-select',
  /** id кнопки "Выбрать" в разделе Триггеры договора */
  policyStateButton: 'policy-state-button',
  /** id раздела "Триггеры договора" */
  constraintsViewPolicy: 'ConstraintsViewPolicy',
  /** id combobox "Дата начала" */
  insuranceStartInput: 'insurance-start-input',
  /** id combobox "Дата окончания" */
  insuranceEndInput: 'insurance-end-input',
  /** id combobox "Период предъявления требований" */
  requirementPeriod: 'requirement-period-ng-select',
  /** id combobox "История страхования" */
  insuranceHistory: 'insurance-history-ng-select',
  /** id раздела "История страхования" */
  insuranceHistorySection: 'insurance-history-section',
  /** id combobox "Уплата премии" */
  ngSelect: '-ng-select',
  /** id combobox "Сострахование" */
  GLICoinsuranceAttributes: 'GLICoinsuranceAttributes-coinsuranceAttributes',
  /** id блока "Ручные платежи" */
  manualPaymentsSection: 'manual-payments-section',
  /** id блока "График платежей" */
  paymentPlanOverviewSection: 'payment-plan-overview-section',
  /** id таблицы "График платежей" */
  paymentGraph: 'payment-graph',
  /** id пагинатора в таблице "График платежей" */
  paymentGraphPaginatorResult: 'payment-graph-paginator-result',
  /** id модального окна "Ошибка" */
  confirmationDialogId: 'confirmationDialogId',
  /** id вкладки "Общая информация" */
  tabGeneralInformation: 'tab-general-information-nav',
  /** id вкладки "Условия договора" */
  tabPolicyConditions: 'tab-policy-conditions-nav',
  /** id раздела "Условия договора" */
  GLIPolicyAttributesPolicyData: 'GLIPolicyAttributes-policyData',
  /** id кнопки поиска "Менеджер договора" */
  policyManager: 'policy-manager-search-dialog-button',
  /** id кнопки поиска "Менеджер по продажам" */
  salesManager: 'sales-manager-search-dialog-button',
  /** id кнопки поиска Страховщика */
  employeeSearchDialogButton: 'employee-search-dialog-button',
  /** id текстового поля "Документ-основание" страховщика */
  representativeDoc: 'representative-doc',
  /** id combobox "Дата документа-основания" страховщика */
  representativeDocDate: 'representative-doc-date',
  /** id текстового поля "Должность подписанта от имени Страховщика" */
  representativeRank: 'representative-rank',
  /** id combobox "Банк для указания реквизитов оплаты" */
  preambleBankInfo: 'preamble-bank-info-ng-select',
  /** id combobox "Наличие оговорки о рассмотрении споров в коммерческом арбитраже" */
  needReservation: 'need-reservation-ng-select',
  /** id вкладки "Документы и фотоматериалы" */
  tabAttachedDocuments: 'tab-Attached-documents-nav',
  /** id вкладки "Расчет тарифа и триггеры" */
  tabTariffsTriggers: 'tab-tariffs-triggers-nav',
  /** id кнопки "Направить договор на согласование" */
  transitionsDraftToForApproval: 'ai-transitions-relations-control-Draft_to_ForApproval',
  /** id страницы */
  TabLayout: 'TabLayout',
  /** id кнопки "Пересчитать триггеры" */
  transitionsForApprovalToForApproval: 'ai-transitions-relations-control-ForApproval_to_ForApproval',
  /** id кнопки поиска "Страхователя" */
  partySearch: 'party-search',
  /** id кнопки поиска в разделе Поиск контрагентов */
  partyApiSearch: 'partyapi-search',
  /** id текстового поля "Документ-основание" страхователя */
  partyDoc: 'party-doc',
  /** id текстового поля "Должность подписанта от имени Страхователя" */
  partyRank: 'party-rank',
  /** id кнопки "Подписать" */
  transitionsApprovedToSigned: 'ai-transitions-relations-control-Approved_to_Signed',
  /** id кнопки "Активировать" */
  transitionsSignedToActivated: 'ai-transitions-relations-control-Signed_to_Activated',
  /** id строки в таблицах "Триггеры котировки/ Триггеры договора" */
  dataGridRow: 'ai-data-grid-row-',
  /** id строки в таблице "График платежей" */
  paymentGraphRow: 'payment-graph-row-',
  /** id раздела меню "Страховые продукты" */
  ContractsMenu: 'Contracts_menu_1',
  /** id подраздела меню "Общегражданская ответственность" */
  GeneralLiabilityInsurance: 'GeneralLiabilityInsurance_1_2',
  /** id подраздела меню "Договор" */
  GLIPolicy: 'GLIPolicy_1_3',
  /** id номера документа */
  aiInfoControl: 'ai-info-control',
  /** id выпадающего списка хедера */
  headerUserDropdownMenu: 'header-user-dropdown-menu',
  /** id кнопки "Вход" */
  enterButton: 'enter-button',
  /** id чекбокса "Внешний сотрудник (по логину/паролю)" */
  loginTypeAdinsure: 'login-type-adinsure',
  /** id поля "Имя пользователя" */
  username: 'Username',
  /** id поля "Пароль" */
  password: 'Password',
  /** id кнопки "Войти" */
  loginButton: 'login-button',
  /** id раздела "Витрина задач" */
  workflow12: 'Workflow_1_2',
  /** id вкладки "Нераспределенные задачи" */
  tabUnassignedTasksNav: 'tab-Unassigned-tasks-nav',
  /** id combobox "Поиск контрагента в системах" */
  systemSelectionDropdown: 'system-selection-dropdown-ng-select',
  /** id кнопки "Поиск" в разделе Поиск контрагентов - по параметрам */
  detailedPartySearchView: 'DetailedPartySearchView_SearchButton',
  /** id поля "ИНН" */
  partyInn: 'party-inn',
  /** id поля "КПП" */
  partyKpp: 'party-kpp',
  /** id кнопки "Поиск" в разделе виды деятельности*/
  activitySearchButton: 'activity-search-button',
  /** id кнопки "Выбрать" в разделе виды деятельности*/
  lookupDialogConfirmButton: 'lookup-dialog-confirm-button',
  /** id блока "Индивидуальные рисковые факторы"*/
  individualRiskFactorsSection: 'individual-risk-factors-section',
  /** id поля "Код риска" в разделе Отрасль*/
  industryRiskCode: 'industry-risk-code',
  /** id кнопки "Добавить"в таблице Информация об убытках*/
  arrayAddButton: 'ai-array-add-button',
  /** id раздела "Информация об убытках" */
  claimsInformation: 'claims-information',
  /** id кнопки "ОК"в таблице Информация об убытках*/
  arrayOkButton: 'ai-array-ok-button',
  /** id поля "Срок действия"*/
  insuranceDuration: 'insurance-duration',
  /** id поля "Фамилия"*/
  lastName: 'ie-last-name',
  /** id поля "Имя"*/
  firstName: 'ie-first-name',
  /** id поля "Отчество"*/
  middleName: 'ie-middle-name',
  /** id чек-бокса "В % от страховой суммы"*/
  deducitbleInPercentage: 'deducitble-in-percentage',
  /** id скрытого поля "Значение франшизы"*/
  deducitbleInPercentageValue: 'deducitble-in-percentage-value',
  /** id кнопки поиска 'Подразделение сделки'*/
  departmentSearchButton: 'department-search-dialog-button',
  /** id поля "Подразделение"*/
  departmentName: 'department-name',
  /** id блока "Расчет премии"*/
  premiumCalculationSection: 'premium-calculation-section',
  /** id таблицы "Расчет премии"*/
  tablepremiumCalculationSection: '-table',
  /** id кнопки поиска 'Сохранить'*/
  operationsСontrolSave: 'ai-operations-control-Save',
  /** id атрибута "Общая страховая премия" в боковом меню*/
  generalPremimumSide: 'general-premimum-side',
  /** id атрибута "Общая страховая сумма" в боковом меню*/
  generalSumInsuredSide: 'general-sum-insured-side',
  /** id кнопки "Согласование условий страхования" */
  relationsControlDraftToQuoteUW: 'ai-transitions-relations-control-Draft_to_QuoteUW',
  /** id вкладки "Общая информация" в боковом меню */
  tabSummary: 'tab-Summary-nav',
  /** id таблицы "Триггеры котировки" */
  ConstraintsViewGLIQuote: 'ConstraintsViewGLIQuote',
  /** id таблицы "Триггеры договора" */
  ConstraintsViewPolicy: 'ConstraintsViewPolicy',
  /** id кнопки "Согласовать" из статуса Согласование условий страхования */
  relationsControlQuoteUW3ToQuoteApproved: 'ai-transitions-relations-control-QuoteUW3_to_QuoteApproved',
  /** id кнопки "Направить договор на согласование" из статуса Котировка.Условия согласованы */
  relationsControlQuoteApprovedtoForApproval: 'ai-transitions-relations-control-QuoteApproved_to_ForApproval',
  /** id вкладки "Задачи группы" */
  tabGroupTasksNav: 'tab-Group-tasks-nav',
  /** id поля "Дата документ-основания" страхователя */
  partyDocDate: 'party-doc-date',
  /** id вкладки "Сделка" */
  tabApplicationNav: 'tab-application-nav',
  /** id кнопки "Добавить" в блоке комментарии */
  commentsSectionAddButton: 'comments-section-add-button',
  /** id кнопки "ОК" в блоке комментарии */
  commentsSectionoOkButton: 'comments-section-ok-button',
  /** id чекбокса "Отметка о проверке Страхователя ООВК" */
  oovkCheckbox: 'ieoovk-checkbox',
  /** id поля "Комментарий по проверке ООВК" */
  oovkNote: 'oovk-note',
  /** id кнопки "Андеррайтер" */
  underwriter: 'ai-actor-selection-control-Underwriter',
  /** id кнопки "Продавец" */
  agent: 'ai-actor-selection-control-Agent',
  /** id кнопки "Корпоративная защита" */
  kzAgent: 'ai-actor-selection-control-KZ',
  /** id кнопки "Операционист" */
  operations: 'ai-actor-selection-control-Operations',
  /** id чек-бокса "Требуется отказ от суброгации в отношении конкретных ЮЛ" */
  waiverOfSubrogation: 'waiver-of-subrogation',
  /** id чек-бокса 'Укажите этих ЮЛ' */
  waiverOfSubrogationValue: 'waiver-of-subrogation-value',
  /** id чек-бокса 'Требуется внесение изменений в типовую форму договора (в том числе исключение/ изменение обязательных оговорок) или использование нетиповой формы' */
  policyUntypicalContract: 'policy-untypical-contract',
  /** id поля 'Укажите пункты договора, в которые необходимо внести изменения' */
  policyUntypicalItems: 'policy-untypical-items',
  /** id чек-бокса 'Требуется включение условий урегулирования убытков, отличных от указанных в Правилах страхования, типовой форме договора страхования либо локальных нормативных актах Общества ' */
  changingLossesСonditions: 'changing-losses-conditions',
  /** id поля 'Укажите условия договора по урегулированию убытков, в которые необходимо внести изменения' */
  changingLossesItems: 'changing-losses-items',
  /** id кнопки 'Направить договор на оформление' из статуса Котировка.Новая */
  transitionsDraftToRegistration: 'ai-transitions-relations-control-Draft_to_Registration',
  /** id кнопки 'Направить договор на согласование' из статуса Договор.На оформлении */
  transitionsRegistrationToForApproval: 'ai-transitions-relations-control-Registration_to_ForApproval',
  /** id поля 'Номер заявки в CRM' */
  applicationNumberCrm: 'application-number-crm',
  /** id блока 'Сострахование и перестрахование' */
  reinsuranceSection: 'reinsurance-section',
  /** id кнопки 'Сопровождение' */
  maintenance: 'ai-actor-selection-control-Maintenance',
  /** id вкладки 'История согласования' */
  tabContractActivityNav: 'tab-Contract-activity-nav',
  /** id кнопки 'Финансовый блок' */
  finance: 'ai-actor-selection-control-Finance',
  /** id кнопки 'Урегулирование убытков' */
  claimHandler: 'ai-actor-selection-control-ClaimHandler',
  /** id кнопки 'Юридическое управление' */
  legalDepartment: 'ai-actor-selection-control-LegalDepartment',
  /** id кнопки 'Перестрахование' */
  reinsurance: 'ai-actor-selection-control-Reinsurance',
  /** id кнопки 'Направить на принятие решений по замечаниям' из статуса Договор.Корректировка */
  transitionsForCorrectionToRemark: 'ai-transitions-relations-control-ForCorrection_to_Remark',
  /** id кнопки 'Решение принято' из статуса Договор.Принятие решения */
  transitionsRemarkToForCorrection: 'ai-transitions-relations-control-Remark_to_ForCorrection',
  /** id кнопки 'Направить договор на согласование' из статуса Договор.Корректировка */
  transitionsForCorrectionToForApproval: 'ai-transitions-relations-control-ForCorrection_to_ForApproval',
  /** id чек-бокса 'Жилой комплекс' */
  residentialComplex: 'residential-complex',
  /** id чек-бокса 'На территории и около здания имеются объекты, являющиеся опасными' */
  isDangerObjectsExist: 'is-danger-objects-exist',
  /** id чек-бокса 'Иное'в блоке Индивидуальные рисковые факторы */
  anotherObjectOnTerritory: 'another-object-on-territory',
  /** id поля 'Укажите:' если чекбокс Иное = true , в блоке Индивидуальные рисковые факторы */
  anotherObjectInformation: 'another-object-information',
  /** id чек-бокса 'Вред окружающей среде' */
  harmToEnvironmentRisk: 'harm-to-environment-risk',
  /** id чек-бокса 'Вследствие разрушения, повреждения здания, сооружения, либо части указанного здания или сооружения, нарушения требований к обеспечению безопасной эксплуатации указанного здания, сооружения' */
  dueToDestructionBuilding: 'due-to-destruction-building',
  /** id чек-бокса 'Вследствие разрушения, повреждения объекта незавершенного строительства, нарушения требований безопасности при строительстве указанного объекта' */
  dueToDestructionIncompleteBuilding: 'due-to-destruction-incomplete-building',
  /** id чек-бокса 'Расходы на защиту' */
  protectionCosts: 'protection-costs',
  /** id поля 'Страховая сумма в части расходов на защиту' */
  protectionCostsValue: 'protection-costs-value',
  /** id чек-бокса 'Расходы на проведение независимой экспертизы' */
  independentExaminationsCosts: 'independent-examinations-costs',
  /** id поля 'Лимит' если чекбокс Расходы на проведение независимой экспертизы = true */
  independentExaminationsCostsValue: 'independent-examinations-costs-value',
  /** id чек-бокса 'Судебные расходы' */
  expensesCosts: 'expenses-costs',
  /** id combobox 'Включая оплату услуг представителей' */
  expensesCostsType: 'expenses-costs-type',
  /** id поля 'Лимит' если чекбокс Судебные расходы = true */
  expensesCostsValue: 'expenses-costs-value',
  /** id чек-бокса 'Террористический акт, диверсия' */
  terrorism: 'terrorism',
  /** id поля 'Лимит' если чекбокс Террористический акт, диверсия = true */
  terrorismValue: 'terrorism-value',
  /** id блока 'По страхованию ответственности'*/
  coefficientsStandardRisksSection: 'coefficients-standard-risks-section',
  /** id таблицы 'По страхованию ответственности'*/
  coefficientsStandardRisksSectionTable: 'coefficients-standard-risks-section-table',
  /** id строки в таблице  'По страхованию ответственности'*/
  coefficientsStandardRisksSectionRow: 'coefficients-standard-risks-section-row-',
  /** id блока 'По расходам на защиту'*/
  coefficientsProtectionCostsRisksSection: 'coefficients-protection-costs-risks-section',
  /** id таблицы 'По расходам на защиту'*/
  coefficientsProtectionCostsRisksSectionTable: 'coefficients-protection-costs-risks-section-table',
  /** id строки в таблице 'По расходам на защиту'*/
  coefficientsProtectionCostsRisksSectionRow: 'coefficients-protection-costs-risks-section-row-',
  /** id чек-бокса 'Договор страхования предусматривает необходимость открытия отдельного счета в подразделениях Федерального казначейства под операции и осуществления казначейского сопровождения в рамках государственного контракта.' */
  needTreasuryCheckbox: 'need-treasury-checkbox',
  /** id папки 'Страховые продукты'*/
  Contractsmenu1: 'Contracts_menu_1',
  /** id элемента меню 'Поиск документов*/
  ContractSearchByCurrentUserBranch12: 'ContractSearchByCurrentUserBranchTemp_1_2',
  /** id блока 'Поиск документов'*/
  searchSection: 'search-section',
  /** id таблицы с документами в блоке 'Поиск документов'*/
  contractSearchTable: 'contract-search-table',
  /** id блока 'РУЧНОЙ БИЗНЕС-ЦИКЛ СОГЛАСОВАНИЯ (ДОПОЛНИТЕЛЬНО)'*/
  coerciveTriggersSection: 'coercive-triggers-section',
  /** id строки в таблице Вложений вкладка 'Документы и фотоматериалы'*/
  attachmentsTableRow: 'attachments-table-row-',
  /** id кнопки 'Направить на принятие решений по замечаниям' из статуса Договор.Согласован */
  transitionsApprovedToRemark: 'ai-transitions-relations-control-Approved_to_Remark',
  /** id кнопки 'Решение принято' из статуса Договор.Принятие решения в статус Договор.Согласован */
  transitionsRemarkToApproved: 'ai-transitions-relations-control-Remark_to_Approved',
  /** id чек-бокса 'Склад' */
  industryWarehouse: 'industry-warehouse',
  /** id combobox 'Вид товарно-материальных ценностей' */
  stocksType: 'stocks-type',
  /** id поля 'Иные товары, которые хранятся или будут храниться на складе' */
  anotherStocks: 'another-stocks',
  /** id чек-бокса 'На территории страхования имеются здания, помещения, занимаемые (суб-)арендаторами' */
  isSubtenantsExist: 'is-subtenants-exist',
  /** id поля 'Информация о других (суб-)арендаторах (площадь, вид деятельности и др.)' */
  subtenantsInformation: 'subtenants-information',
  /** id чек-бокса 'Имущество третьих лиц' */
  propertyOfThirdPartiesRisk: 'property-of-third-parties-risk',
  /** id чек-бокса 'Вред имуществу (ТМЦ) в обороте (на хранении)' */
  damageToPropertyCirculation: 'damage-to-property-circulation',
  /** id поля 'Лимит' при условии, что чек-бокс 'Вред имуществу (ТМЦ) в обороте (на хранении) = true' */
  damageToPropertyCirculationValue: 'damage-to-property-circulation-value',
  /** id кнопки Добавить в блоке Посредники */
  partnersButton: 'partners-table-add-button',
  /** id кнопки поиска Наименование посредника */
  partnersSearch: 'partners-search',
  /** id поля 'Поиск по подстроке' в блоке Поиск агентов */
  agentSearch: 'agent-search-input',
  /** id кнопки поиска в блоке Поиск агентов */
  agentSearchButton: 'agent-search-button',
  /** id кнопки Выбрать в блоке Поиск агентов */
  lookupDialogButton: 'lookup-dialog-confirm-button',
  /** id кнопки OK в блоке Посредники */
  partnersOkButton: 'partners-table-ok-button',
  /** id блока 'РАСЧЕТНЫЕ ПАРАМЕТРЫ ДОГОВОРА СТРАХОВАНИЯ'*/
  tariffCalculationParametersSection: 'tariff-calculation-parameters-section',
  /** id таблицы 'СОСТРАХОВЩИКИ (КРОМЕ СОГАЗ) в блоке СОСТРАХОВАНИЕ И ПЕРЕСТРАХОВАНИЕ */
  coinsurersTable: 'coinsurers-table',
  /** id кнопки Добавить в блоке СОСТРАХОВАНИЕ И ПЕРЕСТРАХОВАНИЕ */
  coinsurersButton: 'coinsurers-table-add-button',
  /** id combobox Тип контрагента в блоке Поиск контрагентов - по параметрам (СОСТРАХОВАНИЕ И ПЕРЕСТРАХОВАНИЕ) */
  partyTypeCoinsurens: 'party-type',
  /** id поля 'Наименование' в блоке Поиск контрагентов - по параметрам (СОСТРАХОВАНИЕ И ПЕРЕСТРАХОВАНИЕ) */
  organisationName: 'organisation-name',
  /** id поля 'ИНН' в блоке Поиск контрагентов - по параметрам (СОСТРАХОВАНИЕ И ПЕРЕСТРАХОВАНИЕ) */
  innCoinsurens: 'inn',
  /** id поля 'КПП' в блоке Поиск контрагентов - по параметрам (СОСТРАХОВАНИЕ И ПЕРЕСТРАХОВАНИЕ) */
  kppCoinsurens: 'kpp',
  /** id кнопки 'На корректировку' из статуса Согласование условий страхования ГО */
  transitionsQuoteUW3ToQuoteForCorrection: 'ai-transitions-relations-control-QuoteUW3_to_QuoteForCorrection',
  /** id чек-бокса 'Строительно-монтажные работы (все виды работ)' */
  constructionAndInstallationWork: 'construction-and-installation-work',
  /** id поля 'Лимит' при условии, что чек-бокс 'Строительно-монтажные работы (все виды работ) = true' */
  constructionAndInstallationWorkValue: 'construction-and-installation-work-value',
  /** id кнопки 'Согласование условий страхования' из статуса Котировка.Корректировка */
  transitionsQuoteForCorrectionToQuoteUW: 'ai-transitions-relations-control-QuoteForCorrection_to_QuoteUW',
  /** id кнопки 'Направить договор на оформление' из статуса Котировка. Условия согласованы */
  transitionsQuoteApprovedToRegistration: 'ai-transitions-relations-control-QuoteApproved_to_Registration',
  /** id кнопки 'Отозвать' */
  transitionsRecall: 'ai-transitions-relations-control-Recall',
  /** id чек-бокса 'Текстовая часть нетипового договора была ранее согласована Дирекцией по правовым вопросам (в том числе пролонгации)' */
  idApproved: 'ld-approved',
  /** id поля Укажите дату согласования */
  idApprovedDate: 'ld-approved-date',
  /** id поля Укажите регистрационный номер документа */
  idApprovedNumber: 'ld-approved-number',
  /** id чек-бокса 'Текстовая часть нетипового договора была ранее согласована Дирекцией по УУ' */
  isApproved: 'ls-approved',
  /** id поля Укажите дату согласования */
  isApprovedDate: 'ls-approved-date',
  /** id поля Укажите регистрационный номер документа */
  isApprovedNumber: 'ls-approved-number',
  /** id кнопки "Бухгалтер" */
  dbu: 'ai-actor-selection-control-DBU',
  /** id кнопки "Назначить задачу на себя" блок Задачи документа, вкладка Сделка */
  btnAssignActivityToMe: 'btnAssignActivityToMe',
  /** id чек-бокса 'Нежилые помещения' */
  nonResidentialPremises: 'non-residential-premises',
  /** id чек-бокса 'Автостоянка (парковка)' */
  parking: 'parking',
  /** id чек-бокса 'Конкурсная форма договора (44-ФЗ/223-ФЗ)' */
  policyUntypicalContractFZ: 'policy-untypical-contract-FZ',
  /** id блока 'ФОРМА ДОГОВОРА'*/
  policyFormSection: 'policy-form-section',
  /** id кнопки 'Направить на оформление' из статуса Котировка.Корректировка */
  transitionsQuoteForCorrectionToRegistration: 'ai-transitions-relations-control-QuoteForCorrection_to_Registration',
  /** id элемента 'Филиал' в боковой панели Общая информация*/
  branchNameSide: 'branch-name-side',
  /** id элемента 'Зона ответственности' в боковой панели Общая информация*/
  salesZoneSide: 'sales-zone-side',
  /** id элемента 'Назначение имущества' в боковой панели Общая информация*/
  riskOccupationSide: 'risk-occupation-side',
  /** id элемента 'Отрасль' в боковой панели Общая информация*/
  riskIndustrySide: 'risk-industry-side',
  /** id элемента 'Код и класс риска' в боковой панели Общая информация*/
  codeClassSide: 'code-class-side',
  /** id элемента 'Дата начала' в боковой панели Общая информация*/
  startDateSide: 'start-date-side',
  /** id элемента 'Дата окончания' в боковой панели Общая информация*/
  endDateSide: 'end-date-side',
  /** id элемента 'Страхователь' в боковой панели Общая информация*/
  policyholderSide: 'policyholder-side',
  /** id элемента 'Общая франшиза' в боковой панели Общая информация*/
  deductibleSide: 'deductible-side',
  /** id кнопки "Вернуть заявку инициатору" */
  transitionsReturnInitiator: 'ai-transitions-relations-control-Return_Initiator',
  /** id кнопки "Активировать (без интеграции)" */
  transitionsSignedToDisableIntegration: 'ai-transitions-relations-control-Signed_to_DisableIntegration',
  /** id поля "Фамилия" для физ.лица в блоке Поиск контрагентов - по параметрам */
  partyLastName: 'party-last-name',
  /** id поля "Имя" для физ.лица в блоке Поиск контрагентов - по параметрам */
  partyFirstName: 'party-first-name',
  /** id поля "Отчество" для физ.лица в блоке Поиск контрагентов - по параметрам */
  partyMiddleName: 'party-middle-name',
  /** id поля "Дата рождения" для физ.лица в блоке Поиск контрагентов - по параметрам */
  partyBirthday: 'party-birthday',
  /** id комбобокса "Дата рождения" для физ.лица в блоке Поиск контрагентов - по параметрам */
  partyGender: 'party-gender',
  /** id комбобокса "Вид документа" для физ.лица в блоке Поиск контрагентов - по параметрам */
  partyDocumentType: 'party-document-type',
  /** id поля "Серия" для физ.лица в блоке Поиск контрагентов - по параметрам */
  partyDocumentSeries: 'party-document-series',
  /** id поля "Номер" для физ.лица в блоке Поиск контрагентов - по параметрам */
  partyDocumentNumber: 'party-document-number',
  /** id кнопки "Поиск" для физ.лица в блоке Поиск контрагентов - по параметрам */
  DetailedPartySearchViewSearchButton: 'DetailedPartySearchView_SearchButton',
  /** id чек-бокса 'Моральный вред' */
  moralHarm: 'moral-harm',
  /** id поля 'Лимит', при условии, что чек-бокс моральный вред = true  */
  moralHarmValue: 'moral-harm-value',
  /** id кнопки "Поиск" (лупы) в блоке Скопировать документ на вкладке Характеристики */
  copyingPolicyButtonDialogButton: 'copying-policy-button-dialog-button',
  /** id поля "Номер документа" в блоке Скопировать документ на вкладке Характеристики */
  contractSearchArea: 'contract-search-area',
  /** id кнопки "Поиск" в всплывающем окне, в блоке Скопировать документ */
  searchContractButton: 'search-contract-button',
  /** id блока Скопировать документ */
  copyingSection: 'copying-policy-from-other-section',
  /** id блока "Связанные документы (вручную)" */
  manuallyRelatedDocumentSection: 'manually-related-documents-section',
  /** id поля "Номер документа" */
  contractSelectionSearchDocumentNumber: 'contract-selection-search-document-number',
  /** id колонка ТИП ДОКУМЕНТА таблицы "Связанные документы (вручную)" */
  manuallyRelatedDocumentTypeTable: 'manually-related-documents-type-table',
  /** id гиперссылки на связанный вручную документ */
  manuallyRelatedDocumentNumberLinkTable: 'manually-related-documents-number-link-table',
  /** id колонка СТАТУС таблицы "Связанные документы (вручную)" */
  manuallyRelatedDocumentStateTable: 'manually-related-documents-state-table',
  /** id колонка СВЯЗЬ таблицы "Связанные документы (вручную)" */
  manuallyRelatedDocumentRelationTypeTable: 'manually-related-documents-relation-type-table',
  /** id combobox 'Порядок установления СС' */
  ccProcedure: 'cc-procedure',
  /** id таблицы "Посредники" */
  partnersTable: 'partners-table',
  /** id строки в таблице "СОСТРАХОВЩИКИ (КРОМЕ СОГАЗ)" */
  partnersTableRrow: 'partners-table-row-',
  /**id строки в таблице "СОСТРАХОВЩИКИ (КРОМЕ СОГАЗ)"*/
  coinsurersTableRow: 'coinsurers-table-row-',
  /**id пагинатора в таблице "Посредники"*/
  partnersTablePaginator: 'partners-table-paginator',
  /** id кнопки "Согласовать" из статуса (Согласовании условий страхования (филиал))*/
  transitionsQuoteUW1ToQuoteApproved: 'ai-transitions-relations-control-QuoteUW1_to_QuoteApproved',
  /**id сообщения "Условия по котировке согласованы" в блоке Триггеры котировки*/
  quoteApprovedelement: 'quote-approved-element',
  /**id чек-бокса "Требуется оформление специальной доверенности"*/
  needPowerAttorney: 'need-power-attorney',
  /** id кнопки "Аннулировать" из статуса Договор.Согласован */
  transitionsApprovedToAnnulled: 'ai-transitions-relations-control-Approved_to_Annulled',
  /** id кнопки "Скопировать" */
  copyGLI: 'ai-transitions-relations-control-CopyGLI',
  /** id таблицы "Связанные документы" */
  relatedDocumentsTable: 'related-documents-table',
  /** id элемента Менеджер договора" */
  policyManagerLink: 'policy-manager-link',
  /** id элемента Менеджер по продажам" */
  salesManagerLink: 'sales-manager-link',
  /** id поля Дата начала" */
  insuranceStart: 'insurance-start',
  /** id секции Общая информация в карточке КА (ЮЛ) */
  legeneralInformationSection: 'legeneral-information-section',
  /** id чек-бокса 'Резидент' в карточке КА (ЮЛ) */
  residentCheckbox: 'resident-checkbox',
  /** id секции "Не резидента" в карточке КА, отображается при условии, что чек-бокс Резидент = false  */
  residentSection: 'resident-section',
  /** id кнопки 'Сохранить' в блоке Страхователь, в карточке КА (ЮЛ) */
  masterEntityFooter: 'MasterEntityFooter-#',
  /** id секции Общая информация в карточке КА (ИП) */
  iegeneralInformationSection: 'iegeneral-information-section',
  /** id секции Общая информация в карточке КА (ФЛ) */
  npgeneralInformationSection: 'npgeneral-information-section',
  /** id поля Индекс */
  postalCode: 'postal-code',
  /** id поля Страна */
  country: 'country',
  /** id поля Субъект РФ */
  region: 'region',
  /** id поля Город */
  city: 'city',
  /**id чек-бокса "Наличие первичных средств пожаротушения (огнетушители, пожарные щиты) в работоспособном состоянии"*/
  isBasicFireProtectionExist: 'is-basic-fire-protection-exist',
  /** id раздела меню "Рабочий стол" */
  dashboardsMenu1: 'Dashboards_menu_1',
  /** id чек-бокса Ремонтные, отделочные работы (исключая огневые) */
  repairAndFinishingWork: 'repair-and-finishing-work',
  /** id поля Лимит, отображается при условии, что чек-бокс Ремонтные, отделочные работы (исключая огневые) = true */
  repairAndFinishingWorkLimit: 'repair-and-finishing-work-limit',
  /** id чек-бокса Ретроактивный период */
  retroactivePeriod: 'retroactive-period',
  /** id поля Дата начала ретроактивного периода */
  retroactiveDate: 'retroactive-date',
  /** id чек-бокса В рублях (валюте) */
  deducitbleInCurrency: 'deducitble-in-currency',
  /** id поля Значение франшизы */
  deducitbleInCurrencyValue: 'deducitble-in-currency-value',
  /** id чек-бокса Упущенная выгода */
  lostProfit: 'lost-profit',
  /** id поля Лимит, отображается при условии, что чекбокс Упущенная выгода = true */
  listProfitValue: 'list-profit-value',
  /** id чек-бокса Перекрестная ответственность */
  crossLiability: 'cross-liability',
  /** id чек-бокса Договор страхования предусматривает необходимость открытия счета любого типа в банке, в том числе под операции в рамках государственного оборонного заказа или государственного контракта */
  needBankCheckbox: 'need-bank-checkbox',
}
export { policyGLI }
