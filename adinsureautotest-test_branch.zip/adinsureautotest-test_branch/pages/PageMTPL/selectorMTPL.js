// @ts-check

const application = {}

const quote = {
  /** id combobox Тип БСО */
  bsoType: 'bso-type-ng-select',

  /** id field VIN */
  vin: 'vin',

  /** id checbox VIN идентифицирован */
  vinIdentified: 'vin-identified',

  /** id текстовое поле Номер кузова */
  bodyNumber: 'body-number',

  /** id combobox Марка */
  make: 'make-ng-select',

  /** id combobox Модель */
  model: 'model-ng-select',

  /** id combobox Год выпуска */
  productionYear: 'production-year-ng-select',

  /** id combobox Тип ТС */
  vehicleType: 'vehicle-type-ng-select',

  /** id combobox Категория ТС */
  vehicleCategory: 'vehicle-category-ng-select',

  /** id combobox Мощность, л.с. */
  power: 'power-hp-ng-select',

  /** id field Код модификации */
  modificationCode: 'modification-code',

  /** id field Модификация */
  modificationName: 'modification-name',

  /** id field Код РСА */
  rsaCode: 'rsa-code',

  /** id field Модификация (комбобокс) */
  modificationNameComboBox: 'modification',

  /** id combobox Цель использования */
  usagePurpose: 'usage-purpose-ng-select',

  /** id combobox Лица, допущенные к управлению */
  allowedInput: 'allowed-input-ng-select',

  /** id строки в таблице Данные о лицах, допущенных к управлению */
  driversListRow: 'drivers-list-row',

  /** id field Пробег, км */
  mileage: 'mileage-input',

  /** id combobox Тип документа ТС */
  vehicleDocType: 'vehicle-doc-type-ng-select',

  /** id field Серия документа ТС */
  vehicleDocSeries: 'vehicle-doc-series',

  /** id field Номер документа ТС */
  vehicleDocNumber: 'vehicle-doc-number',

  /** id field Дата выдачи документа ТС */
  vehicleDocDate: 'vehicle-doc-date-input',

  /** id field Премия */
  calculatedPremium: 'calculated-premium-input',

  /** id field Базовый тариф */
  baseTariff: 'base-tariff-input',

  /** id field КБМ */
  kbm: 'kbm-input',

  /** id field КВС */
  kvs: 'kvs-input',

  /** id field КМ */
  km: 'km-input',

  /** id field КО */
  ko: 'ko-input',

  /** id field КП */
  kp: 'kp-input',

  /** id field КС */
  ks: 'ks-input',

  /** id field КТ */
  kt: 'kt-input',

  /** id table Таблица с триггерами */
  triggersList: 'triggers-list',

  /** id field Комментарий (для андеррайтера) */
  commentArea: 'comment-area',

  /** id table Таблица с комментариями (для андеррайтера) */
  conclusionTable: 'conclusion-table',
}

const policy = {
  /** id combobox Способ оплаты */
  paymentMethod: 'payment-method-ng-select',

  /** id field Способ оплаты */
  paymentDocumentNumber: 'payment-document-number',

  /** id field Способ оплаты */
  paymentDocumentDate: 'payment-document-date-input',
}

export { application, quote, policy }
