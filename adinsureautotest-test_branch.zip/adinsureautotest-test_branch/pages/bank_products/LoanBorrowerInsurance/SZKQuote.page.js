import { GeneralPageBankProducts } from '../generalPageBankProducts.page'
/**
 * @deprecated
 */
export class SZKQuotePage extends GeneralPageBankProducts {
  constructor(page) {
    super(page)
    this.page = page

    this.accident = page.getByTestId('Accident_1_2')
    this.quoteSzk = page.getByTestId('LBQuote_1_3')
  }
}
