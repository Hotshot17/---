import { test, expect } from '@playwright/test'
import { GeneralPageBankProducts } from '../generalPageBankProducts.page'
/**
 * @deprecated
 */
export class ZNPolicyPage extends GeneralPageBankProducts {
  constructor(page) {
    super(page)
    this.page = page

    /* ---------------------------------------------------------"Название продукта в главном меню" -------------------------------------------------- */

    this.realEstateProtection = page.getByTestId('RealEstateProtection_1_2')
    this.reProtectionPolicy = page.getByTestId('REProtectionPolicy_1_3')
    /* ---------------------------------------------------------"Действия документа" -------------------------------------------------- */
    this.draftToPaymentWaiting = page.getByTestId('ai-transitions-relations-control-Draft_to_PaymentWaiting') // действие "К оплате"
    this.draftToRejected = page.getByTestId('ai-transitions-relations-control-Draft_to_Rejected') // действие "Отказаться от оформления"

    /* ---------------------------------------------------------"Печатные формы" -------------------------------------------------- */
    this.policyOferta = page.getByTestId('ai-printouts-control-RealEstateProtectionPolicyPrintout')
    this.conditionsPrintout = page.getByTestId('ai-printouts-control-RealEstateProtectionConditionsPrintout')
    this.memoPrintout = page.getByTestId('ai-printouts-control-RealEstateProtectionMemoPrintout')
    this.kidPrintout = page.getByTestId('ai-printouts-control-RealEstateProtectionKeyInformationPaper')

    /* ---------------------------------------------------------"Вкладки" -------------------------------------------------- */
    /** Вариант коробки */
    this.tabInsurance = 'tab-Insurance-conditions-nav' // Условия страхования
    this.tabObject = 'tab-Object-nav' // Параметры договора
    this.tabIssue = 'tab-Issue-contract-nav' // Выпуск договора
    this.tabCalculated = 'tab-CalculatedObjects-nav' // Расчет
    this.tabHistory = 'tab-Contract-activity-nav' // История документа

    /* ---------------------------------------------------------Вкладка "Условия страхования" -------------------------------------------------- */
    // локаторы секций
    this.sectionGeneralInformation = page.getByTestId('REPInsuranceConditions-#').locator('.ai-section-1').first()
    this.sectionPackageVariant = page.getByTestId('REPInsuranceConditions-#').getByTestId('rep-select-width-detail')

    // Элементы блока "Вариант коробки"
    this.boxOption = this.sectionPackageVariant.locator('.ai-th-style')
    /* ---------------------------------------------------------Вкладка "Параметры договора" -------------------------------------------------- */
    // локаторы секций
    this.sectionPolisiHolder = page.getByTestId('REPPolicyHolder-#') // блок Страхователь
    this.sectionObject = page.getByTestId('object-section') // блок Объект
    this.sectionOrgStrucrure = page.getByTestId('organisation-structure-section') // блока Орг.структура
    this.sectionAgentComissions = page.getByTestId('agent-commission-section') // блок Агенты и КВ
    this.sectionInsuranceDates = page.getByTestId('insurance-dates-section') // блок Дата страхования

    // Элементы блока "Страхователь"
    this.searchPolicyHolderButton = this.sectionPolisiHolder.getByTestId('search-policyholder-button')
    this.lastName = this.sectionPolisiHolder.getByTestId('party-last-name').getByRole('textbox')
    this.firstName = this.sectionPolisiHolder.getByTestId('party-first-name').getByRole('textbox')
    this.middleName = this.sectionPolisiHolder.getByTestId('party-middle-name').getByRole('textbox')
    this.partySearch = this.sectionPolisiHolder.getByTestId('system-selection-dropdown-ng-select').getByRole('combobox')
    this.searchButtonPolicy = this.sectionPolisiHolder.getByTestId('DetailedPartySearchView_SearchButton')
    this.selectButtonPolicy = this.sectionPolisiHolder.getByRole('button', { name: 'Выбрать' })
    // Элементы блока "Объект"

    this.policyHolderAddressButton = this.sectionObject.getByTestId('policyholder-address-button') // кнопка "По адресу страхователя"
    this.fullAdress = this.sectionObject.getByTestId('PPAddress-#').getByTestId('AddressAutocomplete') // поле "Адрес объекта"objectType
    // this.objectType = this.sectionObject.getByTestId('object-type-ng-select') // выпадающий список  "Тип объекта"
    this.objectType = this.sectionObject.getByTestId('object-type') // выпадающий список  "Тип объекта"

    // Элементы блока "Агенты и КВ"
    this.agent = this.sectionAgentComissions.getByTestId('agent-name-link')
    this.agentAgreement = this.sectionAgentComissions.getByTestId('agent-agreement-link')
    this.conclusionDateAgent = this.sectionAgentComissions
      .getByTestId('agent-commission-table')
      .locator('.ai-text-span')
      .nth(2)
    this.startDateAgent = this.sectionAgentComissions
      .getByTestId('agent-commission-table')
      .locator('.ai-text-span')
      .nth(3)
    this.endDateAgent = this.sectionAgentComissions
      .getByTestId('agent-commission-table')
      .locator('.ai-text-span')
      .nth(4)
    this.commissionRate = this.sectionAgentComissions
      .getByTestId('agent-commission-table')
      .locator('.ai-text-span')
      .nth(6)
    this.commissionAmount = this.sectionAgentComissions
      .getByTestId('agent-commission-table')
      .locator('.ai-text-span')
      .nth(7)

    // Элементы блока "Дата страхования"
    this.startDate = this.sectionInsuranceDates.locator('#policy-start-date-input')

    this.endDate = this.sectionInsuranceDates.locator('#policy-end-date-input')

    /* ---------------------------------------------------------Вкладка "Выпуск договора" -------------------------------------------------- */
    // локаторы секций
    this.sectionSigning = page.getByTestId('signing-section') // блок "Подписание"
    this.sectionPaymentPlan = page.getByTestId('REPPaymentData-#').locator('.ai-section-1').first() // блок "График платежей"
    this.sectionPayer = page.getByTestId('REPPaymentData-#').locator('.ai-section-1').nth(1) // блок "Плательщик"

    // Элементы блока "Подписание"
    this.conclusionType = this.sectionSigning.getByTestId('conclusion-type')
    this.signingType = this.sectionSigning.getByTestId('signing-type')
    this.signerName = this.sectionSigning.getByTestId('signer-link')
    this.proxyNumber = this.sectionSigning.getByTestId('proxy-number').locator('input')
    this.proxyDate = this.sectionSigning.getByTestId('proxy-date').locator('input').first()

    // Элементы блока "График платежей"
    this.paymentMethod = this.sectionPaymentPlan.locator('ng-select').getByRole('combobox')
    this.checkPaymentMethod = this.sectionPaymentPlan.locator('.ng-value-label').nth(0)

    // Элементы блока "Плательщик"
    this.paymentNotificationMethod = this.sectionPayer.locator('#-ng-select')
    this.payerEmail = this.sectionPayer
      .getByTestId('REPPaymentData-#')
      .locator('.ai-section-1')
      .nth(1)
      .locator('input')
      .nth(1)
    this.payerSms = this.sectionPayer
      .getByTestId('REPPaymentData-#')
      .locator('.ai-section-1')
      .nth(1)
      .locator('input')
      .nth(2)
    /* ---------------------------------------------------------Вкладка "Расчет" -------------------------------------------------- */

    // локаторы секций
    this.sectionRealsestate = page.getByTestId('REPCalculatedObjects-#').locator('.ai-card-list').first() // недвижимое имущество
    this.sectionMovableProperty = page.getByTestId('movable-property-section') // движимое имущество
    this.sectionCivilResponsibility = page.getByTestId('civil-responsibility-section') // гражданска ответственность
    this.sectionUnexpectedExprenses = page.getByTestId('unexpected-expenses-section') // непредвиденные расходы

    this.service = page.getByTestId('REPServices-#') // поле "Объем услуг"
    // Элементы блока "Недвижимое имущество"
    this.sumInsuredRealsestate = this.sectionRealsestate.getByTestId('sum-insured-input') // страховая сумма
    this.premiumRealsestate = this.sectionRealsestate.getByTestId('premium-input') // премия

    // Таблица "Застрахованные риски"
    this.tableRiskRealsestate = this.sectionRealsestate.getByTestId('insured-risks-table')

    // this.elriskRealestate1 = this.sectionRealsestate.getByTestId('insured-risks-table').getByRole('row', { name: 'Огонь' })

    // Таблица "Лимиты"
    this.tableRiskLimitRealsestate = this.sectionRealsestate.getByTestId('limits-table')

    // this.realestateLimits1 = this.sectionRealsestate.getByTestId('limits-table').getByRole('row', { name: 'Огонь' })

    // --------------Элементы блока "Движимое имущество"
    this.sumInsuredMova = this.sectionMovableProperty.getByTestId('sum-insured-input')
    this.premiumMova = this.sectionMovableProperty.getByTestId('premium-input')
    // Таблица "Застрахованные риски"
    this.tableRiskMova = this.sectionMovableProperty.getByTestId('insured-risks-table')

    // this.elriskMova1 = this.sectionMovableProperty.getByTestId('insured-risks-table').getByRole('row', { name: 'Огонь' })

    // Таблица "Лимиты"
    this.tableRiskLimitMova = this.sectionMovableProperty.getByTestId('limits-table')

    // this.elriskMovalimit1 = this.sectionMovableProperty.getByTestId('limits-table').getByRole('row', { name: 'Огонь' })

    // ---------------------Элементы блока "Гражданская  ответственность"
    this.sumInsuredCivil = this.sectionCivilResponsibility.getByTestId('sum-insured-input')
    this.premiumCivil = this.sectionCivilResponsibility.getByTestId('premium-input')

    this.civilResponsibility = page
      .getByTestId('civil-responsibility-section')
      .getByRole('row', { name: 'С ответственностью за все риски' })

    /* ---------------------------------Элементы раздела НЕПРЕДВИДЕННЫХ РАСХОДОВ */
    // --------блок "Мастер на час"
    this.sumInsuredUnexpectedMaster = this.sectionUnexpectedExprenses.getByTestId('sum-insured-input').first() // сс
    this.premiumUnexpectedMaster = this.sectionUnexpectedExprenses.getByTestId('premium-input').first() // сп
    // this.sumInsuredUnexpectedMaster = page.getByTestId('unexpected-expenses-section').getByTestId('sum-insured-input').first()

    // Таблица "Застрахованные риски"
    this.tableRiskUnexpectedMaster = this.sectionUnexpectedExprenses.getByTestId('insured-risks-table').first()

    // Таблица "Лимиты - "
    this.tableLimitUnexpectedMaster = this.sectionUnexpectedExprenses.getByTestId('limits-table').first()

    // ---------------блок "Клининг"
    this.sumInsuredUnexpectedKlining = this.sectionUnexpectedExprenses.getByTestId('sum-insured-input').nth(1) // сс
    this.premiumUnexpectedKlining = this.sectionUnexpectedExprenses.getByTestId('premium-input').nth(1) // сп

    // Таблица "Застрахованные риски"
    this.tableRiskUnexpectedKlining = this.sectionUnexpectedExprenses.getByTestId('insured-risks-table').nth(1)

    // Таблица "Лимиты"
    this.tableLimitUnexpectedKlining = this.sectionUnexpectedExprenses.getByTestId('limits-table').nth(1)

    // ---------------------Элементы боковой вкладки "Общая информация"

    this.sectionSummary = page.getByTestId('REPSummary-#')

    this.summaryPolicyHolder = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Страхователь' })
      .locator('.ai-text-span')
    this.summaryInsuranceType = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Программа страхования' })
      .locator('.ai-text-span')
    this.summaryPackageVariant = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Вариант коробки' })
      .locator('.ai-text-span')
    this.summaryPaymentFrequency = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Порядок оплаты премии' })
      .locator('.ai-text-span')
    this.summaryValidFrom = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Дата начала действия страхования' })
      .locator('.ai-text-span')
    this.summaryValidUntil = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Дата окончания действия страхования' })
      .locator('.ai-text-span')
    this.summaryObjectType = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Тип объекта' })
      .locator('.ai-text-span')
    this.summaryBusinessTypes = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Тип бизнеса' })
      .locator('.ai-text-span') // только для программы ОСО
    this.summaryInsuranceDuration = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Срок действия' })
      .locator('.ai-text-span')
    this.summaryIssueDate = this.sectionSummary
      .locator('.form-group')
      .filter({ hasText: 'Дата заключения' })
      .locator('.ai-text-span')
    this.summaryPremium = this.sectionSummary.getByTestId('premium-rubles')
    // page.getByTestId('unexpected-expenses-section').getByTestId('insured-risks-table').first().getByRole('row').nth(1).getByRole('cell').nth(2)
  }

  // ------------------------------------------------------------Методы для продукта "Защита недвижимости"
  async checkTableProperty(locatorTable, number, numCell, arrayNameRisk, valueTarif, valuePremium) {
    // const nameRisk = ['Огонь', 'Вода', 'Природные силы и стихийные бедствия', 'Посторонние воздействия', 'Противоправные действия третьих лиц']

    for (let i = 1, j = 0; i <= number; i++, j++) {
      await expect(locatorTable.getByRole('row').nth(i).getByRole('cell').nth(0)).toContainText(arrayNameRisk[j])

      await expect(locatorTable.getByRole('row').nth(i).getByRole('cell').nth(numCell)).toContainText(valueTarif)

      await expect(
        locatorTable
          .getByRole('row')
          .nth(i)
          .getByRole('cell')
          .nth(numCell + 1)
      ).toContainText(valuePremium)
    }
  }

  async checkTablelimitUnexpected(locatorTable, number, arrayNameLimit, valueTypeLimit, valueVarLimit) {
    for (let i = 1, j = 0; i <= number; i += 2, j++) {
      await expect(locatorTable.getByRole('row').nth(i).getByRole('cell').nth(0)).toContainText(arrayNameLimit[j])
      await expect(
        locatorTable
          .getByRole('row')
          .nth(i + 1)
          .getByRole('cell')
          .nth(0)
      ).toContainText(arrayNameLimit[j])

      await expect(locatorTable.getByRole('row').nth(i).getByRole('cell').nth(1)).toContainText('Количество обращений')
      await expect(
        locatorTable
          .getByRole('row')
          .nth(i + 1)
          .getByRole('cell')
          .nth(1)
      ).toContainText('В рублях на 1 обращение')

      await expect(locatorTable.getByRole('row').nth(i).getByRole('cell').nth(2)).toContainText(valueTypeLimit)
      await expect(
        locatorTable
          .getByRole('row')
          .nth(i + 1)
          .getByRole('cell')
          .nth(2)
      ).toContainText(valueVarLimit)

      console.log(j)
    }
  }
}
