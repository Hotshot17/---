import { test, expect } from '@playwright/test'
/**
 * @deprecated
 */
export class GeneralPageBankProducts {
  constructor(page) {
    this.page = page

    /* ---------------------------------------------------------"Вкладки" -------------------------------------------------- */
    // Вкладка  "Проверки и ошибки"
    this.tabNotifications = 'tab-Notifications-nav'
    this.totalIssues = page.getByTestId('RequiredPropertiesValidations-error-count') // количество валидаций
    this.totalNameValidations = page.getByTestId('RequiredPropertiesValidations') // название валидации

    /* ---------------------------------------------------------Главное меню" -------------------------------------------------- */
    this.contractsMenu = page.getByTestId('Contracts_menu_1')

    /* ---------------------------------------------------------Кнопки документа" -------------------------------------------------- */

    this.actionsButton = this.page.getByTestId('ai-transitions-relations-control') // кнопка действия
    this.saveButton = this.page.getByTestId('ai-operations-control-Save') // кнопка сохранить
    this.printButton = this.page.getByTestId('ai-printouts-control') // кнопка печать
    this.actorButton = this.page.getByTestId('ai-actor-selection-control') // кнопка выбора роли

    /* ---------------------------------------------------------Заголовок документа" -------------------------------------------------- */

    this.documentName = this.page.getByTestId('header-document-name') // имя документа
    this.documentState = this.page.getByTestId('header-document-state') // статус документа
    this.documentNumber = this.page.getByTestId('ai-info-control') // номер документа

    /* ---------------------------------------------------------"Роли пользователей" -------------------------------------------------- */

    this.actorAgent = page.getByTestId('ai-actor-selection-control-Agent') // Продавец
    this.actorUnderwriter = page.getByTestId('ai-actor-selection-control-Underwriter') // Андеррайтер
    this.actorSalesManager = page.getByTestId('ai-actor-selection-control-SalesManager') // Руководитель продаж
    this.actorSalesCurator = page.getByTestId('ai-actor-selection-control-SalesCurator') // Куратор продаж
    this.actorSalesManager = page.getByTestId('ai-actor-selection-control-Operations') // Операционист/Сотрудник ДОСОД

    /* ---------------------------------------------------------Прочее" -------------------------------------------------- */

    this.generalTextModalWindow = this.page.getByRole('paragraph') // текст уведомления в модальном окне
  }

  /* ------------------------------------------------------------Общие методы-------------------------------------------------------------------- */
  async selectCombobox(nameValue) {
    await this.page.getByRole('option', { name: nameValue }).click() // метод для выбора значений в комбобоксе
  }

  async selectCheckboxTable(nameValue) {
    await this.page.getByRole('row', { name: nameValue }).getByRole('checkbox').first().check() // метод для установки чек-бокса
  }

  async checkComboboxValue(locatorSection, num, value) {
    await expect(locatorSection.locator('.ng-value-label').nth(num)).toContainText(value) // метод для проверки значения в комбобоксе
  }
}
