import { GeneralPageBankProducts } from '../generalPageBankProducts.page'
/**
 * @deprecated
 */
export class SZPolicyPage extends GeneralPageBankProducts {
  constructor(page) {
    super(page)
    this.page = page
    /* ---------------------------------------------------------ОБЩИЕ элементы документа "Договор" -------------------------------------------------- */
    // id вкладок
    this.tabInsuranceConditions = 'tab-insurance-conditions-nav' // Условия страхования
    this.tabCalculations = 'tab-calculations-nav' // Андеррайтинг
    this.tabPolicyAttributes = 'tab-policy-attributes-nav' // Параметры договора
    this.tabIssueOfContract = 'tab-Issue-contract-nav' // Выпуск договора
    this.tabAttachedDocuments = 'tab-policy-attributes-nav' // Вложения
    this.tabContractActivityAndTransitionHistory = 'tab-Contract-activity-nav' // История документа

    //  Роли пользователей
    this.actorPMIAgent = page.getByTestId('ai-actor-selection-control-PMIAgent') // продавец
    this.actorPMIUnderwriter = page.getByTestId('ai-actor-selection-control-PMIUnderwriter') // андеррайтер
    this.actorPMIPolicyViewer = page.getByTestId('ai-actor-selection-control-PMIPolicyViewer') // куратор продаж

    //  id cтрахового продукта для создания документа в главном меню
    this.personalMedicalInsurance = page.getByTestId('PersonalMedicalInsurance_1_2')
    this.sZPolicy = page.getByTestId('SZPolicy_1_3')

    // локатор текста уведомления в сплывающем модальном окне
    // this.generalTextModalWindow = page.getByRole('paragraph')

    /* ---------------------------------------------------------Вкладка "Условия страхования" -------------------------------------------------- */

    // Блок "Вариант коробки"
    this.boxVariant = page.getByTestId('rep-select-width-detail-option').locator('span.ai-th-style')
    this.boxVariantCheck = page.locator('th#rep-select-width-detail-option') // id чек-бокса
    this.basePremium = page.getByTestId('rep-select-width-detail').getByRole('row', { name: 'Премия' }).locator('td')
    this.sumInsured = page
      .getByTestId('rep-select-width-detail')
      .getByRole('row', { name: 'Страховая сумма' })
      .locator('td')
    this.ambulatoryTreatment = page
      .getByTestId('rep-select-width-detail')
      .getByRole('row', { name: 'Амбулаторно-поликлиническое обслуживание' })
      .first()
      .locator('td')
    this.telemed = page
      .getByTestId('rep-select-width-detail')
      .getByRole('row', { name: 'Телемедицинские услуги' })
      .locator('td')
    this.dentalTreatment = page
      .getByTestId('rep-select-width-detail')
      .getByRole('row', { name: 'Стоматологическое обслуживание' })
      .locator('td')
    this.deductable = page
      .getByTestId('rep-select-width-detail')
      .getByRole('row', {
        name: 'Безусловная франшиза. В % от оплаты мед услуг (только для Амбулаторно-поликлиническое обслуживание)',
      })
      .locator('td')
    this.deductableDays = page
      .getByTestId('rep-select-width-detail')
      .getByRole('row', { name: 'Временная франшиза. В днях с даты начала срока страхования' })
      .locator('td')

    /* ---------------------------------------------------------Вкладка "Параметры договора" -------------------------------------------------- */
    // блок "Страхователь"
    this.searchPolicyHolder = page
      .getByTestId('SZPolicyHolderData-#')
      .getByRole('button', { name: 'Поиск страхователя' })
    this.partySearch = page
      .getByTestId('SZPolicyHolderData-#')
      .getByTestId('system-selection-dropdown-ng-select')
      .getByRole('combobox')
    this.lastName = page.getByTestId('SZPolicyHolderData-#').getByTestId('party-last-name').getByRole('textbox')
    this.firstName = page.getByTestId('SZPolicyHolderData-#').getByTestId('party-first-name').getByRole('textbox')
    this.middleName = page.getByTestId('SZPolicyHolderData-#').getByTestId('party-middle-name').getByRole('textbox')
    this.searchButtonPolicy = page
      .getByTestId('SZPolicyHolderData-#')
      .getByTestId('DetailedPartySearchView_SearchButton')
    this.selectButtonPolicy = page.getByTestId('SZPolicyHolderData-#').getByRole('button', { name: 'Выбрать' })
    this.checkboxInsuredPolicyHolder = page
      .getByTestId('SZPolicyHolderData-#')
      .locator('ng-component')
      .filter({ hasText: 'Страхователь является застрахованным' })
      .locator('i')

    // блок "Застрахованный"
    this.insuredSearchPolicyHolder = page
      .getByTestId('SZInsuredPersonData-#')
      .getByRole('button', { name: 'Поиск застрахованного' })
    this.insuredPartySearch = page
      .getByTestId('SZInsuredPersonData-#')
      .getByTestId('system-selection-dropdown-ng-select')
      .getByRole('combobox')
    this.insuredLastName = page.getByTestId('SZInsuredPersonData-#').getByTestId('party-last-name').getByRole('textbox')
    this.insuredFirstName = page
      .getByTestId('SZInsuredPersonData-#')
      .getByTestId('party-first-name')
      .getByRole('textbox')
    this.insuredMiddleName = page
      .getByTestId('SZInsuredPersonData-#')
      .getByTestId('party-middle-name')
      .getByRole('textbox')
    this.insuredSearchButtonPolicy = page
      .getByTestId('SZInsuredPersonData-#')
      .getByTestId('DetailedPartySearchView_SearchButton')
    this.insuredSelectButtonPolicy = page.getByTestId('SZInsuredPersonData-#').getByRole('button', { name: 'Выбрать' })

    // Блок "Орг.структура"
    this.salesOutlet = this.page.getByTestId('org-structure').locator('app-text-input').getByRole('textbox')
    this.department = this.page.getByTestId('department-ng-select')
    this.branch = this.page.getByTestId('branch-ng-select')
    this.profileProgram = this.page.getByTestId('profileProgram-ng-select')
    this.sellingChannel = this.page.getByTestId('sellingChannel-ng-select')

    // Блок "Посредники и КВ"

    this.agent = this.page.getByTestId('agent-name-link')
    this.agentAgreement = this.page.getByTestId('agent-agreement-link')
    this.conclusionDate = this.page.getByTestId('agent-commission-table').locator('.ai-text-span').nth(1)
    this.startDateAgent = this.page.getByTestId('agent-commission-table').locator('.ai-text-span').nth(2)
    this.endDateAgent = this.page.getByTestId('agent-commission-table').locator('.ai-text-span').nth(3)
    this.commissionRate = this.page.getByTestId('agent-commission-table').locator('.ai-text-span').nth(4)
    this.commissionAmount = this.page.getByTestId('agent-commission-table').locator('.ai-text-span').nth(5)

    /* ---------------------------------------------------------Вкладка "Андеррайтинг" -------------------------------------------------- */
    // Блок "Риски"
    this.insuredRiskName = page.getByTestId('group-risk-name').getByRole('textbox')
    this.insuredRiskSumInsured = page.getByTestId('sumInsured-input')
    this.insuredRiskPremium = page.getByTestId('premium-input')
    this.insuredRiskRule = page.getByTestId('rule-ng-select')
    this.insuredRiskTariff = page.getByTestId('tariff-ng-select')

    // Столбец "ЭЛ.РИСК"
    this.elRiskNameRow0 = this.page.getByTestId('elementary-risks-table-row-0').getByTestId('el-risk-name')
    this.elRiskNameRow1 = this.page.getByTestId('elementary-risks-table-row-1').getByTestId('el-risk-name')

    // Столбец "СТРАХОВАЯ СУММА ПО ЭЛ.РИСКУ"
    this.elRiskSumRow0 = this.page.getByTestId('elementary-risks-table-row-0').getByTestId('suminsured').locator('span')
    this.elRiskSumRow1 = this.page.getByTestId('elementary-risks-table-row-1').getByTestId('suminsured').locator('span')

    // Столбец "СТРАХОВАЯ ПРЕМИЯ ПО ЭЛ.РИСКУ"
    this.elRiskPremiumRow0 = this.page
      .getByTestId('elementary-risks-table-row-0')
      .getByTestId('premium')
      .locator('span')
    this.elRiskPremiumRow1 = this.page
      .getByTestId('elementary-risks-table-row-1')
      .getByTestId('premium')
      .locator('span')

    // Столбец "ТЕРРИТОРИЯ СТРАХОВАНИЯ"
    this.territiryRow0 = this.page.getByTestId('elementary-risks-table-row-0').getByTestId('territory-ng-select')
    this.territiryRow1 = this.page.getByTestId('elementary-risks-table-row-1').getByTestId('territory-ng-select')
    // Столбец "ФРАНШИЗА"
    this.deductableRow0Input1 = this.page
      .getByTestId('SZDeductables-deductable')
      .locator('input.form-control.ai-text-input.ng-untouched.ng-pristine')
      .first()
    this.deductableRow0Input2 = this.page
      .getByTestId('SZDeductables-deductable')
      .locator('input.form-control.ai-text-input.ng-untouched.ng-pristine')
      .nth(1)
    this.deductableRow0Input3 = this.page
      .getByRole('row', { name: 'Амбулаторно-поликлиническое обслуживание' })
      .locator('#-input')
      .first()
    this.deductableRow0Input4 = this.page
      .getByTestId('SZDeductables-deductable')
      .locator('input.form-control.ai-text-input.ng-untouched.ng-pristine')
      .nth(2)
    this.deductableRow0Input5 = this.page
      .getByTestId('SZDeductables-deductable')
      .locator('input.form-control.ai-text-input.ng-untouched.ng-pristine')
      .nth(3)
    this.deductableRow0Input6 = this.page
      .getByRole('row', { name: 'Амбулаторно-поликлиническое обслуживание' })
      .locator('#-input')
      .nth(1)

    this.deductableRow1Input1 = this.page
      .getByTestId('SZDeductables-deductable')
      .locator('input.form-control.ai-text-input.ng-untouched.ng-pristine')
      .nth(4)
    this.deductableRow1Input2 = this.page
      .getByTestId('SZDeductables-deductable')
      .locator('input.form-control.ai-text-input.ng-untouched.ng-pristine')
      .nth(5)
    this.deductableRow1Input3 = this.page.getByRole('row', { name: 'Телемедицинские услуги' }).locator('#-input')

    /* ---------------------------------------------------------Вкладка "Выпуск договора" -------------------------------------------------- */
    // блок "График платежей"
    this.paymentMethod = page.getByTestId('SZPaymentData-#').locator('ng-select').getByRole('combobox').first()
    this.checkPaymentMethod = page.getByTestId('SZPaymentData-#').locator('.ng-value-label').first()

    // блок "Плательщик"
    this.paymentNotificationMethod = page.getByTestId('notification-method').getByRole('combobox')
    this.payerEmail = page.getByTestId('payer-email').getByRole('textbox')
    this.payerSms = page.getByTestId('payer-mobile').getByRole('textbox')

    /* ---------------------------------------------------------Боковое меню вкладка "Общая информация" -------------------------------------------------- */
    this.summaryPolicyHolder = this.page.getByTestId('SZSummary-#').locator('div.form-group').first()
    this.summaryInsuranceProgram = this.page.getByTestId('SZSummary-#').locator('div.form-group').nth(1)
    this.summaryBoxVariant = this.page.getByTestId('SZSummary-#').locator('div.form-group').nth(2)
    this.summaryPaymentFrequency = this.page.getByTestId('SZSummary-#').locator('div.form-group').nth(3)
    this.summaryIssueDate = this.page.getByTestId('SZSummary-#').locator('div.form-group').nth(4)
    this.summaryStartDate = this.page.getByTestId('SZSummary-#').locator('div.form-group').nth(5)
    this.summaryEndDate = this.page.getByTestId('SZSummary-#').locator('div.form-group').nth(6)
    this.summaryPolicyDuration = this.page.getByTestId('SZSummary-#').locator('div.form-group').nth(7)
    this.summaryPremium = this.page.getByTestId('SZSummary-#').getByTestId('premium-rubles')
  }

  // async selectCombobox (nameValue) {
  //   await this.page.getByRole('option', { name: nameValue }).click() // метод для выбора значений в комбобоксе
  // }

  // async selectCheckboxTable (nameValue) {
  //   await this.page.getByRole('row', { name: nameValue }).getByRole('checkbox').check() // метод для установки чек-бокса
  // }
}
