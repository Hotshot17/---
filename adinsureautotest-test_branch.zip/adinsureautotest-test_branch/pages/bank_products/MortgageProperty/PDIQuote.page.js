import { GeneralPageBankProducts } from '../generalPageBankProducts.page'
/**
 * @deprecated
 */
export class PDIQuotePage extends GeneralPageBankProducts {
  constructor(page) {
    super(page)

    this.page = page

    this.otherProduct = page.getByTestId('Other_1_2')
    this.quotePdi = page.getByTestId('QuoteMP_3_3')
  }
}
