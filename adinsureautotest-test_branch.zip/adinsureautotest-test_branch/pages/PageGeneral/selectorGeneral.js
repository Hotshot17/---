// @ts-check

const generalSelectors = {
  /**
   * **Кнопка поиска контрагента**
   */
  поискКонтрагент: 'original-reinsurer-search',
  полеПоиск: 'partyapi-search',
  //кнопкаЛупы: 'policyholder-search-button',
  кнопкаЛупы: 'btn-policy-holder-search',

  /**
   * Блок Авторизации
   */
  кнопкаВход: 'enter-button',
  типВходаВнешнийСотрудник: 'login-type-adinsure',
  имяПользователя: 'Username',
  пароль: 'Password',
  кнопкаВойти: 'login-button',

  /**
   * Поиск контрагентов-по параментрам
   */
  типКонтрагента: 'party-type-dropdown-ng-select',
  поискКонтрагентаВСистеме: 'system-selection-dropdown-ng-select',
  кнопкаПоиск: 'DetailedPartySearchView_SearchButton',

  /**
   * Общие id
   */
  фамилия: 'party-last-name',
  имя: 'party-first-name',
  отчество: 'party-middle-name',
  пол: 'party-gender',
  датаРождения: 'party-birthday',
  инн: 'party-inn',

  /**
   * Физ.лицо
   */
  серия: 'party-document-series',
  номер: 'party-document-number',
  видДокумента: 'party-document-type',

  /**
   * Юр.лицо
   */
  наименование: 'party-name',
  кпп: 'party-kpp',

  /**
   * Документ
   */
  номерДокумента: 'ai-info-control',

  /**
   * Данные сделки
   */
  каналПродаж: 'sales-channel',
  зонаОтвественности: 'sales-zone',
  ПрофильнаяПрограмма: 'atrDealProgram',
  кнопкаПоискПодразделенияСделки: 'application-branch-search',
  подразделение: 'department-name',

  /**
   * Роли
   */
  роли: 'ai-actor-selection-control',
  андеррайтер: 'ai-actor-selection-control-Underwriter',
  продавец: 'ai-actor-selection-control-Agent',
  дэб: 'ai-actor-selection-control-DEB',
  операционист: 'ai-actor-selection-control-Operations',
  руководительПродавец: 'ai-actor-selection-control-SalesManager',
  рискАнализ: 'ai-actor-selection-control-RiskAnalysis',
  бухгалтер: 'ai-actor-selection-control-DBU',
  финансовыйБлок: 'ai-actor-selection-control-Finance',
  юридическоеПодразделение: 'ai-actor-selection-control-LegalDepartment',
  урегулированиеУбытков: 'ai-actor-selection-control-ClaimHandler',
  руководительАндеррайтер: 'ai-actor-selection-control-ManagerUnderwriter',
  сопровождение: 'ai-actor-selection-control-Maintenance',

  /**
   * Боковое меню
   */
  проверкиИОшибки: 'tab-Notifications-nav',
  общаяИнформация: 'tab-Summary-nav',

  /**
   * Вложения
   */
  типВложения: 'attachment-type',
  таблицаВложения: 'attachments-table-table',

  /**
   * История документов
   */
  таблицаСвязанныеДокументы: 'related-documents-table',

  /**
   * Мои задачи
   */
  группа: 'userGroupsSelect',
  задачиНомерДокумента: 'document-number',
  типДокумента: 'document-type',
  продукт: 'product-code',
  статусЗадачи: 'task-status',
  датаСозданияС: 'create-date-from-input',
  датаСозданияПо: 'create-date-to-input',

  /**
   * Профильная программа
   */
  профильнаяПрограмма: 'profile-program-ng-select',
  кнопкаЛупыТочкаПродаж: 'sales-outlet-search-dialog-button',

  /**
   * Поиск сотрудников
   */
  заголовокПоискСотрудников: 'search-header',
  кнопкаПоискСотрудников: 'employee-search',
  полеПоискСотрудников: 'employee-search-input',

  /**
   * Поиск агентов
   */
  заголовокПоискАгентов: 'search-header',
  кнопкаПоискАгентов: 'employee-search',
  полеПоискАгентов: 'ext-search-input',

  /**
   * История Владения ТС
   */
  кнопкаЛупаИсторияВладения: 'select-previous-button',
  полеНаименование: 'organisation-name',
  полеИНН: 'inn',
  полеКПП: 'kpp',
  кнопкаПоискСотрудника: 'DetailedPartySearchView_SearchButton',

  /**
   * Печать
   */
  кнопкаПечать: 'ai-printouts-control',

  /**
   * Нераспределенные задачи
   */
  вкладкаНераспределенныеЗадачи: 'tab-Unassigned-tasks-nav',
  группаЛокатор: 'userGroupsSelect',
  исполнительНераспределенныеЗадачи: 'groupMembersSelect',
  номерДокументаЛокатор: 'document-number',
  типДокументаЛокатор: 'document-type',
  датаСозданияЛокатор: 'ESGroupActivitiesSearchViewUnassigned',
  датаСозданияПоЛокатор: 'create-date-to-input',
  статусЗадачиЛокатор: 'task-status',

  /**
   * Поиск документов
   */
  номерДокументаПоиск: 'contract-search-area',
  номерДокументаПоискЛокатор: 'app-text-input',

  /**
   * Страхователь
   */
  страховательФамилия: 'ie-last-name',
  страховательИмя: 'ie-first-name',
  страховательОтчество: 'ie-middle-name',
  страховательИнн: 'ie-inn',
  страховательПол: 'ie-gender',
  страховательДатаРождения: 'ie-birthday-input',

  /**
   * История Страхования
   */
  кодСк: 'insurance-company-code',
  регистрационныйНомер: 'insurance-company-number',
  наименованиеСтраховаяКомпания: 'organisation-name',

  /**
   * ПОИСК КОНТРАГЕНТОВ - ПО ПАРАМЕТРАМ
   */
  поискКонтрагентаВСистемах: 'system-selection-dropdown',
  кнопкаЛупаКонтрагент: 'section-travel-cancellation-attributes',

  /**
   * Поиск контрагентов
   */
  общийПоиск: 'detailedparty-param_general-search',
  названиеДокумента: 'header-document-name',
  состояниеДокумента: 'header-document-state',

  /**
   * Уровень согласования договора
   */
  уровеньСогласованияДоговора: 'policy-approval-section',

  /**
   * УРОВЕНЬ СОГЛАСОВАНИЯ ДОПСА
   */
  уровеньСогласованияДопса: 'amendment-approval-level',

  /**
   * Элементы главного меню
   */
  рабочийСтол: 'Dashboards_menu_1',
  поискДокументов: 'ContractSearchByCurrentUserBranch_1_2',
  витринаЗадач: 'Workflow_1_2',
}

export { generalSelectors }
