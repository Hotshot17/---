export const selectorQuote = {
  /*-----------------------------------------------------------------------Селекторы элементов главного меню-------------------------------------------------------*/
  /** @description Папка  "Страховые продукты"' */
  contracts: 'Contracts_menu_1',

  /** @description Папка  продукта "СОГАЗ Квартира"' */
  sogazFlat: 'SogazFlat_1_2',

  /** @description Элемент создания документа   "Договор"' */
  sogazFlatPolicy: 'SogazFlatPolicy_1_3',

  /*-----------------------------------------------------------------------Селекторы элементов бокового информационного меню(сайдбар)-------------------------------------------------------*/
  /** @description  id атрибута "Страхователь" */
  sideBarPolicyHolder: 'policyholder-side',

  /** @description  id атрибута "Программа страхования" */
  sideBarNsuranceType: 'insurance-type-side',

  /** @description  id атрибута "Вариант коробки" */
  sideBarPackageVariant: 'package-variant-side',

  /** @description  id атрибута "Порядок оплаты премии" */
  sideBarPaymentFrequency: 'payment-frequency-side',

  /** @description  id атрибута "Дата начала действия страхования" */
  sideBarValidFrom: 'valid-from-side',

  /** @description  id атрибута "Дата окончания действия страхования" */
  sideBarValidUntil: 'valid-untill-side',

  /** @description  id атрибута "Тип объекта" */
  sideBarObjectType: 'object-type-side',

  /** @description  id атрибута "Тип бизнеса" */
  sideBarBusinessTypes: 'business-type-side',

  /** @description  id атрибута "премия" */
  sideBarPremium: 'premium-rubles',

  /*-----------------------------------------------------------------------Селекторы вкладок документа-------------------------------------------------------*/
  /** @description  id вкладки "Условия страхования" */
  insuranceConditions: 'tab-Insurance-conditions-nav',

  /** @description  id вкладки "Общая информация" */
  generalData: 'tab-General-nav',

  /** @description  id вкладки "Параметры объекта" */
  objectParameters: 'tab-Object-nav',

  /** @description  id вкладки "Андеррайтинг" */
  underwriting: 'tab-Underwriting-nav',

  /** @description  id вкладки "Вложения" */
  attachedDocuments: 'tab-Attached-documents-nav',

  /** @description  id вкладки "Выпуск договора" */
  issueOfContract: 'tab-Issue-contract-nav',

  /** @description  id вкладки "История документа" */
  contractActivityAndTransitionHistory: 'tab-Contract-activity-nav',
  /*-----------------------------------------------------------------------Селекторы вкладок инфоменю-------------------------------------------------------*/
  /** @description  id вкладки "Общая информация" */
  tabSummary: 'tab-Summary-nav',

  /** @description  id вкладки "Проверки и ошибки" */
  tabNotification: 'tab-Notifications-nav',

  /** @description  id вкладки "Всего проблем" */
  validations: 'RequiredPropertiesValidations',

  /** @description  id поля "Премия, руб" */
  premiumRubles: 'premium-rubles',

  /*-----------------------------------------------------------------------Селекторы списка действий документа-------------------------------------------------------*/
  /** @description Button 'Кнопка действия "Отказаться от оформления" Котировки' */
  draftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',

  /** @description Button 'Кнопка действия "Выпустить котировку"' */
  createSogazFlatPolicy: 'ai-transitions-relations-control-CreateSogazFlatPolicy',

  /** @description Button 'Кнопка действия "Отправить на согласование"' */
  draftToUW1: 'ai-transitions-relations-control-Draft_to_UW1',

  /** @description Button 'Кнопка действия "Отправить на согласование UW3"' */
  draftToUW3: 'ai-transitions-relations-control-Draft_to_UW3',

  /** @description Button 'Кнопка действия "Отправить на согласование (Уровень 1)"' */
  forCorrectionSendToHigherLevel: 'ai-transitions-relations-control-ForCorrection_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Вернуть на корректировку (UW1_to_ForCorrection)"' */
  controlUW1ToForCorrection: 'ai-transitions-relations-control-UW1_to_ForCorrection',

  /** @description Button 'Кнопка действия "Вернуть на корректировку (UW3_to_ForCorrection)"' */
  controlUW3ToForCorrection: 'ai-transitions-relations-control-UW3_to_ForCorrection',

  /** @description Button 'Кнопка действия "Вернуть на корректировку (UW4_to_ForCorrection)"' */
  controlUW4ToForCorrection: 'ai-transitions-relations-control-UW4_to_ForCorrection',

  /** @description Button 'Кнопка действия "Согласовать c UW1 до UW3"' */
  controlUW1ToUW3: 'ai-transitions-relations-control-UW1_to_UW3',

  /** @description Button 'Кнопка действия "Согласовать с UW3 до UW4"' */
  controlUW3ToUW4: 'ai-transitions-relations-control-UW3_to_UW4',

  /** @description Button 'Кнопка действия "Согласовать с UW1_to_Approved"' */
  controlUW1ToApproved: 'ai-transitions-relations-control-UW1_to_Approved',

  /** @description Button 'Кнопка действия "Согласовать с UW4_to_Approved"' */
  controlUW4ToApproved: 'ai-transitions-relations-control-UW4_to_Approved',

  /** @description Button 'Кнопка действия "Отказать"' */
  controlUW1ToRejected: 'ai-transitions-relations-control-UW1_to_Rejected',

  /** @description Button 'Кнопка действия "Отказать"' */
  controlUW3ToRejected: 'ai-transitions-relations-control-UW3_to_Rejected',

  /** @description Button 'Кнопка действия "Отказать"' */
  controlUW4ToRejected: 'ai-transitions-relations-control-UW4_to_Rejected',

  /** @description Button 'Кнопка действия "Вернуть на корректировку"' */
  rejectToForCorrection: 'ai-transitions-relations-control-Rejected_to_ForCorrection',

  /** @description Button 'Кнопка действия "К оплате"' */
  draftToPaymentWaiting: 'ai-transitions-relations-control-Draft_to_PaymentWaiting',

  /** @description Button 'Кнопка действия "Оформить договор"' */
  paymentWaitingToActivated: 'ai-transitions-relations-control-PaymentWaiting_to_Activated',

  /** @description Button 'Кнопка действия "Отказаться от оформления"' */
  controlApprovedToAnnulled: 'ai-transitions-relations-control-Approved_to_Annulled',

  /** @description Button 'Кнопка действия "Отказаться от оформления Договора"' */
  draftToRejected: 'ai-transitions-relations-control-Draft_to_Rejected',

  /** @description Button 'Кнопка действия "Отказаться от оформления из корректировки"' */
  controlForCorrectionToAnnulled: 'ai-transitions-relations-control-ForCorrection_to_Annulled',

  /** @description Button 'Кнопка действия "Вернуть на редактирование"' */
  controlPaymentWaitingToDraft: 'ai-transitions-relations-control-PaymentWaiting_to_Draft',
  /*-----------------------------------------------------------------------Селекторы вкладки "Условия страхования"-------------------------------------------------------*/

  /*-------------------------Селекторы блока "Общее" */

  /** @description  'Программа страхования' id секции "Общее" */
  generalInformation: 'general-section',

  /** @description Combobox 'Программа страхования' */
  insuranceType: 'insurance-type',

  /** @description Combobox 'Порядок оплаты премии' */
  paymentFrequency: 'insurance-frequency',

  /** @description Combobox 'Валюта договора' */
  currency: 'currency',

  /** @description Combobox 'Акция' */
  promotion: 'promotion',

  /** @description Combobox 'Специальная программа' */
  specialProgram: 'special-program',

  /** @description Combobox 'Партнерская программа' */
  partnerProgram: 'partner-program-ng-select',

  /** @description Combobox 'Зона ответственности' */
  responsibilityZone: 'responsibility-zone',

  /*--------------------------Селекторы блока "Вариант коробки"*/

  /** @description  'Программа страхования' id секции "Вариант коробки" */
  packageVariant: 'package-variant-section',

  /** @description  'Программа страхования' id таблицы "Вариант коробки" */
  packageVariantTable: 'package-variant-table',

  /** @description Checkbox 'Мастер по дому' */
  housekeeper: 'housekeeper',

  /*-----------------------------------------------------------------------Селекторы вкладки "Общая информация"-------------------------------------------------------*/
  // : '' ,
  /*--------------------------Селекторы блока "ДАТЫ И СРОК СТРАХОВАНИЯ"*/
  /** @description поля 'Срок действия страхования, дни' */
  insuranceDuration: 'insurance-duration',

  /** @description поля 'Дата заключения' */
  issueDat: 'insurance-date',

  /** @description поля 'Дата начала действия страхования ' */
  validFrom: 'valid-from',

  /** @description поля 'Дата окончания действия страхования ' */
  validUntil: 'date-to',

  /*--------------------------Селекторы блока "СТРАХОВАТЕЛЬ"*/

  /** @description Button 'Кнопка поиск страхователя' */
  searchPolicyHolder: 'search-policyholder-button',

  /** @description Button 'Кнопка поиск точки продаж' */
  salesOutletSearchButton: 'sales-outlet-search-dialog-button',

  /** @description Button 'Кнопка обновить' */
  reload: 'button-reload',

  /** @description поле 'Точка продаж' */
  pointOfSales: 'sales-outlet-name',

  /** @description поле 'Особый статус' */
  specialClientStatus: 'special-client-status',

  /** @description таблица 'Таблица поиска точек продаж' */
  adSearchTable: 'ad-search-table',

  /*--------------------------Селекторы блока "ИСТОРИЯ СТРАХОВАНИЯ"*/

  /** @description поле 'Номер предыдущего договора' */
  previousPolicyNumber: 'previous-policy-number',

  /** @description поле 'Дата окончания предыдущего договора' */
  previousEndDate: 'previous-end-date',

  /** @description поле 'Страховая премия предыдущего договора' */
  previousPremium: 'previous-premium',

  /** @description кнопка 'Поиск предыдущей компании' */
  previousInsuranceCompany: 'history-search-button',

  /*--------------------------Селекторы блока "Агенты и КВ"*/

  /** @description таблица 'Таблица сотрудника агента' */
  agentCommissionTable: 'agent-commission-table',

  /** @description Link 'Сотрудник агента' */
  agentNameLink: 'agent-name-link',

  /** @description Button 'Поиск агента' */
  agentSearchButton: 'agent-search-button-dialog-button',

  /*--------------------------Селекторы блока "Организационая структура"*/
  /** @description Атрибут 'Инициатор'(ссылка на инициатора) */
  initiator: 'initiator-link',

  /** @description Button 'Поиск менеджера договора' */
  buttonSearchManager: 'manager-search',

  /** @description Атрибут 'Менеджер договора'(ссылка на Менеджера договора) */
  policyManager: 'manager-link',

  /** @description Поле 'Филиал СОГАЗ */
  branchName: 'branch-name',

  /** @description Button 'Поиск подразделения СОГАЗ' */
  buttonSearchBranch: 'branch-search',

  /** @description Поле 'Подразделение СОГАЗ */
  departmentName: 'department-name',

  /** @description Button 'Поиск Менеджера договора */
  managerSearchButton: 'manager-search-dialog-button',
  /*-----------------------------------------------------------------------Селекторы вкладки "Параметры объекта"-------------------------------------------------------*/
  // : '' ,
  /*--------------------------Селекторы блока "Объект"*/
  /** @description поле 'Адрес объекта' */
  objectAdress: 'AddressAutocomplete-ng-select',

  /** @description поле 'По адресу страхователя' */
  policyholderAddressButton: 'policyholder-address-button',

  /** @description поле 'Тип объекта' */
  objectType: 'object-type-ng-select',

  /** @description поле 'Год постройки' */
  buldingYear: 'building-year',

  /** @description 'checkbox' 'Стены из горючих материалов' */
  flammableWalls: 'flammable-walls',

  /*-----------------------------------------------------------------------Селекторы вкладки "Выпуск договора"-------------------------------------------------------*/
  // : '' ,
  /*--------------------------Селекторы блока "Плательщик"*/
  /** @description чб 'Плательщик совпадает со страхователем' */
  payerPolicyholder: 'payer-policyholder',

  /** @description поле 'Способ уведомления' */
  notificationMethod: 'notification-method-ng-select',

  /** @description поле 'E-mail плательщика' */
  payerEmail: 'payer-email',

  /** @description поле 'Мобильный телефон плательщика' */
  payerMobile: 'payer-mobile',

  /** @description Button 'Поиск плательщика' */
  buttonSearchPayer: 'search-payer-button',

  /** @description Ссылка 'Имя плательщика (ссылка на КА)' */
  payerName: 'payer-name-link',

  /** @description Button 'Уведомление' */
  buttonSendNotification: 'button-send-notification',

  /** @description id секции 'Поступление взносов' */
  paymentsReceived: 'payments-received-section',

  /*-----------------------------------------------------------------------Селекторы вкладки "Выпуск договора"-------------------------------------------------------*/
  /** @description блок 'История документа' */
  documentActivityHistory: 'document-activity-history-section',
  /*-----------------------------------------------------------------------Селекторы вкладки "Андеррайтинг"-------------------------------------------------------*/

  /*--------------------------Селекторы блока "Комментарии"*/
  /** @description поле 'Комментарий' */
  commentsArea: 'comments-area',
  /** @description секция 'Комментарий' */
  commentsSection: 'comments-section',
}
