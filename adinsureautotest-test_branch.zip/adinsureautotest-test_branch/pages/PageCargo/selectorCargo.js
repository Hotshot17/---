// @ts-check

const quoteCargo = {
  /*-----------------------------------------Селекторы элементов главного меню-----------------------------------*/

  /** Папка  "Страховые продукты" */
  contracts: 'Contracts_menu_1',

  /** Папка  продукта "Грузы" */
  cargo: 'Cargo_1_2',

  /** Элемент создания документа "Котировка" */
  cargoQuote: 'CGQuote_1_3',

  /** Элемент создания документа "Договор CARGO EXPRESS" */
  cargoExpressPolicy: 'CGExpressPolicy_1_3',

  /** Папка  "Витрина задач" */
  workflow: 'Workflow_1_2',

  /** Вкладка "Нераспределенные задачи" витрины задач */
  tabUnassignedTasks: 'tab-Unassigned-tasks-nav',

  /** Папка  "Полномочия" */
  powers: 'Powers_1_3',

  /** Папка  "Лимиты (импорт)" */
  userLimitsImportMG: 'UserLimitsImportMG_1_4',

  /** Папка  "Лимиты (экспорт)" */
  userLimitsExportView: 'UserLimitsExportView_1_4',

  /** Папка  "Таблица с максимальными лимитами групп" */
  cargoGroupUWLimitsView: 'CargoGroupUWLimitsView_1_3',

  /** Папка "Справочники" */
  codeTables: 'Code-tables_1_3',

  /** Папка  "Оговорки" */
  manualClausesView: 'CGManualClausesView_1_4',

  /*-----------------------------------------Селекторы элементов бокового информационного меню-------------------*/

  /** id вкладки "Общая информация" */
  tabSummaryNav: 'tab-Summary-nav',

  /** id блока "Общая информация" */
  tabSummary: 'tab-Summary',

  /** id вкладки "Проверки и ошибки" */
  tabNotification: 'tab-Notifications-nav',

  /** id блока "Всего проблем" */
  validations: 'RequiredPropertiesValidations',

  /*------------------------------------------Селекторы списка действий документа "Котировка"---------------------------------*/

  /** id кнопки действия "Аннулировать" */
  controlDraftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',

  /** id кнопки действия "Создать копию" */
  controlCGCopyQuote: 'ai-transitions-relations-control-CGCopyQuote',

  /** id кнопки действия "Направить на согласование" (текущий уровень Draft) */
  controlDraftSendToHigherLevel: 'ai-transitions-relations-control-Draft_SendToHigherLevel',

  /** id кнопки действия "Направить на согласование" (текущий уровень ForCorrection) */
  controlForCorrectionSendToHigherLevel: 'ai-transitions-relations-control-ForCorrection_SendToHigherLevel',

  /** id кнопки действия "Направить на согласование" (текущий уровень ApprovedInAdvance) */
  controlApprovedInAdvanceSendToHigherLevel: 'ai-transitions-relations-control-ApprovedInAdvance_SendToHigherLevel',

  /** id кнопки действия "Направить на согласование" (текущий уровень UW1) */
  controlUW1SendToHigherLevel: 'ai-transitions-relations-control-UW1_SendToHigherLevel',

  /** id кнопки действия "Направить Исполнительному Директору по андеррайтингу" (текущий уровень UW3) */
  controlUW3toUW4: 'ai-transitions-relations-control-UW3_to_UW4',

  /** id кнопки действия "Направить Исполнительному Директору по андеррайтингу" (текущий уровень UW3h) */
  controlUW3htoUW4: 'ai-transitions-relations-control-UW3h_to_UW4',

  /** id кнопки действия "Продолжить согласование внутри ГО" */
  controlUW3toUW3h: 'ai-transitions-relations-control-UW3_to_UW3h',

  /** id кнопки действия "Вернуть на корректировку" (текущий уровень UW1) */
  controlUW1ToForCorrection: 'ai-transitions-relations-control-UW1_to_ForCorrection',

  /** id кнопки действия "Вернуть на корректировку" (текущий уровень UW3) */
  controlUW3ToForCorrection: 'ai-transitions-relations-control-UW3_to_ForCorrection',

  /** id кнопки действия "Вернуть на корректировку" (текущий уровень UW3h) */
  controlUW3hToForCorrection: 'ai-transitions-relations-control-UW3h_to_ForCorrection',

  /** id кнопки действия "Вернуть на корректировку" (текущий уровень UW4) */
  controlUW4ToForCorrection: 'ai-transitions-relations-control-UW4_to_ForCorrection',

  /** id кнопки действия "Отозвать" (текущий уровень UW1) */
  controlUW1ToForCorrectionAgent: 'ai-transitions-relations-control-UW1_to_ForCorrection_Agent',

  // /** id кнопки действия "Отозвать" (текущий уровень UW3) */
  // controlUW3ToForCorrectionAgent: '',

  // /** id кнопки действия "Отозвать" (текущий уровень UW4) */
  // controlUW4ToForCorrectionAgent: '',

  /** id кнопки действия "Согласовать предварительно" (текущий уровень UW1) */
  controlUW1ToApprovedInAdvance: 'ai-transitions-relations-control-UW1_to_ApprovedInAdvance',

  /** id кнопки действия "Согласовать предварительно" (текущий уровень UW3) */
  controlUW3ToApprovedInAdvance: 'ai-transitions-relations-control-UW3_to_ApprovedInAdvance',

  /** id кнопки действия "Согласовать предварительно" (текущий уровень UW3h) */
  controlUW3hToApprovedInAdvance: 'ai-transitions-relations-control-UW3h_to_ApprovedInAdvance',

  /** id кнопки действия "Согласовать предварительно" (текущий уровень UW4) */
  controlUW4ToApprovedInAdvance: 'ai-transitions-relations-control-UW4_to_ApprovedInAdvance',

  /** id кнопки действия "Согласовать" (текущий уровень UW1) */
  controlUW1ToApproved: 'ai-transitions-relations-control-UW1_to_Approved',

  /** id кнопки действия "Согласовать" (текущий уровень UW3) */
  controlUW3ToApproved: 'ai-transitions-relations-control-UW3_to_Approved',

  /** id кнопки действия "Согласовать" (текущий уровень UW3h) */
  controlUW3hToApproved: 'ai-transitions-relations-control-UW3h_to_Approved',

  /** id кнопки действия "Согласовать" (текущий уровень UW4) */
  controlUW4ToApproved: 'ai-transitions-relations-control-UW4_to_Approved',

  /** id кнопки действия "Отказать" (текущий уровень UW1) */
  controlUW1ToRejected: 'ai-transitions-relations-control-UW1_to_Rejected',

  /** id кнопки действия "Отказать" (текущий уровень UW3) */
  controlUW3ToRejected: 'ai-transitions-relations-control-UW3_to_Rejected',

  /** id кнопки действия "Отказать" (текущий уровень UW3) */
  controlUW3hToRejected: 'ai-transitions-relations-control-UW3h_to_Rejected',

  /** id кнопки действия "Отказать" (текущий уровень UW4) */
  controlUW4ToRejected: 'ai-transitions-relations-control-UW4_to_Rejected',

  /** id кнопки действия "Создать договор из котировки" (Новый) */
  controlCGCreatePolicy: 'ai-transitions-relations-control-CGCreatePolicy',

  /** id кнопки действия "Создать договор из котировки" (Заявка) */
  controlCGCreatePolicyRequest: 'ai-transitions-relations-control-CGCreatePolicyRequest',

  /*-------------------------------------Селекторы печатные формы Котировкии-------------------------------------*/

  /** id ПФ Котировочный лист */
  printoutsCGQuotationList: 'ai-printouts-control-CGQuotationListPrintout',

  /*------------------------------------------Селекторы вкладки "Сделка"------------------------------------------*/

  /** id вкладки Сделка */
  tabApplicationNav: 'tab-Application-nav',

  /*------------Селекторы блока "ЗАДАЧИ ДОКУМЕНТА"------------*/

  /** id блока "ЗАДАЧИ ДОКУМЕНТА" */
  documentActivitiesSection: 'documentActivities',

  /** id кнопки поиска "Назначить задачу на себя" */
  btnAssignActivityToMe: 'btnAssignActivityToMe',

  /** id кнопки поиска "Назначить задачу на сотрудника" */

  /*------------Селекторы блока "Страхователь"------------*/

  /** id блока "Страхователь" */
  policyHolderSection: 'policy-holder-section',

  /** id кнопки поиска Страхователя */
  policyHolderSearch: 'policy-holder-search-button',

  /*------------Селекторы блока "Данные сделки"------------*/

  /** id блока "Данные сделки" */
  applicationDataSection: 'application-data-section',

  /** id checkbox "Сделка заведена в CRM" */
  integrationCRM: 'integrationCRM',

  /** id текстового поля "Ид сделки в CRM" */
  idCRM: 'idCRM',

  /** id combobox "Специальная программа" */
  specialProgramme: 'specialProgramme-ng-select',

  /** id combobox "Канал продаж" */
  salesChannel: 'salesChannel-ng-select',

  /** id combobox "Зона ответственности" */
  salesZone: 'salesZone-ng-select',

  /** id combobox "Профильная программа" */
  profileProgramme: 'atrDealProgram-ng-select',

  /** id combobox "Перевод портфеля ВТБс" */
  vtbTransition: 'VTBsTransition-ng-select',

  /** id checkbox "Признак ГПС" */
  signGPS: 'sign-GPS',

  /** id текстового поля "Подразделение" */
  departmentName: 'department-name',

  /** id кнопки поиска Подразделения */
  applicationBranchSearch: 'application-branch-search-dialog-button',

  /*----------------------------------------Селекторы вкладки "ГРУЗОПЕРЕВОЗКИ"----------------------------------------*/

  /** id вкладки "ГРУЗОПЕРЕВОЗКИ" */
  tabCargoNav: 'Cargo-nav',

  /*--------Селекторы блока "ОБЩИЕ ХАРАКТЕРИСТИКИ"--------*/

  /** id блока "ОБЩИЕ ХАРАКТЕРИСТИКИ" */
  mainPolicyDataSection: 'main-policy-data-section',

  /** id combobox "Вид договора" */
  documentType: 'documentType-ng-select',

  /** id combobox "Валюта" */
  description: 'currency-ng-select',

  /** id текстовое поле "Курс валюты " */
  currencyExchange: 'currency-exchange-rate-input',

  /** id checkbox "Валютная оговорка не применяется либо максимальное увеличение курса ЦБ РФ, указываемое в валютной оговорке, превышает 5%" */
  nonCurrencyDisput: 'nonCurrencyDisput',

  /*-------------Селекторы блока "Страхователь"-------------*/

  /** id блока "Страхователь" */
  policyHolderInfoSection: 'policy-holder-info-section',

  /** id combobox "Страхователь является:" */
  policyHolderRole: 'policyHolderRole-ng-select',

  /** id текстовое поле "Иное (укажите):" */
  policyHolderRoleText: 'policyHolderRoleText',

  /*------------Селекторы блока "ВЫГОДОПРИОБРЕТАТЕЛЬ"------------*/

  /** id блока "ВЫГОДОПРИОБРЕТАТЕЛЬ" */
  beneficiarySection: 'beneficiary-section',

  /** id подраздела блока "ВЫГОДОПРИОБРЕТАТЕЛЬ" */
  CGBeneficiaryData: 'CGBeneficiaryData-beneficiary',

  /** id кнопка поиска */
  beneficiarySearchButton: 'beneficiary-search-button',

  /** id текстовое поле "ИНН контрагента" */
  taxNumber: 'taxNumber',

  /** id текстовое поле "Категория контрагента" */
  categoryTax: 'category-ng-select',

  /** id checkbox "Выгодоприобретателем является Страхователь" */
  beneficiaryPolicyHolder: 'beneficiaryPolicyHolder',

  /** id checkbox "За счет кого следует (не определен) " */
  expenditionFollowsNotDefine: 'expenditionFollowsNotDefine',

  /*-------Селекторы блока "ХАРАКТЕРИСТИКИ ГРУЗОПЕРЕВОЗКИ"-------*/

  /** id блока "ХАРАКТЕРИСТИКИ ГРУЗОПЕРЕВОЗКИ" */
  informationSection: 'information-section',

  /** id подраздела блока "ХАРАКТЕРИСТИКИ ГРУЗОПЕРЕВОЗКИ" */
  CGInformationInformation: 'CGInformation-Information',

  /** id таблицы с выбранными грузами */
  informationDataGridTable: 'information-data-grid-table',

  /** id кнопка "Добавить" */
  informationDataGridAddButton: 'information-data-grid-add-button',

  /** id combobox "Вид груза" */
  cargoTypes: 'cargoTypes',

  /** id кнопка "Определить вид груза" */
  mainBusinessActivityButton: 'main-business-activity-search-dialog-button',

  /** id текстовое поле "Наименование". Форма поиска "ВИД ГРУЗА" */
  name: 'name',

  /** id кнопка "Поиск" */
  cargoTypeSearchButton: 'cargo-type-search-button',

  /** id кнопка "Выбрать". Форма "ВИД ГРУЗА" */
  видГрузаВыбрать: 'lookup-dialog-confirm-button',

  /** id кнопка "Отменить". Форма "ВИД ГРУЗА" */
  видГрузаОтменить: 'lookup-dialog-cancel-button',

  /** id текстовое поле "Вид груза" */
  type: 'Type',

  /** id текстовое поле "Категория перевозимого груза" */
  category: 'category',

  /** id текстовое поле "Процентное содержание" */
  percentage: 'percentage-input',

  /** id текстовое поле "Высоколиквидный груз" */
  cargoHighlyLiquid: 'cargoHighlyLiquid',

  /** id текстовое поле "Наименование груза" */
  cargoName: 'cargoName',

  /** id текстовое поле "Клиентский сегмент" */
  riskSegment: 'riskSegment',

  /** id текстовое поле "Код риска" */
  codeRisk: 'codeRisk',

  /** id текстовое поле "Класс риска" */
  classRisk: 'classRisk',

  /** id checkbox "Осуществляется перевозка продукции военного и/или "двойного" назначения" */
  isMilitaryorDual: 'isMilitaryorDual',

  /** id кнопка "ОК", добавление вида груза в таблицу. Блок "ХАРАКТЕРИСТИКИ ГРУЗОПЕРЕВОЗКИ" */
  informationDataGridOkButton: 'information-data-grid-ok-button',

  /** id кнопка "Отменить", отмена добавления вида груза в таблицу. Блок "ХАРАКТЕРИСТИКИ ГРУЗОПЕРЕВОЗКИ" */
  informationDataGridCancelButton: 'information-data-grid-cancel-button',

  /** id текстовое поле "Количество мест" */
  numberOfSeats: 'numberOfSeats-input',

  /** id текстовое поле "Вес (тонны)" */
  weight: 'weight-input',

  /** id кнопка "Удалить", корзинка в таблице с выбранными грузами */
  /** id кнопка "Редактировать", карандаш в таблице с выбранными грузами */

  /*-------------Селекторы блока "Состояние груза"-------------*/

  /** id блока "Состояние груза" */
  cargoConditionSection: 'cargo-condition-section',

  /** id checkbox "Новый груз" */
  newCargo: 'newCargo',

  /** id checkbox "Груз, бывший в употреблении" */
  usedCargo: 'usedCargo',

  /*----------------Селекторы блока "ТЕРРИТОРИЯ"----------------*/

  /** id блока "ТЕРРИТОРИЯ" */
  territorySection: 'territory-section',

  /** id combobox "Территория" */
  territory: 'AddressAutocomplete-ng-select',

  /** id checkbox "страны Европейского Союза" */
  EU: 'EUCheckbox',

  /** id checkbox "Российская Федерация" */
  RussianFederation: 'RussianFederationCheckbox',

  /** id checkbox "включая Крым, Севастополь" */
  Crimea: 'CrimeaCheckbox',

  /** id checkbox "включая ДНР, ЛНР, Запорожскую область и Херсонскую область" */
  DNRAndLNRAndZaporozhskayaOblAndKhersonskayaObl: 'DNRAndLNRAndZaporozhskayaOblAndKhersonskayaOblCheckbox',

  /** id checkbox "СНГ (исключая Украину, ДНР, ЛНР, Херсонскую область, Запорожскую область)" */
  CIS: 'CISCheckbox',

  /** id checkbox "Договор страхования заключается без "Оговорки о территориях-исключениях" (Украина, ДНР, ЛНР, Херсонская и Запорожская области страны и/или географические регионы, относящиеся к категориям «High» и выше в текущей классификации GCWL)" */
  isDisputOfTerritoryExeptions: 'isDisputOfTerritoryExeptions',

  /*----------Селекторы блока "ПУНКТЫ ОТПРАВЛЕНИЯ, НАЗНАЧЕНИЯ, ПЕРЕГРУЗКИ"----------*/

  /** id блока "ПУНКТЫ ОТПРАВЛЕНИЯ, НАЗНАЧЕНИЯ, ПЕРЕГРУЗКИ" */
  departureTypeSection: 'departure-type-section',

  /** id текстовое поле "Маршрут перевозки" */
  cargoRouteDetailes: 'cargoRouteDetailes',

  /** id checkbox "с места производства" */
  fromProductionPlace: 'fromProductionPlace',

  /** id checkbox "с иной точки" */
  fromAnotherPlace: 'fromAnotherPlace',

  /** id textbox "Пункт отправления" */
  departurePointInformation: 'departurePointInformation',

  /** id textbox "Пункт назначения" */
  destinationPointInformation: 'destinationPointInformation',

  /*----------Селекторы блока "ВИДЫ ТРАНСПОРТА"----------*/

  /** id блока "ВИДЫ ТРАНСПОРТА" */
  transportTypeSection: 'transportTypeAndSegmentsOfRoute-section',

  /** id checkbox "автомобильный" */
  automobile: 'automobile',

  /** id checkbox "воздушный" */
  air: 'air',

  /** id checkbox "железнодорожный" */
  railway: 'railway',

  /** id checkbox "водный" */
  water: 'water',

  /** id checkbox "Договор страхования заключается без "Оговорки о водном транспорте"" */
  concludedWithoutWaterTransportClause: 'concludedWithoutWaterTransportClause',

  /** id checkbox "судно не имеет действующий Класс в Российском морском регистре судоходства (РМРС), Международной ассоциации классификационных обществ (МАКО) или Российском классификационном обществе (РКО)" */
  nonClassInRMRSorRRR: 'nonClassInRMRSorRRR',

  /** id combobox "Способ отправки" */
  mandrelMethodWater: 'mandrelMethod-ng-select',

  /** id combobox "Возраст судна" */
  vesselAge: 'vesselAge-ng-select',

  /** id текстовое поле "IMO судна" */
  shipIMO: 'shipIMO-input',

  /** id текстовое поле "год реновации" */
  renovationYear: 'renovationYear',

  /** id checkbox "есть сюрвей судна" */
  isShipSurvey: 'isShipSurvey',

  /** id checkbox "реновация" */
  renovation: 'renovation',

  /** id checkbox "автомобили, используемые для перевозки груза, полностью закрыты жестким (не тент) кузовом-фургоном" */
  hardTop: 'hardTop',

  /*----------Селекторы блока "ДОПОЛНИТЕЛЬНАЯ ИНФОРМАЦИЯ О ПЕРЕВОЗКЕ(АХ)"----------*/

  /** id блока "ДОПОЛНИТЕЛЬНАЯ ИНФОРМАЦИЯ О ПЕРЕВОЗКЕ(АХ)" */
  additionalInformationSection: 'additional-information-section',

  /** id combobox "Для организации перевозки(ок) Страхователь" */
  insuredUseForTransportation: 'insuredUseForTransportation-ng-select',

  /** id combobox "Осмотр груза" */
  cargoInspection: '-ng-select',

  /** id checkbox "В договор будут включены ограничения по перевозчику" */
  contractIncludeCarrierRestriction: 'contractIncludeCarrierRestriction',

  /** id checkbox "В договор будут включены все требования по экспедитору" */
  contractIncludeAllRequirements: 'contractIncludeAllRequirements',

  /** id checkbox "Наличие физ.охраны на протяжении всего маршрута" */
  physicalSecurityonRoute: 'physicalSecurityonRoute',

  /** id checkbox "Охрана вооружена" */
  armedSecurity: 'armedSecurity',

  /*----------------Селекторы блока "ХРАНЕНИЕ ГРУЗА"----------------*/

  /** id блока "ХРАНЕНИЕ ГРУЗА" */
  cargoStorageSection: 'cargo-storage-section',

  /** id checkbox "хранение не предусмотрено" */
  nonStorageProvider: 'nonStorageProvider',

  /** id checkbox "хранение груза в пункте отправления" */
  departureStorage: 'departureStorage',

  /** id checkbox "В договор страхования не включается Оговорка о сюрвейерском осмотре (при включении рисков хранения в пункте отправления)" */
  surveyInDepartureStorageClause: 'surveyInDepartureStorageClause',

  /** id checkbox "хранение груза в пункте перегрузки" */
  transshipmentStorage: 'transshipmentStorage',

  /** id checkbox "хранение груза в пункте назначения" */
  /** id текстовое поле "Количество дней" (хранение груза в пункте назначения) */

  /** id текстовое поле "Количество дней" (хранение груза в пункте отправления) */
  departureStorageDays: 'departureStorageDays-input',

  /** id текстовое поле "Количество дней" (хранение груза в пункте перегрузки) */
  transshipmentStorageDays: 'transshipmentStorageDays-input',

  /*-------------Селекторы блока "СТРАХОВЫЕ СУММЫ, ЛИМИТЫ ОТВЕТСТВЕННОСТИ"-------------*/

  /** id блока "СТРАХОВЫЕ СУММЫ, ЛИМИТЫ ОТВЕТСТВЕННОСТИ" */
  sumInsuredAndLimitsSection: 'sumInsuredAndLimits-section',

  /** id текстовое поле "Грузооборот за период страхования" */
  sumInsuredinPeriod: 'sumInsuredinPeriod-input',

  /** id текстовое поле "Лимит ответственности по перевозке" */
  limitSumInsuredInPeriod: 'limitSumInsuredInPeriod-input',

  /** id текстовое поле "Лимит ответственности по перевозке (только высоколиквидные грузы)" */
  highlyLiquidLimitSumInsuredInPeriod: 'highlyLiquidLimitSumInsuredInPeriod-input',

  /** id текстовое поле "Средняя страховая сумма по перевозке" */
  averageSumInsured: 'averageSumInsured-input',

  /** id текстовое поле "Лимит ответственности на период хранения" */
  limitSumInsuredStorageInPeriod: 'limitSumInsuredStorageInPeriod-input',

  /** id текстовое поле "Страховая сумма" */
  sumInsured: 'sumInsured-input',

  /** id текстовое поле "Страховая сумма (только высоколиквидные грузы)" */
  highlyLiquidSumInsured: 'highlyLiquidSumInsured-input',

  /** id checkbox "Требуется исключение оговорки, предусматривающей стоянки автотранспорта в ночное время только на охраняемых территориях (при перевозке высоколиквидных грузов стоимостью более 30 млн руб.)" */
  excludeNightParkingClause: 'excludeNightParkingClause',

  /*----------------Селекторы блока "СТРАХОВЫЕ РИСКИ И СТРАХОВЫЕ ПОКРЫТИЯ"----------------*/

  /** id блока "СТРАХОВЫЕ РИСКИ И СТРАХОВЫЕ ПОКРЫТИЯ" */
  insuredRisksSection: 'insuredRisks-section',

  /** id combobox "Основное страховое покрытие на период перевозки (перевозок)" */
  basicInsuranceForTransportationPeriod: 'basicInsuranceForTransportationPeriod-ng-select',

  /** id combobox "Страховое покрытие на период хранения" */
  coverageOnStoragePeriod: 'coverageOnStoragePeriod-ng-select',

  /** id checkbox "Тротуарные риски (п. 3.3. ДУ№2 к Правилам)" */
  pavementRisks: 'pavementRisks',

  /** id checkbox "события, произошедшие до момента начала движения перевозочного средства в пункте отправления и/или после момента его остановки в пункте назначения" */
  eventsBeforeDepartureStartOrAfterStop: 'eventsBeforeDepartureStartOrAfterStop',

  /** id checkbox "события, произошедшие в период переноски ценностей от одного перевозочного средства до другого (если в течение перевозки производится перегрузка застрахованных ценностей с одного перевозочного средства на другое)" */
  eventsDuringTransfer: 'eventsDuringTransfer',

  /** id checkbox "мошеннические действия сотрудников Страхователя" */
  fraudulentInsuredActions: 'fraudulentInsuredActions',

  /** id checkbox "мошеннические действия сотрудников Страхователя на период хранения" */
  fraudulentInsuredActionsOnStoragePeriod: 'fraudulentInsuredActionsOnStoragePeriod',

  /** id checkbox "Не применяется" */
  nonFranchise: 'nonFranchise',

  /** id checkbox "В % от страховой суммы" */
  franchiseValue: 'franchiseValue',

  /** id checkbox "В рублях (валюте)" */
  franchiseInRuble: 'franchiseInRuble',

  /** id текстовое поле "Значение франшизы", если тип франшизы В % от страховой суммы */
  franchiseSizeValue: 'franchiseSizeValue-input',

  /** id текстовое поле "Значение франшизы", если тип франшизы В рублях (валюте) */
  franchiseSize: 'franchiseSize-input',

  /** id текстовое поле "но не менее (в валюте договора)" */
  franchiseSizeValueMore: 'franchiseSizeValueMore-input',

  /** id checkbox "отпотевание, согревание, плесень (п. 4.13.2 Правил)" */
  sweatingWarminMold: 'sweatingWarminMold',

  /** id checkbox "утрата или повреждение при целостности наружной упаковки (п. 4.13.6 Правил)" */
  lossOfDamageOuterPacking: 'lossOfDamageOuterPacking',

  /** id checkbox "рефрижераторный риск (п. 4.13.9 Правил)" */
  refrigerantRisk: 'refrigerantRisk',

  /** id текстовое поле "Франшиза, часов" */
  franchiseInHour: 'FranchiseInHour-input',

  /** id checkbox "в рефрижераторных установках не установлены / не исправны датчики температурного режима и/или рефрижераторная установка находится в неисправном состоянии на дату осуществления перевозки " */
  NonTempSencors: 'NonTempSencors',

  /*-------------------------------------------Селекторы вкладки "ОБЩАЯ ИНФОРМАЦИЯ"-------------------------------------------*/

  /** id вкладки "Общая информация" */
  tabGeneralInformation: 'tab-General-information-nav',

  /*-----------------Селекторы блока "ОБЩАЯ ИНФОРМАЦИЯ"-----------------*/

  /** id кнопки в таблице посредников "Добавить" */
  partnerTableButton: 'partners-data-grid-add-button',

  /** id кнопки поиска в таблице посредников */
  partnerSearch: 'partners-search-dialog-button',

  /** id textbox "Поиск по подстроке" */
  agentSearch: 'agent-search-input',

  /** id кнопки "Поиск" в форме "Поиск агентов" */
  agentSearchButton: 'agent-search-button',

  /** id кнопки "Выбрать" в форме "Поиск агентов" */
  agentConfirmButton: 'lookup-dialog-confirm-button',

  /** id кнопки "OK" в таблице посредников */
  partnersTableOk: 'partners-data-grid-ok-button',

  /** id textbox "Размер кв" */
  partnerCommissionPercentage: 'partner_commission_percentage-input',

  /** id таблицы "Посредники" */
  partnersDataGridTable: 'partners-data-grid-table',

  /*------Селекторы блока "СРОК СТРАХОВАНИЯ И ИСТОРИЯ СТРАХОВАНИЯ"------*/

  /** id блока "СРОК СТРАХОВАНИЯ И ИСТОРИЯ СТРАХОВАНИЯ" */
  insuranceDurationSection: 'insurance-duration-section',

  /** id подраздела в блоке "СРОК СТРАХОВАНИЯ И ИСТОРИЯ СТРАХОВАНИЯ" */
  CGInsuranceDuration: 'CGInsuranceDuration-insuranceDuration',

  /** id текстового поля "Дата начала" */
  startDate: 'startDate-input',

  /** id текстового поля "Дата окончания" */
  endDate: 'insurance-end-input',

  /** id текстового поля "Срок действия" */
  policyDuration: 'insurance-duration',

  /** id combobox "Наличие убытков за последние 3 года в других компаниях" */
  numberOfLosses5YearsInOtherCompany: 'numberOfLosses5YearsInOtherCompany-ng-select',

  /** id combobox "Период сотрудничества по страхованию грузов, лет" */
  cargoInsurancePeriodYears: 'cargoInsurancePeriodYears-ng-select',

  /** id текстового поля "Оплаченная премия по страхованию грузов за весь период" */
  fullPremiumForEntirePeriod: 'fullPremiumForEntirePeriod-input',

  /** id текстового поля "Сумма возвратов по договорам страхования грузов" */
  refundOfPolicy: 'refundOfPolicy-input',

  /** id текстового поля "Выплаченное КВ по договорам страхования грузов" */
  paidAgentComissions: 'paidAgentComissions-input',

  /** id текстового поля "Оплаченные убытки по страхованию грузов за весь период" */
  paidLosses: 'paidLosses-input',

  /** id текстового поля "Заявленные, но не урегулированные убытки по страхованию грузов" */
  claimLosses: 'claimLosses-input',

  /** id текстового поля "Убыточность по договору (договорам), %" */
  lossOfPolicyValue: 'lossOfPolicyValue-input',

  /** id текстового поля "Дата убытка" */
  lossDay: 'lossDay-input',

  /** id текстового поля "Сумма убытка (в валюте договора)" */
  sumOfLoss: 'sumOfLoss-input',

  /** id текстового поля "Описание" */
  lossComment: 'lossComment',

  /** id текстового поля "Выплаченные убытки по страхованию грузов" */
  paidLossesOfInsurance: 'paidLossesOfInsurance-input',

  /** id текстового поля "Заявленные, но не урегулированные убытки по страхованию грузов" */
  claimLossesOfInsurance: 'claimLossesOfInsurance-input',

  /** id текстового поля "Расчетная годовая убыточность по договору, %" */
  yearLossOfPolicyValue: 'yearLossOfPolicyValue-input',

  /** id button "Получить данные о просроченной СДЗ" */
  checkDebtButton: 'checkDebt-button',

  /** id button "Проверить убытки в 1С" */
  getLossFrom1CButton: 'getLossFrom1C-button',

  /** id textbox "Номер предыдущего Генерального полиса в СОГАЗ" */
  previousPolicy: 'previousPolicy',

  /** id текстового поля "Тариф по предыдущему Генеральному полису в СОГАЗ" */
  previousPolicyTariff: 'previousPolicyTariff-input',

  /** id секции с таблицей "Данные о просроченной СДЗ по предыдущему договору" */
  debtInformation: 'debtInformation',

  /** id таблицы "Данные о просроченной СДЗ по предыдущему договору" */
  debtInformationTable: 'debtInformation-table',

  /** id секции с проверкой убытков в 1С */
  CGLargestLosses1C: 'CGLargestLosses1C-#',

  /** id таблицы "10 крупнейших убытков по контрагенту за последние три года по транспортному страхованию грузов" */
  largestLossesTable: 'largestLosses-table',

  /** id текстового поля "Дата формирования" (убытки 1С) */
  largestLossesUpdateDate: 'largestLossesUpdateDate-input',

  /** id combobox "С момента" */
  startDateFrom: 'startDateFrom',

  /** id combobox "ДО момента" */
  endDateTo: 'endDateTo',

  /*-------------------Селекторы блока "СОСТРАХОВАНИЕ"-------------------*/

  /** id блока "Сострахование" */
  coinsuranceSection: 'coinsurance-section',

  /** id combobox "Сострахование" */
  coinsuranceAtr: 'coinsurance-atr-ng-select',

  /** id таблицы "Состраховщики" */
  coinsurersTable: 'coinsurers-table',

  /** id кнопки "Добавить" для таблицы "Состраховщики" */
  coinsurersTableAddButton: 'coinsurers-table-add-button',

  /** id combobox "Тип контрагента" */
  partyTypeCoinsurers: 'party-type-ng-select',

  /** id текстового поля "Наименование" */
  coinsurersOrganisationName: 'organisation-name',

  /** id текстового поля "ИНН" */
  coinsurersInn: 'inn',

  /** id текстового поля  "КПП" */
  coinsurersKpp: 'kpp',

  /** id текстового поля  "Доля состраховщика" */
  coinsurerShare: 'coinsurerShare-input',

  /*-------------Селекторы блока "НЕТИПОВАЯ ФОРМА ДОГОВОРА"-------------*/

  /** id checkbox "Требуется внесение изменений в типовую форму договора (в том числе исключение/ изменение обязательных оговорок) или использование нетиповой формы" */
  untypicalContract: 'untypicalContract',

  /** id текстовое поле "Изменения, которые необходимо внести в типовую форму" */
  untypicalItems: 'atr_rqs_untypical_items',

  /** id checkbox "Конкурсная форма договора (44-Ф3/223-Ф3)" */
  untypicalContract44223FZ: 'untypicalContract_44_223_FZ',

  /** id checkbox "Договор заключается без ссылки на Правила Страховщика" */
  untypicalContractNonTerms: 'untypicalContract_non_terms',

  /*-------------------------------------------Селекторы вкладки "Оговорки"-------------------------------------------*/

  /** id вкладки "Оговорки" */
  tabClausesNav: 'Clauses-tab-nav',

  /** id таблицы с оговорками */
  clausesTable: 'clauses-table',

  /*-------------------------------------------Селекторы вкладки "РАСЧЕТ ТАРИФА И ТРИГГЕРЫ"-------------------------------------------*/

  /** id вкладки "РАСЧЕТ ТАРИФА И ТРИГГЕРЫ" */
  tabTariffCalculationAndUWReview: 'tab-Tariff-calculation and UW review-nav',

  /*-----------------Селекторы блока "Расчет премии"-----------------*/

  /** id блока "Расчет премии" */
  premiumCalculationSection: 'premium-calculation-section',

  /** id текстовое поле "Нагрузка по договору страхования (%)" */
  contractLoadValue: 'contractLoadValue',

  /** id текстовое поле "Нагрузка по договору страхования (%)" */
  contractLoad: 'contract-load-value-input',

  /** id checkbox "Корректировка тарифа" */
  correctTariff: 'correctTariff',

  /** id текстовое поле "Укажите тариф, %" */
  tariffValue: 'tariffValue',

  /** id checkbox "Вернуть расчетную премию" */
  showOriginalTariff: 'showOriginalTariff',

  /** id кнопка "Подтвердить" */
  confirmButton: 'confirm-button',

  /** id текстовое поле "Грузооборот за период страхования" */
  sumInsuredinPeriodtabTariff: 'sumInsuredinPeriod-input',

  /** id текстовое поле "Страховая сумма" */
  sumInsuredTabTariff: 'sumInsured-input',

  /** id текстовое поле "Итоговый андеррайтерский коэффициент" */
  totalUnderwritingFactor: 'totalUnderwritingFactor-input',

  /** id текстовое поле "Брутто-премия по договору" */
  grossPremiumPolicy: 'grossPremiumPolicy-input',

  /** id текстовое поле "Брутто-тариф по договору" */
  grossTariffPolicy: 'grossTariffPolicy-input',

  /** id текстовое поле "Средняя премия по одной перевозке" */
  averagePremiumInsured: 'averagePremiumInsured-input',

  /** id текстовое поле "Максимальная премия по одной перевозке" */
  maxPremiumInsured: 'maxPremiumInsured-input',

  /*-----------Селекторы блока "ПОПРАВОЧНЫЕ КОЭФФИЦИЕНТЫ"-----------*/

  /** id блока "ПОПРАВОЧНЫЕ КОЭФФИЦИЕНТЫ" */
  coefficientsSection: 'coefficients-section',

  /** id таблицы с коэффициентами "Коэффициенты на период перевозки" */
  coefficientsForTransportationTable: 'coefficients-for-transportation-data-grid-table',

  /*-----------------Селекторы блока "КОММЕНТАРИИ"-----------------*/

  /** id блока "КОММЕНТАРИИ" */
  commentsSection: 'comments-section',

  /** id кнопка "Добавить" */
  commentsSectionAddButton: 'comments-section-add-button',

  /** id текстовое поле "Комментарии" */
  commentsTextArea: 'comments-text-area',

  /*-------------------Селекторы блока "ТРИГГЕРЫ"-------------------*/

  /** id блока "КОММЕНТАРИИ" */
  constraintsSection: 'constraints-section',

  /** id таблицы с триггерами */
  aiDataGridConstraints: 'ai-data-grid',

  /** id combobox "Статус" */
  commonTargetState: 'commonTargetState-ng-select',

  /** id кнопка "Выбрать" */
  updateConstraintsButton: 'update-constraints-button',

  /** id checkbox "Требуется решение андеррайтера Головного офиса (3 уровень)" */
  quoteApprovalUnderwriterLevel3: 'quoteApprovalUnderwriterLevel3',

  /** id checkbox "Требуется стандартный бизнес-цикл согласования после статуса «На корректировке»" */
  fullCycleApproval: 'full-cycle-approval',

  /*----------------Селекторы блока "ПЕРЕСТРАХОВАНИЕ"----------------*/

  /** id блока "ПЕРЕСТРАХОВАНИЕ" */
  reinsuranceSection: 'reinsurance-section',

  /** id combobox "Требуется факультативное перестрахование" */
  farceReinsurance: 'farceReinsurance-ng-select',

  /** id checkbox "Перестрахование в рамках морского облигаторного договора" */
  reinsuranceMarineObligatoryContract: 'reinsuranceMarineObligatoryContract',

  /** id checkbox "Перестрахование в рамках военного облигаторного договора" */
  reinsuranceMilitaryObligatoryContract: 'reinsuranceMilitaryObligatoryContract',

  /*-------------------------------------------Селекторы вкладки "ВЛОЖЕНИЯ"-------------------------------------------*/

  /** id вкладки "ВЛОЖЕНИЯ" */
  tabAttachedDocuments: 'tab-Attached-documents-nav',
}

const policyCargo = {
  /*------------------------------------------Селекторы списка действий документа "Договор"---------------------------------*/

  /** id кнопки действия "Направить заявку на оформление" */
  controlRequestToDraft: 'ai-transitions-relations-control-Request_to_Draft',

  /** id кнопки действия "Направить на согласование" (статус Draft/Новый) */
  controlDraftToForApprovalL1: 'ai-transitions-relations-control-Draft_to_ForApprovalL1',

  /** id кнопки действия "Направить на согласование" (статус На корректировку/ForCorrection) */
  controlForCorrectionSendToHigherLevel: 'ai-transitions-relations-control-ForCorrection_SendToHigherLevel',

  /** id кнопки действия "На подписание" */
  controlApprovedToForSigning: 'ai-transitions-relations-control-Approved_to_ForSigning',

  /** id кнопки действия "Отозвать" (текущий статус Согласован/Approved) */
  controlApprovedToForCorrection: 'ai-transitions-relations-control-Approved_to_ForCorrection',

  /** id кнопки действия "Отозвать" (текущий статус Draft/Новый) */
  controlDraftToRequestAgent: 'ai-transitions-relations-control-Draft_to_Request_Agent',

  /** id кнопки действия "Подписан" (текущий статус Согласован/Approved) */
  controlApprovedToSigned: 'ai-transitions-relations-control-Approved_to_Signed',

  /** id кнопки действия "Подписан" (текущий статус ForSigning) */
  controlForSigningToSigned: 'ai-transitions-relations-control-ForSigning_to_Signed',

  /** id кнопки действия "Аннулировать" (текущий статус Согласован/Approved) */
  controlApprovedToAnnulled: 'ai-transitions-relations-control-Approved_to_Annulled',

  /** id кнопки действия "Аннулировать" (текущий статус Draft/Новый) */
  controlDraftToAnnulledAgent: 'ai-transitions-relations-control-Draft_to_Annulled_Agent',

  /** id кнопки действия "Аннулировать" (текущий статус Request/Заявка) */
  controlRequestToAnnulled: 'ai-transitions-relations-control-Request_to_Annulled',

  /** id кнопки действия "Аннулировать" (текущий статус На корректировку/ForCorrection) */
  controlForCorrectionToAnnulled: 'ai-transitions-relations-control-ForCorrection_to_Annulled',

  /** id кнопки действия "Аннулировать" (текущий статус На подписании/ForSigning) */
  controlForSigningToAnnulled: 'ai-transitions-relations-control-ForSigning_to_Annulled',

  /** id кнопки действия "Активировать" */
  controlSignedToActivated: 'ai-transitions-relations-control-Signed_to_Activated',

  /** id кнопки действия "Отказать в интеграции" */
  controlSignedToDisableIntegration: 'ai-transitions-relations-control-Signed_to_DisableIntegration',

  /** id текстовое поле "Номер договора страхования в 1С:" */
  insurancePolicyNumber1C: 'insurancePolicyNumber1C',

  /** id кнопки действия "На подписание" (CARGO EXPRESS) (текущий статус Draft/Новый) */
  controlDraftToForSigning: 'ai-transitions-relations-control-Draft_to_ForSigning',

  /** id кнопки действия "Аннулировать" (CARGO EXPRESS) (текущий статус Draft/Новый) */
  controlDraftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',

  /** id текстовое поле "Подписан" (CARGO EXPRESS) из статуса Новый */
  controlDraftToSigning: 'ai-transitions-relations-control-Draft_to_Signed',

  /** id кнопки действия "Создать копию" (CARGO EXPRESS) */
  controlCGCopyCargoExpressPolicy: 'ai-transitions-relations-control-CGCopyCargoExpressPolicy',

  /** id текстовое поле "Вернуть в статус "На подписании"" */
  controlAnnulledToForSigning: 'ai-transitions-relations-control-Annulled_to_ForSigning',

  /** id кнопки действия "Вернуть в статус "Новый"" (CARGO EXPRESS) */
  controlAnnulledToDraft: 'ai-transitions-relations-control-Annulled_to_Draft',

  /** id кнопки действия "Создать страховой сертификат" */
  controlCGCreateInsuranceCertificate: 'ai-transitions-relations-control-CGCreateInsuranceCertificate',

  /** id кнопки действия "Создать декларацию за период" */
  controlCGCreatePeriodDeclaration: 'ai-transitions-relations-control-CGCreatePeriodDeclaration',

  /*------------------------------------------Селекторы вкладки "Условия договора"------------------------------------------*/

  /** id вкладки "Условия договора" */
  tabCGPolicyConditions: 'CGPolicyConditions-nav',

  /*-----------------Селекторы блока "Условия договора"-----------------*/

  /** id блока "Условия договора" */
  policyConditionsSection: 'policy-conditions-section',

  /** id текстовое поле "Краткое содержание" */
  policyShortDescription: 'short-description',

  /** id текстовое поле "Дата письменного заявления" */
  dateOfWrittenApplication: 'application-date-input',

  /** id текстовое поле "Менеджер договора" */
  policyManagerFio: 'policyManagerFio',

  /** id checkbox "Являюсь менеджером договора" */
  policyManagerIsCurrentUser: 'policyManagerIsCurrentUser',

  /** id текстовое поле "Менеджер по продажам" */
  salesManagerFio: 'salesManagerFio',

  /** id checkbox "Являюсь менеджером по продажам" */
  salesManagerIsCurrentUser: 'salesManagerIsCurrentUser',

  /** id текстовое поле "Дата заключения" */
  conclusionDate: 'conclusion-date-input',

  /** id checkbox "Договор страхования предусматривает необходимость открытия счета любого типа в банке, в том числе под операции в рамках государственного оборонного заказа или государственного контракта " */
  needBank: 'need-bank-checkbox',

  /** id checkbox "Договор страхования предусматривает необходимость открытия отдельного счета в подразделениях Федерального казначейства под операции и осуществления казначейского сопровождения в рамках государственного контракта" */
  needTreasury: 'need-treasury-checkbox',

  /*--------------------Селекторы блока "ПОДПИСАНТЫ"--------------------*/

  /** id блока "ПОДПИСАНТЫ" */
  representativesSection: 'representatives-section',

  /** id текстовое поле "ФИО подписанта от имени Страховщика" */
  insurerRepresentativeFIO: 'representative-fio',

  /** id текстовое поле "Документ-основание" */
  insurerRepresentativeDoc: 'representative-doc',

  /** id текстовое поле "Дата документа-основания" */
  insurerRepresentativeDocDate: 'representative-doc-date-input',

  /** id текстовое поле "Должность подписанта от имени Страховщика" */
  insurerRepresentativeRank: 'representative-rank',

  /** id combobox "Банк для указания реквизитов оплаты" */
  bankInfo: 'preamble-bank-info-ng-select',

  /** id текстовое поле "Документ-основание" */
  baseDocument: 'party-doc',

  /** id текстовое поле "Дата документа-основания" */
  baseDocumentDate: 'party-doc-date-input',

  /** id текстовое поле "Должность подписанта от имени Страхователя" */
  rank: 'party-rank',

  /** id button кнопка лупа "ФИО подписанта от имени Страхователя" */
  partySearch: 'party-search',

  /** id текстовое поле "Поиск" */
  partyapiSearch: 'partyapi-search',

  /** id button кнопка поиска "Искать" */
  partyapiSearchButton: 'partyapi-search-button',

  /** id checkbox "Требуется оформление специальной доверенности" */
  needAttorney: 'need-attorney-checkbox',

  /*--------Селекторы блока "Дополнительная информация о страхователе"--------*/

  /** id блока "Дополнительная информация о страхователе" */
  additionalHolderInformationSection: 'additionalHolderInformation-section',

  /** id текстовое поле "Электронная почта для направления уведомлений/извещений" */
  emailForNotifications: 'emailForNotifications',

  /*----------------Селекторы блока "Декларирование перевозок"----------------*/

  /** id блока "Декларирование перевозок" */
  declarationOfTransportationSection: 'declarationOfTransportation-section',

  /** id combobox "С декларированием" */
  withDeclaration: 'withDeclaration-ng-select',

  /** id combobox "Общая страховая сумма по договору страхования будет определена как сумма страховых сумм по отдельным перевозкам (в соответствии с Декларациями об отгрузке)" */
  totalSumInsuredEqualSumOfTransportation: 'totalSumInsuredEqualSumOfTransportation-ng-select',

  /** id combobox "Договором страхования предусмотрено установление Выгодоприобретателя по каждой перевозке отдельно (в соответствии с Декларацией об отгрузке)" */
  needBeneficiaryForEachTransportation: 'needBeneficiaryForEachTransportation-ng-select',

  /*----------------Селекторы блока "Перевозчики и экспедиторы"----------------*/

  /** id блока "Перевозчики и экспедиторы" */
  carriersAndForvardersSection: 'carriersAndForvarders-section',

  /** id таблицы блока "Перевозчики и экспедиторы" */
  carriersAndForvardersDataGrid: 'carriers-and-forvarders-data-grid',

  /** id кнопки "Добавить" для таблицы блока */
  carriersAndForvardersAddButton: 'carriers-and-forvarders-data-grid-add-button',

  /** id combobox "Тип контрагента" для добавления в таблицу блока */
  partyType: 'partyType',

  /** id combobox "Полное наименование" для добавления в таблицу блока */
  fullName: 'fullName',

  /** id textbox "Поиск" для добавления в таблицу блока */
  partyApi: 'partyapi-search',

  /** id textbox "Поиск" блока "Перевозчики и экспедиторы" */
  partyName: 'party-name',

  /** id textbox "ИНН" блока "Перевозчики и экспедиторы" для ЮЛ */
  partyInn: 'party-inn',

  /** id textbox "ИНН" блока "Перевозчики и экспедиторы" для ИП */
  ieInn: 'ie-inn',

  /** id textbox "Фамилия" блока "Перевозчики и экспедиторы" для ИП */
  ieLastName: 'ie-last-name',

  /** id textbox "Имя" блока "Перевозчики и экспедиторы" для ИП */
  ieFirstName: 'ie-first-name',

  /** id textbox "Отчество" блока "Перевозчики и экспедиторы" для ИП */
  ieMiddleName: 'ie-middle-name',

  /** id checkbox "Перевозчик(и) не известен(ны) на момент заключения договора страхования" */
  carrierIsUnknown: 'carrierIsUnknown',

  /** id checkbox "Экспедитор(ы) не известен(ны) на момент заключения договора страхования" */
  forwarderIsUnknown: 'forwarderIsUnknown',

  /** id combobox "Тип контрагента" (ИП/ЮЛ) */
  partyTypeDropdown: 'party-type-dropdown-ng-select',

  /** id combobox 'Поиск контрагента в системах' в таблице блока */
  systemSelectionDropdown: 'system-selection-dropdown-ng-select',

  /*-----------------Селекторы блока "Транспортные документы"-----------------*/

  /** id блока "Транспортные документы" */
  transportDocumentsSection: 'transportDocuments-section',

  /** id checkbox "На момент оформления договора страхования транспортные документы отсутствуют" */
  noTransportDocuments: 'noTransportDocuments',

  /*-------------------Селекторы блока "ДОКУМЕНТЫ ПО ПЕРЕВОЗКЕ"-------------------*/

  /** id блока "ДОКУМЕНТЫ ПО ПЕРЕВОЗКЕ" */
  deliveryDocumentsSection: 'deliveryDocuments-section',

  /** id checkbox "Страхователем предоставлен Список договоров поставки" */
  listOfContractsWasProvided: 'listOfContractsWasProvided',

  /** id текстовое поле "Документ поставки" */
  deliveryDocument: 'deliveryDocument',

  /** id текстовое поле "Дата документа поставки" */
  dateOfDeliveryDocument: 'dateOfDeliveryDocument-input',

  /** id текстовое поле "Дополнительная информация" */
  additionalInformation: 'additionalInformation',

  /** id таблицы блока "Документы поставки" */
  deliveryDocumentsDataGrid: 'delivery-documents-data-grid',

  /** id кнопки "Добавить" */
  deliveryDocumentsAddButton: 'delivery-documents-data-grid-add-button',

  /** id кнопки "ОК" */
  deliveryDocumentsOKButton: 'delivery-documents-data-grid-ok-button',

  /** id combobox "Базис поставки по ИНКОТЕРМС" */
  INCOTERMSDelivery: 'INCOTERMSDelivery-ng-select',

  /*------------------------Селекторы блока "Оговорки"------------------------*/

  /** id блока "Оговорки" */
  reservationsSection: 'reservations-section',

  /** id combobox "Наличие оговорки об отказе Страховщика от прав требования по суброгации" */
  reservationOfSubrogationWaiver: 'reservationOfSubrogationWaiver',

  /** id combobox "Наличие оговорки о рассмотрении споров в коммерческом арбитраже" */
  disputInCommArbitration: 'disputInCommArbitration',

  /** id combobox "Договором страхования прямо предусмотрено исключение НДС из суммы страхового возмещения" */
  exclusionOfVAT: 'exclusionOfVAT',

  /** id combobox "Общая страховая сумма по договору страхования будет определена как сумма страховых сумм по отдельным перевозкам (в соответствии с Декларациями об отгрузке)" */
  totalSumInsuredEqualSumOfTransportation: 'totalSumInsuredEqualSumOfTransportation',

  /** id combobox "Договором страхования предусмотрено установление Выгодоприобретателя по каждой перевозке отдельно (в соответствии с Декларацией об отгрузке)" */
  needBeneficiaryForEachTransportation: 'needBeneficiaryForEachTransportation',

  /*---------------------Селекторы блока "Форма договора"---------------------*/

  /** id блока "Форма договора" */
  policyFormSection: 'policy-form',

  /*--------------Селекторы блока "Ретроактивная ответственность"--------------*/

  /** id блока "Ретроактивная ответственность" */
  policyConditionRetroactiveSection: 'policyConditionRetroactive-section',

  /** id checkbox "Требуется включение условия о ретроактивной дате" */
  policyConditionOfRetroactiveDate: 'policyConditionOfRetroactiveDate',

  /** id текстовое поле "Причина требования включения условия о ретроактивной дате" */
  policyConditionOfRetroactiveComment: 'policyConditionOfRetroactiveComment',

  /** id текстовое поле "Требуемая дата начала срока страхования" */
  policyRetroactiveStartDate: 'policyRetroactiveStartDate-input',

  /** id combobox "Включение оговорки" */
  inclusionOfReservation: 'inclusionOfReservation-ng-select',

  /** id checkbox "Получена декларация от Страхователя об отсутствии страховых случаев / о наличии причин, которые могут повлечь наступление страхового случая или Страхователю отправлено уведомление о непризнании страховыми случаями событий, наступивших в ретроактивный период" */
  retroactiveDeclaration: 'retroactive-declaration',

  /** id checkbox "В период ретроактивной ответственности произошли события (причины событий), имеющие признаки страховых случаев" */
  retroactiveLosses: 'retroactive-losses',

  /** id текстовое поле "Описание событий (причин событий), в т.ч. дата наступления" */
  retroactiveLossesDescription: 'retroactive-losses-description',

  /*--------------Селекторы блока "Уровень согласования договора"--------------*/

  /** id блока "Уровень согласования договора" */
  policyApprovalSection: 'policy-approval-section',

  /*------Селекторы блока "Ручной бизнес-цикл согласования (дополнительно)"------*/

  /** id блока "Ручной бизнес-цикл согласования (дополнительно)" */
  coerciveTriggersSection: 'coercive-triggers-section',

  /** id checkbox "Ручной триггер для согласования с андеррайтером" */
  policyCoerciveTriggerUw: 'policyCoerciveTriggerUw',

  /** id combobox "Уровень андеррайтера" */
  policyCoerciveTriggerUwLevel: 'policyCoerciveTriggerUwLevel',

  /** id textbox "Укажите причину повторного согласования с андеррайтером" */
  policyCoerciveTriggerUwReason: 'policyCoerciveTriggerUwReason',

  /** id checkbox "Ручной триггер для согласования с Юридическим подразделением" */
  policyCoerciveTriggerLD: 'policyCoerciveTriggerLD',

  /** id textbox "Укажите причину согласования с Юристом" */
  policyCoerciveTriggerLDReason: 'policyCoerciveTriggerLDReason',

  /** id checkbox "Ручной триггер для согласования с Подразделением урегулирования убытков" */
  policyCoerciveTriggerLosses: 'policyCoerciveTriggerLosses',

  /** id textbox "Укажите причину согласования с Подразделением урегулирования убытков" */
  policyCoerciveTriggerLossesReason: 'policyCoerciveTriggerLossesReason',

  /** id checkbox "Ручной триггер для согласования с Бухгалтерией" */
  policyCoerciveTriggerDBU: 'policyCoerciveTriggerDBU',

  /** id textbox "Укажите причину согласования с Бухгалтерией" */
  policyCoerciveTriggerDBUReason: 'policyCoerciveTriggerDBUReason',

  /** id checkbox "Ручной триггер для согласования с Дирекцией по операционной эффективности" */
  policyCoerciveTriggerRiskAnalysis: 'policyCoerciveTriggerRiskAnalysis',

  /** id textbox "Укажите причину согласования с Дирекцией по операционной эффективности" */
  policyCoerciveTriggerRiskAnalysisReason: 'policyCoerciveTriggerRiskAnalysisReason',

  /** id checkbox "Ручной триггер для согласования с Отделом расчетных и казначейских операций" */
  policyCoerciveTriggerFinance: 'policyCoerciveTriggerFinance',

  /** id textbox "Укажите причину согласования с Отделом расчетных и казначейских операций" */
  policyCoerciveTriggerFinanceReason: 'policyCoerciveTriggerFinanceReason',

  /** id checkbox "Ручной триггер для согласования с Перестрахованием" */
  policyCoerciveTriggerReinsurance: 'policyCoerciveTriggerReinsurance',

  /** id textbox "Укажите причину согласования с Перестрахованием" */
  policyCoerciveTriggerReinsuranceReason: 'policyCoerciveTriggerReinsuranceReason',

  /** id checkbox "Ручной триггер для согласования с ООВК" */
  policyCoerciveTriggerOOVK: 'policyCoerciveTriggerOOVK',

  /*---------------------------------------------Селекторы вкладки "История согласования"---------------------------------------------*/

  /** id вкладки "История согласования" */
  tabContractActivityTransitionHistory: 'tab-Contract-activity and transition history-nav',

  /*-----------------------------------------Селекторы вкладки "ГРАФИК ПЛАТЕЖЕЙ И ДЕКЛАРАЦИЙ"-----------------------------------------*/

  /** id вкладки "ГРАФИК ПЛАТЕЖЕЙ И ДЕКЛАРАЦИЙ" */
  tabPaymentsAndDeclarations: 'ScheduleOfPaymentsAndDeclarations-nav',

  /** id combobox "Периодичность декларирования" */
  frequencyOfDeclaration: 'frequencyOfDeclaration',

  /** id текстовое поле "Дата предоставления первой декларации" */
  firstDeclarationDate: 'firstDeclarationDate-input',

  /** id combobox "Уплата премии" */
  premiumPayment: 'premiumPayment-ng-select',

  /** id текстовое поле "Срок оплаты счета, раб. дней" */
  invoicePaymentDueDate: 'invoicePaymentDueDate-input',

  /** id текстовое поле "Дата платежа" */
  paymentDate: 'paymentDate-input',

  /** id текстовое поле "Сумма платежа" */
  payment: 'payment-input',

  /** id button "Добавить" в таблице с ручным графиком */
  manualPaymentAddButton: 'manual-payment-data-grid-add-button',

  /** id текстовое поле "Срок направления декларации, не позднее (дней)" */
  termSubmittingOfDeclaration: 'termSubmittingOfDeclaration-input',

  /*-----------------------------------------------Селекторы вкладки "ПЕРЕСТРАХОВАНИЕ"-----------------------------------------------*/

  /** id вкладки "ПЕРЕСТРАХОВАНИЕ" */
  tabReinsurance: 'Reinsurance-nav',

  /** id текстовое поле "МВУ, в рублях" */
  facrePMLRub: 'facrePMLRub-input',

  /** id текстовое поле "Номер сделки в CRM" */
  crmApplicationNumber: 'CRMApplicationNumber',

  /** id текстовое поле "Начисленная премия в факультативное перестрахование по доле, в рублях" */
  facrePremium: 'facrePremium-input',

  /** id текстовое поле "Собственное удержание, в рублях" */
  facreOwnRetention: 'facreOwnRetention-input',

  /** id combobox "Тип перестрахования" */
  facreType: 'facreType-ng-select',

  /** id combobox "База перестрахования" */
  facreBasic: 'facreBasic-ng-select',

  /*-------------------------------------------Селекторы вкладки "РАСЧЕТ ТАРИФА И ТРИГГЕРЫ"-------------------------------------------*/

  /*-------------------Селекторы блока "ТРИГГЕРЫ"-------------------*/

  /** id таблицы с триггерами */
  aiDataGridConstraints: 'ai-data-grid',

  /** id combobox "Статус" */
  policyTriggerState: 'policy-state-ng-select',

  /** id кнопка "Выбрать" */
  policyStateButton: 'policy-state-button',

  /*-----------------------------------------Селекторы вкладки "ОБЩАЯ ИНФОРМАЦИЯ" CARGO EXPRESS-----------------------------------------*/

  /** id вкладки "ОБЩАЯ ИНФОРМАЦИЯ" */
  tabGeneralInformationNav: 'tab-general-information-nav',

  /*-----------------Селекторы блока "Варианты страхования"-----------------*/

  /** id таблицы с вариантами страхования, обращение к элементам таблицы через индекс */
  repSelectWidthDetail: 'rep-select-width-detail',

  /** id checkbox "Корректировка премии" */
  correctPremium: 'correctPremium',

  /** id текстовое поле "Премия (скорректированная)" */
  correctPremiumInput: 'correctedPremium-input',

  /** id текстовое поле "Расчетная премия по выбранному варианту страхования" */
  calculatedPremiumInput: 'calculatedPremium-input',

  /*--------------------Селекторы блока "Страхователь"--------------------*/

  /** id кнопки "Поиска Страхователя" */
  policyHolderSearchCargoExpress: 'policy-holder-search-button',

  /** id textbox "Наименование (как в Полисе)" */
  nameForPrint: 'nameForPrint',

  /*--------------------Селекторы блока "ПОСРЕДНИКИ И КВ"--------------------*/

  /** id блока "ПОСРЕДНИКИ И КВ" */
  partnersSection: 'partners-section',

  /** id текстовое поле "Нагрузка по договору страхования (%)" */
  contractLoadValue: 'contractLoadValue-input',

  /*--------------------Селекторы блока "Орг. структура"--------------------*/

  /** id текстовое поле "Филиал СОГАЗ" */
  orgStructure: 'org-structure',

  /*-----------------------------------------Селекторы вкладки "УСЛОВИЯ ДОГОВОРА" CARGO EXPRESS-----------------------------------------*/

  /** id вкладки "УСЛОВИЯ ДОГОВОРА" */
  tabPolicyConditionsData: 'tab-policy-conditions-data-nav',

  /** id checkbox "страны страны ЕС" */
  EU: 'EU',

  /** id checkbox "СНГ (исключая Украину, ДНР, ЛНР, Херсонскую область, Запорожскую область)" */
  CIS: 'CIS',

  /** id checkbox "Российская Федерация" */
  RussianFederation: 'RussianFederation',

  /** id button "Добавить" Документы по перевозке */
  shippingDocumentsAdd: 'shipping-documents-data-grid-add-button',

  /** id button "Отменить" Документы по перевозке */
  shippingDocumentsCancel: 'shipping-documents-data-grid-cancel-button',

  /** id button "ОК" Документы по перевозке */
  shippingDocumentsOK: 'shipping-documents-data-grid-ok-button',

  /** id текстовое поле "Дата" Документы по перевозке */
  documentDate: 'documentDate-input',

  /** id textbox "Номер" Документы по перевозке */
  documentNumber: 'documentNumber',

  /** id textbox "Иной" Документы по перевозке */
  specifyDocument: 'specifyDocument',

  /** id combobox "Документ" Документы по перевозке */
  documentTypeC: 'documentType-ng-select',

  /*-------------------------------------------Селекторы вкладки "Выпуск договора" CARGO EXPRESS-------------------------------------------*/

  /** id вкладки "Выпуск договора" */
  tabIssueContract: 'tab-Issue-contract-nav',

  /** id combobox "Вариант заключения" */
  conclusionType: 'conclusionType',

  /** id combobox "Способ подписания" */
  signingType: 'signingType',

  /** id button лупа-поиск в блоке Подписание */
  employeeSearchButton: 'employee-search-dialog-button',

  /** id textbox "Поиск" Поиск сотрудников */
  employeeSearchInput: 'employee-search-input',

  /** id button "Поиск" Поиск сотрудников */
  searchButtonEmployee: 'employee-search-button',

  /** id combobox "ФИО подписанта от имени Страховщика" */
  signatoryName: 'signatoryName',

  /** id текстовое поле "Дата выдачи договора Страхователю" */
  issueDate: 'issueDate-input',

  /** id текстовое поле "Дата документа-основания" */
  validFrom: 'validFrom-input',

  /** id textbox "Документ-основание" */
  numberDoc: 'number',

  /** id textbox "Должность подписанта от имени Страховщика" */
  signatoryPosition: 'signatoryPosition',

  /** id combobox "Уплата премии" */
  paymentFrequency: 'paymentFrequency',

  /** id таблица "График платежей" */
  paymentPlanDataGrid: 'payment-plan-data-grid',

  /** id combobox "Банк для указания реквизитов оплаты" */
  bankInfoCE: 'bankInfo-ng-select',

  /*-------------------------------------------Селекторы вкладки "История согласования" CARGO EXPRESS-------------------------------------------*/

  /** id вкладки "История согласования" */
  tabContractActivity: 'tab-Contract-activity-nav',

  /*-----------------------------------------Селекторы элементов бокового информационного меню CARGO EXPRESS-------------------*/

  /** id блока с элементами "Общая информация" */
  CGESummary: 'CGESummary-#',

  /*-------------------------------------------Селекторы вкладки "Проверка СБ"-------------------------------------------*/

  /** id вкладки Проверка СБ */
  tabCheckingSBnav: 'tab-Checking-SB-nav',

  /** id textbox "Комментарий СБ" */
  sbComment: 'SBComment',

  /*-----------------------------------------Селекторы печатных форм-------------------*/

  /** id в списке печатных форм "Полис (pdf)" в CARGO EXPRESS */
  CGEPolicyPrintout: 'ai-printouts-control-CGEPolicyPrintout',

  /** id в списке печатных форм "Счет на оплату" */
  CGEInvoicePrintout: 'ai-printouts-control-CGEInvoicePrintout',

  /** id в списке печатных форм "Сопроводительный лист" в CARGO EXPRESS */
  CGECoverListOfPolicyPrintout: 'ai-printouts-control-CGECoverListOfPolicyPrintout',

  /** id в списке печатных форм "Полис (pdf)" в Грузах (Cargo) */
  CGPolicyPrintoutPDF: 'ai-printouts-control-CGPolicyPrintoutPDF',

  /** id в списке печатных форм "Лист согласования" */
  CGDocumentApprovalListPrintout: 'ai-printouts-control-CGDocumentApprovalListPrintout',

  /** id в списке печатных форм "Сопроводительный лист" в Грузах (Cargo) */
  CGCoverListOfPolicyPrintout: 'ai-printouts-control-CGCoverListOfPolicyPrintout',
}

const partyCard = {
  // В карточке контрагента для Грузов требуются только блоки САНКЦИИ, СБ и ООВК

  /** Папка  "Контрагенты" */
  partiesMenu: 'Parties_menu_1',

  /** Папка  "Поиск контрагентов" */
  detailedPartySearchView: 'DetailedPartySearchView_1_2',

  /** id блока СБ (для ЮЛ) */
  lekzSection: 'lekz-section',

  /** id блока СБ (для ИП) */
  iekzSection: 'iekz-section',

  /** id блока СБ (для ФЛ) */
  npkzSection: 'npkz-section',

  /** id checkbox Отметка о проверке Страхователя сотрудником Отдела СБ  (для ЮЛ) */
  lekzCheckbox: 'lekz-checkbox',

  /** id checkbox Отметка о проверке Страхователя сотрудником Отдела СБ  (для ИП) */
  iekzCheckbox: 'iekz-checkbox',

  /** id checkbox Отметка о проверке Страхователя сотрудником Отдела СБ  (для ФЛ) */
  npkzCheckbox: 'npkz-checkbox',

  /** id textbox Комментарий СБ */
  kzNote: 'kz-note',
}

const certificateCargo = {
  /*-------------------------------------------Селекторы вкладки "Грузоперевозки"-------------------------------------------*/

  /** id текстовое поле "Дата отгрузки (не ранее)" */
  shippingDateNotEarlier: 'shippingDateNotEarlier-input',

  /** id текстовое поле "Дата доставки (не позднее)" */
  deliveryDateNotLater: 'deliveryDateNotLater-input',

  /** id текстовое поле "Страховая сумма по перевозке" */
  transportationSumInsured: 'transportationSumInsured-input',

  /** id текстовое поле "Лимит ответственности на период хранения" */
  transportationLimitSumInsuredStorageInPeriod: 'transportationLimitSumInsuredStorageInPeriod-input',

  /*-------------------------------------------Селекторы вкладки "Условия сертификата"-------------------------------------------*/

  /** id вкладки "Условия сертификата" */
  tabCertificateCondition: 'tab-Certificate-condition-nav',

  /** id таблицы блока "Транспортные документы" */
  transportDocumentsDataGrid: 'transport-documents-data-grid',

  /** id textbox "Номер транспортного документа" */
  numberOfTransportDocument: 'numberOfTransportDocument',

  /** id текстовое поле "Дата транспортного документа" */
  dateOfTransportDocument: 'dateOfTransportDocument-input',

  /** id button "Добавить" в таблице Транспортные документы */
  transportDocumentsAddButton: 'transport-documents-data-grid-add-button',

  /** id combobox "Способ подписания" */
  signingType: 'signingType',

  /** id combobox "ФИО подписанта от имени Страховщика" */
  representativeFIOcombobox: 'representative-fio',

  /*-------------------------------------------Селекторы вкладки "График платежей"-------------------------------------------*/

  /** id checkbox "Требуется сформировать счет по Страховому сертификату" */
  invoiceRequired: 'invoice-required',

  /** id текстовое поле "Дата платежа" */
  dateOfPayment: 'dateOfPayment-input',

  /*-------------------------------------------Селекторы вкладки "Страховые сертификаты"---------------------------------*/

  /** id вкладки "Страховые сертификаты" */
  tabCargoInsuranceCertificates: 'CargoInsuranceCertificates-nav',

  /*-------------------------------------------Печатные формы Страхового сертификата-------------------------------------------*/

  /** id вкладки "Счет на оплату" */
  printoutsCGInvoicePrintout: 'ai-printouts-control-CGInvoicePrintout',

  /** id вкладки "Страховой сертификат (RUS)" */
  printoutsCGInsuranceCertificateRUSt: 'ai-printouts-control-CGInsuranceCertificatePrintout',

  /** id вкладки "Страховой сертификат" */
  printoutsCGInsuranceCertificatePDF: 'ai-printouts-control-CGInsuranceCertificatePrintoutPDF',

  /** id вкладки "Лист согласования" */
  printoutsCGDocumentApprovalList: 'ai-printouts-control-CGDocumentApprovalListPrintout',

  /*------------------------------------------Селекторы списка действий документа Страхового сертификата---------------------------------*/

  /** id кнопки действия "Направить на согласование" (статус Draft/Новый) */
  controlDraftToForApproval: 'ai-transitions-relations-control-Draft_to_ForApproval',

  /** id кнопки действия "Направить на согласование" (статус ForCorrection/На корректировку) */
  controlForCorrectionToForApproval: 'ai-transitions-relations-control-ForCorrection_to_ForApproval',

  /** id кнопки действия "Аннулировать" */
  controlDraftAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',

  /** id кнопки действия "Создать копию" */
  controlCGCopyInsuranceCertificate: 'ai-transitions-relations-control-CGCopyInsuranceCertificate',

  /** id кнопки действия "Подписан" (текущий статус Согласован/Approved) */
  controlApprovedToSigned: 'ai-transitions-relations-control-Approved_to_Signed',

  /** id кнопки действия "Выпустить" */
  controlDraftToApproved: 'ai-transitions-relations-control-Draft_to_Approved',

  /** id кнопки действия "Аннулировать" (статус Draft/Новый)*/
  controlInsuranceCertificateDraftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',
}

const declarationCargo = {
  /*-------------------------------------------------Селекторы боковая панель------------------------------------*/

  /** id checkbox "Требуется согласование условий, отличных от Генерального договора" */
  needOtherConditions: 'needOtherConditions',

  /*-------------------------------------------Селекторы вкладки "Грузоперевозки"-------------------------------------------*/

  /** id текстовое поле "Дата начала периода декларирования" */
  declarationStartDate: 'declarationStartDate-input',

  /** id текстовое поле "Дата окончания периода декларирования" */
  declarationEndDate: 'declaration-end-input',

  /** id textbox "Период декларирования" */
  declarationDuration: 'declaration-duration',

  /** id текстового поля "Страховая сумма по перевозке (только высоколиквидные грузы)" */
  highlyLiquidTransportationSumInsured: 'highlyLiquidTransportationSumInsured-input',

  /*-------------------------------------------Селекторы вкладки "Условия Декларации"------------------------------*/

  /** id вкладки "Условия декларации" */
  tabDeclarationCondition: 'tab-Declaration-condition-nav',

  /*-------------------------------------------Селекторы вкладки "График платежей"---------------------------------*/

  /*-------------------------------------------Печатные формы Декларации-------------------------------------------*/

  /*------------------------------------------Селекторы списка действий документа "Декларации"---------------------------------*/

  /** id кнопки действия "Направить на согласование" (статус Draft/Новый) */
  controlDraftToForApproval: 'ai-transitions-relations-control-Draft_to_ForApproval',

  /** id кнопки действия "Направить на согласование" (статус ForCorrection/На корректировку) */
  controlForCorrectionToForApproval: 'ai-transitions-relations-control-ForCorrection_to_ForApproval',

  /** id кнопки действия "Аннулировать" */
  controlDraftAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',

  /** id кнопки действия "Создать копию" */
  controlCGCopyPeriodDeclaration: 'ai-transitions-relations-control-CGCopyPeriodDeclaration',

  /** id кнопки действия "Подписан" (текущий статус Согласован/Approved) */
  controlApprovedToSigned: 'ai-transitions-relations-control-Approved_to_Signed',
}

const userLimitsCargo = {
  /*-------------------------------------------------Селекторы Лимиты (Импорт)------------------------------------*/

  /** id блока "Общая информация" */
  tabUserLimitsImportMGFile: 'tab-UserLimitsImportMGFile',

  /** id вкладки "Информация о загрузке" */
  tabUserLimitsImportMGLoaded: 'tab-UserLimitsImportMGLoaded-nav',

  /** id блока "Ошибки при загрузке" */
  userLimitsImportMGLoadedInlineView: 'UserLimitsImportMGLoadedInlineView',

  /** id таблицы "Загруженные данные" */
  userLimitImportCargoTable: 'UserLimitImportCargo-#',

  /** id пагинатор таблицы "Загруженные данные" */
  userLimitImportPaginator: 'UserLimitImportCargo-#-paginator-result',

  /** id блока "Ошибки при загрузке" */
  userLimitsImportMGLoadedErrorsInlineView: 'UserLimitsImportMGLoadedErrorsInlineView',

  /** id таблицы "Ошибки при загрузке" */
  dataErrorsTable: 'data-errors-table',

  /** id пагинатор таблицы "Ошибки при загрузке" */
  dataErrorsTablePaginator: 'data-errors-table-paginator-result',

  /** id вкладки "Информация об импорте" */
  tabUserLimitsImportMGImported: 'tab-UserLimitsImportMGImported-nav',

  /** id блока "Импортированные данные" */
  userLimitsImportMGRecordStatusInlineView: 'UserLimitsImportMGRecordStatusInlineView',

  /** id блока "Ошибки при импорте" */
  userLimitsImportMGRecordStatusFailedInlineView: 'UserLimitsImportMGRecordStatusFailedInlineView',

  /*-------------------------------------------------Селекторы Лимиты (Экспорт)------------------------------------*/

  /** id textbox "Пользователь" */
  searchRole: 'search-role-input',

  /** id textbox "Группа" */
  userGroupsSelect: 'userGroupsSelect',

  /** id textbox "Код лимита" */
  productCode: 'product-code',

  /*-------------------------------------Селекторы Таблица с максимальными лимитами групп---------------------------*/

  /** id textbox "Код группы пользователей" */
  userGroupCode: 'userGroupCode',

  /** id textbox "Группа пользователей" */
  groupName: 'groupName',

  /** id таблицы Таблица с максимальными лимитами групп */
  uwGroupLimitsTable: 'uw-group-limits-data-grid',

  /*---------------------------------Селекторы списка действий импорта полномочий---------------------------------*/

  /** id кнопки действия "Начать загрузку" */
  controlStartLoading: 'ai-transitions-relations-control-StartLoading',

  /** id кнопки действия "Перезагрузить" */
  controlReload: 'ai-transitions-relations-control-Reload',

  /** id кнопки действия "Начать импорт" */
  controlStartImporting: 'ai-transitions-relations-control-StartImporting',
}

export { quoteCargo, policyCargo, partyCard, certificateCargo, declarationCargo, userLimitsCargo }
