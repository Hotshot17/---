// @ts-check

const base = {
  /*---------------------------Логины и пароли--------------------------*/
  balashov: 'Balashov.Artem',
  popel: 'Popel.Ilya',
  detenysheva: 'Detenysheva.Olga',
  polikarpov: 'Polikarpov.Sergey',
  password: 'Test_12345',
  stageUrl: 'https://stage.adinsure.sogaz.ru/entry',

  /*---------------------------Локаторы элементов левого меню--------------------------*/
  /** id Папка Страховые продукты */
  contractsMenu: 'Contracts_menu_1',

  /** id элемент Поиск документов */
  contractSearch: 'ContractSearchByCurrentUserBranch_1_2',

  /** id Папка СОГАЗ-АВТО */
  motor: 'Motor_1_2',

  /** id элемент Предрасчет */
  motorCascoApplication: 'MotorCascoApplication_1_3',

  /** id элемент Котировка Парк */
  motorCascoParkQuote: 'MotorCascoParkQuote_1_3',

  /** id Папка Рабочий стол */
  dashboardsMenu: 'Dashboards_menu_1',

  /** id Элемент Витрина задач */
  workflow: 'Workflow_1_2',

  /** id Вкладка Нераспределенные задачи */
  unassignedTasksTab: 'tab-Unassigned-tasks-nav',

  /** id Вкладка Задачи группы */
  groupTasksTab: 'tab-Group-tasks-nav',

  /*---------------------------Роли (акторы)--------------------------*/
  /** id Роли Андеррайтер */
  underwriter: 'ai-actor-selection-control-Underwriter',

  /** id Роли ДЭБ */
  deb: 'ai-actor-selection-control-DEB',

  /*---------------------------Общие элементы--------------------------*/
  /** id Номер документа */
  documentNumber: 'ai-info-control',

  /** id dropdown С именем пользователя (для выхода из системы) */
  headerUserDropdownMenu: 'header-user-dropdown-menu',
}

const application = {
  /*---------------------------Локаторы элементов вкладки Общее--------------------------*/
  /** id Вкладка Общее */
  applicationTab: 'tab-Application-nav',

  /** id combobox Тип обременения */
  burdenSelect: 'burden-ng-select',

  /** id button Финансовая организация */
  financialOrganisation: 'financial-organisation-button',

  /** id field Наименование (финансовой организации) */
  organisationName: 'organisation-name',

  /** id field ИНН (финансовой организации) */
  inn: 'inn',

  /** id field КПП (финансовой организации) */
  kpp: 'kpp',

  /** id button Кнопки "Поиск" */
  searchButton: 'DetailedPartySearchView_SearchButton',

  /** id combobox Порядок оплаты премии */
  paymentFrequency: 'payment-frequency-ng-select',

  /** id button Кнопки поиска Страхователя */
  selectPolicyholderButton: 'select-policyholder-button',

  /** id button Кнопки поиска Собственника */
  selectOwnerButton: 'select-owner-button',

  /** id button Кнопки поиска Лизингополучателя */
  lesseeSearchButton: 'lessee-search-button',

  /** id checkbox Страхователь и собственник совпадают */
  ownerPolicyholderMatch: 'owner-policyholder-match',

  /** id combobox Лица, допущенные к управлению */
  allowedDrive: 'allowed-drive-ng-select',

  /** id button ФИО водителя */
  selectDriver: 'select-driver-button',

  /** id combobox Поиск контрагента в системах */
  systemSelectionDropdown: 'system-selection-dropdown-ng-select',

  /** id field Фамилия (водителя) */
  partyLastName: 'party-last-name',

  /** id field Имя (водителя) */
  partyFirstName: 'party-first-name',

  /** id field Отчество (водителя) */
  partyMiddleName: 'party-middle-name',

  /** id field VIN */
  vin: 'vin',

  /** id checkbox VIN отсутствует */
  vinAbsent: 'vin-absent',

  /** id field № кузова (прицепа) */
  bodyNumber: 'body-number',

  /** id field № шасси (рамы) */
  chassisNumber: 'chassis-number',

  /** id field Марка */
  make: 'make',

  /** id combobox Марка */
  makeComboBox: 'make-ng-select',

  /** id combobox Модель */
  model: 'model-ng-select',

  /** id combobox Год выпуска */
  productionYear: 'production-year-ng-select',

  /** id combobox Тип ТС */
  vehicleType: 'vehicle-type-ng-select',

  /** id combobox Категория ТС */
  vehicleCategory: 'vehicle-category-ng-select',

  /** id field Количество мест */
  seatsNumber: 'seats-number',

  /** id field Количество мест */
  seatsNumberInput: 'seats-number-input',

  /** id field Разрешенная максимальная масса, кг */
  maxWeight: 'max-weight',

  /** id field Пробег, км. */
  mileage: 'mileage-input',

  /** id field Действительная стоимость */
  actualValue: 'actual-value-input',

  /** id field Дата приобретения ТС */
  purchaseDate: 'purchase-date-input',

  /** id field Дата последней регистрации ТС */
  lastRegistrationDate: 'last-registration-date-input',

  /** id checkbox Спутниковая противоугонная система */
  antiTheft: 'has-anti-theft',

  /** id button Иконка поиска рядом с полем "Марка СПС" */
  antiTheftSearchButton: 'anti-theft-search-dialog-button',

  /** id field Марка СПС */
  spsBrand: 'sps-brand',

  /** id field Модель СПС */
  spsModel: 'sps-model',

  /** id field Дата окончания предыдущего полиса */
  previousEndDate: 'previous-end-date-input',

  /** id field Премия прошлого года */
  previousYearPremium: 'previous-year-premium-input',

  /** id field Количество ДТП за последний год владения */
  lastClaimAmount: 'last-claim-amount-input',

  /** id combobox Цель использования */
  usagePurpose: 'application-usage-purpose-ng-select',

  /*---------------------------Локаторы элементов вкладки Условия страхования--------------------------*/
  /** id вкладки Условия страхования (Предрасчет) / Программы и риски (Котировка) */
  insuranceConditionsTab: 'tab-InsuranceConditions-nav',

  /** id combobox Программа страхования */
  insuranceProgram: 'insurance-program-ng-select',

  /** id combobox Специальные профильные программы */
  profileProgram: 'profile-program',

  /** id combobox Размер парка */
  parkSize: 'park-size',

  /** id combobox Требуется перестрахование */
  isReinsuranceRequired: 'is-reinsurance-required-ng-select',

  /** id checkbox Ручная корректировка */
  isManualRequired: 'is-manual-required',

  /** id button Кнопка поиска посредника */
  brokerSearchButton: 'broker-search-dialog-button',

  /** id field Поиск по подстроке (в модальном окне) */
  agentSearch: 'agent-search-input',

  /** id combobox Вариант возмещения по повреждению */
  damageCompensation: 'damage-compensation',

  /** id checkbox Сбор справок */
  certificatesCollection: 'certificates-collection',

  /** id checkbox Выезд аварийного комиссара */
  emergencyDeparture: 'emergency-departure',

  /** id checkbox Вне дорог */
  offRoad: 'off-road',

  /** id combobox Вид франшизы */
  deductibleType: 'deductible-type-ng-select',

  /** id combobox Тип франшизы */
  deductibleOption: 'deductible-option-ng-select',

  /** id combobox Размер франшизы */
  deductibleSize: 'deductible-size-ng-select',

  /** id combobox Вариант возмещения по повреждению */
  withoutCertificates: 'without-certificates',

  /** id checkbox Риск Несчастный случай */
  accident: 'accident-valid',

  /** id combobox Страховая сумма (риск Несчастный случай) */
  accidentSum: 'accident-sum-ng-select',

  /** id checkbox Риск Гражданская ответственность */
  civilLiability: 'civil-liability-valid',

  /** id combobox Страховая сумма (риск Гражданская ответственность) */
  civilSum: 'civil-sum-ng-select',

  /** id checkbox Риск GAP */
  gap: 'gap-valid',

  /** id field Номер полиса каско */
  cascoPolicyNumberInput: 'cascoPolicyNumberInput',

  /*---------------------------Локаторы действий в Действиях (Предрасчет)--------------------------*/
  /** id Действия Перейти к оформлению (создать котировку) */
  createMotorCascoQuote: 'ai-transitions-relations-control-CreateMotorCascoQuote',

  /** id Действия Отказаться от оформления */
  draftToCancelled: 'ai-transitions-relations-control-Draft_to_Cancelled',
}

const quote = {
  /** id icon Иконка Карандаш */
  pen: 'i.fa-pen',

  /** id icon Иконка Корзина */
  trash: 'i.fa-trash',

  /*---------------------------Локаторы элементов вкладки Транспортное средство--------------------------*/
  /** id Вкладка Транспортное средство */
  vehicleTab: 'tab-Vehicle-nav',

  /** id combobox Тип КПП */
  tmType: 'tm-type-ng-select',

  /** id combobox Тип привода */
  driveType: 'drive-type-ng-select',

  /** id combobox Рабочий объем двигателя, л */
  engineVolume: 'engine-volume-ng-select',

  /** id combobox Рабочий объем двигателя, л */
  engineVolumeInput: 'engine-volume-input',

  /** id combobox Тип кузова */
  bodyType: 'body-type-ng-select',

  /** id combobox Тип двигателя */
  engineType: 'engine-type-ng-select',

  /** id combobox Мощность, л.с. */
  enginePower: 'engine-power',

  /** id combobox Мощность, л.с. */
  enginePowerInput: 'engine-power-input',

  /** id field Марка для печати */
  markForPrintAis: 'mark-for-print-ais',

  /** id field Модель для печати */
  modelForPrintAis: 'model-for-print-ais',

  /** id checkbox ТС переоборудовано */
  vehicleHasBeenModified: 'vehicle-has-been-modified',

  /** id field Регистрационный знак */
  regNum: 'reg-num',

  /** id combobox Цель использования */
  usagePurpose: 'usage-purpose-ng-select',

  /** id combobox Тип ПТС */
  ptsDocType: 'pts-doc-type-ng-select',

  /** id field Номер ПТС */
  ptsNumber: 'pts-number',

  /** id field Дата выдачи ПТС */
  ptsIssueDate: 'pts-issue-date-input',

  /** id field Номер СТС */
  stsNumber: 'sts-number',

  /** id field Дата выдачи СТС */
  stsIssueDate: 'sts-issue-date-input',

  /** id table Таблица в блоке Информация по лизингу/кредитованию (при лизинге) */
  documentBurdenLeasing: 'document-burden-leasing',

  /** id field Дата договора лизинга */
  dateLeasingAgreement: 'date-leasing-agreement-input',

  /** id field Номер кредитного договора */
  numberCreditsAgreement: 'number-credits-agreement',

  /** id field Дата кредитного договора */
  dateCreditsAgreement: 'date-credits-agreement-input',

  /** id field Номер договора залога */
  numberPledgeAgreement: 'number-pledge-agreement',

  /** id field Дата договора залога */
  datePledgeAgreement: 'date-pledge-agreement-input',

  /** id block Доп. оборудование */
  optionalEquipment: 'optional-equipment',

  /** id table Таблица в блоке Доп. оборудование */
  optionalEquipmentTable: 'optional-equipment-table',

  /** id combobox Тип */
  equipmentType: 'equipment-type-ng-select',

  /** id field Наименование */
  equipmentName: 'equipment-name',

  /** id field Количество */
  equipmentAmount: 'equipment-amount-input',

  /** id field Стоимость */
  equipmentValue: 'equipment-value-input',

  /*---------------------------Локаторы элементов вкладки Субъекты--------------------------*/
  /** id Вкладка Субъекты */
  subjectsTab: 'tab-Subjects-nav',

  /** id checkbox Ручная корректировка */
  isManualCorrection: 'isManualCorrection',

  /** id table Таблица в блоке Выгодоприобретатели */
  beneficiaryDataGrid: 'beneficiaryDataGrid',

  /** id button Кнопка поиска выгодоприобретателей */
  selectBeneficiaryButton: 'select-beneficiary-button',

  /** id combobox Тип контрагента */
  partyTypeDropdown: 'party-type-dropdown-ng-select',

  /** id field Наименование (контрагента) */
  partyName: 'party-name',

  /** id combobox Покрытие ВГП по рискам */
  beneficiaryRiskCoverage: 'beneficiary-risk-coverage-ng-select',

  /** id checkbox Индивидуальные выгодоприобретатели */
  isIndividualBeneficiaries: 'isIndividualBeneficiaries',

  /** id field Индивидуальные выгодоприобретатели */
  individualBeneficiaries: 'individual-beneficiaries',

  /*---------------------------Локаторы элементов вкладки Общее--------------------------*/
  /** id button Кнопка добавления/поиска Точки продаж */
  salesOutletSearchButton: 'sales-outlet-search-dialog-button',

  /** id field Дата заключения */
  conclusionDate: 'conclusion-date-input',

  /** id field Дата окончания */
  endDate: 'end-date-input',

  /*---------------------------Локаторы элементов вкладки Программы и риски--------------------------*/
  /** id combobox Территория покрытия */
  coverageTerritory: 'coverage-territory-ng-select',

  /*---------------------------Локаторы элементов вкладки Расчет--------------------------*/
  /** id Вкладка Расчет */
  underwritingTab: 'tab-Underwriting-nav',

  /** id field Андеррайтерский коэффициент */
  uwCoefficient: 'uw-coefficient-input',

  /** id таблицы с триггерами */
  triggersTable: 'uw-triggers-list-table',

  /** id field Номер доверенности */
  attorneyNumber: 'attorney-number',

  /** id field Дата доверенности */
  attorneyDate: 'attorney-date-input',

  /** id field Ответственный руководитель */
  responsibleManager: 'responsible-manager-ng-select',

  /** id block Взаимодействие с ДЭБ */
  debConfirmationSection: 'deb-confirmation-section',

  /** id combobox Резолюция ДЭБ */
  debResolution: 'deb-resolution-ng-select',

  /*---------------------------Локаторы элементов вкладки Осмотры--------------------------*/
  /** id Вкладка Осмотры */
  inspectionsTab: 'tab-Inspections-nav',

  /*---------------------------Локаторы элементов вкладки Вложения--------------------------*/
  /** id Вкладка Вложения */
  attachedDocumentsTab: 'tab-Attached-documents-nav',

  /*---------------------------Локаторы действий в меню Действия (Котировка)--------------------------*/
  /** Провести (осомотр) */
  draftToIssued: 'ai-transitions-relations-control-Draft_to_Issued',

  /** Новая -> На согласование Уровень 1 */
  draftToOnConfirmationL1: 'ai-transitions-relations-control-Draft_to_OnConfirmationL1',

  /** Новая -> На согласование Уровень 2 */
  draftToOnConfirmationL2: 'ai-transitions-relations-control-Draft_to_OnConfirmationL2',

  /** На согласовании Уровень 1 -> На согласование Уровень 2 */
  onConfirmationL1ToOnConfirmationL2: 'ai-transitions-relations-control-OnConfirmationL1_to_OnConfirmationL2',

  /** На согласовании Уровень 2 -> На корректировку */
  onConfirmationL2ToCorrection: 'ai-transitions-relations-control-OnConfirmationL2_to_ToCorrection',

  /** На корректировке -> На согласование Уровень 2 */
  ToCorrectionToOnConfirmationL2: 'ai-transitions-relations-control-ToCorrection_to_OnConfirmationL2',

  /** На согласовании Уровень 2 -> На согласование ДЭБ */
  onConfirmationL2ToOnDEBConfirmation: 'ai-transitions-relations-control-OnConfirmationL2_to_OnDEBConfirmation',

  /** На согласовании ДЭБ -> На согласование Уровень 2 */
  onDEBConfirmationToOnConfirmationL2: 'ai-transitions-relations-control-OnDEBConfirmation_to_OnConfirmationL2',

  /** На согласовании Уровень 2 -> На согласование Уровень 3 */
  onConfirmationL2ToOnConfirmationL3: 'ai-transitions-relations-control-OnConfirmationL2_to_OnConfirmationL3',

  /** На согласовании Уровень 2 -> На согласование Уровень 3 - экстренно */
  onConfirmationL2ToOnConfirmationL3Special:
    'ai-transitions-relations-control-OnConfirmationL2_to_OnConfirmationL3_Special',

  /** Согласовать */
  onConfirmationL2ToConfirmed: 'ai-transitions-relations-control-OnConfirmationL2_to_Confirmed',

  /** Согласовать */
  onConfirmationL3ToConfirmed: 'ai-transitions-relations-control-OnConfirmationL3_to_Confirmed',

  /** Согласовать с изменениями */
  onConfirmationL2ToConfirmedWithChanges: 'ai-transitions-relations-control-OnConfirmationL2_to_ConfirmedWithChanges',

  /** Согласовать с изменениями */
  onConfirmationL3ToConfirmedWithChanges: 'ai-transitions-relations-control-OnConfirmationL3_to_ConfirmedWithChanges',

  /** Выпустить котировку (создать договор) */
  createMotorCascoPolicy: 'ai-transitions-relations-control-CreateMotorCascoPolicy',

  /** Отказаться от оформления */
  confirmedWithChangesToCancelled: 'ai-transitions-relations-control-ConfirmedWithChanges_to_Cancelled',

  /** Отказать (андеррайтером) */
  onConfirmationL2ToRejected: 'ai-transitions-relations-control-OnConfirmationL2_to_Rejected',
}

const policy = {
  /*---------------------------Локаторы элементов вкладки Расчет--------------------------*/
  /** id field Должность подписанта */
  insurerPosition: 'insurer-position',

  /*---------------------------Локаторы элементов вкладки График платежей и оплаты--------------------------*/
  /** id Вкладка График платежей и оплаты */
  paymentsTab: 'tab-Payments-nav',

  /** id combobox Способ оплаты */
  paymentsMethod: 'payments-method-ng-select',

  /** id combobox Способ подписания договора */
  signingMethod: 'signing-method-ng-select',

  /** id combobox Реквизиты банка получателя */
  recipientBankDetails: 'recipient-bank-details-ng-select',

  /** id checkbox Плательщик совпадает со страхователем */
  isPolicyholder: 'is-policyholder',

  /** id button Кнопка поиска Плательщика */
  payerSearchButton: 'payer-search-button',

  /*---------------------------Локаторы действий в Действиях (Договор)--------------------------*/
  /** id Действия Заключить договор */
  draftToOnActivationAIS: 'ai-transitions-relations-control-Draft_to_OnActivationAIS',

  /** id Действия Отказаться от оформления */
  draftToCancelled: 'ai-transitions-relations-control-Draft_to_Cancelled',
}

export { base, application, quote, policy }
