export const selectorContract = {
  /*-----------------------------------------------------------------------Селекторы элементов главного меню-------------------------------------------------------*/
  /** @description Папка  "Страховые продукты"' */
  contracts: 'Contracts_menu_1',

  /** @description Папка  продукта "Спутник здоровья"' */
  personalMedicalInsurance: 'PersonalMedicalInsurance_1_2',

  /** @description Элемент создания документа   "Договор"' */
  sZPolicy: 'SZPolicy_1_3',

  /*-----------------------------------------------------------------------Селекторы вкладок документа-------------------------------------------------------*/
  /** @description  id вкладки "Условия страхования" */
  tabInsuranceConditions: 'tab-insurance-conditions-nav',

  /** @description  id вкладки "Андеррайтинг" */
  tabCalculations: 'tab-calculations-nav',

  /** @description  id вкладки "Параметры договора" */
  tabPolicyAttributes: 'tab-policy-attributes-nav',

  /** @description  id вкладки "Выпуск договора" */
  tabIssueOfContract: 'tab-Issue-contract-nav',

  /** @description  id вкладки "Вложения" */
  tabAttachedDocuments: 'tab-policy-attributes-nav',

  /** @description  id вкладки "История документа" */
  tabContractActivityAndTransitionHistory: 'tab-Contract-activity-nav',

  /*-----------------------------------------------------------------------Селекторы списка действий документа-------------------------------------------------------*/
  /** @description Button 'Кнопка действия "К оплате"' */
  Draft_to_PaymentWaiting: 'ai-transitions-relations-control-Draft_to_PaymentWaiting',

  /*-----------------------------------------------------------------------Селекторы ролей-------------------------------------------------------*/
  /** @description  id Роли "Продавец" */
  pmiAgent: 'ai-actor-selection-control-PMIAgent',

  /** @description  id Роли "Андеррайтер" */
  pmiUnderwriter: 'ai-actor-selection-control-PMIUnderwriter',

  /** @description  id Роли "Куратор продаж" */
  pmiPolicyViewer: 'ai-actor-selection-control-PMIPolicyViewer',

  /* ---------------------------------------------------------Вкладка "Условия страхования" -------------------------------------------------- */

  /** @description id таблицы  "Вариант коробки" */
  boxOptionTable: 'sz-select-width-detail',

  /* ---------------------------------------------------------Вкладка "Параметры договора" -------------------------------------------------- */
  /** @description id секции  "Страхователь" */
  sectionPolicyHolder: 'SZPolicyHolderData-#',

  /** @description id секции  "Застрахованный" */
  sectionInsuredPolicyHolder: 'SZInsuredPersonData-#',

  // Блок "Посредники и КВ"

  /** @description id таблицы  "Посредники и КВ" */
  tableAgent: 'agent-commission-table',

  /** @description id ячейки  "агент" "Посредники и КВ" */
  agent: 'agent-name-link',

  /** @description id ячейки   "АГЕНТСКИЙ ДОГОВОР" "Посредники и КВ" */
  agentAgreement: 'agent-agreement-link',

  // Блок "Орг.структура"

  /** @description id поля   "Подразделение" */
  department: 'department-ng-select',

  /** @description id поля   "Филиал" */
  branch: 'branch-ng-select',

  /** @description id поля   "Профильная программа" */
  profileProgram: 'profileProgram-ng-select',

  /** @description id поля   "Канал продаж" */
  sellingChannel: 'sellingChannel-ng-select',

  /* ---------------------------------------------------------селекторы вкладки "Андеррайтинг" -------------------------------------------------- */
  // -----------------------------------Блок "Риски"
  insuredRiskName: 'group-risk-name',
  insuredRiskSumInsured: 'sumInsured-input',
  insuredRiskPremium: 'premium-input',
  insuredRiskRule: 'rule-ng-select',
  insuredRiskTariff: 'tariff-ng-select',

  /* ---------------------------------------------------------селекторы вкладки "Выпуск договора" -------------------------------------------------- */
  /** @description combobox    "Способ оплаты" */
  paymentMethod: '-ng-select',

  /** @description combobox    "Способ уведомления" */
  paymentNotificationMethodAi: 'notification-method-ng-select',

  /** @description id поля   "E-mail плательщика" */
  payerEmail: 'payer-email',

  /** @description id поля   "Телефон плательщика" */
  payerMobilePhone: 'payer-mobile',
}
