import { test, expect } from 'playwright/test'
/**
 * @deprecated
 */
export const RegisterMortgageVTB = class RegisterMortgageVTB {
  constructor(page) {
    this.page = page

    // ADI-T2607 (1.0) Авторизация (Step 1)
    this.EnterButton = page.getByTestId('enter-button')
    this.UserNameLable = page.getByTestId('Username')
    this.PasswordLable = page.getByTestId('Password')
    this.LoginTypeRadioBox = page.getByTestId('login-type-adinsure')
    this.LoginButton = page.getByTestId('login-button')

    // ADI-T1990 (1.0) Переход по главному меню (Step 2)
    this.InsuranceProducts = page.locator('li').filter({ hasText: 'Страховые продукты' })
    this.MortgageVTB = page.locator('li').filter({ hasText: 'Ипотека ВТБ' })
    this.VTBQuote = page.locator('li').filter({ hasText: 'Котировка ВТБ' })

    // ADI-T3007 (1.0) Поиск и выбор в форме 'Поиск контрагента - по параметрам' ФЛ в системе Адакта (Step 3)
    this.PhLookupButton = page.getByTestId('phLookupButton').getByRole('button', { name: '' })
    this.CounterpartyTypeCombobox = page.locator(
      '#party-type-dropdown-ng-select > .ng-select-container > .ng-arrow-wrapper'
    )
    this.IndividualOption = page.getByRole('option', { name: 'Физ. лицо' })
    this.SystemSelectionDropdownCombobox = page.getByTestId('system-selection-dropdown').getByRole('combobox')
    this.AdaktaSystem = page.getByRole('option', {
      name: 'Поиск в системе Адакта',
    })
    this.PartyLastName = page.getByTestId('party-last-name').getByRole('textbox')
    this.PartyFirstName = page.getByTestId('party-first-name').getByRole('textbox')
    this.PartyMiddleName = page.getByTestId('party-middle-name').getByRole('textbox')
    this.SearchButton = page
      .getByTestId('DetailedPartySearchView_SearchButton')
      .getByRole('button', { name: ' Поиск' })
    this.ArrowRightButton = page.getByRole('button', { name: '' })
    this.ChoiceButton = page.getByRole('button', { name: ' Выбрать' })

    // ADI-T3272 (1.0) [Ипотека ВТБ][ОС][Котировка] Заполнение доп информации по Страхователю (категория, сем.положение, тел, почта) (Step 4)
    this.MaritalStatusCombobox = page.getByTestId('marital-status').getByRole('combobox')
    this.MarriedOption = page.getByRole('option', { name: 'женат / замужем' })
    this.SelectedPhoneCombobox = page.getByTestId('selected-phone').getByRole('combobox')
    this.PhoneOption = page.getByRole('option', { name: '8(900)398-05-' })
    this.CategoryCombobox = page.getByTestId('category').getByRole('combobox')
    this.BorrowerOption = page.getByRole('option', {
      name: 'Заемщик',
      exact: true,
    })

    // ADI-T3194 (1.0) Установка, снятие чек-бокса в блоке (Step 5)
    this.NoEmailCheck = page.getByTestId('no-email').getByRole('checkbox')
    this.IpDataSection = page.getByTestId('ip-data-section').getByTestId('no-email').getByRole('checkbox')

    // ADI-T2365 (1.0) [Ипотека ВТБ][Котировка] Заполнение блока 'Кредитный договор' (ОСЗ/валюта/даты/срок/% ставка/цель/% увел СС/порядок определения СС/фикс. сумма) (Step 6)
    this.OSZInputLable = page.locator('#OSZ-input')
    this.CreditDateInputLable = page.locator('#credit-date-input')
    this.RemainingMonthsInputLable = page.locator('#remaining-months-input')
    this.CreditPurposeCombobox = page.getByTestId('credit-purpose').getByRole('combobox')
    this.BuyingHousingOption = page.getByRole('option', {
      name: 'Покупка готового жилья',
    })
    this.SumInsuredCombobox = page.locator(
      '#MGEnumInsSumCalcMethod-ng-select > .ng-select-container > .ng-arrow-wrapper'
    )
    this.OSZPercentOption = page.getByRole('option', { name: 'ОСЗ + процент' })
    this.CreditPercentageInputLable = page.locator('#creditPercentage-input')

    // ADI-T3843 (1.0) [Ипотека ВТБ] Блок Договор страхования. Заполнение полей (дата начала, дата закл, прогр. стр) (Step 7)
    this.IssueDateInputLable = page.locator('#issue-date-input')
    this.InsuranceProgram = page.getByTestId('insuranceProgram')
    this.MainProgramOption = page.getByRole('option', {
      name: 'Основная программа',
    })

    // ADI-T2367 (1.0) [Ипотека ВТБ][Общее] Заполнение блока 'Орг структура' (Step 8)
    this.DepartmentSearch = page.getByTestId('department-search').getByRole('button', { name: '' })
    this.DepartmentNameSection = page
      .getByTestId('department-name-section')
      .getByTestId('department-name')
      .getByRole('textbox')
    this.StandartSearchButton = page.getByRole('button', { name: ' Поиск' })
    this.StantartCheckbox = page.getByRole('checkbox')
    this.Disease = page.getByRole('cell', { name: 'Ревмокардит' })
    // this.ChoiceButton = page.getByRole('button', { name: ' Выбрать' })

    // ADI-T2641 (1.0) Переход на вкладку документа (Step 9)
    this.PersonsNav = page.locator('[id="Insured\\ persons-nav"]')

    // ADI-T3097 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Нажатие кнопки Добавить в блоке 'Список застрахованных'(Step 10)
    this.AddButton = page.getByRole('button', { name: '+ Добавить' })

    // ADI-T2371 (1.0) [[Ипотека ВТБ][Котировка][ЛС][ЗЛ] Выбор страхователя и проверка автозаполненных полей (Step 11)
    this.SelectPolicyholder = page.getByRole('button', {
      name: 'Выбрать страхователя',
    })
    this.SelectedPhone = page.getByTestId('ip-data-section').getByTestId('selected-phone').getByRole('combobox')
    this.NumberOption = page.getByRole('option', { name: '8(900)398-05-' })

    // ADI-T3194 (1.0) Установка, снятие чек-бокса в блоке (Step 12)
    // this.IpDataSection = page.getByTestId('ip-data-section').getByTestId('no-email').locator('i')

    // ADI-T2959 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение блока 'Тарификация'(Step 13)
    this.PercentageParticipationInput = page.locator('#percentage-participation-input')

    // ADI-T2408 (1.0) [[Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение блока 'Информация о профессии' / Раздела 'ПРОФЕССИЯ'(Step 14)
    this.TypeEmploymentCombobox = page.getByTestId('type-employment').getByRole('combobox')
    this.HiringOption = page.getByRole('option', { name: 'Найм' })
    this.OrganizationLable = page.getByTestId('organization').getByRole('textbox')
    this.ProfessionSkillsLable = page.getByTestId('profession-skills').getByRole('textbox')
    this.ProfessionSearchLable = page.getByTestId('profession-search').getByRole('button', { name: '' })
    this.ProfessionIndustryLable = page.getByTestId('profession-industry').getByRole('textbox')
    this.ProfessionNameLable = page.getByTestId('profession-name').getByRole('textbox')
    // this.PercentageParticipationInput = page.getByRole('button', { name: ' Поиск' })
    this.ManagersText = page
      .getByRole('row', {
        name: ' Руководители, административная служба Директор',
      })
      .getByRole('checkbox')
    // this.PercentageParticipationInput = page.getByRole('button', { name: ' Выбрать' })

    // ADI-T2776 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение разделов 'Рост/Вес/Давление', 'Заболевания' в блоке 'Медицинская информация'(Step 15)
    this.IpHeightInput = page.locator('#ip-height-input')
    this.IpWeightInput = page.locator('#ip-weight-input')
    this.BloodPressureUpInput = page.locator('#blood-pressure-up-input')
    this.BloodPressureLowInput = page.locator('#blood-pressure-low-input')
    this.MedicationGroupCombobox = page.getByTestId('medication-group').getByRole('combobox').first()
    this.DontTakeMedicationOption = page.getByRole('option', {
      name: 'не принимаю медикаменты',
    })
    this.DisabilityGroupCombobox = page.getByTestId('disability-group').getByRole('combobox')
    this.NotOption = page.getByRole('option', { name: 'нет' })

    // ADI-T2783 (1.0) [Ипотека ВТБ][Котировка][ЗЛ] Заполнение раздела 'Заболевания'(Step 16)
    this.PresenceOfDiseases = page.locator(
      '#disease-section > .ai-section-2 > .card > div > div:nth-child(2) > ng-component > .ai-group-bootstrap > .row > .parent-grid-12 > ng-component > .ai-boolean-input-bootstrap-container > .form-group > .ai-boolean-icon-wrapper > .ai-boolean-icon'
    )
    this.AddDiseaseTableButton = page.getByTestId('disease-table').getByRole('button', { name: '+ Добавить' })
    this.DiseaseSearchButton = page.getByTestId('disease-search').getByRole('button', { name: '' })
    this.DiseaseGroupNameText = page.getByTestId('disease-group-name').getByRole('textbox')
    this.DiseaseName = page.getByTestId('disease-name').getByRole('textbox')
    this.OrganВiseasesRow = page
      .getByTestId('disease-data-table')
      .locator('div')
      .filter({
        hasText: 'ГРУППА ЗАБОЛЕВАНИЙ ЗАБОЛЕВАНИЕ КЛАСС КОД Болезни органов пищеварения (пищевода, ',
      })
      .first()
    // this.OrganВiseasesRow = page.getByRole('row', { name: ' Болезни органов пищеварения (пищевода, желудка, кишечника, печени, желчного пузыря, поджелудочной железы) Панкреатит underTrigger N/A', exact: true }).getByRole('checkbox')
    // this.NotOption = page.getByRole('button', { name: ' Выбрать' }).click()
    this.AppTextInputLable = page
      .locator('app-text-input')
      .filter({ hasText: 'Описание заболевания --' })
      .getByRole('textbox')
    this.OkButton = page.getByRole('button', { name: ' OK' })
    this.DiseaseAdditionLable = page.getByTestId('disease-addition').getByRole('textbox')

    // ADI-T2044 (1.0) Сохранить / Рассчитать (Step 17)
    this.SaveButton = page.getByRole('button', { name: ' Сохранить' })

    // ADI-T3097 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Нажатие кнопки Добавить в блоке 'Список застрахованных'(Step 18)
    this.InsuredPersonsList = page.getByTestId('insured-persons-list').getByRole('button', { name: '+ Добавить' })

    // ADI-T3007 (1.0) Поиск и выбор в форме 'Поиск контрагента - по параметрам' ФЛ в системе Адакта (Step 19)
    this.SelectIpButton = page.getByTestId('select-ip-button').getByRole('button', { name: '' })
    this.SystemSelectionDropDown = page.getByTestId('system-selection-dropdown').getByRole('combobox')
    this.Row1479791 = page.getByRole('row', { name: ' 1479791' }).getByRole('checkbox')

    // ADI-T12639 (1.0) [Ипотека ВТБ][Котировка][ЗЛ] Заполнение полей в блоке 'Личная информация' (категория, сем.положение, телефон, email) (Step 20)
    this.IpGeneralCategory = page.getByTestId('ip-general').getByTestId('category').getByRole('combobox')
    this.IpDataSectionMaritalStatus = page
      .getByTestId('ip-data-section')
      .getByTestId('marital-status')
      .getByRole('combobox')
    this.IpDataSectionSelectedPhone = page
      .getByTestId('ip-data-section')
      .getByTestId('selected-phone')
      .getByRole('combobox')
    this.IpDataSectionSelectedEmail = page
      .getByTestId('ip-data-section')
      .getByTestId('selected-email')
      .getByRole('combobox')

    // ADI-T2959 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение блока 'Тарификация' (Step 21)
    // this.PercentageParticipationInput = page.locator('#percentage-participation-input')

    // ADI-T2408 (1.0) [[Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение блока 'Информация о профессии' / Раздела 'ПРОФЕССИЯ' (Step 22)
    this.RowEconomicsFinance = page
      .getByRole('row', {
        name: ' Экономика, финансы, статистика, банк, недвижимость, консалтинг, страхование Менеджер',
      })
      .getByRole('checkbox')

    // ADI-T3288 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение раздела 'Вопрос для женщин' в блоке 'Медицинская информация' (Step 24)
    this.DiseaseSectionNgComponent = page
      .getByTestId('disease-section')
      .locator('ng-component')
      .filter({
        hasText: 'Вопрос для женщинНаличие гинекологических заболеваний --Необходимо заполнить нал',
      })
      .getByRole('combobox')
    this.ExactNoOption = page.getByRole('option', { name: 'нет', exact: true })

    // ADI-T3007 (1.0) Поиск и выбор в форме 'Поиск контрагента - по параметрам' ФЛ в системе Адакта(Step 26)
    this.Row868040 = page.getByRole('row', { name: ' 868040' }).getByRole('checkbox')

    // ADI-T12639 (1.0) [Ипотека ВТБ][Котировка][ЗЛ] Заполнение полей в блоке 'Личная информация' (категория, сем.положение, телефон, email) (Step 27)
    this.IpGeneral = page.getByTestId('ip-general').getByTestId('category').getByRole('combobox')
    this.GuarantorOption = page.getByRole('option', { name: 'Поручитель' })
    this.NumberOption47 = page.getByRole('option', { name: '8(962)576-47-' })

    // ADI-T2408 (1.0) [[Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение блока 'Информация о профессии' / Раздела 'ПРОФЕССИЯ'(Step 30)
    this.RowManagersAdministrative = page
      .getByRole('row', {
        name: ' Руководители, административная служба Директор',
      })
      .getByRole('checkbox')

    // ADI-T2641 (1.0) Переход на вкладку документа (Step 33)
    this.PropertyNav = page.locator('[id="Insured\\ property-nav"]')

    // ADI-T2788 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ИС] Заполнение блока 'Основная информация' (наименование, тип, стоимость, адрес) (Step 34)
    this.AppTextInputLableObject = page
      .locator('app-text-input')
      .filter({
        hasText: 'Наименование объекта --Необходимо заполнить наименование объекта',
      })
      .getByRole('textbox')
    this.GeneralInformationSection = page
      .getByTestId('general-information-section')
      .locator('ng-component')
      .filter({
        hasText:
          'Наименование объекта --Тип объекта --Необходимо заполнить Тип объекта.Действительная (оценочная) стоимость объекта --Необходимо заполнить Действительная (оценочная) стоимость объекта',
      })
      .getByRole('combobox')
    this.ApartmentsOption = page.getByRole('option', { name: 'Квартиры' })
    this.GeneralInformationSectionLable = page
      .getByTestId('general-information-section')
      .locator('ng-component')
      .filter({
        hasText:
          'Наименование объекта --Тип объекта Квартиры××--Действительная (оценочная) стоимость объекта --Необходимо заполнить Действительная (оценочная) стоимость объекта',
      })
      .locator('[id="-input"]')
    this.AddressAutocomplete = page.getByTestId('AddressAutocomplete').getByRole('textbox')
    this.AdressNumber = page.getByRole('option', {
      name: 'г Владимир, ул Баумана, д 10, кв',
    })
    this.StandardizationButton = page.getByRole('button', {
      name: 'Стандартизация',
    })
    this.GeneralInformationSectionDate = page.getByTestId('general-information-section').locator('input[name="dp"]')
    this.NgComponentGeneral = page
      .getByTestId('general-information-section')
      .locator('ng-component')
      .filter({
        hasText:
          'Дата оценки --Необходимо заполнить Дата оценки.Документ оценки --Необходимо заполнить Документ оценки',
      })
      .getByRole('combobox')
    this.EvaluationReport = page.getByRole('option', {
      name: 'Отчет об оценке',
    })
    this.InputFact = page.locator('[id="-input"]').nth(2)

    // ADI-T2789 (1.0) [Ипотека ВТБ] [Котировка] [ИС] Заполнение блока 'Имущественное страхование' (площадь, отопление, год поcтройки + характер использования) (Step 35)
    this.PropertyInsurance = page
      .getByTestId('general-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Страхование имущества Страхование титула Строящееся жилье',
      })
      .locator('i')
      .first()
    this.TotalArea = page
      .getByTestId('property-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Общая площадь --Необходимо заполнить общую площадьКоличество комнат --Необходимо',
      })
      .locator('[id="-input"]')
      .first()
    this.TotalAreaComponent = page
      .getByTestId('property-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Общая площадь --Необходимо заполнить общую площадьКоличество комнат --Необходимо',
      })
      .locator('[id="-input"]')
      .nth(1)
    this.TotalAreaComponentCombobox = page
      .getByTestId('property-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Общая площадь --Количество комнат --Необходимо заполнить Количество комнатОтопле',
      })
      .getByRole('combobox')
    this.CentralHeating = page.getByRole('option', {
      name: 'Центральное отопление',
    })
    this.NumberOfFloors = page
      .getByTestId('property-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Количество этажей в здании --Необходимо заполнить Количество этажейЭтаж располож',
      })
      .locator('[id="-input"]')
      .first()
    this.NumberOfFloorsnhs = page
      .getByTestId('property-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Количество этажей в здании --Необходимо заполнить Количество этажейЭтаж располож',
      })
      .locator('[id="-input"]')
      .nth(1)
    this.NumberOfFloorsnhs2 = page
      .getByTestId('property-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Год постройки здания --Необходимо заполнить Год постройки зданияГод последнего к',
      })
      .locator('[id="-input"]')
      .nth(2)
    this.NumberOfFloorsFirst = page
      .getByTestId('property-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Год постройки здания --Необходимо заполнить Год постройки зданияГод последнего к',
      })
      .locator('[id="-input"]')
      .first()
    this.ComboboxInfomation = page.getByTestId('property-information-section').getByRole('combobox').nth(1)
    this.VisibleDamage = page.getByRole('option', {
      name: 'Видимых повреждений нет',
    })
    this.UsageDescriptionSection = page.getByTestId('usage-description-section').getByRole('combobox')

    // ADI-T3211 (1.0) [Ипотека ВТБ][Котировка][ИС] Заполнение чекбоксов раздела 'Источники повышенной пожарной опасности' (Step 36)
    this.FireSourceSection = page.locator(
      '#fire-source-section > .ai-section-2 > .card > div > div > ng-component > div > div > div > ng-component > .ai-group-bootstrap > .row > .parent-grid-12 > ng-component > .ai-boolean-input-bootstrap-container > .form-group > .ai-boolean-icon-wrapper > .ai-boolean-icon'
    )

    // ADI-T2880 (1.0) [Ипотека ВТБ][Котировка][ИС] Заполнение чекбоксов раздела 'Внешние стены' (Step 37)
    this.WallSection = page
      .getByTestId('wall-section')
      .locator('ng-component')
      .filter({
        hasText: 'железобетон дерево кирпич иное Проверьте корректность описания стен',
      })
      .locator('i')
      .first()
    // ADI-T2880 (1.0) [Ипотека ВТБ][Котировка][ИС] Заполнение чекбоксов раздела 'Внешние стены' (Step 38)
    this.DeckSection = page
      .getByTestId('deck-section')
      .locator('ng-component')
      .filter({
        hasText: 'Нет Проверьте корректность описания межэтажных перекрытийЖелезобетон Дерево Смеш',
      })
      .locator('i')
      .nth(1)
    // ADI-T2887 (1.0) [Ипотека ВТБ] [Котировка] [ИС] Заполнение разделов 'Пожарная/Охранная безопасность' (Step 39)
    this.FireProtectionSection = page
      .getByTestId('fire-protection-section')
      .locator('ng-component')
      .filter({
        hasText: 'Нет Проверьте корректность описания систем пожарной безопасности',
      })
      .locator('i')
    this.SecuritySystemsSection = page
      .locator(
        '#security-systems-section > .ai-section-2 > .card > div > div > ng-component > .ai-group-bootstrap > .row > .parent-grid-12 > ng-component > .ai-boolean-input-bootstrap-container > .form-group > .ai-boolean-icon-wrapper > .ai-boolean-icon'
      )
      .first()

    // ADI-T2794 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Выбор вида страхования, проверка и заполнение разделов 'Тарификация' 'Риски ТИТ ' (срок, пакет рисков, Кпрод, чекбокс андер)(Step 41)
    this.GeneralPropertyInsurance = page
      .getByTestId('general-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Страхование имущества Страхование титула Строящееся жилье',
      })
      .locator('i')
      .nth(1)
    this.OwnershipLossSection = page
      .getByTestId('ownership-loss-section')
      .locator('ng-component')
      .filter({
        hasText: 'Дата начала --Срок страхования в месяцах --Укажите Срок страхования в месяцахДат',
      })
      .locator('numeric-input-bootstrap [id="-input"]')

    // ADI-T2797 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение блока 'Cобственник имущества' (собств., вид владения)(Step 42)
    this.OwnerShipLossCombobox = page.getByTestId('ownership-loss-section').getByRole('combobox').nth(1)
    this.InsuredOption = page.getByRole('option', { name: 'Страхователя' })
    this.OwnerShipLossComboboxTwo = page.getByTestId('ownership-loss-section').getByRole('combobox').nth(2)
    this.IndividuallyOption = page.getByRole('option', { name: 'eдинолично' })

    // ADI-T2904 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение и проверка полей в блоке 'Собственник имущества' (таблица: доля, сем.полож, чекбоксы) (Step 43)
    this.OwnesTableButton = page.getByTestId('owners-table').getByRole('button', { name: '+ Добавить' })
    this.AiGroupBootstrap = page.locator(
      'ng-component > div > div:nth-child(3) > ng-component > .ai-group-bootstrap > .row > div > ng-component > .ai-boolean-input-bootstrap-container > .form-group > .ai-boolean-icon-wrapper > .ai-boolean-icon'
    )
    this.OwnersTablelable = page
      .getByTestId('owners-table')
      .locator('percentage-permille-numeric-input-bootstrap [id="-input"]')
    this.OwersTableCombobox = page.getByTestId('owners-table').getByRole('combobox').nth(1)

    // ADI-T2908 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение и проверка полей в блоке 'Собственник имущества' (таблица) (Step 44)
    this.ButtonSearch = page.getByRole('button', { name: '' })
    this.ComboboxPartyType = page.getByTestId('party-type').getByRole('combobox')
    this.LableLastName = page.getByTestId('last-name').getByRole('textbox')
    this.LableFirstName = page.getByTestId('first-name').getByRole('textbox')
    this.LableMiddleName = page.getByTestId('middle-name').getByRole('textbox')
    this.CheckboxRow2902065 = page.getByRole('row', { name: ' 2902065' }).getByRole('checkbox')

    // ADI-T4966 (1.0) Выбор значения из выпадающего списка (Step 45)
    this.EncumbrancesSection = page.getByTestId('encumbrances-section').getByRole('combobox')

    // ADI-T2799 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение количества переходов прав (Step 46)
    this.OptionTransferOfRights = page.getByRole('option', {
      name: '1 переход права',
    })
    this.ComboboxOwnershipHistorySection = page.getByTestId('ownership-history-section').getByRole('combobox')

    // ADI-T1997 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение истории переходов прав(Step 47)
    this.OwnershipHistory = page.getByTestId('ownership-history-table').getByRole('button', { name: '+ Добавить' })
    this.ComboboxOwnershipHistory = page.getByTestId('ownership-history-table').getByRole('combobox')
    this.ContractOfSale = page.getByRole('option', {
      name: 'Договор купли-продажи',
    })
    this.LableOwnerDateOne = page.getByTestId('ownership-history-table').locator('[id="-input"]').first()
    this.LableOwnerDateTwo = page.getByTestId('ownership-history-table').locator('[id="-input"]').nth(1)
    this.ButtonOwnerOk = page.getByTestId('ownership-history-table').getByRole('button', { name: ' OK' })

    // ADI-T3674 (1.0) [Ипотека ВТБ] Нажатие кнопки Добавить в Имущественном страховании(Step 49)
    this.ApartmentsAddButton = page
      .locator('div')
      .filter({ hasText: /^КвартираДобавить$/ })
      .getByRole('button')

    // ADI-T2788 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ИС] Заполнение блока 'Основная информация' (наименование, тип, стоимость, адрес) (Step 50)
    this.AppTextInput = page
      .locator('app-text-input')
      .filter({
        hasText: 'Наименование объекта --Необходимо заполнить наименование объекта',
      })
      .getByRole('textbox')
    this.ComboboxGeneralSection = page
      .getByTestId('general-information-section')
      .locator('ng-component')
      .filter({
        hasText:
          'Наименование объекта --Тип объекта --Необходимо заполнить Тип объекта.Действительная (оценочная) стоимость объекта --Необходимо заполнить Действительная (оценочная) стоимость объекта',
      })
      .getByRole('combobox')
    this.LandPlot = page.getByRole('option', { name: 'Земельный участок' })
    this.LableGeneralInformation = page
      .getByTestId('general-information-section')
      .locator('ng-component')
      .filter({
        hasText:
          'Наименование объекта --Тип объекта Земельный участок××--Действительная (оценочная) стоимость объекта --Необходимо заполнить Действительная (оценочная) стоимость объекта',
      })
      .locator('[id="-input"]')
    this.LableAssessedValue = page.locator('[id="-input"]').nth(2)
    this.LableAssressAutocomplete = page.getByTestId('AddressAutocomplete').getByRole('textbox')
    this.ClickOptionAdress = page.getByRole('option', {
      name: 'г Владимир, ул Аграрная, д 15',
    })
    this.Standardization = page.getByRole('button', { name: 'Стандартизация' })
    this.LableCadastralNumber = page
      .locator('app-text-input')
      .filter({
        hasText: 'Кадастровый номер --Необходимо заполнить Кадастровый номер',
      })
      .getByRole('textbox')
    this.LableGeneralDate = page.getByTestId('general-information-section').locator('input[name="dp"]')
    this.ComboboxGeneralDate = page
      .getByTestId('general-information-section')
      .locator('ng-component')
      .filter({
        hasText:
          'Дата оценки --Необходимо заполнить Дата оценки.Документ оценки --Необходимо заполнить Документ оценки',
      })
      .getByRole('combobox')
    this.OptionEvaluationReport = page.getByRole('option', {
      name: 'Отчет об оценке',
    })

    // ADI-T5247 (1.0) [Ипотека ВТБ] ИС. Заполнение блока Имущественное страхование по ЗУ (площадь, характер использования) (Step 51)
    this.PropertyInsuranceTrue = page
      .getByTestId('general-information-section')
      .locator('ng-component')
      .filter({ hasText: 'Страхование имущества Страхование титула' })
      .locator('i')
      .first()
    this.LableTotalArea = page
      .getByTestId('property-information-section')
      .locator('ng-component')
      .filter({
        hasText: 'Общая площадь --Необходимо заполнить общую площадьОтопление --',
      })
      .locator('[id="-input"]')
    // ADI-T5248 (1.0) [Ипотека ВТБ][Котировка][ИС] Заполнение раздела 'Охранная безопасность' для объекта 'Земельный участок' (чекбоксы) (Step 52)
    this.SecuritySystems = page
      .locator(
        '#security-systems-section > .ai-section-2 > .card > div > div > ng-component > .ai-group-bootstrap > .row > .parent-grid-12 > ng-component > .ai-boolean-input-bootstrap-container > .form-group > .ai-boolean-icon-wrapper > .ai-boolean-icon'
      )
      .first()
    // ADI-T2987 (1.0) Сохранить уникальный номер в заголовке (документа/контрагента)(Step 54)
    this.AiInfoControl = page.getByTestId('ai-info-control').getByText('MGQ-')

    // ADI-T2387 (1.0) Выполнение действия (с выбором исполнителя) (Step 55)
    this.ButtonDo = page.getByRole('button', { name: 'Действия ' })
    this.SendForApproval = page.getByRole('button', {
      name: 'Направить на согласование Андеррайтеру ГО',
    })
    this.ComboboxClick = page.getByRole('combobox')
    this.OptionName = page.getByRole('option', {
      name: 'Косинская Вера Константиновна',
    })

    // ADI-T2607 (1.0) Авторизация(Step 56)
    this.ButtonWelcom = page.getByRole('button', {
      name: 'Добрый день, Косинская Вера Константиновна ',
    })
    this.ButtonExit = page.getByRole('button', { name: ' Выйти' })
    this.ButtonHere = page.getByRole('link', { name: 'сюда' })

    // ADI-T1990 (1.0) Переход по главному меню(Step 57)
    this.ButtonTaskShowcase = page.locator('li').filter({ hasText: 'Витрина задач' })

    // ADI-T2641 (1.0) Переход на вкладку документа (Step 58)
    this.ButtonTabGroupTasks = page.locator('#tab-Group-tasks-nav')

    // ADI-T3954 (1.0) [Витрина задач] Поиск, назначение задачи в группе и переход к документу (Step 59)
    this.ComboboxGroupTasks = page.getByTestId('group-tasks-area').getByTestId('userGroupsSelect').getByRole('combobox')
    this.OptionUnderwritingGO = page.getByRole('option', {
      name: 'Андеррайтинг ГО (Ипотека)',
    })
    this.LableDocumentNumber = page.getByTestId('group-tasks-frame').getByTestId('document-number').getByRole('textbox')
    this.GroupTabeRow = page.locator('#group-tasks-table-row-0').getByRole('cell', { name: '' })
    this.ButtonAssignATaskToYourself = page.getByRole('button', {
      name: 'Назначить задачу на себя',
    })
    this.GroupTasksTableDoc = page.getByTestId('group-tasks-table_doc-number-link').getByRole('link', { name: 'MGQ-' })

    // ADI-T2413 (1.0) Переключение и проверка роли (Step 60)
    this.ButtonP = page.getByRole('button', { name: 'П ' })
    this.ButtonUnderwriter = page.getByRole('button', { name: 'Андеррайтер' })

    // ADI-T2399 (1.0) Выполнение действия (без выбора исполнителя) (Step 61)
    this.HireAsAnUnderwriter = page.getByRole('button', {
      name: 'Взять в работу андеррайтером',
    })
    this.ButtonYes = page.getByRole('button', { name: ' Дa' })

    // ADI-T2802 (1.0) [Ипотека ВТБ][Котировка][Андеррайтинг] Согласование триггеров (Step 62)
    this.TabUnderwrightOverview = page.locator('#tab-underwriting-overview-nav')
    this.RowKlass = page
      .getByRole('row', {
        name: ' ОБЪЕКТЫ СТРАХОВАНИЯ  КЛАСС  НАИМЕНОВАНИЕ  СТАТУС ПОДТВЕРДИЛ ПОДТВЕРЖДЕНО',
      })
      .getByRole('checkbox')
    this.ComboboxObjectsOfInsurance = page.locator('[id="-ng-select"]').getByRole('combobox')
    this.OptionAgreed = page.getByRole('option', {
      name: 'Согласовано',
      exact: true,
    })
    this.ButtonChoice = page.getByRole('button', { name: 'Выбрать' })

    // ADI-T2399 (1.0) Выполнение действия (без выбора исполнителя) (Step 63)
    this.OptionContinueNegotiation = page.getByRole('button', {
      name: 'Продолжить согласование',
    })

    // ADI-T2413 (1.0) Переключение и проверка роли (Step 63)
    this.AiActorControl = page.getByTestId('ai-actor-selection-control').getByRole('button', { name: 'А ' })
    this.OptionSalesman = page.getByRole('button', {
      name: 'Продавец',
      exact: true,
    })

    // ADI-T2399 (1.0) Выполнение действия (без выбора исполнителя) (Step 65)
    this.ReleaseQuote = page.getByRole('button', {
      name: 'Выпустить котировку',
    })

    // ADI-T2641 (1.0) Переход на вкладку документа(Step 66)
    this.TabPolicyNav = page.locator('#tab-Policy-nav')

    // ADI-T2923 (1.0) [Ипотека ВТБ][Договор][ОР] Заполнение блока 'Кредитный договор' (Step 67)
    this.LableCreditDocument = page.getByTestId('credit-document-number').getByRole('textbox')
    this.LableAppTextInput = page
      .locator('app-text-input')
      .filter({
        hasText: 'Место заключения кредита --Необходимо заполнить Место заключения кредита',
      })
      .getByRole('textbox')
    this.LablePeriodPay = page.getByTestId('period-pay-input')
    this.LableDateCreadit = page.getByTestId('credit-conclusion-date').getByRole('textbox')

    // ADI-T2641 (1.0) Переход на вкладку документа (Step 68)
    this.InsuredPersons = page.getByTestId('Insured persons-nav')

    // ADI-T3117 (1.0) [Ипотека ВТБ][Договор][ЗЛ] Проверка и заполнение полей в блоке 'Личная информация'(Step 69)
    this.IpSmsMessages = page.getByTestId('ip-sms-messages').locator('i')
    this.ProcessingPersonalData = page.getByTestId('processing-personal-data').locator('i')

    // ADI-T3075 (1.0) [Ипотека ВТБ][ЗЛ][ЛС] Переключение карточек застрахованных лиц (Step 70)
    this.InsuredPersonsListTrue = page.getByTestId('insured-persons-list').locator('i').nth(3)

    // ADI-T3117 (1.0) [Ипотека ВТБ][Договор][ЗЛ] Проверка и заполнение полей в блоке 'Личная информация' (Step 71)
    this.IpSmsMessagesTrue = page.getByTestId('ip-sms-messages').locator('i')
    this.ProcessingPersonalDataTrue = page.getByTestId('processing-personal-data').locator('i')

    // ADI-T3075 (1.0) [Ипотека ВТБ][ЗЛ][ЛС] Переключение карточек застрахованных лиц (Step 72)
    this.InsuredPersonslistTrue = page.getByTestId('insured-persons-list').locator('i').nth(4)

    // ADI-T2399 (1.0) Выполнение действия (без выбора исполнителя) (Step 75)
    this.ButtonAiTransitions = page.getByTestId('ai-transitions-relations-control-Draft_to_Signing')

    // ADI-T2641 (1.0) Переход на вкладку документа (Step 76)
    this.TabpaymentPlan = page.locator('#tab-Payment-plan-nav')

    // ADI-T2926 (1.0) [Ипотека ВТБ] [Договор] Заполнение блока 'Порядок оплаты премии' (Step 77)
    this.ButtonPaymentMethod = page.getByTestId('payment-method-ng-select').locator('span').first()
    this.OptionPayMo = page.getByText('Интернет-эквайринг/PAYMO')

    // ADI-T3301 (1.0) [Ипотека ВТБ][Договор] Заполнение блока 'Плательщик' (способ уведомления) (Step 78)
    this.PaymentNotification = page.getByTestId('payment-notification-method-ng-select').locator('span').first()
    this.OptionSMS = page.getByRole('option', { name: 'SMS' }).first()

    // ADI-T3302 (1.0) [Ипотека ВТБ][Договор] Проверка и заполнение данных (номер, дата документа оплаты) в блоке 'Оплата по договору' (Step 79)
    this.LableEmail = page.getByTestId('email').getByRole('textbox')
    this.LablePaymentDocumentNumber = page.getByTestId('payment-document-number').getByRole('textbox')
    this.LablePaymentDocumentData = page.getByTestId('payment-document-date').getByRole('textbox')

    // ADI-T2641 (1.0) Переход на вкладку документа (Step 81)
    this.TabPremiumGraph = page.getByTestId('tab-premium-graph-nav')

    // ADI-T8049 (1.0) Проверка наличия или отсутствия поля в блоке (универсальное) (Step 82)
    this.AiTransitionsRelations = page.getByTestId('ai-transitions-relations-control-Signing_to_Signed')

    // ADI-T3071 (1.0) [Ипотека ВТБ][Котировка][ЗЛ] Заполнение полей в блоке 'Страхователь' (категория, сем.положение, телефон, email)
    this.SelectedEmail = page.getByTestId('selected-email').getByRole('combobox')

    //
    this.ServiceSector = page
      .getByTestId('lookupDialogId')
      .getByTestId('ip-profession-industry')
      .locator('div')
      .filter({
        hasText: 'ОТРАСЛЬ ПРОФЕССИЯ КАТЕГОРИЯ РИСКА Сфера обслуживания, жилищно-коммунального хозяйства, торговляПовар',
      })
      .first()
    this.DisabilityGroup = page.getByTestId('disability-group').locator('app-text-input').getByRole('textbox')

    // Выбор чекбокса
    this.PsychologicalGroup = page
      .getByTestId('psychological-group')
      .locator('ng-component')
      .filter({
        hasText: 'Были обращения к психиатру/наркологу; состоит на учете/лечится/прошел курс лечен',
      })
      .locator('i')
    this.Psychological = page.getByTestId('psychological-group').getByRole('textbox')
    this.SurgeryExists = page.getByTestId('surgery-exists').locator('i')
    this.DiseaseSection = page.getByTestId('disease-section').getByRole('combobox').first()
    this.AppTextInputO = page
      .locator('app-text-input')
      .filter({
        hasText: 'Описание операции --Необходимо указать описание операции',
      })
      .getByRole('textbox')
    this.Underwriting = page.locator('#tab-underwriting-overview-nav')
    this.Purpura = page.getByRole('cell', { name: 'Пурпура' })
    this.SpidOption = page.getByRole('cell', { name: 'СПИД', exact: true })
    this.OptionDiabet = page.getByRole('cell', { name: 'Диабет 2 типа' })
    this.OptionServal = page.getByRole('cell', { name: 'Цирроз печени' })
    this.OptionGlomerulonefrit = page.getByRole('cell', { name: 'Гломерулонефрит' }).locator('div').nth(2)
    this.Optionbehter = page.getByRole('cell', { name: 'Болезнь Бехтерева' })
    this.OptionMiopiy = page.getByRole('cell', {
      name: 'Высокая степень миопии',
    })
    this.OptionPsoriaz = page.getByRole('cell', { name: 'Псориаз (тяжелая степень - 3' }).locator('div').nth(2)
    this.OptionSarkoidoz = page.getByRole('cell', { name: 'Саркоидоз' })
    this.OptionPoliomielit = page.getByRole('cell', { name: 'Полиомиелит' }).locator('div').nth(2)
    this.OptionOnkologi = page.getByRole('cell', {
      name: 'Доброкачественные опухоли головного мозга и спинного мозга',
    })

    // ADI-T3382 (1.0) [Ипотека ВТБ][Котировка][Андеррайтинг] Проверка отображения триггеров в блоке 'Андертриггеры и стопфакторы'
  }

  async Examination(object, object1, object2) {
    await test.step('Проверка значений', async () => {
      for (let i = 1; i < 2; i++) {
        const con = await this.page
          .locator('.ai-no-filter')
          .locator(`#-row-${i}`)
          .getByRole('cell')
          .nth(0)
          .textContent()
        const cot = await this.page
          .locator('.ai-no-filter')
          .locator(`#-row-${i}`)
          .getByRole('cell')
          .nth(2)
          .textContent()
        const cos = await this.page
          .locator('.ai-no-filter')
          .locator(`#-row-${i}`)
          .getByRole('cell')
          .nth(3)
          .textContent()
        if ((con === object) | (cot === object1) | (cos === object2)) {
          break
        }
      }
    })
  }

  async ClickOptionOnkologi() {
    await test.step('Выбран чек-бокс "Онкология"', async () => {
      await this.OptionOnkologi.click() // Нажать кнопку войти
    })
  }

  async ClickOptionPoliomielit() {
    await test.step('Выбран чек-бокс "Болезни нервной системы"', async () => {
      await this.OptionPoliomielit.click() // Нажать кнопку войти
    })
  }

  async ClickOptionSarkoidoz() {
    await test.step('Выбран чек-бокс "Системные заболевания"', async () => {
      await this.OptionSarkoidoz.click() // Нажать кнопку войти
    })
  }

  async ClickOptionPsoriaz() {
    await test.step('Выбран чек-бокс "Заболевания глаз"', async () => {
      await this.OptionPsoriaz.click() // Нажать кнопку войти
    })
  }

  async ClickOptionMiopiy() {
    await test.step('Выбран чек-бокс "Заболевания глаз"', async () => {
      await this.OptionMiopiy.click() // Нажать кнопку войти
    })
  }

  async ClickOptionbehter() {
    await test.step('Выбран чек-бокс "Болезни опорно-двигательного аппарата"', async () => {
      await this.Optionbehter.click() // Нажать кнопку войти
    })
  }

  async ClickOptionGlomerulonefrit() {
    await test.step('Выбран чек-бокс "Болезни мочеполовой системы"', async () => {
      await this.OptionGlomerulonefrit.click() // Нажать кнопку войти
    })
  }

  async ClickOptionServal() {
    await test.step('Выбран чек-бокс "Болезни органов пищеварения (пищевода, желудка, кишечника, печени, желчного пузыря, поджелудочной железы)"', async () => {
      await this.OptionServal.click() // Нажать кнопку войти
    })
  }

  async ClickOptionDiabet() {
    await test.step('Выбран чек-бокс "Болезни эндокринной системы, расстройства питания и нарушение обмена веществ"', async () => {
      await this.OptionDiabet.click() // Нажать кнопку войти
    })
  }

  async ClickSpidOption() {
    await test.step('Выбран чек-бокс "СПИД, ВИЧ инфекция, вирусный гепатит (вид, год заболевания)"', async () => {
      await this.SpidOption.click() // Нажать кнопку войти
    })
  }

  async clickPurpura() {
    await test.step('Выбран чек-бокс "Болезни крови, кроветворных органов и лимфатической системы"', async () => {
      await this.Purpura.click() // Нажать кнопку войти
    })
  }

  async clickUnderwriting() {
    await test.step('Нажата на вкладку "Андеррайтинг"', async () => {
      await this.Underwriting.click() // Нажать кнопку войти
    })
  }

  async fillAppTextInputO(AppTextInputO) {
    await test.step(`Заполнено поле "Описание операции" - (${AppTextInputO})`, async () => {
      await this.AppTextInputO.fill(AppTextInputO) // Заполнить поле Фамилия
    })
  }

  async clickSurgeryExists() {
    await test.step('Нажата чекбокс "Проводимые ранее или планируемые операции в связи с болезнями, травмами"', async () => {
      await this.SurgeryExists.click() // Нажать кнопку войти
    })
  }

  async clickPsychologicalGroup() {
    await test.step('Нажата чекбокс "Были обращения к психиатру/наркологу; состоит на учете/лечится/прошел курс лечения"', async () => {
      await this.PsychologicalGroup.click() // Нажать кнопку войти
    })
  }

  async fillDisabilityGroup(DisabilityGroup) {
    await test.step(`Заполнено поле "Описание" - (${DisabilityGroup})`, async () => {
      await this.DisabilityGroup.fill(DisabilityGroup) // Заполнить поле Фамилия
    })
  }

  async fillPsychological(Psychological) {
    await test.step(`Заполнено поле "Описание" - (${Psychological})`, async () => {
      await this.Psychological.fill(Psychological) // Заполнить поле Фамилия
    })
  }

  async ClickDiseaseSection() {
    await test.step('Нажата чекбокс "Сфера обслуживания, жилищно-коммунального хозяйства, торговля"', async () => {
      await this.DiseaseSection.click() // Нажать кнопку войти
    })
  }

  async clickServiceSector() {
    await test.step('Нажата чекбокс "Сфера обслуживания, жилищно-коммунального хозяйства, торговля"', async () => {
      await this.ServiceSector.click() // Нажать кнопку войти
    })
  }

  async clickSelectedEmail() {
    await test.step('Нажата кнопка "Контактный e-mail"', async () => {
      await this.SelectedEmail.click() // Нажать кнопку войти
    })
  }

  // Выбор значения
  async SelectingAValue(value) {
    await test.step(`Выбрано значение - "${value}"`, async () => {
      await this.page.getByRole('option', { name: value }).click()
    })
  }

  // Выбор кнопки
  async SelectingAButton(value) {
    await test.step(`Выбрано значение - "${value}"`, async () => {
      await this.page.getByRole('button', { name: value }).click()
    })
  }

  // Переход по вкладкам
  async SwitchingToTheMainMenu(firstLevel, secondLevel, thirdLevel) {
    await test.step(`Переход по вкладкам - ("${firstLevel}", "${secondLevel}", "${thirdLevel}")`, async () => {
      const menuList = [firstLevel, secondLevel, thirdLevel]
      for (const value of menuList) {
        if (value != null) {
          await this.page.locator('li').filter({ hasText: value }).click()
        }
      }
    })
  }

  async FindingTheValue(partyCode) {
    await test.step(`Выбрана галка в чек-бокс в таблице напротив контрагента с кодом (${partyCode})`, async () => {
      const counter = await this.page.locator('#policyholder-search-table-paginator-result').getByText(/\((\d+)\)/)
      await this.page.waitForTimeout(5000)
      const matchescount = await counter.textContent()
      const inde = await this.page.getByTestId('policyholder-search-table').locator('div.ng-input')
      const incon = await inde.textContent()
      console.log(incon)

      const index = 4 // доделать
      const matches = matchescount.match(/\((\d+)\)/)
      let number
      if (matches && matches.length > 1) {
        number = parseInt(matches[1] - 1)
      }

      for (let i = 0; i <= number; i++) {
        const tableRow = await this.page
          .locator('#policyholder-search-table-table')
          .locator(`#policyholder-search-table-row-${i}`)
          .getByRole('cell')
          .nth(1)
        const tableRowCon = await tableRow.textContent()

        if (tableRowCon.trim() === partyCode.trim()) {
          const checkbox = await this.page.getByRole('row', { name: partyCode }).getByRole('checkbox')
          await checkbox.first().check()
          break
        }

        if (i === index) {
          await this.page.getByRole('button', { name: '' }).click()
          await this.page.waitForTimeout(5000)
          number -= index
          i = -1
        }
      }
    })
  }

  async FindingTheValueAnother(partyCode) {
    await test.step(`Выбрана галка в чек-бокс в таблице напротив контрагента с кодом (${partyCode})`, async () => {
      const counter = await this.page.locator('#parti-search-table-paginator-result').getByText(/\((\d+)\)/)
      await this.page.waitForTimeout(5000)
      const matchescount = await counter.textContent()
      const inde = await this.page.getByTestId('parti-search-table').locator('div.ng-input')
      const incon = await inde.textContent()
      console.log(incon)

      const index = 4 // доделать
      const matches = matchescount.match(/\((\d+)\)/)
      let number
      if (matches && matches.length > 1) {
        number = parseInt(matches[1] - 1)
      }

      for (let i = 0; i < number; i++) {
        const tableRow = await this.page
          .locator('#parti-search-table-table')
          .locator(`#parti-search-table-row-${i}`)
          .getByRole('cell')
          .nth(1)
        const tableRowCon = await tableRow.textContent()

        if (tableRowCon.trim() === partyCode.trim()) {
          const checkbox = await this.page.getByRole('row', { name: partyCode }).getByRole('checkbox')
          await checkbox.check()
          break
        }

        if (i === index) {
          await this.page.getByRole('button', { name: '' }).click()
          await this.page.waitForTimeout(5000)
          number -= index
          i = -1
        }
      }
    })
  }

  async goto(testEnvironment) {
    await test.step(`Выполнен переход к тестовой среде (${testEnvironment})`, async () => {
      await this.page.goto(testEnvironment)
    })
  }

  // Общие методы
  async inserOnlyDay(days) {
    const result = new Date()
    result.setDate(result.getDate() + days)

    let day = result.getDate()
    // let month = result.getMonth() + 1
    // const year = result.getFullYear()

    day = day < 10 ? '0' + day : day
    // month = month < 10 ? '0' + month : month

    return day
  }

  async insertDate(days) {
    const result = new Date()
    result.setDate(result.getDate() + days)

    let day = result.getDate()
    let month = result.getMonth() + 1
    const year = result.getFullYear()

    day = day < 10 ? '0' + day : day
    month = month < 10 ? '0' + month : month

    return day + '.' + month + '.' + year
  }

  async insertMonth(Month) {
    const result = new Date()
    result.setDate(result.getMonth() - Month)

    let day = result.getDate()
    let month = result.getMonth() + 1
    const year = result.getFullYear()

    day = day < 10 ? '0' + day : day
    month = month < 10 ? '0' + month : month

    return day + '.' + month + '.' + year
  }

  async insertDateMinus(days) {
    const result = new Date()
    result.setDate(result.getDate() - days)

    let day = result.getDate()
    let month = result.getMonth() + 1
    const year = result.getFullYear()

    day = day < 10 ? '0' + day : day
    month = month < 10 ? '0' + month : month

    return day + '.' + month + '.' + year
  }

  async getDocumentNumber() {
    return this.AiInfoControl.textContent()
  }

  // ADI-T2607 (1.0) Авторизация (Step 1)
  async clickEnterButton() {
    await test.step('Нажата кнопка "Вход"', async () => {
      await this.EnterButton.click() // Нажать кнопку Войти
    })
  }

  async fillUserNameLable(UserName) {
    await test.step(`Заполнено поле "Имя" - (${UserName})`, async () => {
      await this.UserNameLable.fill(UserName) // Заполнить поле Имя
    })
  }

  async fillPasswordLable(Password) {
    await test.step(`Заполнено поле "Пароль" - (${Password})`, async () => {
      await this.PasswordLable.fill(Password) // Заполнить поле Пароль
    })
  }

  async clickLoginTypeRadioBox() {
    await test.step('Нажата радио-кнопка "Внешний сотрудник (по логину/паролю)"', async () => {
      await this.LoginTypeRadioBox.click() // Нажать радио-кнопку Внешний сотрудник (по логину/паролю)
    })
  }

  async clickLoginButton() {
    await test.step('Нажата кнопка "Войти"', async () => {
      await this.LoginButton.click() // Нажать кнопку войти
    })
  }

  // ADI-T1990 (1.0) Переход по главному меню (Step 2)
  async clickInsuranceProducts() {
    await this.InsuranceProducts.click() // Перейти по вкладке "Страховые продукты"
  }

  async clickMortgageVTB() {
    await this.MortgageVTB.click() // Перейти по вкладке "Ипотека ВТБ"
  }

  async clickVTBQuote() {
    await this.VTBQuote.click() // Перейти по вкладке "Котировка ВТБ"
  }

  // ADI-T3007 (1.0) Поиск и выбор в форме 'Поиск контрагента - по параметрам' ФЛ в системе Адакта (Step 3)
  async clickPhLookupButton() {
    await test.step('Нажат значок "Лупы"', async () => {
      await this.PhLookupButton.click() // Нажать значок лупы
    })
  }

  async clickCounterpartyTypeCombobox() {
    await test.step('Нажат combobox "Тип контрагента"', async () => {
      await this.CounterpartyTypeCombobox.click() // Нажать на combobox "Тип контрагента"
    })
  }

  async clickIndividualOption() {
    await test.step('Выбрано "Физ.лицо"', async () => {
      await this.IndividualOption.click() // Выбрать "Физ.лицо"
    })
  }

  async clickSystemSelectionDropdownCombobox() {
    await test.step('Нажат combobox "Поиск контрагента а системах"', async () => {
      await this.SystemSelectionDropdownCombobox.click() // Нажать на combobox "Поиск контрагента а системах"
    })
  }

  async clickAdaktaSystem() {
    await test.step('Выбрано "Поиск в системе Адакта"', async () => {
      await this.AdaktaSystem.click() // Выбрать "Поиск в системе Адакта"
    })
  }

  async fillPartyLastName(PartyLastName) {
    await test.step(`Заполнено поле "Фамилия" - (${PartyLastName})`, async () => {
      await this.PartyLastName.fill(PartyLastName) // Заполнить поле Фамилия
    })
  }

  async fillPartyFirstName(PartyFirstName) {
    await test.step(`Заполнено поле "Имя" - (${PartyFirstName})`, async () => {
      await this.PartyFirstName.fill(PartyFirstName) // Заполнить поле Имя
    })
  }

  async fillPartyMiddleName(PartyMiddleName) {
    await test.step(`Заполнено поле "Отчество" - (${PartyMiddleName})`, async () => {
      await this.PartyMiddleName.fill(PartyMiddleName) // Заполнить поле Отчество
    })
  }

  async clickSearchButton() {
    await test.step('Нажата кнопка "Поиск"', async () => {
      await this.SearchButton.click() // Нажать кнопку "Поиск"
    })
  }

  // async clickArrowRightButton () {
  //   await this.ArrowRightButton.click() // Нажать на стрелочку вправа
  // }

  // async clickRow2902065 () {
  //   await this.Row2902065.check() // Поставить галку в чек-бокс с номером "2902065"
  // }

  async clickChoiceButton() {
    await test.step('Нажата кнопка "Выбрать"', async () => {
      await this.ChoiceButton.click() // Нажать кнопку "Выбрать"
    })
  }

  // ADI-T3272 (1.0) [Ипотека ВТБ][ОС][Котировка] Заполнение доп информации по Страхователю (категория, сем.положение, тел, почта) (Step 4)
  async clickMaritalStatusCombobox() {
    await test.step('Нажат combobox "Семейное положение"', async () => {
      await this.MaritalStatusCombobox.click() // Нажать на combobox "Семейное положение"
    })
  }

  async clickMarriedOption() {
    await test.step('Выбрано "женат / замужем"', async () => {
      await this.MarriedOption.click() // Выбрать "женат / замужем"
    })
  }

  async clickSelectedPhoneCombobox() {
    await test.step('Нажат combobox "Контактный телефон"', async () => {
      await this.SelectedPhoneCombobox.click() // Нажать на combobox "Контактный телефон"
    })
  }

  async clickPhoneOption() {
    await this.PhoneOption.click() // Выбрать "8(900)398-05-35"
  }

  async clickCategoryCombobox() {
    await test.step('Нажат combobox "Категория"', async () => {
      await this.CategoryCombobox.click() // Нажать на combobox "Категория"
    })
  }

  async clickBorrowerOption() {
    await test.step('Выбрано значение "заемщик"', async () => {
      await this.BorrowerOption.click() // Выбрать "заемщик"
    })
  }

  // ADI-T3194 (1.0) Установка, снятие чек-бокса в блоке (Step 5)
  async clickNoEmailCheck() {
    await test.step('Установлена галка в чек-бокс с номером "Отказ от предоставления e-mail"', async () => {
      await this.NoEmailCheck.click() // Поставить галку в чек-бокс с номером "Отказ от предоставления e-mail"
    })
  }

  // ADI-T2365 (1.0) [Ипотека ВТБ][Котировка] Заполнение блока 'Кредитный договор' (ОСЗ/валюта/даты/срок/% ставка/цель/% увел СС/порядок определения СС/фикс. сумма) (Step 6)
  async fillOSZInputLable(OSZInputLable) {
    await test.step(`Заполнено поле "Остаток ссудной задолженности" - (${OSZInputLable})`, async () => {
      await this.OSZInputLable.fill(OSZInputLable) // Заполнить поле "Остаток ссудной задолженности"
    })
  }

  async fillCreditDateInputLable(CreditDateInputLable) {
    await test.step(`Заполнено поле "Дата выдачи кредита" - (${CreditDateInputLable})`, async () => {
      await this.CreditDateInputLable.fill(CreditDateInputLable) // Заполнить поле "Дата выдачи кредита"
    })
  }

  async fillRemainingMonthsInputLable(RemainingMonthsInputLable) {
    await test.step(`Заполнено поле "Оставшийся срок кредита (в мес.)" - (${RemainingMonthsInputLable})`, async () => {
      await this.RemainingMonthsInputLable.fill(RemainingMonthsInputLable) // Заполнить поле "Оставшийся срок кредита (в мес.)"
    })
  }

  async clickCreditPurposeCombobox() {
    await test.step('Нажат combobox "Цель кредита"', async () => {
      await this.CreditPurposeCombobox.click() //  Нажать на combobox "Цель кредита"
    })
  }

  async clickBuyingHousingOption() {
    await test.step('Выбрано "Покупка готового жилья"', async () => {
      await this.BuyingHousingOption.click() //  Выбрать "Покупка готового жилья"
    })
  }

  async clickSumInsuredCombobox() {
    await test.step('Нажат combobox "Порядок определения Страховой суммы"', async () => {
      await this.SumInsuredCombobox.click() // Нажать на combobox "Порядок определения Страховой суммы"
    })
  }

  async clickOSZPercentOption() {
    await test.step('Выбрано "ОСЗ + процент"', async () => {
      await this.OSZPercentOption.click() // Выбрать "ОСЗ + процент"
    })
  }

  async fillCreditPercentageInputLable(CreditPercentageInputLable) {
    await test.step(`Заполнено поле "Текущая ставка по кредиту" - (${CreditPercentageInputLable})`, async () => {
      await this.CreditPercentageInputLable.fill(CreditPercentageInputLable) // Заполнить поле "Текущая ставка по кредиту"
    })
  }

  // ADI-T3843 (1.0) [Ипотека ВТБ] Блок Договор страхования. Заполнение полей (дата начала, дата закл, прогр. стр) (Step 7)
  async fillIssueDateInputLable(IssueDateInputLable) {
    await test.step(`Заполнено поле "Дата начала" - (${IssueDateInputLable})`, async () => {
      await this.IssueDateInputLable.fill(IssueDateInputLable) // Заполнить поле "Дата начала"
    })
  }

  async clickInsuranceProgram() {
    await test.step('Нажат combobox "Программа страхования"', async () => {
      await this.InsuranceProgram.click() //  Нажать на 'Программа страхования'
    })
  }

  async clickMainProgramOption() {
    await test.step('Выбрано "Основная программа"', async () => {
      await this.MainProgramOption.click() // Выбрать "Основная программа"
    })
  }

  // ADI-T2367 (1.0) [Ипотека ВТБ][Общее] Заполнение блока 'Орг структура' (Step 8)
  async clickDepartmentSearch() {
    await test.step('Нажата кнопка "Поиск"', async () => {
      await this.DepartmentSearch.click() // Нажать кнопку "Поиск"
    })
  }

  async fillDepartmentNameSection(DepartmentNameSection) {
    await test.step(`Заполнено поле "Подразделение заключения" - (${DepartmentNameSection})`, async () => {
      await this.DepartmentNameSection.fill(DepartmentNameSection) // Заполнить поле "Подразделение заключения"
    })
  }

  async clickStandartSearchButton() {
    await test.step('Нажата кнопка "Поиск"', async () => {
      await this.StandartSearchButton.click() // Нажать кнопку "Поиск"
    })
  }

  async clickStantartCheckbox() {
    await test.step('Нажат чек-бокс', async () => {
      await this.StantartCheckbox.check() // Нажать на чек-бокс
    })
  }

  async clickDisease() {
    await test.step('Нажат чек-бокс', async () => {
      await this.Disease.click() // Нажать на чек-бокс
    })
  }

  // ADI-T2641 (1.0) Переход на вкладку документа (Step 9)
  async clickPersonsNav() {
    await test.step(' Перейти по вкладке "Застрахованные"', async () => {
      await this.PersonsNav.click() // Перейти по вкладке "Застрахованные"
    })
  }

  // ADI-T3097 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Нажатие кнопки Добавить в блоке 'Список застрахованных'(Step 10)
  async clickAddButton() {
    await test.step('Нажат кнопка "Добавить"', async () => {
      await this.AddButton.click() // Нажать кнопку "Добавить"
    })
  }

  // ADI-T2371 (1.0) [[Ипотека ВТБ][Котировка][ЛС][ЗЛ] Выбор страхователя и проверка автозаполненных полей (Step 11)
  async clickSelectPolicyholder() {
    await test.step('Нажата кнопка "Выбрать страхователя"', async () => {
      await this.SelectPolicyholder.click() // Нажать кнопку "Выбрать страхователя"
    })
  }

  async clickSelectedPhone() {
    await test.step('Нажат combobox "Контактный телефон"', async () => {
      await this.SelectedPhone.click() // Нажать на combobox "Контактный телефон"
    })
  }

  async clickNumberOption() {
    await this.NumberOption.click() // Выбрать "8(900)398-05-35"
  }

  // ADI-T3194 (1.0) Установка, снятие чек-бокса в блоке (Step 12)
  async clickIpDataSection() {
    await test.step('Нажат чек-бокс', async () => {
      await this.IpDataSection.click() // Нажать на чек-бокс
    })
  }

  // ADI-T2959 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение блока 'Тарификация'(Step 13)
  async fillPercentageParticipationInput(PercentageParticipationInput) {
    await test.step(`Заполнено поле "Процент участия застрахованного в кредите" - (${PercentageParticipationInput})`, async () => {
      await this.PercentageParticipationInput.fill(PercentageParticipationInput) // Заполнить поле "Процент участия застрахованного в кредите"
    })
  }

  // ADI-T2408 (1.0) [[Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение блока 'Информация о профессии' / Раздела 'ПРОФЕССИЯ'(Step 14)
  async clickTypeEmploymentCombobox() {
    await test.step('Нажат combobox "Настоящее место работы"', async () => {
      await this.TypeEmploymentCombobox.click() // Нажать на combobox "Настоящее место работы"
    })
  }

  async clickHiringOption() {
    await this.HiringOption.click() // Выбрать "Найм"
  }

  async fillOrganizationLable(OrganizationLable) {
    await test.step(`Заполнено поле "Наименование организации" - (${OrganizationLable})`, async () => {
      await this.OrganizationLable.fill(OrganizationLable) // Заполнить поле "Наименование организации"
    })
  }

  async fillProfessionSkillsLable(ProfessionSkillsLable) {
    await test.step(`Заполнено поле "Должностные обязанности" - (${ProfessionSkillsLable})`, async () => {
      await this.ProfessionSkillsLable.fill(ProfessionSkillsLable) // Заполнить поле "Наименование организации"
    })
  }

  async clickProfessionSearchLable() {
    await test.step('Нажата "Лупа"', async () => {
      await this.ProfessionSearchLable.click() // Нажать на Лупу
    })
  }

  async fillProfessionNameLable(ProfessionNameLable) {
    await test.step(`Заполнено поле "Процент участия застрахованного в кредите" - (${ProfessionNameLable})`, async () => {
      await this.ProfessionNameLable.fill(ProfessionNameLable) // Заполнить поле "Процент участия застрахованного в кредите"
    })
  }

  async clickManagersText() {
    await test.step('Нажат чек-бокс', async () => {
      await this.ManagersText.click() // Нажать на чек-бокс
    })
  }

  // ADI-T2776 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение разделов 'Рост/Вес/Давление', 'Заболевания' в блоке 'Медицинская информация'(Step 15)
  async fillIpHeightInput(IpHeightInput) {
    await test.step(`Заполнено поле "Рост в см" - (${IpHeightInput})`, async () => {
      await this.IpHeightInput.fill(IpHeightInput) // Заполнить поле "Рост в см"
    })
  }

  async fillIpWeightInput(IpWeightInput) {
    await test.step(`Заполнено поле "Вес в кг" - (${IpWeightInput})`, async () => {
      await this.IpWeightInput.fill(IpWeightInput) // Заполнить поле "Вес в кг"
    })
  }

  async fillBloodPressureUpInput(BloodPressureUpInput) {
    await test.step(`Заполнено поле "Артериальное давление (последнее измерение, верхнее, мм. рт. ст.)" - (${BloodPressureUpInput})`, async () => {
      await this.BloodPressureUpInput.fill(BloodPressureUpInput) // Заполнить поле "Артериальное давление (последнее измерение, верхнее, мм. рт. ст.)"
    })
  }

  async fillBloodPressureLowInput(BloodPressureLowInput) {
    await test.step(`Заполнено поле "Артериальное давление (последнее измерение, нижнее, мм. рт. ст.)" - (${BloodPressureLowInput})`, async () => {
      await this.BloodPressureLowInput.fill(BloodPressureLowInput) // Заполнить поле "Артериальное давление (последнее измерение, нижнее, мм. рт. ст.)"
    })
  }

  async clickMedicationGroupCombobox() {
    await test.step('Нажат combobox "Употребляете ли Вы (назначены ли Вам) какие-либо медикаменты "', async () => {
      await this.MedicationGroupCombobox.click() // Нажать на combobox "Употребляете ли Вы (назначены ли Вам) какие-либо медикаменты "
    })
  }

  async clickDontTakeMedicationOption() {
    await test.step('Выбрано значение "не принимаю медикаменты"', async () => {
      await this.DontTakeMedicationOption.click() // Выбрать "не принимаю медикаменты"
    })
  }

  async clickDisabilityGroupCombobox() {
    await test.step('Нажат combobox "Имеете ли Вы или имели в прошлом группу Инвалидности или подготовку к направлению на медико-социальную экспертизу"', async () => {
      await this.DisabilityGroupCombobox.click() //  Нажать на combobox "Имеете ли Вы или имели в прошлом группу Инвалидности или подготовку к направлению на медико-социальную экспертизу"
    })
  }

  async clickNotOption() {
    await test.step('Выбрано значение "нет"', async () => {
      await this.NotOption.click() // Выбрать "нет"
    })
  }

  // ADI-T2783 (1.0) [Ипотека ВТБ][Котировка][ЗЛ] Заполнение раздела 'Заболевания'(Step 16)

  async clickPresenceOfDiseases() {
    await test.step('Нажат чек-бокс "Наличие заболеваний"', async () => {
      await this.PresenceOfDiseases.click() // Нажать на чек-бокс "Наличие заболеваний"
    })
  }

  async clickAddDiseaseTableButton() {
    await test.step('Нажата кнопка "+ Добавить"', async () => {
      await this.AddDiseaseTableButton.click() // Нажать кнопку "+ Добавить"
    })
  }

  async clickDiseaseSearchButton() {
    await test.step('Нажата "Лупа"', async () => {
      await this.DiseaseSearchButton.click() // Нажать на лупу
    })
  }

  async fillDiseaseGroupNameText(DiseaseGroupNameText) {
    await test.step(`Заполнено поле "Группа заболеваний" - (${DiseaseGroupNameText})`, async () => {
      await this.DiseaseGroupNameText.fill(DiseaseGroupNameText) // Заполнить поле "Группа заболеваний"
    })
  }

  async fillDiseaseName(DiseaseName) {
    await test.step(`Заполнено поле "Заболевание" - (${DiseaseName})`, async () => {
      await this.DiseaseName.fill(DiseaseName) // Заполнить поле "Заболевание"
    })
  }

  async clickOrganВiseasesRow() {
    await test.step('Выбрано "Болезни органов пищеварения (пищевода, желудка, кишечника, печени, желчного пузыря, поджелудочной железы)"', async () => {
      await this.OrganВiseasesRow.click() // Выбрать "Болезни органов пищеварения (пищевода, желудка, кишечника, печени, желчного пузыря, поджелудочной железы)"
    })
  }

  async fillAppTextInputLable(AppTextInputLable) {
    await test.step(`Заполнено поле "Описание заболевания" - (${AppTextInputLable})`, async () => {
      await this.AppTextInputLable.fill(AppTextInputLable) // Заполнить поле "Описание заболевания"
    })
  }

  async clickOkButton() {
    await test.step('Нажата кнопка "Ок"', async () => {
      await this.OkButton.click() // Нажать Ок
    })
  }

  async fillDiseaseAdditionLable(DiseaseAdditionLable) {
    await test.step(`Заполнено поле "Дополнительная информация" - (${DiseaseAdditionLable})`, async () => {
      await this.DiseaseAdditionLable.fill(DiseaseAdditionLable) // Заполнить поле "Дополнительная информация"
    })
  }

  // ADI-T2044 (1.0) Сохранить / Рассчитать (Step 17)
  async clickSaveButton() {
    await test.step('Нажата кнопка "Сохранить"', async () => {
      await this.SaveButton.click() // Нажать кнопку "Сохранить"
    })
  }

  // ADI-T3097 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Нажатие кнопки Добавить в блоке 'Список застрахованных'(Step 18)
  async clickInsuredPersonsList() {
    await test.step('Нажата кнопка "+ Добавить"', async () => {
      await this.InsuredPersonsList.click() // Нажать кнопку "+ Добавить"
    })
  }

  // ADI-T3007 (1.0) Поиск и выбор в форме 'Поиск контрагента - по параметрам' ФЛ в системе Адакта (Step 19)
  async clickSelectIpButton() {
    await test.step('Нажата "Лупа"', async () => {
      await this.SelectIpButton.click() // Нажать на лупу
    })
  }

  async clickSystemSelectionDropDown() {
    await test.step('Нажата кнопка "Поиск контрагента в системах"', async () => {
      await this.SystemSelectionDropDown.click() // Нажать кнопку "Поиск контрагента в системах"
    })
  }

  // ADI-T12639 (1.0) [Ипотека ВТБ][Котировка][ЗЛ] Заполнение полей в блоке 'Личная информация' (категория, сем.положение, телефон, email) (Step 20)
  async clickIpGeneralCategory() {
    await test.step('Нажат combobox "Категория"', async () => {
      await this.IpGeneralCategory.click() // Нажать на combobox "Категория"
    })
  }

  async clickIpDataSectionMaritalStatus() {
    await test.step('Нажат combobox "Семейное положение"', async () => {
      await this.IpDataSectionMaritalStatus.click() // Нажать на combobox "Семейное положение"
    })
  }

  async clickIpDataSectionSelectedPhone() {
    await test.step('Нажат combobox "Контактный телефон"', async () => {
      await this.IpDataSectionSelectedPhone.click() // Нажать на combobox "Контактный телефон"
    })
  }

  async clickIpDataSectionSelectedEmail() {
    await test.step('Нажат combobox "Контактный e-mail"', async () => {
      await this.IpDataSectionSelectedEmail.click() // Нажать на combobox "Контактный e-mail"
    })
  }

  // ADI-T2408 (1.0) [[Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение блока "Информация о профессии" / Раздела "ПРОФЕССИЯ"(Step 22)
  async fillProfessionIndustryLable(ProfessionIndustryLable) {
    await test.step(`Заполнено поле "Дополнительная информация" - (${ProfessionIndustryLable})`, async () => {
      await this.ProfessionIndustryLable.fill(ProfessionIndustryLable) // Заполнить поле "Дополнительная информация"
    })
  }

  async clickRowEconomicsFinance() {
    await test.step('Выбрана строка "Экономика, финансы, статистика, банк, недвижимость, консалтинг, страхование Менеджер"', async () => {
      await this.RowEconomicsFinance.check() // Выбрать строку "Экономика, финансы, статистика, банк, недвижимость, консалтинг, страхование Менеджер"
    })
  }

  // ADI-T3288 (1.0) [Ипотека ВТБ][Котировка][ЗЛ][ЛС] Заполнение раздела 'Вопрос для женщин' в блоке 'Медицинская информация' (Step 24)
  async clickDiseaseSectionNgComponent() {
    await test.step('Нажат combobox "Наличие гинекологических заболеваний "', async () => {
      await this.DiseaseSectionNgComponent.click() // Нажать на combobox "Наличие гинекологических заболеваний "
    })
  }

  async clickExactNoOption() {
    await test.step('Выбрано значение "нет"', async () => {
      await this.ExactNoOption.click() // Выбрать "нет"
    })
  }

  // ADI-T2641 (1.0) Переход на вкладку документа (Step 33)
  async clickPropertyNav() {
    await test.step(' Перейти по вкладке "Застрахованное имущество"', async () => {
      await this.PropertyNav.click() // Выбрать "Застрахованное имущество"
    })
  }

  // ADI-T2788 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ИС] Заполнение блока 'Основная информация' (наименование, тип, стоимость, адрес) (Step 34)
  async clickGeneralInformationSection() {
    await test.step('Нажат combobox "Тип объекта"', async () => {
      await this.GeneralInformationSection.click() // Нажать на combobox "Тип объекта"
    })
  }

  async fillGeneralInformationSectionLable(GeneralInformationSectionLable) {
    await test.step(`Заполнено поле "Тип объекта" - (${GeneralInformationSectionLable})`, async () => {
      await this.GeneralInformationSectionLable.fill(GeneralInformationSectionLable) // Заполнить поле "Тип объекта"
    })
  }

  async fillAppTextInputLableObject(AppTextInputLableObject) {
    await test.step(`Заполнено поле "Наименование объекта" - (${AppTextInputLableObject})`, async () => {
      await this.AppTextInputLableObject.fill(AppTextInputLableObject) // Заполнить поле "Наименование объекта"
    })
  }

  async fillAddressAutocomplete(AddressAutocomplete) {
    await test.step(`Заполнено поле "Адрес целиком" - (${AddressAutocomplete})`, async () => {
      await this.AddressAutocomplete.fill(AddressAutocomplete) // Заполнить поле "Адрес целиком"
    })
  }

  async clickAdressNumber() {
    await test.step('Выбрано значение "г Владимир, ул баумана, дом 10, квартира 10"', async () => {
      await this.AdressNumber.click() // Выбрано значение "г Владимир, ул баумана, дом 10, квартира 10"
    })
  }

  async clickStandardizationButton() {
    await test.step('Нажата кнопка "Стандартизация"', async () => {
      await this.StandardizationButton.click() // Нажать на "Стандартизация"
    })
  }

  async fillGeneralInformationSectionDates(GeneralInformationSectionDate) {
    await test.step(`Заполнено поле "Дата оценки" - (${GeneralInformationSectionDate})`, async () => {
      await this.GeneralInformationSectionDate.fill(GeneralInformationSectionDate) // Заполнить поле "Дата оценки"
    })
  }

  async clickNgComponentGeneral() {
    await test.step('Нажат combobox "Документ оценки"', async () => {
      await this.NgComponentGeneral.click() // Заполнить поле "Документ оценки"
    })
  }

  async fillInputFact(InputFact) {
    await test.step(`Заполнено поле "Иной документ оценки" - (${InputFact})`, async () => {
      await this.InputFact.fill(InputFact) // Заполнить поле "Иной документ оценки"
    })
  }

  // ADI-T2789 (1.0) [Ипотека ВТБ] [Котировка] [ИС] Заполнение блока 'Имущественное страхование' (площадь, отопление, год поcтройки + характер использования) (Step 35)
  async clickPropertyInsurance() {
    await test.step('В блоке ОСНОВНАЯ ИНФОРМАЦИЯ  чекбокс "Страхование имущества" заполняется значением "true"', async () => {
      await this.PropertyInsurance.click() // В блоке ОСНОВНАЯ ИНФОРМАЦИЯ  чекбокс 'Страхование имущества' заполняется значением 'true'
    })
  }

  async fillTotalArea(TotalArea) {
    await test.step('Заполнено поле "Общая площадь"', async () => {
      await this.TotalArea.fill(TotalArea) // Заполнить поле "Количество комнат"
    })
  }

  async fillTotalAreaComponent(TotalAreaComponent) {
    await test.step('Заполнено поле "Общая площадь"', async () => {
      await this.TotalAreaComponent.fill(TotalAreaComponent) // Заполнить поле "Общая площадь"
    })
  }

  async clickTotalAreaComponentCombobox() {
    await test.step('Нажат combobox "Отопление"', async () => {
      await this.TotalAreaComponentCombobox.click() // Нажать на "Отопление"
    })
  }

  async fillNumberOfFloors(NumberOfFloors) {
    await test.step(`Заполнено поле "Количество этажей в здании" - (${NumberOfFloors})`, async () => {
      await this.NumberOfFloors.fill(NumberOfFloors) // Заполнить поле "Количество этажей в здании"
    })
  }

  async fillNumberOfFloorsnhs(NumberOfFloorsnhs) {
    await test.step(`Заполнено поле "Этаж расположения" - (${NumberOfFloorsnhs})`, async () => {
      await this.NumberOfFloorsnhs.fill(NumberOfFloorsnhs) // Заполнить поле "Этаж расположения"
    })
  }

  async fillNumberOfFloorsnhs2(NumberOfFloorsnhs2) {
    await test.step(`Заполнено поле "Год постройки здания" - (${NumberOfFloorsnhs2})`, async () => {
      await this.NumberOfFloorsnhs2.fill(NumberOfFloorsnhs2) // Заполнить поле "Год постройки здания"
    })
  }

  async fillNumberOfFloorsFirst(NumberOfFloorsFirst) {
    await test.step(`Заполнено поле "Процент износа" - (${NumberOfFloorsFirst})`, async () => {
      await this.NumberOfFloorsFirst.fill(NumberOfFloorsFirst) // Заполнить поле "Процент износа"
    })
  }

  async clickComboboxInfomation() {
    await test.step('Нажат combobox "Имеются ли внутренние и/или внешние повреждения/дефекты объекта недвижимости"', async () => {
      await this.ComboboxInfomation.click() // Нажать на "Квартирыы"
    })
  }

  async ClickUsageDescriptionSection() {
    await test.step(' "Характер использования(планируемого использования) объекта недвижимости"', async () => {
      await this.UsageDescriptionSection.click() // Заполнить поле "ОС_объекта"
    })
  }

  // ADI-T3211 (1.0) [Ипотека ВТБ][Котировка][ИС] Заполнение чекбоксов раздела 'Источники повышенной пожарной опасности' (Step 36)
  async clickFireSourceSection() {
    await test.step('"Нет" чекбокс заполняется значением "true"', async () => {
      await this.FireSourceSection.click() // Нажать на "Квартирыы"
    })
  }

  // ADI-T2880 (1.0) [Ипотека ВТБ][Котировка][ИС] Заполнение чекбоксов раздела 'Внешние стены' (Step 37)
  async clickWallSection() {
    await test.step('Чекбокс "железобетон" заполнить значением "true"', async () => {
      await this.WallSection.click() // Нажать на "Квартирыы"
    })
  }

  // ADI-T3195 (1.0) [Ипотека ВТБ][Котировка][ИС] Заполнение чекбоксов раздела 'Межэтажные перекрытия' (Step 38)
  async clickDeckSection() {
    await test.step('Чекбокс "Железобетон" заполнить значением "true"', async () => {
      await this.DeckSection.click() // Нажать на "Квартирыы"
    })
  }

  // ADI-T2887 (1.0) [Ипотека ВТБ] [Котировка] [ИС] Заполнение разделов 'Пожарная/Охранная безопасность'(Step 39)
  async clickFireProtectionSection() {
    await test.step('"Нет" чекбокс заполняется значением "true"', async () => {
      await this.FireProtectionSection.click() // Нажать на "Квартирыы"
    })
  }

  async clickSecuritySystemsSection() {
    await test.step('"Нет" чекбокс заполняется значением "true"', async () => {
      await this.SecuritySystemsSection.click() // Нажать на "Квартирыы"
    })
  }

  // ADI-T2794 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Выбор вида страхования, проверка и заполнение разделов 'Тарификация' 'Риски ТИТ ' (срок, пакет рисков, Кпрод, чекбокс андер)(Step 41)
  async clickGeneralPropertyInsurance() {
    await test.step('Чекбокс "Страхование титула" заполнить значением "true"', async () => {
      await this.GeneralPropertyInsurance.click() // Нажать на "Квартирыы"
    })
  }

  async fillOwnershipLossSection(OwnershipLossSection) {
    await test.step(`Заполнено поле "Срок страхования в месяцах" - (${OwnershipLossSection})`, async () => {
      await this.OwnershipLossSection.fill(OwnershipLossSection) // Заполнить поле "ОС_объекта"
    })
  }

  // ADI-T2797 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение блока 'Cобственник имущества' (собств., вид владения)(Step 42)
  async clickOwnerShipLossCombobox() {
    await test.step('Нажат combobox "Объект страхования в настоящее время находится в собственности"', async () => {
      await this.OwnerShipLossCombobox.click() // Нажать на "Квартирыы"
    })
  }

  async clickOwnerShipLossComboboxTwo() {
    await test.step('Нажат combobox "Вид владения"', async () => {
      await this.OwnerShipLossComboboxTwo.click() // Нажать на "Квартирыы"
    })
  }

  // ADI-T2904 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение и проверка полей в блоке 'Собственник имущества' (таблица: доля, сем.полож, чекбоксы) (Step 43)
  async clickOwnesTableButton() {
    await test.step('Выполнено нажатие на "Добавить"', async () => {
      await this.OwnesTableButton.click() // Нажать на "Квартирыы"
    })
  }

  async clickAiGroupBootstraps() {
    await test.step('Нажат combobox "Текущий собственник"', async () => {
      await this.AiGroupBootstrap.click() // Нажать на "Квартирыы"
    })
  }

  async fillOwnersTablelable(OwnersTablelable) {
    await test.step(`Заполнено поле "Доля владения" - (${OwnersTablelable})`, async () => {
      await this.OwnersTablelable.fill(OwnersTablelable) // Заполнить поле "ОС_объекта"
    })
  }

  async clickOwersTableCombobox() {
    await test.step('Нажат combobox "Семейное положение Собственника"', async () => {
      await this.OwersTableCombobox.click() // Нажать на "Семейное положение"
    })
  }

  // ADI-T2908 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение и проверка полей в блоке 'Собственник имущества' (таблица) (Step 44)
  async clickButtonSearch() {
    await test.step('Нажата кнопка "Поиск"', async () => {
      await this.ButtonSearch.click() // Нажать на "Поиск"
    })
  }

  async clickComboboxPartyType() {
    await test.step('Нажат combobox "Тип контрагента"', async () => {
      await this.ComboboxPartyType.click() // Нажать на "Тип контрагента"
    })
  }

  async fillLableLastName(LableLastName) {
    await test.step(`Заполнено поле "Фамилию" - (${LableLastName})`, async () => {
      await this.LableLastName.fill(LableLastName) // Заполнить поле "Фамилию"
    })
  }

  async fillLableFirstName(LableFirstName) {
    await test.step(`Заполнено поле "Отчество" - (${LableFirstName})`, async () => {
      await this.LableFirstName.fill(LableFirstName) // Заполнить поле "Отчество"
    })
  }

  async fillLableMiddleName(LableMiddleName) {
    await test.step(`Заполнено поле "Имя" - (${LableMiddleName})`, async () => {
      await this.LableMiddleName.fill(LableMiddleName) // Заполнить поле "Имя"
    })
  }

  // ADI-T4966 (1.0) Выбор значения из выпадающего списка (Step 45)
  async clickEncumbrancesSection() {
    await test.step('Нажат combobox "Наличие обременения имущества"', async () => {
      await this.EncumbrancesSection.click() // Нажать на combobox
    })
  }

  // ADI-T2799 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение количества переходов прав (Step 46)
  async clickOptionTransferOfRights() {
    await this.OptionTransferOfRights.click() // Нажать на combobox
  }

  async clickComboboxOwnershipHistorySection() {
    await test.step('Нажат combobox "Количество переходов права собственности"', async () => {
      await this.ComboboxOwnershipHistorySection.click() // Нажать на combobox
    })
  }

  // ADI-T1997 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ТИТ] Заполнение истории переходов прав(Step 47)
  async clickOwnershipHistory() {
    await test.step('Нажата кнопку "Добавить"', async () => {
      await this.OwnershipHistory.click() // Нажать на кнопку Добавить
    })
  }

  async clickComboboxOwnershipHistory() {
    await test.step('Нажат combobox "Документ основание"', async () => {
      await this.ComboboxOwnershipHistory.click() // Нажать на combobox
    })
  }

  async fillLableOwnerDateOneы(LableOwnerDateOne) {
    await test.step('Заполнено поле "Дата подписания"', async () => {
      await this.LableOwnerDateOne.fill(LableOwnerDateOne) // Заполнить поле "Дата подписания"
    })
  }

  async fillLableOwnerDateTwo(LableOwnerDateTwo) {
    await test.step('Заполнено поле "Дата входа в собственность"', async () => {
      await this.LableOwnerDateTwo.fill(LableOwnerDateTwo) // Заполнить поле "Дата входа в собственность"
    })
  }

  async clickButtonOwnerOk() {
    await test.step('Нажата кнопка "ОК"', async () => {
      await this.ButtonOwnerOk.click() // Нажать кнопку ОК
    })
  }

  // ADI-T3674 (1.0) [Ипотека ВТБ] Нажатие кнопки Добавить в Имущественном страховании(Step 49)
  async clickApartmentsAddButton() {
    await test.step('Нажата кнопку "Добавить"', async () => {
      await this.ApartmentsAddButton.click() // Нажать кнопку Добавить
    })
  }

  // ADI-T2788 (1.0) [Ипотека ВТБ][Котировка][ЗИ][ИС] Заполнение блока 'Основная информация' (наименование, тип, стоимость, адрес) (Step 50)
  async fillAppTextInput(AppTextInput) {
    await test.step(`Заполнено поле "Наименование обьекта страхования" - (${AppTextInput})`, async () => {
      await this.AppTextInput.fill(AppTextInput) // Заполнить поле "Наименование обьекта страхования"
    })
  }

  async clickComboboxGeneralSection() {
    await test.step('Нажат combobox "Тип объекта"', async () => {
      await this.ComboboxGeneralSection.click() // Нажать кнопку combobox
    })
  }

  async fillLableGeneralInformation(LableGeneralInformation) {
    await test.step(`Заполнено поле "Описание" - (${LableGeneralInformation})`, async () => {
      await this.LableGeneralInformation.fill(LableGeneralInformation) // Заполнить поле "Описание"
    })
  }

  async fillLableAssessedValue(LableAssessedValue) {
    await test.step(`Заполнено поле "Стоимость по ДКП (которая будет указана в договоре купли-продажи с использованием кредитных средств)" - (${LableAssessedValue})`, async () => {
      await this.LableAssessedValue.fill(LableAssessedValue) // Заполнить поле "факт.оцен_стоимость"
    })
  }

  async fillLableAssressAutocomplete(LableAssressAutocomplete) {
    await test.step(`Заполнено поле "Тип адреса" - (${LableAssressAutocomplete})`, async () => {
      await this.LableAssressAutocomplete.fill(LableAssressAutocomplete) // Заполнить поле "адрес_целиком"
    })
  }

  async clickClickOptionAdress() {
    await test.step('Выбрано значение "г Владимир, ул Аграрная, дом 15"', async () => {
      await this.ClickOptionAdress.click() // Выбрать 'г Владимир, ул Аграрная, дом 15'
    })
  }

  async clickStandardization() {
    await test.step('Нажата кнопка "Стандартизация"', async () => {
      await this.Standardization.click() // Нажать кнопку 'Стандартизация'
    })
  }

  async fillLableCadastralNumber(LableCadastralNumber) {
    await test.step(`Заполнено поле "Кадастровый номер" - (${LableCadastralNumber})`, async () => {
      await this.LableCadastralNumber.fill(LableCadastralNumber) // Заполнить поле "Кадастровый номер"
    })
  }

  async fillLableGeneralDate(LableGeneralDate) {
    await test.step(`Заполнено поле "Дата оценки" - (${LableGeneralDate})`, async () => {
      await this.LableGeneralDate.fill(LableGeneralDate) // Заполнить поле "Дата оценки"
    })
  }

  async clickComboboxGeneralDate() {
    await test.step('Выбрано значение "г Владимир, ул Аграрная, дом 15"', async () => {
      await this.ComboboxGeneralDate.click() //
    })
  }

  // ADI-T5247 (1.0) [Ипотека ВТБ] ИС. Заполнение блока Имущественное страхование по ЗУ (площадь, характер использования) (Step 51)
  async clickPropertyInsuranceTrue() {
    await test.step('чекбокс "Страхование имущества" заполнить значением true', async () => {
      await this.PropertyInsuranceTrue.click() // Выбрать "несоотв_режима_исп_объект"
    })
  }

  // ADI-T5248 (1.0) [Ипотека ВТБ][Котировка][ИС] Заполнение раздела 'Охранная безопасность' для объекта 'Земельный участок' (чекбоксы) (Step 52)
  async clickSecuritySystems() {
    await test.step('Чекбокс "Нет" заполнить значением', async () => {
      await this.SecuritySystems.click() // Выбрать "несоотв_режима_исп_объект"
    })
  }

  // ADI-T2387 (1.0) Выполнение действия (с выбором исполнителя) (Step 55)
  async clickButtonDo() {
    await test.step('Нажата кнопка "Действие"', async () => {
      await this.ButtonDo.click() // Нажать "Действие"
    })
  }

  async clickSendForApproval() {
    await test.step('Нажата кнопка "Направить на согласование Андеррайтеру ГО"', async () => {
      await this.SendForApproval.click() // Нажать "Направить на согласование Андеррайтеру ГО"
    })
  }

  async clickComboboxClick() {
    await test.step('Нажат combobox', async () => {
      await this.ComboboxClick.click() // Выбрать "несоотв_режима_исп_объект"
    })
  }

  async clickOptionName() {
    await this.OptionName.click() // Выбрать "Косинская Вера Константиновна"
  }

  // ADI-T2607 (1.0) Авторизация(Step 56)
  async clickButtonWelcom() {
    await test.step('Нажата кнопка "Добрый день, Косинская Вера Константиновна"', async () => {
      await this.ButtonWelcom.click() // Нажать 'Добрый день, Косинская Вера Константиновна '
    })
  }

  async clickButtonExit() {
    await test.step('Нажата кнопка "Выйти"', async () => {
      await this.ButtonExit.click() // Нажать ' Выйти'
    })
  }

  async clickButtonHere() {
    await test.step('Нажата кнопка "сюда"', async () => {
      await this.ButtonHere.click() // Нажать 'сюда'
    })
  }

  // ADI-T1990 (1.0) Переход по главному меню(Step 57)
  async clickButtonTaskShowcase() {
    await this.ButtonTaskShowcase.click() // Нажать 'Витрина задач'
  }

  // ADI-T2641 (1.0) Переход на вкладку документа (Step 58)
  async clickButtonTabGroupTasks() {
    await test.step('Перейти по вкладке "Задачи группы"', async () => {
      await this.ButtonTabGroupTasks.click() // Нажать 'Задачи группы'
    })
  }

  // ADI-T3954 (1.0) [Витрина задач] Поиск, назначение задачи в группе и переход к документу (Step 59)
  async clickComboboxGroupTasks() {
    await test.step('Нажат combobox "Группа"', async () => {
      await this.ComboboxGroupTasks.click() // Нажать на combobox
    })
  }

  async fillLableDocumentNumber(LableDocumentNumber) {
    await test.step('Заполнено поле "Номер документа"', async () => {
      await this.LableDocumentNumber.fill(LableDocumentNumber) // Заполнить поле "Номер документа"
    })
  }

  async clickGroupTabeRow() {
    await test.step('Выбрана строка', async () => {
      await this.GroupTabeRow.click() // Выбрать строку
    })
  }

  async clickButtonAssignATaskToYourself() {
    await test.step('Нажата кнопка "Назначить задачу на себя"', async () => {
      await this.ButtonAssignATaskToYourself.click() // нажать на кнопку "Назначить задачу на себя"
    })
  }

  async clickGroupTasksTableDoc() {
    await test.step('Перейти по ссылкке номера', async () => {
      await this.GroupTasksTableDoc.click() // Перейти по ссылкке номера
    })
  }

  // ADI-T2413 (1.0) Переключение и проверка роли (Step 60)
  async clickButtonP() {
    await test.step('Нажата кнопка "П"', async () => {
      await this.ButtonP.click() // Нажать П
    })
  }

  async clickButtonUnderwriter() {
    await test.step('Выбрано значение "Андеррайтер"', async () => {
      await this.ButtonUnderwriter.click() // Выбрать "Андеррайтер"
    })
  }

  // ADI-T2399 (1.0) Выполнение действия (без выбора исполнителя) (Step 61)

  async clickButtonYes() {
    await test.step('Нажата кнопка "Дa"', async () => {
      await this.ButtonYes.click() // Выбрать "Дa"
    })
  }

  // ADI-T2802 (1.0) [Ипотека ВТБ][Котировка][Андеррайтинг] Согласование триггеров (Step 62)
  async clickTabUnderwrightOverview() {
    await test.step('Переход по вкладке "АНДЕРРАЙТИНГ"', async () => {
      await this.TabUnderwrightOverview.click() // Перейти по вкладке
    })
  }

  async clickRowKlass() {
    await test.step('Выбрано значение "Обьекты Страхования"', async () => {
      await this.RowKlass.check() // Выбрать Обьекты Страхования
    })
  }

  async clickComboboxObjectsOfInsurance() {
    await test.step('Нажат combobox "Статус"', async () => {
      await this.ComboboxObjectsOfInsurance.click() // Нажать на combobox
    })
  }

  async clickOptionAgreed() {
    await test.step('Выбрано значение "Согласовано"', async () => {
      await this.OptionAgreed.click() // Согласовано
    })
  }

  async clickButtonChoice() {
    await test.step('Нажата кнопка "Выбрать"', async () => {
      await this.ButtonChoice.click() // Нажать кнопку Выбрать
    })
  }

  // ADI-T2399 (1.0) Выполнение действия (без выбора исполнителя) (Step 63)
  async clickOptionContinueNegotiation() {
    await this.OptionContinueNegotiation.click() // Выбрать 'Продолжить согласование'
  }

  // ADI-T2413 (1.0) Переключение и проверка роли (Step 63)
  async clickAiActorControl() {
    await test.step('Нажата кнопка "А"', async () => {
      await this.AiActorControl.click() // Нажать на А
    })
  }

  async clickOptionSalesman() {
    await test.step('Выбрано значение "Продавец"', async () => {
      await this.OptionSalesman.click() // Выбрать 'Продавец'
    })
  }

  // ADI-T2399 (1.0) Выполнение действия (без выбора исполнителя) (Step 65)
  async clickReleaseQuote() {
    await this.ReleaseQuote.click() // Выбрать 'Выпустить котировку'
  }

  // ADI-T2641 (1.0) Переход на вкладку документа(Step 66)
  async clickTabPolicyNav() {
    await test.step('Перейти по вкладке "Договор"', async () => {
      await this.TabPolicyNav.click() // Перейти по вкладке "Договор"
    })
  }

  // ADI-T2923 (1.0) [Ипотека ВТБ][Договор][ОР] Заполнение блока 'Кредитный договор' (Step 67)
  async fillLableCreditDocument(LableCreditDocument) {
    await test.step('Заполнено поле "Номер кредитного договора"', async () => {
      await this.LableCreditDocument.fill(LableCreditDocument) // Заполнить поле "Номер кредитного договора"
    })
  }

  async fillLableAppTextInput(LableAppTextInput) {
    await test.step('Заполнено поле "Место заключения кредита"', async () => {
      await this.LableAppTextInput.fill(LableAppTextInput) // Заполнить поле "Место заключения кредита"
    })
  }

  async fillLablePeriodPay(LablePeriodPay) {
    await test.step('Заполнено поле "Номер документа"', async () => {
      await this.LablePeriodPay.fill(LablePeriodPay) // Заполнить поле "Номер документа"
    })
  }

  async fillLableDateCreadit(LableDateCreadit) {
    await test.step('Заполнено поле "Текущая дата"', async () => {
      await this.LableDateCreadit.fill(LableDateCreadit) // Заполнить поле "Текущая дата"
    })
  }

  // ADI-T3117 (1.0) [Ипотека ВТБ][Договор][ЗЛ] Проверка и заполнение полей в блоке 'Личная информация'(Step 69)
  async clickIpSmsMessages() {
    await test.step('Чекбокс "Обработка персональных данных" заполнен значением "true" ', async () => {
      await this.IpSmsMessages.click() // True
    })
  }

  async clickProcessingPersonalData() {
    await test.step('Чекбокс " СМС-Уведомления для ЗЛ" заполнен значением "true" ', async () => {
      await this.ProcessingPersonalData.click() // True
    })
  }

  // ADI-T3075 (1.0) [Ипотека ВТБ][ЗЛ][ЛС] Переключение карточек застрахованных лиц (Step 70)
  async clickInsuredPersonsListTrue() {
    await test.step('В блоке СПИСОК ЗАСТРАХОВАННЫХ поставлена галк в чекбокс "Лазарева Елена Геннадьевна"', async () => {
      await this.InsuredPersonsListTrue.click() // True
    })
  }

  // ADI-T3117 (1.0) [Ипотека ВТБ][Договор][ЗЛ] Проверка и заполнение полей в блоке 'Личная информация' (Step 71)
  async clickIpSmsMessagesTrue() {
    await this.IpSmsMessagesTrue.click() // True
  }

  async clickProcessingPersonalDataTrue() {
    await this.ProcessingPersonalDataTrue.click() // True
  }

  // ADI-T3075 (1.0) [Ипотека ВТБ][ЗЛ][ЛС] Переключение карточек застрахованных лиц (Step 72)
  async clickInsuredPersonslistTrue1() {
    await test.step('В блоке СПИСОК ЗАСТРАХОВАННЫХ поставлена галк в чекбокс "Сидоров Юрий Николаевич"', async () => {
      await this.InsuredPersonslistTrue.click() // True
    })
  }

  // ADI-T2399 (1.0) Выполнение действия (без выбора исполнителя) (Step 75)
  async clickButtonAiTransitions() {
    await this.ButtonAiTransitions.click() // Выбрать "Оформить договор"
  }

  // ADI-T2641 (1.0) Переход на вкладку документа (Step 76)
  async clickTabpaymentPlan() {
    await test.step('Перейти по вкладке "График платежей"', async () => {
      await this.TabpaymentPlan.click() // Перейти по вкладке "График платежей"
    })
  }

  // ADI-T2926 (1.0) [Ипотека ВТБ] [Договор] Заполнение блока 'Порядок оплаты премии' (Step 77)
  async clickButtonPaymentMethod() {
    await test.step('Выбрано значение "Ежегодно"', async () => {
      await this.ButtonPaymentMethod.click() // Выбрать "Ежегодно"
    })
  }

  async clickOptionPayMo() {
    await test.step('Выбрано значение "Интернет-эквайринг"', async () => {
      await this.OptionPayMo.click() // Выбрать "Интернет-эквайринг"
    })
  }

  // ADI-T3301 (1.0) [Ипотека ВТБ][Договор] Заполнение блока 'Плательщик' (способ уведомления) (Step 78)
  async clickPaymentNotification() {
    await test.step('Выбрано "Способ уведомления"', async () => {
      await this.PaymentNotification.click() // Выбрать "Способ уведомления"
    })
  }

  async clickOptionSMS() {
    await this.OptionSMS.click() // Выбрать "SMS"
  }

  // ADI-T3302 (1.0) [Ипотека ВТБ][Договор] Проверка и заполнение данных (номер, дата документа оплаты) в блоке 'Оплата по договору' (Step 79)
  async fillLableEmail(LableEmail) {
    await test.step(`Заполнено поле "Тип документа " - (${LableEmail})`, async () => {
      await this.LableEmail.fill(LableEmail) // Заполнить поле "Текущая дата"
    })
  }

  async fillLablePaymentDocumentNumber(LablePaymentDocumentNumber) {
    await test.step(`Заполнено поле "Номер документа " - (${LablePaymentDocumentNumber})`, async () => {
      await this.LablePaymentDocumentNumber.fill(LablePaymentDocumentNumber) // Заполнить поле "Текущая дата"
    })
  }

  async fillLablePaymentDocumentData(LablePaymentDocumentData) {
    await test.step(`Заполнено поле "Дата документа" - (${LablePaymentDocumentData})`, async () => {
      await this.LablePaymentDocumentData.fill(LablePaymentDocumentData) // Заполнить поле "Текущая дата"
    })
  }

  // ADI-T2641 (1.0) Переход на вкладку документа (Step 81)
  async clickTabPremiumGraph() {
    await test.step('Перейти по вкладке "График тарифов"', async () => {
      await this.TabPremiumGraph.click() // Выбрать "SMS"
    })
  }

  // ADI-T8049 (1.0) Проверка наличия или отсутствия поля в блоке (универсальное) (Step 82)
  async clickAiTransitionsRelations() {
    await this.AiTransitionsRelations.click() // Выбрать "SMS"
  }
}
