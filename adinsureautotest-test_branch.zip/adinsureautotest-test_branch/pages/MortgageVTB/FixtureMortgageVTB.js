// const base = require('@playwright/test')
import { test as baseTest, expect as baseExpect } from '@playwright/test'
import { MortgageVTB } from './ClassFunc'
// const { MortgageVTB } = require('./ClassFunc')

// Extend base test by providing "todoPage" and "settingsPage".
// This new "test" can be used in multiple test files, and each of them will get the fixtures.

/**
 * @deprecated
 */
export const test = baseTest.extend({
  /**
   * @type {MortgageVTB}
   */
  mortgageVTB: async ({ page }, use) => {
    // Set up the fixture.
    const mortgageVTB = new MortgageVTB(page)
    await use(mortgageVTB)
  },
  autoWorkerFixture: [
    async ({ page }, use, testInfo) => {
      await use()

      const pageUrl = page.url()
      if (!(pageUrl.includes('entity=Contract') || pageUrl.includes('entity=UniversalDocument'))) return

      console.log(page.url())

      if (testInfo.status === testInfo.expectedStatus) return

      const responsePromise = page.waitForResponse(
        (response) => response.url().includes('/get-initial-view-model') && response.status() === 200
      )
      await page.reload()
      const response = await responsePromise
      const json = await response.json()

      const errors = getErrorsFromViewModel(json)

      console.log('Ошибки валиации документа:')
      errors.forEach((error, number) => {
        console.log(`Номер ошибки: ${number + 1}`)
        console.log(`Сообщение: ${error.message}`)
        // console.log(`Code: ${error.code}`)
        // console.log(`Строгость: ${error.severity}`)
      })
    },
    { auto: true },
  ],
})

function getErrorsFromViewModel(viewModel) {
  if (!viewModel.ValidationResult) return []
  const validationResult = viewModel.ValidationResult.schemaValidations
  const errors = []

  validationResult.forEach((error) => {
    errors.push({
      message: error.message,
      code: error.code,
      severity: error.severity,
    })
  })
  return errors
}
export const expect = baseExpect
