// @ts-check

const applicationPLE = {
  /** ---------------------- Элементы бокового меню ---------------------- */

  /** Папка  "Страховые продукты" */
  contracts: 'Contracts_menu_1',
  /** Папка  продукта "ИЮЛ" */
  propertyLegalEntities: 'PropertyLegalEntities_1_2',
  /** Элемент создания документа "Котировка" */
  application: 'Application_1_3',
  /** Папка  продукта "Программа МСБ RE" */
  smbRe: 'SMBRE_1_2',
  /** Элемент создания документа "Договор МСБ RE" */
  smbRePolicy: 'SMBREPolicy_1_3',

  /** ---------------------- Элементы витрины задач ---------------------- */

  /** Папка  "Витрина задач"' */
  workflow: 'Workflow_1_2',
  /** Вкладка "Нераспределенные задачи" витрины задач */
  tabUnassignedTasks: 'tab-Unassigned-tasks-nav',
  /** id текстбокса "Номер документа" */
  documentNumber: 'document-number',
  /** id combobox "Тип документа"*/
  documentType: 'document-type',

  /** --------------- Элементы документа Сделка / вкладки Сделка --------------- */

  /** id кнопки поиска Страхователя */
  policyHolderSearch: 'policyholder-search-button',
  /** id combobox Канал продаж */
  dealSalesChannel: 'sales-channel-ng-select',
  /** id combobox Зона ответственности */
  dealSalesZone: 'sales-zone-ng-select',
  /** id combobox Профильная программа */
  dealProgramme: 'atrDealProgram-ng-select',
  /** id кнопки поиска "Подразделение сделки" */
  departmentNameSearchButton: 'application-branch-search-dialog-button',
  /** id текстового поля "Подразделение" */
  dealDepartment: 'department-name',
  /** id checkbox "Входящее перестрахование" */
  incomingReinsurance: 'incoming-reinsurance',
  /** id button "Скопировать ИНН" */
  copyTaxnumberButton: 'copy-taxnumber-button',

  /** ------------------ Действия в документе Сделка ------------------ */

  /** id кнопки действия "Создать котировку из сделки" */
  controlPLECreateQuoteFromApplication: 'ai-transitions-relations-control-PLECreateQuoteFromApplication',
}

const quotePLE = {
  /** --------------------- id вкладок Котировки --------------------- */

  /** id вкладки "Сделка" */
  tabApplicationNav: 'tab-Application-nav',
  /** id вкладки "Локации" */
  tabLocationsNav: 'tab-Locations-nav',
  /** id вкладки "Общая информация" */
  tabGeneralInformationNav: 'tab-General-information-nav',
  /** id вкладки "РАСЧЕТ ТАРИФА & ТРИГГЕРЫ" */
  tabTariffСalculationNav: 'tab-Tariff-calculation and UW review-nav',
  /** id вкладки "Документы и фотоматериалы" */
  tabAttachedDocumentsNav: 'tab-Attached-documents-nav',
  /** id вкладки "График платежей" */
  tabPaymentPlanNav: 'tab-Payment-plan-nav',
  /** id вкладки "История согласования" */
  tabContractActivityHistoryNav: 'tab-Contract-activity and transition history-nav',

  /** ------------------ id элементов вкладки Сделка ------------------ */

  /** id кнопки "Назначить задачу на себя". Вкладка "Сделка" */
  btnAssignActivityToMe: 'btnAssignActivityToMe',
  /** id таблицы "Задачи документа" */
  задачиДокумента: '-table',

  /** ------------------ id элементов боковой панели ------------------ */

  /** id атрибута "Лимит по риску "Бой стекол"" */
  glassRiskSide: 'glass-risk-side',
  /** id атрибута "Лимит по риску "Радиационное воздействие"" */
  radiationRiskSide: 'radiation-risk-side',
  /** id атрибута "Лимит по риску "Теракт"" */
  terrorismRiskSide: 'terrorism-risk-side',
  /** id атрибута "Лимит по риску "Забастовки, локауты, волнения"" */
  srccRiskSide: 'srcc-risk-side',
  /** id атрибута "Страховая сумма по риску "Перерыв в производстве"" */
  biRiskSide: 'bi-risk-side',

  /** --------------------- id элементов вкладки Локации --------------------- */
  /** ----- id элементов блока Локации ----- */

  /** id блока "Локации" */
  locationInformation: 'location-information-section',
  /** id combobox "Основные Правила страхования" */
  generalRulesPolicy: 'general-rules-ng-select',
  /** id textbox "Реальное количество локаций по котировке" */
  rqsLocationsNumber: 'locations-number',
  /** id combobox "Валюта" */
  сurrency: 'currency-ng-select',
  /** id combobox "Страховое покрытие" */
  сoverType: 'ins-cover-type-ng-select',
  /** id checkbox "Не применяется" */
  сoverGeneralDeductible: 'general-deductible',
  /** id checkbox "В % от страховой суммы" */
  coverGeneralDeductiblePercentage: 'general-deductible-percentage',
  /** id checkbox "В рублях (валюте)" */
  coverGeneralDeductibleAmount: 'deductible-amount',
  /** id textbox "Значение франшизы" при "В % от страховой суммы" */
  coverGeneralDeductiblePercentageValue: 'deductible-percentage-value-input',
  /** id textbox "Значение франшизы" при "В рублях (валюте)" */
  coverGeneralDeductibleAmountValue: 'deductible-amount-value-input',
  /** id секции с вводом адреса локации */
  locationAddressSection: 'location-address-section',
  /** id textbox "Локация" */
  locationDescription: 'location-name',
  /** id combobox "Адрес целиком" */
  fullAddress: 'AddressAutocomplete',
  /** id textbox "Наименование" */
  searchCriteria: 'lookupDialogId',
  /** id textbox "Индекс" */
  postalCode: 'postal-code',
  /** id textbox "Страна" */
  country: 'country',
  /** id textbox "Регион" */
  region: 'region',
  /** id textbox "Город" */
  city: 'city',
  /** id checkbox "Ответственность Страховщика прямо распространяется на следующие территории (за исключением покрытия «Весь мир»): ЛНР, ДНР, Запорожскую и Херсонскую области, Иран, Сирия, Северная Корея, Ирак, Куба, Венесуэла, Бирму, Бурунди, Ливия, Мали, Никарагуа, Сомали, Южного Судана, Йемена, Зимбабве, Афганистан, ЦАР, Демократическая Республика Конго" */
  extendsToAreas: 'extends-to-areas',
  /** id combobox "Укажите территорию страхования" */
  locTypeofTerritory: 'non-localized-type-ng-select',
  /** id checkbox "Нелокализованая территория" */
  locNonlocalizedArea: 'non-localized-area',
  /** id textbox "Укажите адрес" */
  outsideRF: 'outside-rf',
  /** id textbox input "Доля российского интереса, %" */
  rfInterest: 'rf-interest-input',
  /** id checkbox "Имущество полностью или частично расположено на территории Крыма или Севастополя" */
  crimeaCheckbox: 'rk-or-s',

  /** ----- id элементов блока Отрасль ----- */

  /** id блока "Отрасль" */
  industry: 'industry-section',
  /** id кнопки поиска. Форма "Виды деятельности" */
  search: 'activity-search-button',
  /** id кнопки "Выбрать". Форма "Виды деятельности" */
  select: 'lookup-dialog-confirm-button',
  /** id поля "Код риска" */
  riskCode: 'industry-risk-code',
  /** id блока с чекбоксами "ДОПОЛНИТЕЛЬНАЯ ИНФОРМАЦИЯ «НЕФТЕГАЗОПРОВОДЫ»" */
  oilGasInformation: 'OilGasPipelinesInformation-#',
  /** id checkbox "Склад" */
  industryWarehouse: 'industry-warehouse',

  /** ----- id элементов блока ИНДИВИДУАЛЬНЫЕ РИСКОВЫЕ ФАКТОРЫ ----- */

  /** id блока "Индивидуальные рисковые факторы" */
  IndividualRiskFactors: 'individual-risks-factors-section',
  /** id секции с атрибутами "Подлежащее страхованию имущество относится к категориям" */
  openAreaCategories: 'open-area-categories',
  /** id combobox "Заявляемое имущество расположено на открытой площадке" */
  locOpenAreas: 'open-area-ng-select',
  /** id combobox "Здание является капитальным (возведено на фундаменте)" */
  objSubstructure: 'imovable-object-substructure-ng-select',
  /** id combobox "Материал стен" */
  objMaterialWall: 'material-wall-ng-select',
  /** id combobox "Материал перекрытий" */
  objMaterialDeck: 'material-deck-ng-select',
  /** id textbox "Год постройки здания" */
  objBuildingYear: 'building-year',
  /** id combobox "Год последнего капитального ремонта" */
  objBuildingRenovationYear: 'building-renovation-year',
  /** id textbox "Площадь страхуемой недвижимости, кв.м." */
  objBuildingSquare: 'building-square-input',
  /** id combobox "Наличие и тип АПС (автоматическая пожарная сигнализация)" */
  objFireAlarmSystem: 'fire-alarm-system-ng-select',
  /** id combobox "Наличие и тип АСПТ (автоматическая система пожаротушения)" */
  objFireExtinguisherSystem: 'fire-extinguisher-system-ng-select',
  /** id combobox "Тип АСПТ" */
  fireExtinguisherSystemType: 'fire-extinguisher-system-type-ng-select',
  /** id textbox "Удаленность от ближайшей пожарной части (км)" */
  objFirestationGap: 'firestation-gap',
  /** id combobox "Наличие подъездных путей к локации страхования" */
  objRoads: 'obj-roads-ng-select',
  /** id checkbox "Наличие первичных средств пожаротушения (огнетушители, пожарные щиты) в работоспособном состоянии" */
  objBasicProtection: 'basic-protection',
  /** id checkbox "Наличие воды для тушения пожара и средств для ее использования по назначению (гидранты, пожарные краны, укомплектованные пожарными рукавами, противопожарные водоемы, наличие переносной пожарной мотопомпы и т.д.)" */
  objAdvancedProtection: 'advanced-protection',
  /** id checkbox "Наличие физической охраны" */
  objSecurityPhysical: 'security-physical',
  /** id checkbox "Наличие автоматической охранной сигнализации" */
  objSecuritySystems: 'security-systems',
  /** id checkbox "Не относится ни к одной из вышеперечисленных категорий" */
  openAreaNone: 'open-area-none',
  /** id checkbox "Наличие освещения и видеонаблюдения, охватывающего всю территорию открытой площадки" */
  openAreaLighting: 'open-area-lighting',
  /** id checkbox "Регулярные обходы территории сотрудниками службы безопасности страхователя и/или ЧОП / МВД с их регистрацией в журнале" */
  openAreaRegular: 'open-area-regular',
  /** id checkbox "Осуществление контроля работниками страхователя и/или ЧОП въезда/выезда транспортных средств на территорию страхования с их регистрацией в соответствующем журнале" */
  openAreaControl: 'open-area-control',

  /** ----- id элементов блока ОБЪЕКТЫ СТРАХОВАНИЯ, СТРАХОВЫЕ СУММЫ, КУМУЛЯЦИЯ ----- */

  /** id блока "ОБЪЕКТЫ СТРАХОВАНИЯ, СТРАХОВЫЕ СУММЫ, КУМУЛЯЦИЯ" */
  insuredObjects: 'insured-objects-section',
  /** id checkbox "Здание" */
  objectBuilding: 'object-building',
  /** id textbox "Страховая сумма (Здание)" */
  objectBuildingSumInput: 'object-building-sum-input',
  /** id блока с составом здания */
  objectBuildingProperties: 'object-building-properties',
  /** id checkbox "Помещение" */
  objectPremises: 'object-premises',
  /** id textbox "Страховая сумма (Помещение)" */
  objectPremisesSumInput: 'object-premises-sum-input',
  /** id блока с составом помещения*/
  objectPremisesProperties: 'object-premises-properties',
  /** id checkbox "Сооружение(я)" */
  objectFacilities: 'object-facilities',
  /** id textbox "Сооружение(я)" */
  objectFacilitiesSum: 'object-facilities-sum',
  /** id checkbox "Земельные участки" */
  objectLand: 'object-land',
  /** id textbox "Земельные участки" */
  objectLandSumInput: 'object-land-sum-input',
  /** id checkbox "Электронная, бытовая, орг. техника, компьютеры" */
  objectElectronicEquipment: 'object-electronic-equipment',
  /** id textbox "Электронная, бытовая, орг. техника, компьютеры" */
  objectElectronicEquipmentSumInput: 'object-electronic-sum-input',
  /** id checkbox "Оборудование в стадии эксплуатации" */
  objectOperationalEquipment: 'object-operational-equipment',
  /** id checkbox "Наличие оборудования из недружественных стран (необходим план по импортозамещению/альтернативные поставщики запасных частей)" */
  objectOperationalEquipmentUnfriendlyCountries: 'object-operational-equipment-from-unfriendly-countries',
  /** id textbox "Оборудование в стадии эксплуатации" */
  objectOperationalEquipmentSumInput: 'object-operational-sum-input',
  /** id checkbox "Мебель, производственный и хозяйственный инвентарь" */
  objectFurniture: 'object-furniture',
  /** id textbox "Страховая сумма (Мебель, производственный и хозяйственный инвентарь)" */
  objectFurnitureSumInput: 'object-furniture-sum-input',
  /** id checkbox "Товарно-материальные ценности" */
  objectStocks: 'object-stocks',
  /** id textbox "Страховая сумма (Товарно-материальные ценности)" */
  objectStocksSumInput: 'object-stocks-sum-input',
  /** id checkbox "Рекламные вывески и конструкции" */
  objectAdvertising: 'object-advertising',
  /** id textbox "Рекламные вывески и конструкции" */
  objectAdvertisingSumInput: 'object-advertising-sum-input',
  /** id checkbox "Наличные денежные средства" */
  objectCashMoney: 'object-cash',
  /** id textbox "Наличные денежные средства" */
  objectCashMoneySumInput: 'object-cash-sum-input',
  /** id checkbox "Имущественный комплекс" */
  objectPropertyComplex: 'object-property-complex',
  /** id textbox "Имущественный комплекс" */
  objectPropertySumInput: 'object-property-sum-input',

  // Для правил 066 = Правила страхования имущества предприятий (ред. от 30.06.2022)
  /** ----- id элементов блока СТРАХОВЫЕ РИСКИ & СТРАХОВЫЕ ПОКРЫТИЯ ПРЕДПРИЯТИЯ ----- */
  /** id блока "СТРАХОВЫЕ РИСКИ & СТРАХОВЫЕ ПОКРЫТИЯ ПРЕДПРИЯТИЯ", если выбраны правила 066 */
  insuredEnterpriseRisks: 'insured-enterprise-risks',
  // Предписания
  /** id combobox "Проверка предписаний пожарных служб на сайте", правила 066 */
  prescriptions066all: 'fire-prescriptions066-ng-select',
  /** id combobox "Проверка предписаний пожарных служб на сайте", правила 066 */
  prescriptions066poim: 'fire-prescriptions066-flexa-ng-select',
  /** id combobox "Тип предписаний пожарных служб", правила 066 */
  prescriptionsType066all: 'fire-prescriptions066-type-ng-select',
  /** id combobox "Тип предписаний пожарных служб", правила 066 */
  prescriptionsType066poim: 'prescriptions066-type-flexa-ng-select',
  // Страхование оборудования от поломок (по правилам страхования машин и механизмов 065)
  /** id checkbox "Страхование оборудования от поломок (по правилам страхования машин и механизмов 065)", правила 066 */
  risk065mb: '065mb066-risk',
  /** id textbox "Лимит ответственности ", риск "Страхование оборудования от поломок (по правилам страхования машин и механизмов 065)", правила 066 */
  лимитОтветственности: '065mb066-risk-limit-input',
  /** id textbox "Франшиза", риск "Страхование оборудования от поломок (по правилам страхования машин и механизмов 065)", правила 066 */
  франшиза: '065mb066-deductible-input',
  /** id checkbox Ошибки в проектировании, конструкции и расчетах, правила 066 */
  ошибкиВПроектировании: '065mb066-errors-construction',
  /** Ошибки при изготовлении и монтаже, правила 066 */
  ошибкиПриИзготовлении: '065mb066-errors-production',
  /** id checkbox Дефекты литья или использованного материала, правила 066 */
  дефектыЛитья: '065mb066-casting-defects',
  /** id checkbox Непреднамеренные ошибки персонала страхователя (выгодоприобретателя) при использовании и обслуживании застрахованного имущества, правила 066 */
  непреднамеренныеОшибки: '065mb066-negligence',
  /** id checkbox Энергетическая перегрузка, помпаж, перегрев, вибрация, разладка, заклинивание, засор посторонними предметами, воздействие центробежных сил, правила 066 */
  энергетическаяПерегрузка: '065mb066-overheating',
  /** id checkbox Воздействие электроэнергии в виде короткого замыкания электрического тока, перегрузка электросети, падение напряжения, атмосферный разряд (кроме удара молнии) и прочие подобные явления (включая возгорание, если ущерб причинен непосредственно тем предметам, в которых возникло возгорание), правила 066 */
  воздействиеЭлектроэнергии: '065mb066-circuit',
  /** id checkbox Гидравлический удар или недостаток жидкости в котлах, парогенераторах, других аппаратах, действующих с помощью пара или жидкости, правила 066 */
  гидравлическийУдар: '065mb066-hydraulic-shock',
  /** id checkbox Взрыв паровых котлов (разрыв или деформация стенок котла вследствие расширения газа или пара), двигателей внутреннего сгорания, других источников энергии, правила 066 */
  взрывПаровыхКотлов: '065mb066-explosion-boilers',
  /** id checkbox Действие низких температур, правила 066 */
  действиеНизкихТемператур: '065mb066-low-temperature',
  /** id checkbox Разрыв тросов и цепей, падение застрахованных предметов, удар их о другие предметы, правила 066 */
  разрывТросов: '065mb066-breakage-wires',
  // Посторонние воздействия
  /** id checkbox 'Дополнительный риск «Падение беспилотных и внеземных объектов или их частей»', правила 066 */
  fallingExtraterrestrial066: 'InsuredRiskCheckbox-risk_066_falling_extraterrestrial_origin',
  // Дополнительные расходы
  /** id checkbox Дополнительные расходы, для правил 066 */
  expenses066: 'expenses066',
  /** id textbox Лимит ответственности (Дополнительные расходы для правил 066) */
  expensesSum066: 'expenses066-sum-input',
  // Рефрижераторные риски
  /** id checkbox "Рефрижераторные риски", правила 066 */
  refrigeration066Risk: 'refrigeration066-risk',
  /** id checkbox "Поломки холодильного оборудования", правила 066 */
  refrigerationFailure: 'refrigeration-failure',
  /** id checkbox "Утечка хладореагента из системы охлаждения холодильной и/или морозильной установки", правила 066 */
  risk066LeakageRefrigeration: 'InsuredRiskCheckbox-risk_066_leakage_refrigeration',
  /** id текстовое поле "Лимит ответственности" (Рефрижераторные риски), правила 066 */
  refrigeration066Limit: 'refrigeration066-limit-input',
  // Риск BI
  /** id checkbox "Страхование убытков от перерыва в производственной деятельности", правила 066 */
  businessLossRisk066: 'business-loss066-risks',
  /** id combobox "Страхуется все имущество в распоряжении страхователя", правила 066 */
  allPropertyBi066: 'all-property-bi066',
  /** id текстовое поле "Страховая сумма" (Страхование убытков от перерыва в производственной деятельности), правила 066 */
  businessLossSum066: 'business-loss066-sum-input',
  /** id текстовое поле "Временная франшиза (дни)" (Страхование убытков от перерыва в производственной деятельности), правила 066 */
  biDeductibleDays066: 'bi066-deductible-days-input',
  /** id текстовое поле "Временная франшиза (дни) по рискам поломок" (Страхование убытков от перерыва в производственной деятельности), правила 066 */
  biDeductibleDaysBreakdown066: 'bi066-deductible-days-for-breakdown-risks-input',
  /** id combobox поле "Период возмещения (месяцы)" (Страхование убытков от перерыва в производственной деятельности), правила 066 */
  biDeductibleMonths066: 'bi066-deductible-months-ng-select',
  /** id combobox поле "Покрываемые расходы" (Страхование убытков от перерыва в производственной деятельности), правила 066 */
  biExpenses066: 'bi066-expenses-ng-select',
  // Радиационные риски
  /** id checkbox 'Радиационное воздействие', правила 066 */
  radiationRisk066: 'radiation066-risk',
  /** id текстовое поле "Лимит" ('Радиационное воздействие', правила 066) */
  radiationLimit066: 'radiation066-limit-input',
  // Терроризм
  /** id checkbox 'Терроризм и/или диверсия', правила 066 */
  terrorismRisk066: 'terrorism066-risk',
  /** id текстовое поле "Лимит" ('Терроризм и/или диверсия', правила 066) */
  terrorismLimit066: 'terrorism066-limit-input',
  // Забастовки
  /** id checkbox 'Забастовки, локауты, волнения', правила 066 */
  srccRisk066: 'srcc066-risk',
  /** id текстовое поле "Лимит" ('Забастовки, локауты, волнения', правила 066) */
  srccLimit066: 'srcc066-limit-input',
  // Огонь, доп.риски
  /** id checkbox 'Дополнительный риск «Взрыв паровых котлов и двигателей внутреннего сгорания»', правила 066 */
  explosionBoilers066: 'InsuredRiskCheckbox-risk_066_explosion_boilers_internal_combustion_engines',
  /** id checkbox 'Дополнительный риск «Перепад напряжения»', правила 066 */
  voltageDrop066: 'InsuredRiskCheckbox-risk_066_voltage_drop',
  // Посторонние воздействия
  /** id checkbox 'Дополнительный риск «Падение на объект предметов при проведении СМР»', правила 066 */
  damageConstructionWorks066: 'InsuredRiskCheckbox-risk_066_damage_construction_works',
  //Противоправные действия третьих лиц
  /** id checkbox 'Дополнительный риск «Повреждение по неосторожности', правила 066 */
  riskNegligence066: 'InsuredRiskCheckbox-risk_066_negligence',
  /** id checkbox 'Дополнительный риск «Иные противоправные действия третьих лиц»', правила 066 */
  otherUnlawfulActs066: 'InsuredRiskCheckbox-risk_066_other_unlawful_acts_of_third_parties',
  /** id checkbox Дополнительный риск «Нарушения, квалифицированные в соответствии с Кодексом РФ об административных правонарушениях (КоАП)», правила 066 */
  riskViolationsKOAP066: 'InsuredRiskCheckbox-risk_066_violations_by_KOAP',
  // Прочие риски
  /** id checkbox 'Военные действия' */
  militaryActions: 'military-actions',
  /** id checkbox 'Массовые беспорядки', правила 066 */
  massRiotsRisk066: 'mass-riots066-risk',
  /** id checkbox 'Бой стекол', для правил 066 */
  glassRisk066: 'glass066-risk',

  // Для правил 008 = Правила страхования имущества юридических и физических лиц от огня и других опасностей (ред. от 28.06.2022)
  /** ----- id элементов блока СТРАХОВЫЕ РИСКИ & СТРАХОВЫЕ ПОКРЫТИЯ ----- */
  /** id блока "СТРАХОВЫЕ РИСКИ & СТРАХОВЫЕ ПОКРЫТИЯ", если выбраны правила 008 */
  insuredRisks: 'insured-risks-section',
  // Предписания
  /** id combobox "Проверка предписаний пожарных служб на сайте", правила 008 */
  prescriptions008all: 'fire-prescriptions-ng-select',
  /** id combobox "Проверка предписаний пожарных служб на сайте", правила 008 */
  prescriptions008poim: 'fire-prescriptions-flexa-ng-select',
  /** id combobox "Тип предписаний пожарных служб", правила 008 */
  prescriptionsType008all: 'fire-prescriptions-type-ng-select',
  /** id combobox "Тип предписаний пожарных служб", правила 008 */
  prescriptionsType008poim: 'prescriptions-type-flexa-ng-select',
  /** id checkbox "Титульное страхование" */
  risks008lossOwnership: 'loss-ownership-risks',
  // Титульное страхование
  /** id checkbox "Массовые беспорядки" */
  massRiotsRisk: 'mass-riots-risk',
  /** id textbox "Страховая сумма" */
  страховаяСуммаТитул: 'loss-ownership-sum-input',
  /** id combobox "Количество сделок с объектом недвижимости за последние 3 года" */
  riskNumberOfDeals: 'deals-number-ng-select',
  /** id combobox "Сделки между аффилированными лицами или одной бизнес-группой" */
  riskAffiliatedPerson: 'affiliated-person-deals-ng-select',
  // Чекбоксы Стихийные бедствия - Показать риски подробнее
  /** id checkbox Буря (шторм), очень сильный ветер, шквал, ураган, вихрь, смерч, тайфун, штормовой нагон, правила 008 */
  windstormAndOther: 'InsuredRiskGridRecordGeneric-risk_008_windstorm_and_other',
  /** id checkbox Землетрясение, правила 008 */
  earthquak: 'InsuredRiskGridRecordGeneric-risk_008_earthquake',
  /** id checkbox Извержение вулкана, правила 008 */
  volcano: 'InsuredRiskGridRecordGeneric-risk_008_volcano',
  /** id checkbox Просадка грунта, оползень, обвал, правила 008 */
  landslideAndOther: 'InsuredRiskGridRecordGeneric-risk_008_landslide_and_other',
  /** id checkbox Сель, лавина, камнепад, правила 008 */
  avalancheAndOther: 'InsuredRiskGridRecordGeneric-risk_008_avalanche_and_other',
  /** id checkbox Град, правила 008 */
  hail: 'InsuredRiskGridRecordGeneric-risk_008_hail',
  /** id checkbox Гололед, обильный снегопад, правила 008 */
  heavySnowAndOther: 'InsuredRiskGridRecordGeneric-risk_008_heavy_snow_and_other',
  /** id checkbox Сильный ливень, правила 008 */
  heavyRrain: 'InsuredRiskGridRecordGeneric-risk_008_heavy_rain',
  /** id checkbox Действие морозов, правила 008 */
  // Посторонние воздействия
  /** id checkbox 'Посторонние воздействия' */
  outsideInfluenceRisks: 'outside-influence-risks',
  frostAction: 'InsuredRiskGridRecordGeneric-risk_008_frost_action',
  /** id checkbox Дополнительный риск «Падение беспилотных и внеземных объектов или их частей», правила 008 */
  fallingExtraterrestrialOrigin: 'InsuredRiskCheckbox-risk_008_falling_extraterrestrial_origin',
  /** id checkbox Дополнительный риск «Техногенные явления вне территории страхования (вибрации, звук и т.п.)», правила 008 */
  technogenicAccident: 'InsuredRiskCheckbox-risk_008_technogenic_accident',
  /** id checkbox Дополнительный риск «Падение на объект предметов при проведении СМР», правила 008 */
  damageConstructionWorks: 'InsuredRiskCheckbox-risk_008_damage_construction_works',
  // Противоправные действия третьих лиц
  /** id checkbox 'Противоправные действия третьих лиц' */
  unlawfullActsRisks: 'unlawfull-acts-risks',
  /** id checkbox Дополнительный риск «Повреждение по неосторожности» */
  riskNegligence: 'InsuredRiskCheckbox-risk_008_negligence',
  /** id checkbox Дополнительный риск «Иные противоправные действия третьих лиц» */
  otherUnlawfulActs: 'InsuredRiskCheckbox-risk_008_other_unlawful_acts_of_third_parties',
  /** id checkbox Дополнительный риск «Нарушения, квалифицированные в соответствии с Кодексом РФ об административных правонарушениях (КоАП)» */
  violationsByKOAP: 'InsuredRiskCheckbox-risk_008_violations_by_KOAP',
  // Дополнительные расходы
  /** id checkbox Дополнительные расходы, для правил 008 */
  expenses: 'expenses',
  /** id textbox Лимит ответственности (Дополнительные расходы для правил 008) */
  expensesSum: 'expenses-sum-input',
  /** id checkbox Расходы на расчистку и слом  */
  expensesPreparation: 'expenses-preparation',
  /** id textbox Лимит (Расходы на расчистку и слом) */
  expensesPreparationLimit: 'expenses-preparation-limit-input',
  /** id checkbox Расходы на изменения, дополнения, усовершенствования */
  expensesAdditions: 'expenses-additions',
  /** id textbox Лимит (Расходы на изменения, дополнения, усовершенствования) */
  expensesAdditionsLimit: 'additions-limit-input',
  /** id checkbox Расходы на перемещение и защиту  */
  expensesCarriage: 'expenses-carriage',
  /** id textbox Лимит (Расходы на перемещение и защиту) */
  expensesCarriageLimit: 'expenses-carriage-limit-input',
  /** id checkbox Расходы на независимых экспертов  */
  expensesExpert: 'expenses-expert',
  /** id textbox Лимит (Расходы на независимых экспертов) */
  expensesExpertLimit: 'expenses-expert-limit-input',
  /** id checkbox Иные расходы (укажите)  */
  expensesOther: 'other-expenses-dop',
  /** id textbox Лимит (Иные расходы (укажите)) */
  expensesOtherLimit: 'other-expenses-limit-input',
  /** id textbox Иные расходы */
  expensesOtherText: 'other-expenses-text',
  // Рефрижераторные риски
  /** id checkbox "Рефрижераторные риски", правила 008 */
  refrigeration008Risk: 'refrigeration-risk',
  /** id checkbox "Утечка хладореагента из системы охлаждения холодильной и/или морозильной установки", правила 008 */
  risk008LeakageRefrigeration: 'InsuredRiskCheckbox-risk_008_leakage_refrigeration',
  /** id текстовое поле "Лимит ответственности" (Рефрижераторные риски), правила 008 */
  refrigeration008Limit: 'refrigeration-risk-limit-input',
  /** id текстовое поле "Временная франшиза, часов" (Рефрижераторные риски-Поломки холодильного оборудования), правила 008 */
  refrigerationDeductibleHours: 'refrigeration-deductible-hours-input',
  /** id текстовое поле "Временная франшиза, часов" (Рефрижераторные риски-Непредвиденные, аварийные отключения электроснабжения), правила 008 */
  refrigerationElectricityHours: 'refrigeration-electricity-hours-input',
  /** id checkbox "Непредвиденные, аварийные отключения электроснабжения" */
  refrigerationElectricityOutages: 'refrigeration-electricity-outages',
  // Риск BI
  /** id checkbox "Страхование убытков от перерыва в производственной деятельности", правила 008 */
  businessLossRisk008: 'business-loss-risks',
  /** id combobox "Страхуется все имущество в распоряжении страхователя", правила 008 */
  allPropertyBi008: 'all-property-bi',
  /** id текстовое поле "Страховая сумма" (Страхование убытков от перерыва в производственной деятельности), правила 008 */
  businessLossSum008: 'business-loss-sum-input',
  /** id текстовое поле "Временная франшиза (дни)" (Страхование убытков от перерыва в производственной деятельности), правила 008 */
  biDeductibleDays008: 'bi-deductible-days-input',
  /** id текстовое поле "Временная франшиза (дни) по рискам поломок" (Страхование убытков от перерыва в производственной деятельности), правила 008 */
  biDeductibleDaysBreakdown008: 'bi-deductible-days-for-breakdown-risks-input',
  /** id combobox поле "Период возмещения (месяцы)" (Страхование убытков от перерыва в производственной деятельности), правила 008 */
  biDeductibleMonths008: 'bi-deductible-months',
  /** id combobox поле "Покрываемые расходы" (Страхование убытков от перерыва в производственной деятельности), правила 008 */
  biExpenses008: 'bi-expenses',
  /** id checkbox поле "Страховая сумма по риску "BI" установлена по каждой локации отдельно" (Страхование убытков от перерыва в производственной деятельности), правила 008 */
  biSumLocation008: 'bi-sum-location',
  // Огонь - доп.риски
  /** id checkbox 'Дополнительный риск «Взрыв паровых котлов и двигателей внутреннего сгорания»', правила 008 */
  explosionBoilers008: 'InsuredRiskCheckbox-risk_008_explosion_boilers_internal_combustion_engines',
  /** id checkbox 'Дополнительный риск «Перепад напряжения»', правила 008 */
  voltageDrop008: 'InsuredRiskCheckbox-risk_008_voltage_drop',
  // Вода
  /** id checkbox 'Вода' */
  floodRisks: 'flood-risks',
  /** id checkbox 'Водонесущие системы эксплуатируются без замены более 15 лет' */
  waterSupply15years: 'water-supply-15years',
  /** id checkbox 'Имущество расположено в жилом здании или подвальном помещении' */
  apartmentBasementObject: 'apartment-basement-object',
  /** id checkbox 'Стихийные бедствия' */
  naturalRisks: 'natural-risks',
  // Страхование электронного оборудования
  /** id checkbox Страхование электронного оборудования */
  electronicEquipmentRisks: 'electronic-equipment-risks',
  /** id textbox Лимит ответственности - Страхование электронного оборудования */
  electronicEquipmentLimit: 'electronic-equipment-limit-input',
  /** id textbox Франшиза - Страхование электронного оборудования */
  electronicEquipmentDeductible: 'electronic-equipment-deductible-input',
  /** id checkbox Падение электронного оборудования */
  fallingEei: 'falling-eei',
  /** id checkbox Короткое замыкание, перепад напряжения, аварии электросети */
  circuitEei: 'circuit-eei',
  /** id checkbox Попадание инородных предметов в электронное оборудование */
  foreignHitEei: 'foreign-hit-eei',
  /** id checkbox Ошибки работников страхователя при эксплуатации или обслуживании */
  negligenceEei: 'negligence-eei',
  /** id checkbox Механические повреждения из-за непреднамеренных неосторожных действий третьих лиц */
  byThirdEei: 'by-third-eei',
  /** id checkbox Дополнительный риск «Протекание стен или крыши» */
  leakingRoof008: 'InsuredRiskCheckbox-risk_008_leaking_roof',
  /** id checkbox Внезапное загрязнение почвы в результате аварии или катастрофы */
  pollutionLandPlotAccident008: 'InsuredRiskCheckbox-risk_008_pollution_land_plot_accident',
  /** id checkbox Загрязнение почвы в результате противоправных действий третьих лиц */
  pollutionLandPlotUnlawfulActs008: 'InsuredRiskCheckbox-risk_008_pollution_land_plot_unlawful_acts',
  // Бой стекол
  /** id checkbox 'Бой стекол', для правил 008 */
  glassRisk008: 'glass-risk',
  /** id textbox Лимит ответственности - Бой стекол */
  glassRiskLimit008: 'glass-risk-limit-input',
  /** id textbox Франшиза - Бой стекол */
  glassRiskDeductible008: 'glass-risk-deductible-input',
  /** id checkbox 'Лимит по риску "Бой стекол" установлен агрегатно на Договор (по всем Локациям)', для правил 008 */
  glassRiskAggregate008: 'glass-risk-aggregate',
  // Радиационные риски
  /** id checkbox 'Радиационное воздействие', правила 008 */
  radiationRisk008: 'radiation-risk',
  /** id текстовое поле "Лимит" ('Радиационное воздействие', правила 008) */
  radiationLimit008: 'radiation-risk-limit-input',
  /** id checkbox 'Лимит по риску "Радиационное воздействие" установлен агрегатно на Договор (по всем Локациям)', для правил 008 */
  radiationRiskAggregate008: 'radiation-risk-aggregate',
  // Терроризм
  /** id checkbox 'Терроризм и/или диверсия', правила 008 */
  terrorismRisk008: 'terrorism-risk',
  /** id текстовое поле "Лимит" ('Терроризм и/или диверсия', правила 008) */
  terrorismLimit008: 'terrorism-risk-limit-input',
  /** id checkbox 'Лимит по риску "Теракт" установлен агрегатно на Договор (по всем Локациям)', для правил 008 */
  terrorismRiskAggregate008: 'terrorism-risk-aggregate',
  // Забастовки
  /** id checkbox 'Забастовки, локауты, волнения', правила 008 */
  srccRisk008: 'srcc-risk',
  /** id текстовое поле "Лимит" ('Забастовки, локауты, волнения', правила 008) */
  srccLimit008: 'srcc-risk-limit-input',
  /** id checkbox 'Лимит по риску "Забастовки, локауты, волнения" установлен агрегатно на Договор (по всем Локациям)', для правил 008 */
  srccRiskAggregate008: 'srcc-risk-aggregate',
  // Cтрахование оборудования от аварии (по доп.условиям №2 к правилам от огня 008)
  /** id checkbox 'Cтрахование оборудования от аварии (по доп.условиям №2 к правилам от огня 008)' */
  mbRisk008: '008mb-risk',
  /** id textbox Лимит ответственности - 008mb */
  mbRiskLimit008: '008mb-risk-limit-input',
  /** id textbox Франшиза - 008mb */
  mbRiskDeductible008: '008mb-risk-deductible-input',
  /** id checkbox 'Короткое замыкание, перепад напряжения, аварии электросети' */
  mbRisk008circuit: '008mb-risk-circuit',
  /** id checkbox 'Ошибки в проектировании, конструкции и расчетах' */
  mbRisk008designErrors: '008mb-design-errors',
  /** id checkbox 'Ошибки при изготовлении и монтаже' */
  mbRisk008manufacturingErrors: '008mb-manufacturing-errors',
  /** id checkbox 'Гидравлический удар, отсутствие жидкости в котлах или других устройствах' */
  mbRisk008hydraulicShock: '008mb-hydraulic-shock',
  /** id checkbox 'Дефекты литья или использованного материала' */
  mbRisk008castingMaterialDefects: '008mb-casting-or-material-defects',
  /** id checkbox 'Недостаточность смазки, ослабление крепления деталей, перегревание' */
  mbRisk008overheating: '008mb-overheating',
  /** id checkbox 'Взрыв паровых котлов, двигателей внутреннего сгорания' */
  mbRisk008boilersExplosion: '008mb-boilers-explosion',
  /** id checkbox 'Сбой в запорно-регулирующих устройствах' */
  mbRisk008failure: '008mb-failure',
  /** id checkbox 'Действие низких температур' */
  mbRisk008lowTemperature: '008mb-low-temperature',
  /** id checkbox 'Падение оборудования, удар о другие предметы' */
  mbRisk008failureFall: '008-mb-failure',
  /** id checkbox 'Непреднамеренные ошибки персонала Страхователя' */
  mbRisk008staffMistake: '008mb-staff-mistake',
  /** id checkbox 'Энергетическая перегрузка, перегрев, вибрация, разладка, заклинивание, засор посторонними предметами, воздействие центробежных сил, "усталость" материала' */
  mbRisk008foreignHitNew: '008mb-foreign-hit-new',

  // Страхование оборудования от поломок (по правилам страхования машин и механизмов 065), правила 008
  /** id checkbox "Страхование оборудования от поломок (по правилам страхования машин и механизмов 065)", правила 008 */
  risk065mb008: '065mb-risk',
  /** id textbox "Лимит ответственности ", риск "Страхование оборудования от поломок (по правилам страхования машин и механизмов 065)", правила 008 */
  limit065mb008: '065mb-risk-limit-input',
  /** id textbox "Франшиза", риск "Страхование оборудования от поломок (по правилам страхования машин и механизмов 065)", правила 008 */
  deductible065mb008: '065mb-deductible-input',
  /** id checkbox Ошибки в проектировании, конструкции и расчетах, правила 008 */
  errorsConstruction065mb008: '065mb-errors-construction',
  /** Ошибки при изготовлении и монтаже, правила 008 */
  errorsProduction065mb008: '065mb-errors-production',
  /** id checkbox Дефекты литья или использованного материала, правила 008 */
  castingDefects065mb008: '065mb-casting-defects',
  /** id checkbox Непреднамеренные ошибки персонала страхователя (выгодоприобретателя) при использовании и обслуживании застрахованного имущества, правила 008 */
  negligence065mb008: '065mb-negligence',
  /** id checkbox Энергетическая перегрузка, помпаж, перегрев, вибрация, разладка, заклинивание, засор посторонними предметами, воздействие центробежных сил, правила 008 */
  overheating065mb008: '065mb-overheating',
  /** id checkbox Воздействие электроэнергии в виде короткого замыкания электрического тока, перегрузка электросети, падение напряжения, атмосферный разряд (кроме удара молнии) и прочие подобные явления (включая возгорание, если ущерб причинен непосредственно тем предметам, в которых возникло возгорание), правила 008 */
  circuit065mb008: '065mb-circuit',
  /** id checkbox Гидравлический удар или недостаток жидкости в котлах, парогенераторах, других аппаратах, действующих с помощью пара или жидкости, правила 008 */
  hydraulicShock065mb008: '065mb-hydraulic-shock',
  /** id checkbox Взрыв паровых котлов (разрыв или деформация стенок котла вследствие расширения газа или пара), двигателей внутреннего сгорания, других источников энергии, правила 008 */
  explosionBoilers065mb008: '065mb-explosion-boilers',
  /** id checkbox Действие низких температур, правила 008 */
  lowTemperature065mb008: '065mb-low-temperature',
  /** id checkbox Разрыв тросов и цепей, падение застрахованных предметов, удар их о другие предметы, правила 008 */
  breakageWires065mb008: '065mb-breakage-wires',

  /** --------------------- id элементов вкладки ОБЩАЯ ИНФОРМАЦИЯ --------------------- */
  /** ----- id элементов блока Общая информация ----- */

  /** id checkbox "Страхователь/Выгодоприобретатель под торговыми или экономическими санкциями'" */
  usEuSanctions: 'us-eu-sanctions',
  /** id кнопки в таблице посредников "Добавить" */
  partnerTableButton: 'partners-table-add-button',
  /** id кнопки поиска в таблице посредников */
  partnerSearch: 'partners-search-dialog-button',
  /** id textbox "Поиск по подстроке" */
  agentSearch: 'agent-search-input',
  /** id кнопки "Поиск" в форме "Поиск агентов" */
  agentSearchButton: 'agent-search-button',
  /** id кнопки "Выбрать" в форме "Поиск агентов" */
  agentConfirmButton: 'lookup-dialog-confirm-button',
  /** id кнопки "OK" в таблице посредников */
  partnersTableOk: 'partners-table-ok-button',
  /** id таблицы в блоке Посредники */
  partnersTable: 'partners-table',

  /** ----- id элементов блока Выгодоприобретатель ----- */

  /** id checkbox "Выгодоприобретателем является Страхователь" */
  beneficiaryPolicyholder: 'beneficiary-policyholder',
  /** id button поиск Выгодоприобретатель */
  beneficiarySearchButton: 'beneficiary-search-button',

  /** ----- id элементов блока Залог & лизинг, пропорция & первый риск, стоимость ----- */

  /** id кнопки поиска контрагента в блоке "ОРИГИНАЛЬНЫЙ СТРАХОВЩИК (ПЕРЕСТРАХОВАТЕЛЬ)" */
  originalReinsurerSearchButton: 'original-reinsurer-search',
  /** id combobox Порядок выплаты возмещения */
  lossSystem: 'loss-system',
  /** id combobox Порядок установления СС */
  ccProcedure: 'cc-procedure',
  /** id checkbox Имущество передается в залог или лизинг */
  bankLease: 'bank-lease',
  /** id checkbox 'Планируется полная или частичная передача имущества в залог или лизинг в течение' */
  bankLease2month: 'bank-lease-2month',
  /** id combobox Вид финансового учреждения */
  typeBankLease: 'type-bank-lease',
  /** id button кнопка поиска (лупа) над полем Наименование финансового учреждения */
  bankSearchButton: 'bank-serach-button',
  /** id textbox Наименование финансового учреждения */
  leasingPartner: 'leasing-partner',
  /** id textbox Залоговая стоимость (До применения дисконта) или Реальная стоимость */
  insuranceValueInput: 'insurance-value-input',
  /** id checkbox 'Выплата страхового возмещения без учета износа заменяемых частей, узлов, агрегатов и деталей' */
  withoutAmortization: 'without-amortization',
  /** id combobox Требуется отказ от суброгации в отношении конкретных ЮЛ */
  subrogationWaiver: 'subrogation-waiver',
  /** id textbox "В Договор страхования будет включена «Оговорка об отказе от суброгации" */
  subrogationReservation: 'subrogation-reservation',

  /** ----- id элементов блока Срок страхования & история страхования ----- */

  /** id block Блок "Срок страхования & история страхования" */
  insuranceHistorySection: 'insurance-history-section',
  /** id textbox "Дата начала", Блок "Срок страхования & история страхования" */
  insuranceStart: 'insurance-start-input',
  /** id textbox "Дата окончания", Блок "Срок страхования & история страхования" */
  insuranceEnd: 'insurance-end-input',
  /** id combobox "История страхования" Блок "Срок страхования & история страхования" */
  insuranceHistory: 'claims-5years',
  /** id textbox "Срок действия" Блок "Срок страхования & история страхования" */
  insuranceDuration: 'insurance-duration',
  /** id checkbox "Новый бизнес без истории" */
  newBusiness: 'new-business',
  /** id button "Получить данные о просроченной СДЗ" */
  checkDebtButton: 'checkDebt-button',
  /** id checkbox "Первичный договор передан в Головной офис из Центрального филиалаЗ" */
  policyFromCentralOffice: 'policy-from-central-office',

  /** ----- id элементов блока Нетиповая форма договора ----- */

  /** id checkbox "Требуется внесение изменений в типовую форму договора (в том числе исключение/ изменение обязательных оговорок) или использование нетиповой формы" */
  untypicalContract: 'untypical-contract',
  /** id текстовое поле "Изменения, которые необходимо внести в типовую форму" */
  untypicalItems: 'untypical-items',
  /** id checkbox "Конкурсная форма договора (44-Ф3/223-Ф3 или иной государственный или негосударственный конкурс)" */
  untypical44223FZ: 'untypical-44223FZ',
  /** id текстовое поле "Конечная дата подачи заявки на участие в конкурсе" */
  untypicalCompetitionDate: 'untypical-competition-last-date-input',

  /** ----- id элементов блока Декларирование в РНПК ----- */

  /** id textbox "Причина декларирования риска в РНПК" */
  declarationReason: 'declaration-declaration-reason',
  /** id textbox "База цессии в облигатор" */
  declarationCessionBaseObligator: 'declaration-cession-base-in-obligator',
  /** id textbox "Страховая сумма / МВУ / Лимит (база цессии), руб." */
  declarationCessionBaseSum: 'declaration-cession-base-input',

  /** --------------------- id элементов вкладки РАСЧЕТ ТАРИФА & ТРИГГЕРЫ --------------------- */
  /** ----- id элементов блока Комментарии ----- */

  /** id textbox "Комментарии" */
  commentsTextArea: 'comments-text-area',

  /** ----- id элементов блока СОСТРАХОВАНИЕ И ПЕРЕСТРАХОВАНИЕ ----- */

  /** id блока "СОСТРАХОВАНИЕ И ПЕРЕСТРАХОВАНИЕ" */
  coinsuranceReinsuranceSection: 'coinsurance-reinsurance-section',
  /** id textbox "Номер заявки в CRM" */
  crmDealNumber: 'reinsurance-crm-deal-number',
  /** id textbox "Причина спецакцепта" */
  commentSpecialAcceptance: 'reinsurance-facre-comment-special-acceptance',
  /** id textbox "Цена спецакцепта в валюте прямого договора" */
  specialAcceptanceSumVal: 'reinsurance-facre-special-acceptance-sum-val-input',
  /** id combobox "Сострахование" */
  contCoinsurance: 'coinsurance-checkbox-ng-select',
  /** id таблицы "СОСТРАХОВЩИКИ (КРОМЕ СОГАЗ)" */
  coinsurersTable: 'coinsurers-table',
  /** id button ДОБАВИТЬ таблицы "СОСТРАХОВЩИКИ (КРОМЕ СОГАЗ)" */
  coinsurersTableAddButton: 'coinsurers-table-add-button',
  /** id button ПОИСК/Лупа таблицы "СОСТРАХОВЩИКИ (КРОМЕ СОГАЗ)" */
  coinsurersSearchDialogButton: 'coinsurer-search-dialog-button',
  /** id combobox "Тип контрагента" */
  partyTypeCoinsurers: 'party-type',
  /** id текстового поля "Наименование" */
  coinsurersOrganisationName: 'organisation-name',
  /** id текстового поля "ИНН" */
  coinsurersInn: 'inn',
  /** id текстового поля  "КПП" */
  coinsurersKpp: 'kpp',
  /** id combobox "Требуется факультативное перестрахование" */
  rqsFacreRequired: 'facultative-reinsurance-needed-ng-select',
  /** id combobox "Спецакцепт в облигатор" */
  reinsuranceFacreSpecialAcceptance: 'reinsurance-facre-special-acceptance',

  /** ---------- id элементов блока Триггеры ---------- */

  /** id button поиска "Номер Общей котировки" */
  generalQuoteLookupButton: 'general-quote-lookup-button-dialog-button',
  /** id checkbox "Условия страхования согласованы в рамках Общей котировки" */
  agreedGeneralQuote: 'agreed-with-general-quote-checkbox',

  /** --------------------- id элементов вкладки ИСТОРИЯ СОГЛАСОВАНИЯ --------------------- */

  /** ----- id элементов блока Копия ----- */

  /** id кнопки "Добавить" */
  copyNotificationTable: 'copy-notification-table',

  /** ----- id элементов блока Связанные документы (вручную) ----- */

  /** id блока "Связанные документы (вручную)" */
  manuallyRelatedDocumentSection: 'manually-related-documents-section',
  /** id поля "Номер документа" */
  contractSelectionSearchDocumentNumber: 'contract-selection-search-document-number',
  /** id кнопки поиска Лупа, две кнопки с одинаковым ID, nth 0 и 1 */
  contractSelectionSearchDialogButton: 'contract-selection-search-dialog-button',
  /** id колонка ТИП ДОКУМЕНТА таблицы "Связанные документы (вручную)" */
  manuallyRelatedDocumentTypeTable: 'manually-related-documents-type-table',
  /** id гиперссылки на связанный вручную документ */
  manuallyRelatedDocumentNumberLinkTable: 'manually-related-documents-number-link-table',
  /** id колонка СТАТУС таблицы "Связанные документы (вручную)" */
  manuallyRelatedDocumentStateTable: 'manually-related-documents-state-table',
  /** id колонка СВЯЗЬ таблицы "Связанные документы (вручную)" */
  manuallyRelatedDocumentRelationTypeTable: 'manually-related-documents-relation-type-table',

  /** --------------------- id печатных форм PDF в Котировке --------------------- */

  /** id печатной формы "Котировочный лист" PDF */
  quotationListPrintout: 'ai-printouts-control-QuotationListPrintout',
  /** id печатной формы "заявление на страхование" PDF */
  insuranceApplicationPrintout: 'ai-printouts-control-InsuranceApplicationPrintout',

  /** --------------------- id Действий в Котировке --------------------- */

  /** id кнопки действия "Аннулировать" */
  controlDraftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',
  /** id кнопки действия "Направить на согласование" (со статуса Новая) */
  controlDraftSendToHigherLevel: 'ai-transitions-relations-control-Draft_SendToHigherLevel',
  /** id кнопки действия "Направить на согласование" (с уровня UW1) */
  controlUW1SendToHigherLevel: 'ai-transitions-relations-control-UW1_SendToHigherLevel',
  /** id кнопки действия "Направить на согласование" (с уровня UW2) */
  controlUW2SendToHigherLevel: 'ai-transitions-relations-control-UW2_SendToHigherLevel',
  /** id кнопки действия "Направить на согласование" (с уровня UW3 на UW3h) */
  controlUW3toUW3h: 'ai-transitions-relations-control-UW3_to_UW3h',
  /** id кнопки действия "Направить на согласование" (с уровня UW3 на UW4) */
  controlUW3toUW4: 'ai-transitions-relations-control-UW3_to_UW4',
  /** id кнопки действия "Направить на согласование" (с уровня На корректировку) */
  controlForCorrectionSendToHigherLevel: 'ai-transitions-relations-control-ForCorrection_SendToHigherLevel',
  /** id кнопки действия "Направить на согласование" (с уровня Согласовано предварительно) */
  controlApprovedInAdvanceSendToHigherLevel: 'ai-transitions-relations-control-ApprovedInAdvance_SendToHigherLevel',
  /** id кнопки действия "Создать копию" */
  controlPLECopyQuote: 'ai-transitions-relations-control-PLECopyQuote',
  /** id кнопки действия "Создать Проект договора" (создается Заявка) */
  controlPLECreatePolicyProjectRequest: 'ai-transitions-relations-control-PLECreatePolicyProjectRequest',
  /** id кнопки действия "Создать Проект договора" (создается Новый) */
  controlPLECreatePolicyProject: 'ai-transitions-relations-control-PLECreatePolicyProject',
  /** id кнопки действия "Согласовать" (текущий уровень UW1) */
  controlUW1ToApproved: 'ai-transitions-relations-control-UW1_to_Approved',
  /** id кнопки действия "Согласовать" (текущий уровень UW2) */
  controlUW2ToApproved: 'ai-transitions-relations-control-UW2_to_Approved',
  /** id кнопки действия "Согласовать" (текущий уровень UW3) */
  controlUW3ToApproved: 'ai-transitions-relations-control-UW3_to_Approved',
  /** id кнопки действия "Согласовать" (текущий уровень UW3h) */
  controlUW3hToApproved: 'ai-transitions-relations-control-UW3h_to_Approved',
  /** id кнопки действия "Согласовать" (текущий уровень UW4) */
  controlUW4ToApproved: 'ai-transitions-relations-control-UW4_to_Approved',
  /** id кнопки действия "Согласовать предварительно" (текущий уровень UW3) */
  controlUW3ToApprovedInAdvance: 'ai-transitions-relations-control-UW3_to_ApprovedInAdvance',
  /** id кнопки действия "Создать договор из котировки" (создается Заявка) */
  controlPLECreatePolicyFromQuote: 'ai-transitions-relations-control-PLECreatePolicyFromQuote',
  /** id кнопки действия "Создать договор из котировки" (создается Новый) */
  controlPLECreatePolicyInDraftFromQuote: 'ai-transitions-relations-control-PLECreatePolicyInDraftFromQuote',
  /** id кнопки действия "Вернуть на корректировку" (текущий уровень UW4) */
  controlUW4ToForCorrection: 'ai-transitions-relations-control-UW4_to_ForCorrection',
  /** id кнопки действия "Отозвать" (текущий уровень UW3) */
  controlUW3ForCorrectionAgent: 'ai-transitions-relations-control-UW3_to_ForCorrection_Agent',
  /** id кнопки действия "Отказать" (текущий уровень UW3) */
  controlUW3ToRejected: 'ai-transitions-relations-control-UW3_to_Rejected',
  /** id кнопки действия "Направить повторно Руководству: стоп-факторы" (текущий статус Отказано) */
  controlRejectedBackToApprovement: 'ai-transitions-relations-control-Rejected_BackToApprovement',
}

const policyPLE = {
  /** --------------------- id элементов вкладок Договора --------------------- */

  /** id вкладки "УСЛОВИЯ ДОГОВОРА" */
  tabPolicyConditionsNav: 'tab-Policy-Conditions-nav',
  /** id вкладки "Документы и фотоматериалы" */
  tabAttachmentsDocumentsNav: 'tab-Attached-documents-nav',
  /** id вкладки "Перестрахование" */
  tabReinsuranceDataNav: 'tab-Reinsurance-data-nav',

  /** --------------------- id элементов вкладки УСЛОВИЯ ДОГОВОРА--------------------- */

  /** ---------- id элементов блока Условия договора ---------- */

  /** id блока "УСЛОВИЯ ДОГОВОРА" */
  policyConditionsSection: 'policy-conditions-section',
  /** id textbox "Краткое содержание" */
  policyShortDescription: 'short-description',
  /** id textbox "Дата письменного заявления" */
  dogtextDraftApplicationDate: 'application-date-input',
  /** id textbox "Дата заключения" */
  signDate: 'conclusion-date-input',
  /** id checkbox "Договор для участия в закупке" */
  policyForPurchase: 'policy-for-purchase',
  /** id checkbox "договор страхования предусматривает необходимость открытия счета любого типа в банке, в том числе под операции в рамках государственного оборонного заказа или государственного контракта" */
  needBankCheckbox: 'need-bank-checkbox',
  /** id checkbox "договор страхования предусматривает необходимость открытия отдельного счета в подразделениях Федерального казначейства под операции и осуществления казначейского сопровождения в рамках государственного контракта." */
  needTreasuryCheckbox: 'need-treasury-checkbox',
  /** id checkbox "Согласование Отдела организации банковского обслуживания получено" */
  projectApprovedBankService: 'project-approved-bank-service-checkbox',
  /** id текстовое поле "Конечная дата подачи заявки на участие в конкурсе" */
  purchaseCompetitionLastDate: 'purchase-competition-last-date-input',
  /** id текстовое поле "Фактическая дата подачи заявки на участие в конкурсе" */
  purchaseCompetitionFactDate: 'purchase-competition-fact-date-input',

  /** ---------- id элементов блока Подписанты ---------- */

  /** id блока "ПОДПИСАНТЫ" */
  representativesSection: 'representatives-section',
  /** id textbox "Документ-основание" */
  dogtextDraftPreambleInsurerRepresentativeDoc: 'representative-doc',
  /** id textbox "Должность подписанта от имени Страховщика" */
  dogtextDraftPreambleInsurerRepresentativeRank: 'representative-rank',
  /** id textbox "Дата документа-основания" */
  dogtextDraftPreambleInsurerRepresentativeDocDate: 'representative-doc-date-input',
  /** id combobox "Банк для указания реквизитов оплаты" */
  dogtextDraftPreambleBankInfo: 'preamble-bank-info-ng-select',
  /** id textbox "Документ-основание" */
  baseDocument: 'party-doc',
  /** id textbox "Должность подписанта от имени Страхователя" */
  rank: 'party-rank',
  /** id textbox "Дата документа-основания" */
  baseDocumentDate: 'party-doc-date-input',
  /** id button кнопка лупа "ФИО подписанта от имени Страхователя" */
  partySearch: 'party-search',
  /** id textbox "Поиск" */
  partyapiSearch: 'partyapi-search',
  /** id button кнопка поиска "Искать" */
  partyapiSearchButton: 'partyapi-search-button',
  /** id checkbox "Требуется оформление специальной доверенности" */
  needAttorney: 'need-attorney-checkbox',

  /** ---------- id элементов блока Оговорки ---------- */

  /** id блока "Оговорки" */
  reservationsSection: 'reservations-section',
  /** id combobox "По договору страхования установлена страховая стоимость" */
  policyInsuredValueDefined: 'policy-value-defined-ng-select',
  /** id combobox "Выберите применяемую оговорку о стоимости" */
  reservationType: 'reservation-type-ng-select',
  /** id combobox "Договором страхования прямо предусмотрено исключение НДС из суммы страхового возмещения" */
  exclusionOfVAT: 'vat-exclusion-ng-select',
  /** id combobox "Наличие оговорки о рассмотрении споров в коммерческом арбитраже" */
  disputInCommArbitration: 'arbitration-reservation-ng-select',

  /** ---------- id элементов блока Форма договора ---------- */

  /** id блока "Форма договора" */
  policyFormSection: 'policy-form-section',
  /** id checkbox "Требуется внесение изменений в типовую форму договора (в том числе исключение/ изменение обязательных оговорок) или использование нетиповой формы" */
  policyUntypicalContract: 'policy-untypical-contract',
  // /** id checkbox "конкурсная форма договора (ФЗ 44)" */
  // policy_untypical_contract_44_FZ: '',
  // /** id checkbox "конкурсная форма договора (ФЗ 223)" */
  // policy_untypical_contract_223_FZ: '',
  /** id textbox "укажите пункты договора, в которые необходимо внести изменения" */
  policyUntypicalItems: 'policy-untypical-items',
  /** id checkbox "требуется включение условий урегулирования убытков, отличных от указанных в Правилах страхования, типовой форме договора страхования либо локальных нормативных актах Общества" */
  changingLossesConditions: 'changing-losses-conditions',
  /** id textbox "укажите условия договора по урегулированию убытков, в которые необходимо внести изменения" */
  changingLossesItems: 'changing-losses-items',
  /** id combobox "Выберите Дирекцию урегулирования убытков, с которой необходимо согласовать договор" */
  changingLossesDepartment: 'select-losses-department',
  /** id checkbox "Текстовая часть нетипового договора была ранее согласована Юридическим подразделением (в том числе для пролонгации)" */
  ldApproved: 'ld-approved',
  /** id checkbox "В Адакте" (для Текстовая часть нетипового договора была ранее согласована Юридическим подразделением (в том числе для пролонгации)) */
  idApprovedAdacta: 'ld-approved-project-checkbox',
  /** id checkbox "В ДДО" (для Текстовая часть нетипового договора была ранее согласована Юридическим подразделением (в том числе для пролонгации)) */
  idApprovedDDO: 'ld-approved-ddo-checkbox',
  /** id текстовое поле Укажите дату согласования для "В ДДО" */
  idApprovedDate: 'ld-approved-date-input',
  /** id текстовое поле Укажите регистрационный номер документа для "В ДДО" */
  idApprovedNumber: 'ld-approved-number',
  /** id checkbox "Текстовая часть нетипового договора была ранее согласована Подразделением урегулирования убытков" */
  cdApproved: 'cd-approved',
  /** id checkbox "В Адакте" (для Текстовая часть нетипового договора была ранее согласована Подразделением урегулирования убытков) */
  cdApprovedAdacta: 'cd-approved-project-checkbox',
  /** id checkbox "В ДДО" (для Текстовая часть нетипового договора была ранее согласована Подразделением урегулирования убытков) */
  cdApprovedDDO: 'cd-approved-ddo-checkbox',
  /** id checkbox "Получено согласование Бухгалтерии" */
  projectApprovedAccounting: 'project-approved-accounting-checkbox',
  /** id button поиск "Укажите номер документа" (для Согласование Отдела организации банковского обслуживания получено) */
  bankServiceLookupButton: 'lookup-button-dialog-button',
  /** id button поиск "Укажите номер документа" (для Текстовая часть нетипового договора была ранее согласована Юридическим подразделением (в том числе для пролонгации)) */
  projectLinkLawButton: 'PolicyProjectLink-projectLinkLaw',
  /** id button поиск "Укажите номер документа" (для Текстовая часть нетипового договора была ранее согласована Подразделением урегулирования убытков) */
  projectLinkLossesButton: 'PolicyProjectLink-projectLinkLosses',
  /** id button поиск "Укажите номер документа" (для Получено согласование Бухгалтерии) */
  projectLinkAccountingButton: 'PolicyProjectLink-projectLinkAccounting',

  /** ---------- id элементов блока Уровень согласования договора ---------- */

  /** id блока "Уровень согласования договора" */
  policyApprovalSection: 'policy-approval-section',

  /** ---------- id элементов блока Ретроактивная ответственность ---------- */

  /** id блока "Ретроактивная ответственность" */
  retroactiveSection: 'retroactive-section',
  /** id checkbox "Требуется включение условия о ретроактивной дате" */
  retroactiveDate: 'retroactive-date',
  /** id textbox "Причина требования включения условия о ретроактивной дате" */
  retroactiveConditionComment: 'retroactive-condition-comment',
  /** id текстовое поле "Требуемая дата начала срока страхования" */
  retroactiveStartDate: 'retroactive-start-date-input',
  /** id combobox об Указании о добавлении оговорки если НЕ выбран checkbox "В период ретроактивной ответственности произошли события (причины событий), имеющие признаки страховых случаев" */
  retroactiveWithoutLosses: 'retroactive-without-losses',
  /** id combobox об Указании о добавлении оговорки если выбран checkbox "В период ретроактивной ответственности произошли события (причины событий), имеющие признаки страховых случаев" */
  retroactiveWithLosses: 'retroactive-with-losses',
  /** id checkbox "В период ретроактивной ответственности произошли события (причины событий), имеющие признаки страховых случаев" */
  retroactiveLosses: 'retroactive-losses',
  /** id textbox "Описание событий (причин событий), в т.ч. дата наступления" */
  retroactiveLossesDescription: 'retroactive-losses-description',
  /** id checkbox "Получена декларация от Страхователя об отсутствии страховых случаев / о наличии причин, которые могут повлечь наступление страхового случая и/или Страхователю отправлено уведомление о непризнании страховыми случаями событий, наступивших в ретроактивный период и/или имущество уже застраховано в АО «СОГАЗ» на тех же условиях (существенные условия по договору не изменяются)" */
  retroactiveDeclaration: 'retroactive-declaration',
  /** id textbox "Укажите текст оговорки" */
  retroactiveWithText: 'retroactive-with-text',

  /** ---------- id элементов блока Ручной бизнес-цикл согласования ---------- */

  /** id блока "РУЧНОЙ БИЗНЕС-ЦИКЛ СОГЛАСОВАНИЯ (ДОПОЛНИТЕЛЬНО)" */
  coerciveTriggersSectionSection: 'coercive-triggers-section',

  /** ------ id элементов блока Застрахованные убытки от перерыва в производстве ------ */

  /** id checkbox "Заработная плата работников Страхователя" */
  biSalary: 'bi-salary',
  /** id checkbox "Платежи за электроэнергию, тепло, газ, воду" */
  biElectricity: 'bi-electricity',
  /** id textbox "Под производственной деятельностью Страхователя понимается" */
  biActivity: 'bi-activity',
  /** id текстовое поле "Текущие (постоянные) расходы Страхователя, а именно:" */
  biExpensesAmt: 'bi-expenses-amt-input',
  /** id текстовое поле поле напротив чекбокса "Заработная плата работников Страхователя" */
  biSalarySum: 'bi-salary-sum-input',
  /** id текстовое поле поле напротив чекбокса "Платежи за электроэнергию, тепло, газ, воду" */
  biElectricitySum: 'bi-electricity-sum-input',
  /** id текстовое поле поле напротив чекбокса "Потеря прибыли от производственной деятельности Страхователя" */
  biLossProfitsInput: 'bi-loss-profits-input',
  /** id текстовое поле поле напротив чекбокса "Недополученные Страхователем арендные платежи" */
  biRentalPaymentsInput: 'bi-rental-payments-input',
  /** id текстовое поле нередактируемое "Итоговая СС по BI" */
  biTotalAmt: 'bi-total-amt-input',

  /** ------------------ id элементов вкладки РАСЧЕТ ТАРИФА & ТРИГГЕРЫ ------------------ */

  /** id combobox "Статус" в таблице триггеров (договор, проект, допс) */
  policyStateSelect: 'policy-state-ng-select',
  /** id textbox "МВУ, в рублях" */
  pmlInRub: 'pml-in-rub-input',

  /** --------------------- id элементов вкладки ПЕРЕСТРАХОВАНИЯ --------------------- */

  /** id textbox "Номер сделки в CRM" */
  applicationNumberCrm: 'application-number-crm',
  /** id текстового поля для ввода (input) "Ордер в факультативное перестрахование" */
  reinsuranceFacreOrder: 'reinsurance-facre-order-input',
  /** id текстового поля для ввода (input) "Доля в облигатор от 100% риска" */
  reinsuranceObligatorFullRiskShare: 'reinsurance-obligator-full-risk-share-input',
  /** id текстового поля для ввода (input) "Начисленная премия в факультативное перестрахование по доле, в валюте договора прямого" */
  reinsuranceFacrePremiumVal: 'reinsurance-facre-premium-val-input',
  /** id текстового поля для ввода (input) "Нетто-премия в факультативное перестрахование" */
  reinsuranceFacrePremiumNet: 'reinsurance-facre-premium-net-input',
  /** id combobox "Дисконт от факультативной котировки РНПК" */
  reinsuranceFacultativeQuoteDiscount: 'reinsurance-facultative-quote-discount',
  /** id combobox "Тип перестрахования" */
  reinsuranceFacreType: 'reinsurance-facre-type',
  /** id combobox "База перестрахования" */
  reinsuranceFacreBasis: 'reinsurance-facre-basis',
  /** id combobox "Перестрахование на базе эксцедента при использовании облигатора не менее 75% от СС/лимита/МВУ" */
  reinsuranceExcessReinsurance: 'reinsurance-excess-reinsurance',
  /** id текстового поля для ввода (input) "Комиссия размещающего брокера в %" */
  reinsuranceFacreBrokerComissionRate: 'reinsurance-facre-broker-comission-rate-input',
  /** id текстового поля для ввода (input) "Доля РНПК в ордере (%)" */
  reinsuranceFacreBrokerComissionRnpc: 'reinsurance-facre-broker-comission-rnpc-input',
  /** id checkbox "DIC (difference in conditions)" */
  reinsuranceFacreDic: 'reinsurance-facre-dic',
  /** id textbox "Договор ДПИ (номер)" */
  reinsuranceFacreNumberDpi: 'reinsurance-facre-number-dpi',
  /** id textbox "Комментарий DIC" */
  reinsuranceFacreCommentDpi: 'reinsurance-facre-comment-dic',
  /** id combobox "Способ устранения разницы между основным договором и договором факультативного перестрахования" */
  reinsuranceDicRemovalMethod: 'reinsurance-dic-removal-method',
  /** id текстового поля для ввода (input) "Начисленная премия в факультативное перестрахование по доле, в рублях" */
  reinsuranceFacrePremium: 'reinsurance-facre-premium-input',
  /** id textbox "Специальная программа перестрахования" */
  reinsuranceFacreSpecialProgram: 'reinsurance-facre-special-program',
  /** id textbox "Собственное удержание, в валюте договора прямого" */
  reinsuranceFacreOwnRetentionVal: 'reinsurance-facre-own-retention-val',
  /** id текстового поля для ввода (input) "Собственное удержание, в рублях" */
  reinsuranceFacreOwnRetention: 'reinsurance-facre-own-retention-input',
  /** id checkbox "Санкционный риск" */
  reinsuranceFacreSanctions: 'reinsurance-facre-sanctions',
  /** id textbox "Комментарий" */
  reinsuranceFacreComment: 'reinsurance-facre-comment',

  /** --------------------- id Действий в Договоре --------------------- */

  /** id кнопки действия "Направить на согласование" (статус Новый) */
  controlDraftSendToHigherLevel: 'ai-transitions-relations-control-Draft_SendToHigherLevel',
  /** id кнопки действия "Направить на согласование" (статус На корректировку) */
  controlForCorrectionSendToHigherLevel: 'ai-transitions-relations-control-ForCorrection_SendToHigherLevel',
  /** id кнопки действия "Отозвать с согласования" */
  controlForApprovalL1ToForCorrectionAgent: 'ai-transitions-relations-control-ForApprovalL1_to_ForCorrection_Agent',
  /** id кнопки действия "Отозвать" со статуса Согласован Не активирован */
  controlApprovedToForCorrection: 'ai-transitions-relations-control-Approved_to_ForCorrection',
  /** id кнопки действия "Направить на подписание" */
  controlApprovedToForSigning: 'ai-transitions-relations-control-Approved_to_ForSigning',
  /** id кнопки действия "На подписание" */
  controlForDecisionToForSigning: 'ai-transitions-relations-control-ForDecision_to_ForSigning',
  /** id кнопки действия "Передано на подписание" */
  controlForSigningToReadyForSigning: 'ai-transitions-relations-control-ForSigning_to_ReadyForSigning',
  /** id кнопки действия "Подписано" из Передано на подписание */
  controlReadyForSigningToSigned: 'ai-transitions-relations-control-ReadyForSigning_to_Signed',
  /** id кнопки действия "Получить решение Инициатора" */
  controlApprovedToForDecision: 'ai-transitions-relations-control-Approved_to_ForDecision',
  /** id кнопки действия "Подписано" из Согласован Не активирован */
  controlApprovedToSigned: 'ai-transitions-relations-control-Approved_to_Signed',
  /** id кнопки действия "Активировать" */
  controlSignedToActivated: 'ai-transitions-relations-control-Signed_to_Activated',
  /** id кнопки действия "Активировать без интеграции" */
  controlSignedToDisableIntegration: 'ai-transitions-relations-control-Signed_to_DisableIntegration',
  /** id кнопки действия "Аннулировать" (текущий статус На корректировку) */
  controlForCorrectionToAnnulled: 'ai-transitions-relations-control-ForCorrection_to_Annulled',
  /** id кнопки действия "Направить заявку на оформление" */
  controlRequestToDraftPolicy: 'ai-transitions-relations-control-Request_to_Draft',
  /** id кнопки действия "Вернуть в статус "На корректировку"" */
  controlAnnulledToForCorrection: 'ai-transitions-relations-control-Annulled_to_ForCorrection',
  /** id кнопки действия "Создать ДС на изменение" (Заявка) */
  controlPLECreateGeneralAmendment: 'ai-transitions-relations-control-PLECreateGeneralAmendment',
  /** id кнопки действия "Создать ДС на расторжение" (Заявка) */
  controlPLECreateCancellationAmendment: 'ai-transitions-relations-control-PLECreateCancellationAmendment',
  /** id кнопки действия "Создать ДС на изменение" (Новый) */
  controlPLECreateGeneralAmendmentDraft: 'ai-transitions-relations-control-PLECreateGeneralAmendmentDraft',
  /** id кнопки действия "Создать ДС на расторжение" (Новый) */
  controlPLECreateCancellationAmendmentDraft: 'ai-transitions-relations-control-PLECreateCancellationAmendmentDraft',

  /** --------------------- id Печатных форм в Договоре --------------------- */

  /** id печатной формы "Сопроводительный лист" (id одинаковый во всех документах) */
  coverListOfPolicyPrintout: 'ai-printouts-control-CoverListOfPolicyPrintout',

  /** --------------------- id вкладок продукта МСБ Re --------------------- */

  /** id вкладки "Общая информация" */
  tabGeneralInformationNav: 'tab-general-information-nav',
  // /** id вкладки "Вложения" */
  // policyPLE.tabAttachmentsDocumentsNav
  /** id вкладки "Условия страхования" */
  tabInsuranceConditionsNav: 'tab-insurance-conditions-nav',
  /** id вкладки "Расчет тарифа" */
  tabGTariffCalculationNav: 'tab-tariff-calculation-nav',
  /** id вкладки "Оформление полиса" */
  tabPolicyRegistrationNav: 'tab-policy-registration-nav',
  /** id вкладки "История документа" */
  tabContractActivityNav: 'tab-Contract-activity-nav',

  /** ------------------ id элементов вкладки Общая информация МСБ Re ------------------ */

  /** id блока "ОПИСАНИЕ ПРОДУКТА МСБ RE" */
  descriptionSmbreSection: 'description-smbre-section',
  /** id блока "CТРАХОВАТЕЛЬ" */
  policyholderSection: 'policyholder-section',
  /** id блока "ВЫГОДОПРИОБРЕТАТЕЛЬ" */
  beneficiarySection: 'beneficiary-section',
  /** id блока "СРОК СТРАХОВАНИЯ & ИСТОРИЯ СТРАХОВАНИЯ" */
  durationHistorySection: 'duration-history-section',
  /** id блока "ОРГАНИЗАЦИОННАЯ СТРУКТУРА" */
  organisationStructureSection: 'organisation-structure-section',
  /** id атрибута "ИНН" блока CТРАХОВАТЕЛЬ */
  policyHolderTaxNumber: 'policy-holder-tax-number',
  /** id textbox "Наименование (как в Полисе)" */
  editHolderName: 'edit-holder-name',
  /** id атрибута "ИНН" блока ВЫГОДОПРИОБРЕТАТЕЛЬ */
  beneficiaryTaxNumber: 'beneficiary-tax-number',
  /** id checkbox "Выгодоприобретателем является Страхователь" */
  beneficiaryIsPolicyHolder: 'beneficiary-is-policyholder',
  /** id checkbox "Имущество передается в залог или лизинг" */
  propertyIsleased: 'property-is-leased',
  /** id combobox "Вид финансового учреждения" */
  leasingType: 'leasing-type-ng-select',
  /** id button поиск "Поиск" (для Имущество передается в залог или лизинг) */
  bankSearchButton: 'bank-search-button',
  // /** id textbox Наименование финансового учреждения */
  // quotePLE.leasingPartner
  // /** id текстовое поле "Дата начала" */
  // quotePLE.insuranceStart
  // /** id текстовое поле "Дата окончания" */
  // quotePLE.insuranceEnd: 'insurance-end-input',
  // /** id textbox "Срок действия" */
  // quotePLE.insuranceDuration: 'insurance-duration',
  /** id combobox "История страхования" */
  insuranceHistorySmb: 'insurance-history-ng-select',
  /** id textbox "Номер предыдущего договора" */
  previousContracNumber: 'previous-contrac-number',
  // /** id combobox Канал продаж */
  // applicationPLE.dealSalesChannel
  // /** id combobox Зона ответственности */
  // applicationPLE.dealSalesZone
  /** id combobox Профильная программа */
  profileProgram: 'profileProgram-ng-select',
  /** id кнопки поиска "Подразделение сделки" */
  departmentSearchButton: 'department-search-dialog-button',

  /** ------------------ id элементов вкладки Условия страхования МСБ Re ------------------ */

  /** id блока "Локации" */
  locationsSection: 'locations-section',
  /** id блока "СТРАХОВЫЕ РИСКИ И ДОПОЛНИТЕЛЬНЫЕ ПОКРЫТИЯ" */
  insuranceRisksCoveragesSection: 'insurance-risks-and-coverages-section',
  /** id блока "ОТРАСЛЬ" */
  industrySection: 'industry-section',
  /** id блока "ОБЪЕКТЫ СТРАХОВАНИЯ, СТРАХОВЫЕ СУММЫ, КУМУЛЯЦИЯ" */
  insuranceObjectsSumSection: 'insurance-objects-sum-insurances-cumulation-section',
  // /** id textbox "Наименование" */
  // quotePLE.locationDescription
  // /** id combobox "Адрес целиком" */
  // quotePLE.fullAddress
  // /** id textbox "Индекс" */
  // quotePLE.postalCode
  // /** id textbox "Страна" */
  // quotePLE.country
  // /** id textbox "Регион" */
  // quotePLE.region
  // /** id textbox "Город" */
  // quotePLE.city
  /** id combobox "Страховое покрытие" */
  coverageType: 'coverage-type-ng-select',
  /** id checkbox "Не применяется" (Франшиза по каждому страховому случаю) */
  deductibleNotApplied: 'deductible-not-applied',
  /** id checkbox "В % от страховой суммы" (Франшиза по каждому страховому случаю) */
  deductibleInPercentage: 'deducitble-in-percentage',
  /** id combobox "Значение франшизы" (В % от страховой суммы) */
  deductibleInPercentageValue: 'deducitble-in-percentage-value-ng-select',
  /** id checkbox "В рублях (валюте)" (Франшиза по каждому страховому случаю) */
  deductibleInCurrency: 'deducitble-in-currency',
  /** id combobox "Значение франшизы" (В рублях (валюте)) */
  deductibleInCurrencyValue: 'deducitble-in-currency-value-ng-select',
  // /** id checkbox "Здание(я)" */
  // quotePLE.objectBuilding
  // /** id checkbox "Помещение(я)" */
  // quotePLE.objectPremises
  // /** id checkbox "Сооружение(я)" */
  // quotePLE.objectFacilities
  // /** id checkbox "Земельные участки" */
  // quotePLE.objectLand
  // /** id checkbox "Товарно-материальные ценности" */
  // quotePLE.objectStocks
  /** id текстовое поле "Страховая сумма (по зданиям)" */
  objectBuildingSumInsured: 'object-building-sum-insured-input',
  /** id текстовое поле "Страховая сумма (по помещениям)" */
  objectPremisesSumInsured: 'object-premises-sum-insured-input',
  /** id текстовое поле "Страховая сумма (по сооружениям)" */
  objectFacilitiesSumInsured: 'object-facilities-sum-insured-input',
  /** id текстовое поле "Страховая сумма (по земельным участкам)" */
  objectLandSumInsured: 'object-land-sum-insured-input',
  /** id checkbox "Оборудование" */
  objectEquipment: 'object-equipment',
  /** id текстовое поле "Страховая сумма (по оборудованию)" */
  objectEquipmentSumInsured: 'object-equipment-sum-insured-input',
  /** id текстовое поле "Страховая сумма (по ТМЦ)" */
  objectStocksSumInsured: 'object-stocks-sum-insured-input',
  /** id текстовое поле "Страховая сумма с учетом кумуляции" */
  cumulativeSumInsured: 'cumulative-sum-insured-input',
  /** id текстовое поле "Общая страховая сумма" */
  totalSumInsured: 'total-sum-insured-input',
  // /** id checkbox "Склад" */
  // quotePLE.industryWarehouse
  /** id combobox "Вид товарно-материальных ценностей" */
  stocksTypeWarehouse: 'stocks-type-ng-select',
  /** id checkbox "Риски на период демонтажа/монтажа/пуско-наладки застрахованного оборудования" */
  riskCommissioning: 'risk-commissioning',
  /** id checkbox "Бой стекол" */
  riskGlass: 'risk-glass',

  /** ------------------ id элементов вкладки Оформление полиса МСБ Re ------------------ */

  /** id блока "Оформление полиса" */
  policyRegistrationSection: 'policy-registration-section',
  /** id блока "Опись" */
  inventorySection: 'inventory-section',
  /** id блока "Условия договора" */
  policySmbConditionsSection: 'policy-conditions-section',
  /** id блока "График платежей" */
  paymentPlanSection: 'payment-plan-section',
  /** id блока "Подписание" */
  policySigningSection: 'policy-signing-section',
  /** id combobox "Порядок оплаты премии" */
  installments: 'installments-ng-select',
  /** id combobox "Способ подписания договора" */
  signingType: 'signing-type-ng-select',
  /** id checkbox "Заполнить Опись вручную (для большого количества объектов)" */
  manualInventory: 'manual-inventory',
  /** id таблицы в блоке "Опись" */
  inventoryContentGrid: 'inventory-content-grid',
  /** id textbox "Город оформления" */
  cityRegistration: 'city-registration',
  /** id textbox "Номер кредитного договора" */
  creditAgreementNumber: 'credit-agreement-number',
  /** id текстовое поле "Дата кредитного договора" */
  dateCreditAgreement: 'date-credit-agreement-input',
  /** id textbox "Номер договора залога" */
  pledgeAgreementNumber: 'pledge-agreement-number',
  /** id текстовое поле "Дата договора залога" */
  datePledgeAgreement: 'date-pledge-agreement-input',
  /** id checkbox "Выплата страхового возмещения без учета износа заменяемых частей, узлов, агрегат" */
  paymentWithoutAccountDepreciation: 'payment-without-account-depreciation',
  /** id checkbox "Дополнительные расходы (расходы на расчистку и слом + на независимых экспертов)" */
  cleaningDemolition: 'cleaning-and-demolition',
  /** id checkbox "Имеется отчет об оценке заявляемого на страхование имущества" */
  reportAssessmentExist: 'report-on-assessment-exist',
  /** id combobox "Порядок выплаты возмещения" */
  claimSystem: 'claim-system-ng-select',
  /** id combobox "Порядок установления СС" */
  establishingProcedure: 'establishing-procedure-ng-select',
  /** id checkbox "Редактировать раздел "Выгодоприобретатель" */
  editBeneficiary: 'edit-beneficiary',
  /** id textbox "Выгодоприобретатель (скорректированные условия)" */
  beneficiaryAddjustedConditions: 'beneficiary-addjusted-conditions',
  /** id combobox "Банк для указания реквизитов оплаты" */
  preambleBankInfo: 'preamble-bank-info-ng-select',
  /** id combobox "Подписант" */
  signatoryName: 'signatoryName-ng-select',
  /** id textbox "Выгодоприобретатель (типовые условия)" */
  beneficiaryTypicalConditions: 'beneficiary-typical-conditions',
  /** id checkbox "Редактировать раздел "Не добавлять в Полис Оговорку об исключении военных рисков, рисков гражданской войны, терроризма и диверсии" */
  dontClauseExcludeWarRisks: 'dont-add-clause-to-exclude-war-risks',
  /** id textbox "Номер доверенности" */
  number: 'number',
  /** id текстовое поле "Дата доверенности" */
  validFrom: 'validFrom-input',
  /** id combobox "Форма договора" */
  policyForm: 'policy-form-ng-select',
  /** id текстовое поле "Дата подписания договора" */
  issueDate: 'issue-date-input',
  /** id checkbox "Отсрочка первого взноса " */
  enableInstallmentCorrection: 'checkbox-enable-installment-correction',
  /** id текстовое поле дата "Отсрочка первого взноса" */
  enableInstallmentCorrectionDate: 'edit-installment-correction-input',
  /** id textbox "Документ-основание" */
  insuredDoc: 'insured-doc',
  /** id textbox "Должность подписанта от имени Страхователя" */
  insuredRank: 'insured-rank',
  /** id текстовое поле "Дата документа-основания" */
  insuredDocDate: 'insured-doc-date-input',

  /** ------------------ id элементов вкладки Расчет тарифа МСБ Re ------------------ */

  /** id блока "Посредники" */
  partnersSection: 'partners-section',
  /** id блока "ПАРАМЕТРЫ ДОГОВОРА СТРАХОВАНИЯ" */
  generalSummarySection: 'general-summary-section',
  /** id блока "СОГЛАСОВАНИЕ" */
  approvalSection: 'approval-section',
  /** id блока "РАСЧЕТ ПРЕМИИ" */
  premiumCalculationSection: 'premium-calculation-section',
  /** id блока "Комментарии" */
  commentsSection: 'comments-section',
  /** id текстовое поле "Размер КВ" */
  partnerCommisionPercentage: 'partner-commision-percentage-input',
  /** id текстовое поле "Общая страховая сумма по договору" */
  generalSum: 'general-sum-insured-input',
  /** id текстовое поле "Максимальная СС по локации с учетом кумуляции" */
  highestCumulativeSum: 'highest-cumulative-sum-insured-input',
  /** id текстовое поле "Нетто-премия по договору" */
  summaryNetPremium: 'summary-net-premium-input',
  /** id текстовое поле "Нагрузка по договору страхования, %" */
  loadingPercentage: 'loading-percentage-input',
  /** id текстовое поле "Брутто-премия по договору" */
  summaryGrossPremium: 'summary-gross-premium-input',
  /** id текстовое поле "Укажите" в % */
  correctionTariffValue: 'correction-tariff-percentage-value-input',
  /** id текстовое поле "Укажите" в руб. */
  correctionTariffVal: 'correction-tariff-value-input',
  /** id checkbox "Корректировка тарифа / премии" */
  correctionTariff: 'correction-tariff',
  /** id combobox "Выберите вариант" */
  correctionTariffType: 'correction-tariff-type-ng-select',

  /** --------------------- id Действий в Договоре МСБ Re --------------------- */

  /** id кнопки действия "Оформить Полис" (статус Новый) */
  controlDraftToRegistration: 'ai-transitions-relations-control-Draft_to_Registration',
  /** id кнопки действия "Аннулировать" (статус Новый) */
  controlDraftToAnnuled: 'ai-transitions-relations-control-Draft_to_Annuled',
  /** id кнопки действия "Направить на согласование с Дирекцией продаж" (статус Новый) */
  controlDraftToForApproval: 'ai-transitions-relations-control-Draft_to_ForApproval',
  /** id кнопки действия "Создать копию" */
  controlCopySMBREPolicy: 'ai-transitions-relations-control-CopySMBREPolicy',
  /** id кнопки действия "Отозвать" (статус Оформление полиса) */
  controlRegistrationToForCorrection: 'ai-transitions-relations-control-Registration_to_ForCorrection',
  /** id кнопки действия "Аннулировать" (статус Оформление полиса) */
  controlRegistrationToAnnuled: 'ai-transitions-relations-control-Registration_to_Annuled',
  /** id кнопки действия "Подписать" */
  controlRegistrationToSigned: 'ai-transitions-relations-control-Registration_to_Signed',
  /** id кнопки действия "Оформить Полис" (статус На корректировку) */
  controlForCorrectionToRegistration: 'ai-transitions-relations-control-ForCorrection_to_Registration',
  /** id кнопки действия "Аннулировать" (статус На корректировку) */
  controlForCorrectionToAnnuled: 'ai-transitions-relations-control-ForCorrection_to_Annuled',
  /** id кнопки действия "Направить на согласование с Дирекцией продаж" (статус На корректировку) */
  controlForCorrectionToForApproval: 'ai-transitions-relations-control-ForCorrection_to_ForApproval',
  /** id кнопки действия "Согласовать" (статус На согласовании) */
  controlForApprovalToRegistration: 'ai-transitions-relations-control-ForApproval_to_Registration',
  /** id кнопки действия "Отказать" (статус На согласовании) */
  controlForApprovalToRejected: 'ai-transitions-relations-control-ForApproval_to_Rejected',

  /** --------------------- id Печатных форм в Договоре МСБ Re--------------------- */

  /** id печатной формы "Счет" */
  controlSMBREInvoicePrintout: 'ai-printouts-control-SMBREInvoicePrintout',
  /** id печатной формы "Договор (PDF)" */
  controlSMBREPolicyPrintoutPdf: 'ai-printouts-control-SMBREPolicyPrintoutPdf',
}

const projectPLE = {
  /** --------------------- id вкладок Проекта договора --------------------- */

  /** id вкладки "Условия договора" */
  tabConditionsNav: 'tab-conditions-nav',
  /** id вкладки "Документы и фотоматериалы" */
  tabAttachmentsNav: 'tab-attachments-nav',
  /** id вкладки "Триггеры" */
  tabConstraintsNav: 'tab-constraints-nav',
  /** id вкладки "История согласования" */
  tabActivitiesHistoryNav: 'tab-activities-and-history-nav',

  /** --------------------- id элементов вкладки Условия договора --------------------- */

  /** id checkbox "Конкурсная форма договора (ФЗ 44)" */
  editFederalLaw44: 'edit-federal-law-44',
  /** id checkbox "Конкурсная форма договора (ФЗ 223)" */
  editFederalLaw223: 'edit-federal-law-223',
  /** id textbox "Укажите пункты договора, в которые необходимо внести изменения" */
  editChangesCompetition: 'edit-changes-competition',
  /** id checkbox "Договор страхования предусматривает необходимость открытия отдельного счета в подразделениях Федерального казначейства под операции и осуществления казначейского сопровождения в рамках государственного контракта" */
  editNeedTreasuryAccount: 'edit-need-treasury-account',
  /** id checkbox "Требуется включение условий урегулирования убытков, отличных от указанных в Правилах страхования, типовой форме договора страхования либо локальных нормативных актах Общества" */
  editLossChangesNeeded: 'edit-loss-changes-needed',
  /** id textbox "Укажите условия договора по урегулированию убытков, в которые необходимо внести изменения" */
  editChangesLoss: 'edit-changes-loss',
  /** id combobox "Выберите Дирекцию урегулирования убытков, с которой необходимо согласовать договор" */
  selectLossesDepartment: 'select-losses-department-ng-select',
  /** id checkbox "Договор страхования предусматривает необходимость открытия счета любого типа в банке, в том числе под операции в рамках государственного оборонного заказа или государственного контракта" */
  editNeedBankAccount: 'edit-need-bank-account',
  /** id checkbox "Требуется согласование блока перестрахования" */
  reinsuranceApprovalNeeded: 'reinsurance-approval-needed',
  /** id textbox "Укажите номер заявки на перестрахование в CRM" */
  crmRequestNumber: 'crm-request-number',

  /** --------------------- id Действий в Проекте договора --------------------- */

  /** id кнопки действия "Направить заявку на оформление" */
  controlRequestToDraft: 'ai-transitions-relations-control-Request_to_Draft',
  /** id кнопки действия "Направить на согласование" */
  controlDraftToForApproval: 'ai-transitions-relations-control-Draft_to_ForApproval',
  /** id кнопки действия "Направить инициатору" */
  controlApprovedToAtInitiator: 'ai-transitions-relations-control-Approved_to_AtInitiator',
  /** id кнопки действия "Отозвать" из статуса Согласован */
  controlApprovedToForCorrection: 'ai-transitions-relations-control-Approved_to_ForCorrection',
  /** id кнопки действия "Направить на согласование" с корректировки */
  controlForCorrectionToForApproval: 'ai-transitions-relations-control-ForCorrection_to_ForApproval',

  /** --------------------- id Печатных форм в Проекте договора --------------------- */

  /** id печатной формы "Лист согласования" (id одинаковый во всех документах) */
  projectPLEDocumentApprovalList: 'ai-printouts-control-PLEDocumentApprovalList',
}

const amendmentPLE = {
  /** --------------------- id элементов вкладки Дополнительное соглашение --------------------- */

  /** id вкладки "Дополнительное соглашение" */
  tabAmendmentInformationNav: 'tab-Amendment-information-nav',

  /** ---------- id элементов блока УСЛОВИЯ ДОП.СОГЛАШЕНИЯ ---------- */

  /** id текстового поля (ввод даты, input) "Дата письменного заявления Страхователя на внесение изменений" */
  amendmentApplicationDate: 'amendment-application-date-input',
  /** id текстового поля (ввод даты, input) "Дата, с которой необходимо внести изменения" */
  amendmentChangeDate: 'amendment-change-date-input',
  /** id текстового поля (ввод даты, input) "Последний день действия договора" */
  amendmentTerminationDate: 'amendment-termination-date-input',
  /** id текстового поля (ввод даты, input) "Дата заключения" */
  amendmentConclusionDate: 'amendment-conclusion-date-input',
  /** id textbox "Краткое содержание" */
  amendmentShortDescription: 'amendment-short-description',
  /** id combobox "Причина расторжения" */
  amendmentTerminationReason: 'amendment-termination-reason',
  /** id текстового поля (input) "Оплаченная премия" */
  amendmentTerminationPremiumPaid: 'amendment-termination-premium-paid-input',
  /** id checkbox "Требуется нестандартный вычет РВД (стандартный: 0,4 * (1-КВ) + КВ)" */
  amendmentTerminationNonTypeRVD008: 'amendment-termination-non-type-rvd-enterprise-and-physical-rules',
  /** id checkbox "Требуется нестандартный вычет РВД (стандартный: размер КВ + 2%)" */
  amendmentTerminationNonTypeRVD066: 'amendment-termination-non-type-rvd',
  /** id текстового поля (input) "Укажите нестандартный размер РВД" */
  amendmentTerminationNonTypeRVDValue: 'amendment-termination-non-type-rvd-value-input',
  /** id текстового поля (input) "Совокупный размер страховых выплат и заявленных убытков по договору" */
  amendmentTerminationLosses: 'amendment-termination-losses-input',
  /** id checkbox "дополнительное соглашение не предусматривает изменение каких-либо условий, за исключением исправления технических ошибок в реквизитах, доверенностях, изменения номеров и иных реквизитов кредитных договоров или договоров лизинга" */
  amendmentTechAddendum: 'amendment-tech-addendum',

  /** ---------- id элементов блока Форма договора ---------- */

  /** id блока "Форма договора" */
  contractFormSection: 'contract-form-section',

  /** ---------- id элементов блока Форма договора ---------- */

  /** id блока "Повторное рассмотрение" */
  reevaluationSection: 'reevaluation-section',
  /** id textbox "Причина необходимости пересмотра решения андеррайтера на уровне Руководства" */
  reasonReviewUnderwriterDecision: 'reason-to-review-underwriter-decision',

  /** ---------- id элементов блока Подписанты ---------- */

  /** id textbox "Документ-основание" страховщик" */
  insurerRepresentativeDoc: 'general-amendment-insurer-representative-doc',
  /** id textbox "Должность подписанта от имени Страховщика" */
  insurerRepresentativeRank: 'general-amendment-preamble-insurer-representative-rank',
  /** id текстового поля (ввод даты, input) "Дата документа-основания" страховщик */
  insurerRepresentativeDocDate: 'general-amendment-insurer-representative-doc-date-input',
  /** id combobox "Банк для указания реквизитов оплаты" */
  amendmentPreambleBankInfo: 'general-amendment-preamble-bank-info',
  /** id textbox "Документ-основание" страхователь */
  policyHolderRepresentativeDoc: 'general-amendment-policy-holder-representative-base-document',
  /** id textbox "Должность подписанта от имени Страхователя" */
  policyHolderRepresentativeRank: 'general-amendment-policy-holder-representative-rank',
  /** id текстового поля (ввод даты, input) "Дата документа-основания" страхователь */
  policyHolderRepresentativeDocDate: 'general-amendment-policy-holder-representative-base-document-date-input',

  /** ------- id элементов блока Ретроактивная ответственность ------- */

  /** id текстового поля (ввод даты, input) "Дата окончания" */
  amendmentRetroactiveEndDate: 'amendment-retroactive-end-date-input',
  /** id текстового поля (input) "Доплата/Возврат премии" */
  amendmentAdditionalPayment: 'amendment-retroactive-additional-payment-coercive-input',
  /** id текстового поля (input) "Доплата/Возврат премии (расчетное значение)" */
  amendmentAdditionalPaymentCalculated: 'amendment-retroactive-additional-payment-calculated-input',
  /** id текстового поля (ввод даты, input) "Общий срок действия договора с учетом изменений" */
  amendmentDuration: 'amendment-retroactive-policy-duration-amendments',
  /** id checkbox "По условиям доп.соглашения требуется включение ретроактивной ответственности" */
  amendmentRetroactiveCondition: 'amendment-retroactive-condition-of-retroactive-date',
  /** id textbox "Причина требования включения условия о ретроактивной дате" */
  amendmentRetroactiveConditionComment: 'amendment-retroactive-condition-of-retroactive-comment',
  /** id текстового поля (input) "Требуемая дата начала ответственности" */
  amendmentRetroactiveConditionStartDate: 'amendment-retroactive-retroactive-start-date-input',
  /** id checkbox "Получена декларация от Страхователя об отсутствии страховых случаев / о наличии причин, которые могут повлечь наступление страхового случая и/или Страхователю отправлено уведомление о непризнании страховыми случаями событий, наступивших в ретроактивный период и/или имущество уже застраховано в АО «СОГАЗ» на тех же условиях (существенные условия по договору не изменяются)" */
  amendmentRetroactiveDeclaration: 'retroactive-declaration',
  /** id checkbox "В период ретроактивной ответственности произошли события (причины событий), имеющие признаки страховых случаев" */
  amendmentRetroactiveLosses: 'amendment-retroactive-retroactive-losses',
  /** id textbox "Описание событий (причин событий), в т.ч. дата наступления" */
  amendmentRetroactiveLossesDescription: 'amendment-retroactive-retroactive-losses-description',
  /** id combobox оговорки, без чекбокса 'amendment-retroactive-retroactive-losses' */
  amendmentRetroactiveClausesWithoutLosses: 'amendment-retroactive-retroactive-clauses-without-losses',
  /** id combobox оговорки, c чекбоксом 'amendment-retroactive-retroactive-losses' */
  amendmentRetroactiveClausesWithLosses: 'amendment-retroactive-retroactive-clauses-with-losses',

  /** ------- id элементов блока Уровень согласования ДопСа ------- */

  /** id combobox  "Уровень согласования ДопСа" */
  amendmentLevelContractApproval: 'amendment-level-contract-approval-ng-select',

  /** --------------------- id Действий в Доп.соглашениях --------------------- */

  /** id кнопки действия "Направить заявку на оформление" */
  controlRequestToDraftAmend: 'ai-transitions-relations-control-Request_to_Draft',
  /** id кнопки действия "Направить на согласование" */
  controlDraftSendToHigherLevelAmend: 'ai-transitions-relations-control-Draft_SendToHigherLevel',
  /** id кнопки действия "Отозвать с согласования" */
  controlForApprovalL1ToForCorrectionAgentAmend:
    'ai-transitions-relations-control-ForApprovalL1_to_ForCorrection_Agent',
  /** id кнопки действия "Направить на согласование" */
  controlForCorrectionToForApprovalL1Amend: 'ai-transitions-relations-control-ForCorrection_to_ForApprovalL1',
  /** id кнопки действия "Пересчитать триггеры" */
  controlForApprovalL1ToForApprovalL1Amend: 'ai-transitions-relations-control-ForApprovalL1_to_ForApprovalL1',
}

export { applicationPLE, quotePLE, policyPLE, projectPLE, amendmentPLE }
