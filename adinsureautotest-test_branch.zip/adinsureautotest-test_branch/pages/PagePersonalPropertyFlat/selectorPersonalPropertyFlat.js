export const selectorContract = {
  /*-----------------------------------------------------------------------Селекторы элементов главного меню-------------------------------------------------------*/
  /** @description Папка  "Страховые продукты"' */
  contracts: 'Contracts_menu_1',

  /** @description Папка  продукта "Имущество ФЛ"' */
  personalProperty: 'PersonalProperty_1_2',

  /** @description Элемент создания документа   "Договор"' */
  personalPropertyContract: 'SogazBuildingPolicy_1_3',

  /** @description Элемент создания документа   "Поиск документов"' */
  documentSearch: 'ContractSearchByCurrentUserBranchTemp_1_2',

  /*-----------------------------------------------------------------------Селекторы списка действий документа-------------------------------------------------------*/
  /** @description Button 'Кнопка действия "Направить на согласование из статуса "Новый" в статун "На согласование Андеррайтеру 1-го уровня" "' */
  draftSendToHigherLevel: 'ai-transitions-relations-control-Draft_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Направить на согласование (уровень 1) из статуса "На корректировке"  "' */
  forCorrectionSendToHigherLevel: 'ai-transitions-relations-control-ForCorrection_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Отказаться от оформления "' */
  draftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',

  /** @description Button 'Кнопка действия "Копировать документ' */
  copySogazBuildingPolicy: 'ai-transitions-relations-control-CopySogazBuildingPolicy',

  /** @description Button 'Кнопка действия "На корректировку' Действие совершено Продавцом! */
  checkDataToForCorrection: 'ai-transitions-relations-control-CheckData_to_ForCorrection',

  /** @description Button 'Кнопка действия "На корректировку' из статуса "На согласовании у андеррайтера ГО " Действие совершено Продавцом! */
  uw3ToForCorrection: 'ai-transitions-relations-control-UW3_to_ForCorrection',

  /** @description Button 'Кнопка действия "На корректировку' из статуса "из статуса "На согласовании у андеррайтерра уровень 1 " Действие совершено Продавцом! */
  uw1ToForCorrection: 'ai-transitions-relations-control-UW1_to_ForCorrection',

  /** @description Button 'Кнопка действия "На согласование андеррайтеру ГО' */
  approvalDebToUw3Title: 'ai-transitions-relations-control-CheckData_to_UW3',

  /** @description Button 'Кнопка действия "Продолжить согласование внутри ГО' */
  uw3ToUw3hTitle: 'ai-transitions-relations-control-UW3_to_UW3h',

  /** @description Button 'Кнопка действия "Согласовать ( из статуса "На согласовании у андеррайтерра уровень 1")' */
  uW1SendToHigherLevel: 'ai-transitions-relations-control-UW1_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Согласовать ( из статуса "На согласовании у андеррайтерра ГО")' */
  uW3SendToHigherLevel: 'ai-transitions-relations-control-UW3_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Направить на согласование ДЭБ ( из статуса "На согласовании у андеррайтерра ГО")' */
  uw3ToApprovalDeb: 'ai-transitions-relations-control-UW3_to_ApprovalDEB',

  /** @description Button 'Кнопка действия "Направить на согласование ДЭБ ( из статуса "На согласовании у андеррайтерра ГО") (группа: Андеррайтер 3h)' */
  uw3hToApprovalDeb: 'ai-transitions-relations-control-UW3h_to_ApprovalDEB',

  /** @description Button 'Кнопка действия "Направить на согласование ( из статуса "На согласовании ДЭБ") */
  approvalDebSendToHigherLevel: 'ai-transitions-relations-control-ApprovalDEB_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Согласовать ( из статуса "На согласовании у Исполнительного директора по андеррайтингу")' */
  uW4SendToHigherLevel: 'ai-transitions-relations-control-UW4_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Направить Исполнительному директору по андеррайтингу" ( из статуса "На согласовании у андеррайтерра ГО")' */
  uw3ToUW4: 'ai-transitions-relations-control-UW3_to_UW4',

  /** @description Button 'Кнопка действия "Направить Исполнительному директору по андеррайтингу" ( из статуса "На согласовании у андеррайтерра ГО (группа: Андеррайтер 3h)' */
  uw3hToUW4: 'ai-transitions-relations-control-UW3h_to_UW4',

  /** @description Button 'Кнопка действия "Продолжить согласование внутри ГО ( из статуса "На согласовании у андеррайтерра ГО (группа: Андеррайтер 3h)")' */
  uW3hSendToHigherLevel: 'ai-transitions-relations-control-UW3h_SendToHigherLevel',

  /** @description Button 'Кнопка действия "К оплате' */
  approvedToPaymentWaiting: 'ai-transitions-relations-control-Approved_to_PaymentWaiting',

  /** @description Button 'Кнопка действия "Оформлен' */
  paymentWaitingToActivated: 'ai-transitions-relations-control-PaymentWaiting_to_Activated',

  /*-----------------------------------------------------------------------Селекторы вкладок документа-------------------------------------------------------*/

  /** @description  id вкладки "Общая информация" */
  generalInformation: 'general-information-nav',

  /** @description  id вкладки "Проверка СБ" */
  tabSecurityVerification: 'security-verification-nav',

  /** @description  id вкладки "Параметры объекта" для КВАРТИРЫ!*/
  insuranceFacilitiesDetail: 'insurance-facilities-nav',

  /** @description  id вкладки "Параметры объекта" для СТРОЕНИЯ! */
  tabBuildingsStructures: 'buildings-structures-nav',

  /** @description  id вкладки "Осмотр и оценка"для КВАРТИРЫ! */
  inspection: 'inspectionAppartment-nav',

  /** @description  id вкладки "Осмотр и оценка"  для СТРОЕНИЯ!*/
  tabBuildinginspection: 'inspection-nav',

  /** @description  id вкладки "Расчет тарифа" */
  insuranceConditions: 'tab-tariff-nav',

  /** @description  id вкладки "Вложения" */
  attachedDocuments: 'tab-Attached-documents-nav',

  /** @description  id вкладки "Выпуск договора" */
  policyIssue: 'tab-policy-issue-nav',

  /** @description  id вкладки "Триггеры и комментарии" */
  constraintsAndComments: 'tab-constraints-and-comments-nav',

  /** @description  id вкладки "История документа" */
  contractActivityAndTransitionHistory: 'tab-Contract-activity-nav',

  /** @description  combobox "Сострахование" */
  coInsurance: 'co-insurance',

  /*-----------------------------------------------------------------------Селекторы вкладки "Общая информация"-------------------------------------------------------*/

  /*-------------------------Селекторы блока "Общее" */

  /** @description id секции "Общее"' */
  sectionGeneralData: 'SBGeneralData-generalData',

  /** @description Поле "Объект страхования"' */
  insuranceType: 'insurance-type',

  /**@description Поле "Специальная программа"'*/
  specialConditionsGroup: 'special-conditions-group',

  /*-------------------------Селекторы блока "Срок страхования" */

  /** @description combobox "Срок действия договора, мес."' */
  policyDuration: 'policy-duration',

  /*-------------------------Селекторы блока "Страхователь" */

  /** @description button "Поиск страхователя"' */
  findPolicyHolderButton: 'policyholder-search-button',

  /** @description button "Обновить"' */
  reloadButton: 'button-reload',

  /*-------------------------Селекторы блока "Выгодоприобретатель" */
  /** @description button "Обновить"' */
  beneficiary: 'beneficiary-search-button',

  /** @description radioButton "За счет кого следует (не определен)"' */
  expenditionFollowsNotDefine: 'beneficiary-type-1',

  /** @description radioButton "Выгодоприобретателем является Страхователь"' */
  beneficiaryPolicyHolder: 'beneficiary-type-2',

  /** @description radioButton "Выгодоприобретателем является банк (имущество в залоге)"' */
  beneficiaryBank: 'beneficiary-type-3',

  /*-------------------------Селекторы блока "Организационная структура" */

  /** @description Button "Кнопка поиска менеджера договора' */
  buttonSearchManager: '-dialog-button',
  /** @description Textbox "Поле "Поиск сотрудника"' */
  textboxSearchManager: 'employee-search-input',

  /*-------------------------Селекторы блока "Организационная структура" */
  /** @description id секции "ОБЩИЕ РИСКОВЫЕ ФАКТОРЫ"'  ТОЛЬКО ДЛЯ СТРОЕНИЯ */
  generalRiskFactors: 'general-risk-factors',

  /** @description id секции "ОБЩИЕ РИСКОВЫЕ ФАКТОРЫ"'  ТОЛЬКО ДЛЯ КВАРТИРЫ */
  commonRiskFactors: 'common-risk-factors',

  /*-----------------------------------------------------------------------Селекторы вкладки "Параметры объекта"-------------------------------------------------------*/

  /*-------------------------Селекторы блока "Помещение и машино-место" */

  /** @description id секции "Помещение и машино-место"' */
  insuranceFacilities: 'insurance-facilities-section',

  /*-------------------------Селекторы блока "АДРЕС ТЕРРИТОРИИ СТРАХОВАНИЯ" */

  /** @description поле 'Адрес целиком' */
  fullAddress: 'AddressAutocomplete',

  /** @description button 'По адресу страхователя' */
  policyHolderAddress: 'policyholder-address-button',

  /** @description button 'Стандартизация' */
  standardize: 'standardize-button',

  /*-------------------------Селекторы блока "СТРАХОВЫЕ РИСКИ И СТРАХОВЫЕ ПОКРЫТИЯ" */

  /** @description id секции "СТРАХОВЫЕ РИСКИ И СТРАХОВЫЕ ПОКРЫТИЯ"' */
  sectionSBRisks: 'sb-risks',

  /** @description id секции "СТРАХОВАНИЕ ДОПОЛНИТЕЛЬНОГО ИМУЩЕСТВА"' */
  sectionAdditionalProperty: 'additional-property',

  /*-------------------------ТОЛЬКО ДЛЯ СТРОЕНИЯ! Селекторы блока "Строения и сооружения" */

  /** @description id секции "Строения и сооружения"' */
  buildingsStructures: 'buildingsp-structures-section',

  /*-----------------------------------------------------------------------Селекторы вкладки "Осмотр и оценка"-------------------------------------------------------*/
  /** @description id секции "АКТ ОСМОТРА ОБЪЕКТА СТРАХОВАНИЯ"' */
  sectionInspectionActAppartment: 'SBInspectionActApartment-inspectionActAppartment',

  /** @description id секции "Осмотр и фотографирование"'ДЛЯ СТРОЕНИЯ */
  buildinginspectionPhoto: 'SBInspectionPhoto-inspectionPhoto',

  /** @description id секции "Осмотр и фотографирование"'ДЛЯ КВАРТИРЫ */
  flatinspectionPhoto: 'SBInspectionPhoto-inspectionPhoto-1',

  /** @description id секции 'ДОПОЛНИТЕЛЬНАЯ ИНФОРМАЦИЯ'*/
  additionalInformation: 'SBInspectionActAdditional-additionalInformation',

  /** @description id секции 'НАЛИЧИЕ ДЕФЕКТОВ СТРОЕНИЙ/ СООРУЖЕНИЙ' */
  buildingDefects: 'SBInspectionActDefects-buildingDefects',

  /*-----------------------------------------------------------------------Селекторы вкладки "Расчет тарифа"-------------------------------------------------------*/

  /*-------------------------Селекторы блока "РАСЧЕТНЫЕ ПАРАМЕТРЫ ДОГОВОРА СТРАХОВАНИЯ" */

  /** @description id секции "РАСЧЕТНЫЕ ПАРАМЕТРЫ ДОГОВОРА СТРАХОВАНИЯ"' */
  sectionCalcParameters: 'SBCalcParameters-#',

  /** @description id поля "Итоговый андеррайтерский коэффициент"' */
  uWcoefficient: 'uw-coefficient',

  /*-----------------------------------------------------------------------Селекторы вкладки "Выпуск договора"-------------------------------------------------------*/

  /*-------------------------Селекторы блока "Даты договора страхования" */

  /** @description id секции "Даты договора страхования"' */
  policyInsuranceDate: 'policyInsuranceDate-section',

  /** @description textbox 'Дата оплаты (не позднее)' */
  datePayment: 'date-payment',

  /** @description textbox 'Дата начала действия страхования' */
  insuranceStartDate: 'date-start',

  /** @description checkbox 'Плательщик совпадает со страхователем' */
  policyHolderAsPayer: 'payer-policyholder',

  /** @description combobox 'Способ уведомления' */
  paymentNotificationMethod: 'notification-method',

  /** @description textbox 'E-mail плательщика' */
  payerEmail: 'payer-email',

  /** @description id секции "График платежей"' */
  paymentPlan: 'payment-info',

  /** @description id секции "Поступление взносов"' */
  paymentsReceived: 'payments-received-section',

  /** @description групповой id секции "УРОВЕНЬ СОГЛАСОВАНИЯ ДОГОВОРА"' и "РУЧНОЙ БИЗНЕС-ЦИКЛ СОГЛАСОВАНИЯ (ДОПОЛНИТЕЛЬНО)"' */
  underwritingLevel: 'SBUnderwriting-underwriting',

  /** @description id секции "РУЧНОЙ БИЗНЕС-ЦИКЛ СОГЛАСОВАНИЯ (ДОПОЛНИТЕЛЬНО)"' */
  manualUnderwritingCycle: 'manual-underwriting-cycle',
  /*-----------------------------------------------------------------------Селекторы вкладки "Триггеры и комментарии"-------------------------------------------------------*/

  /*-------------------------Селекторы блока "Комментарии" */
  sectionComment: 'comments-section',

  /*-------------------------Селекторы блока "Андер- триггеры" */

  /** @description id секции "Андер- триггеры"' */
  sectionConstraintsUW: 'ConstraintsViewUW',

  /** @description id секции "Андер- триггеры"' */
  constraintsOther: 'constraints-section-other',

  /** @description id секции "ПЕРЕСТРАХОВАНИЕ"' */
  reInsurance: 're-insurance',
}

// export const selectorContractBuildbng = {
//   /*-----------------------------------------------------------------------Селекторы вкладки "Параметры объекта"-------------------------------------------------------*/

//   /*-----------------------------------------------------------------------Селекторы вкладок документа-------------------------------------------------------*/

//   /** @description  id вкладки "Параметры объекта" */
//   tabBuildingsStructures: 'buildings-structures-nav',

//   /** @description  id вкладки "Осмотр и оценка" */
//   tabBuildinginspection: 'inspection-nav',

//   /*-------------------------Селекторы блока "Строения и сооружения" */

//   /** @description id секции "Строения и сооружения"' */
//   buildingsStructures: 'buildingsp-structures-section',

//   /*-------------------------Селекторы блока "Осмотр и оценка" */

//   /** @description id секции "Осмотр и фотографирование"' */
//   inspectionPhoto: 'SBInspectionPhoto-inspectionPhoto',
// }
