import { test, expect } from '@playwright/test'

export class LoginPage {
  constructor(page) {
    this.page = page
    this.enterButton = page.getByTestId('enter-button')
    this.wait = page.waitForTimeout(1000)
    this.userName = page.getByTestId('Username')
    this.password = page.getByTestId('Password')
    this.loginType = page.getByTestId('login-type-adinsure')
    this.loginButton = page.getByTestId('login-button')
    this.logoutButton = page.locator('div.ai-header-position').getByRole('button').first()
  }

  //    async ADI_2607 (Username, Password) {
  //     await test.step('Логинизация', async () => {
  //       await this.page.goto('https://stage.adinsure.sogaz.ru/entry')
  //       await this.page.enterButton.click()
  //       await this.page.waitForTimeout(2500)
  //       await this.page.getByTestId('Username').fill(Username)
  //       await this.page.getByTestId('Password').fill(Password)
  //       await this.page.getByTestId('login-type-adinsure').click()
  //       await this.page.getByTestId('login-button').click()
  //     })

  /**
   * Авторизация без ключа
   * @param url url адрес
   * @param profile Имя профиля из файла users.json
   */
  async login(url, profile) {
    await test.step('Авторизация', async () => {
      await this.page.goto(url)
      await this.enterButton.click()
      await this.wait
      await this.userName.fill(profile.username)
      await this.password.fill(profile.password)
      await this.loginType.check()
      await this.loginButton.click()
    })
  }

  /**
   * Авторизация без ключа с предварительным логаутом
   * @param url url адрес
   * @param profile Имя профиля из файла users.json
   */
  async login_logout(url, profile) {
    await test.step('Авторизация', async () => {
      await this.logoutButton.isVisible({ timeout: 3000 })
      try {
        await this.logoutButton.click()
      } catch (error) {
        await this.logoutButton.click()
        // getByRole('button', { name: 'Добрый день, Мотникова Ирина Сергеевна ' })
      }
      await expect(this.page.locator('div.dropdown-menu').getByRole('button', { name: ' Выйти' })).toBeVisible()
      await this.page.locator('div.dropdown-menu').getByRole('button', { name: ' Выйти' }).click()
      expect(this.page.locator('div a.PostLogoutRedirectUri')).toBeVisible()
      await this.page.locator('div a.PostLogoutRedirectUri').click()
      await this.page.goto(url)
      await this.enterButton.click()
      await this.userName.fill(profile.username)
      await this.password.fill(profile.password)
      await this.loginType.check()
      await this.loginButton.click()
    })
  }
}
