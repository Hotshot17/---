// @ts-check

import { request } from '@playwright/test'

export class AADocumentSearchPage {
  constructor(page) {
    this.page = page

    this.businessNumber = page.locator('app-text-input').filter({ hasText: 'Бизнес номер' }).getByRole('textbox')
    this.documentCode = page.locator('app-text-input').filter({ hasText: 'Номер' }).nth(1).getByRole('textbox')
    this.documentType = page.getByRole('combobox').first()
    this.documentSubType = page.getByRole('combobox').nth(1)
    this.id = page.locator('app-text-input').filter({ hasText: 'Тех. ID' }).getByRole('textbox')

    this.searchButtonInForm = page.getByRole('button', { name: ' Поиск' })
    this.selectButtonInForm = page.getByRole('button', { name: ' Выбрать' })

    this.agentName = page.locator('app-text-input').filter({ hasText: 'Агент' }).getByRole('textbox').first()
    this.agentSearchButton = page.getByRole('button', { name: '' }).first()
    this.agentNameFieldInForm = page.getByTestId('agent-search-input').getByRole('textbox')

    this.orgUnitName = page.locator('app-text-input').filter({ hasText: 'Орг. структура' }).getByRole('textbox')
    this.orgUnitSearchButton = page.getByRole('button', { name: '' }).nth(2)
    this.orgUnitNameFieldInForm = page.getByTestId('lookup-param-section').getByRole('textbox').first()

    this.documentState = page.getByRole('combobox').nth(4)

    this.createdDateFrom = page.locator('[id="-input"]').first()
    this.createdDateTo = page.locator('[id="-input"]').nth(1)

    this.conclusionDateFrom = page.locator('[id="-input"]').nth(2)
    this.conclusionDateTo = page.locator('[id="-input"]').nth(3)

    this.cancellationDateFrom = page.locator('[id="-input"]').nth(4)
    this.cancellationDateTo = page.locator('[id="-input"]').nth(5)

    this.id1c = page.locator('app-text-input').filter({ hasText: '1С ID АД' }).getByRole('textbox')
    this.searchButton = page.getByRole('button', { name: ' Поиск' })
    this.clearButton = page.getByRole('button', { name: ' Очистить' })

    // Элементы таблицы с результатами поиска
    this.emptyResultTable = page.getByRole('row').nth(1)
    this.docNumberTable = page.locator('td:nth-child(1)')
    this.agentNameTable = page.locator('td:nth-child(2)')
    this.businessNumberTable = page.locator('td:nth-child(4)')
    this.documentTypeTable = page.locator('td:nth-child(14)')
    this.orgUnitNameTable = page.locator('td:nth-child(7)')
  }

  async getPath(rowName) {
    const result = await this.page.getByRole('row', { name: rowName }).getByRole('link').getAttribute('href')
    return result
  }

  async getPagesCount() {
    const pageNumberFieldContent = (await this.page.getByTestId('-paginator-result').textContent()).split('(')
    const count = pageNumberFieldContent[1].split(')')
    return parseInt(count[0])
  }

  async selectValueCombobox(nameValue) {
    await this.page.getByRole('option', { name: nameValue }).click()
  }

  async selectRow(rowName) {
    await this.page.getByRole('row', { name: rowName }).getByRole('checkbox').check()
  }

  async goToFoundDocuments(docNumber, baseUrl) {
    const path = await this.page
      .getByRole('row', { name: docNumber })
      .getByRole('cell')
      .first()
      .getByRole('link')
      .getAttribute('href')
    const link = baseUrl + path
    await this.page.goto(link)
  }

  async checkTableData(nameParam, columnLocator) {
    await this.page.waitForTimeout(2000)

    let checkResult = true
    let countResultPage
    const allSearchCountResult = await this.getPagesCount()
    console.log(await this.getPagesCount())
    await this.page.locator('#page-sizes span').nth(2).click()
    await this.page.getByRole('option', { name: '15' }).click()

    do {
      if (checkResult === true) {
        const bnArray = await columnLocator.allInnerTexts()

        if (bnArray.length > 0) {
          for (let i = 0; i < bnArray.length; i++) {
            if (bnArray[i] !== nameParam) {
              let row = i + 1

              console.log(`Строка таблицы №${row} содержит значение: ${bnArray[i]}`)
              console.log(`Ожидаемый результат: ${nameParam}`)
              checkResult = false
              break
            }
          }
        } else {
          console.log()
          console.log('!!!!* Массив пустой *!!!!')
          checkResult = false
          break
        }

        const numberPageField = (await this.page.getByTestId('-paginator-result').textContent()).split(' ')
        countResultPage = numberPageField[2].split('-')
        countResultPage = parseInt(countResultPage[1])

        if (countResultPage < allSearchCountResult) {
          await this.page.getByRole('button', { name: '' }).click()
        }
      } else {
        break
      }
    } while (countResultPage < allSearchCountResult)

    return checkResult
  }

  async getToken() {
    let response
    let token

    const context = await request.newContext()
    try {
      response = await context.post('https://stage.adinsure.sogaz.ru/auth/connect/token', {
        form: {
          grant_type: 'password',
          client_id: process.env.CLIENT_ID,
          client_secret: process.env.CLIENT_SECRET,
          username: 'Usova.Elena',
          password: 'Test_12345',
        },
      })

      const responseBody = await response.json()
      token = responseBody.access_token

      console.log(response.status() + ' ' + response.statusText())
    } catch {
      console.log('Запрос на получение токена')
      console.log('!!!* Потрачено *!!!')
      console.log(response)
    }
    return token
  }

  async checkAllResultValue(expectValueResponse, requestNameParam, responseNameParam, expectValueRequest) {
    let responseTable
    let result = true
    const context = await request.newContext()
    // console.log('Токен: ' + await this.getToken())

    try {
      responseTable = await context.post(
        'https://stage.adinsure.sogaz.ru/server/api/entity-infrastructure/shared/datasource/execute?configurationCodeName=AADocumentESDataSource',
        {
          headers: {
            Authorization: `Bearer ${await this.getToken()}`,
          },
          data: {
            data: {
              criteria: {
                [requestNameParam]: expectValueRequest,
              },
            },
            paging: {
              pageSize: 1500,
              page: 0,
            },
          },
        }
      )
      const responseBody2 = await responseTable.json()
      const resultCount = responseBody2.paging.numberOfResults
      console.log(`Количество элементов (${responseNameParam}) в результах поиска:  ${resultCount}`)

      for (let i = 0; i < resultCount; i++) {
        if (expectValueResponse != responseBody2.data[i].resultData[responseNameParam]) {
          console.log(responseBody2.data[i].resultData[responseNameParam])
          result = false
          break
        }
      }
    } catch {
      console.log('Запрос на получение результов поиска')
      console.log('!!!!* Потрачено *!!!!')
      console.log(responseTable)
    }
    return result
  }

  async checkResultDate(expectValue, requestNameParam, responseNameParam, compare) {
    let result = true

    const context = await request.newContext()

    /**
     *
     * @param dateConv
     */
    function dateConvert(dateConv) {
      const day = String(dateConv).slice(0, 2)
      const month = String(dateConv).slice(3, 5)
      const years = String(dateConv).slice(6, 10)

      const date = `${years}-${month}-${day}`

      const date2 = new Date(date)

      return date2
    }

    const responseTable = await context.post(
      'https://stage.adinsure.sogaz.ru/server/api/entity-infrastructure/shared/datasource/execute?configurationCodeName=AADocumentESDataSource',
      {
        headers: {
          Authorization: `Bearer ${await this.getToken()}`,
        },
        data: {
          data: {
            criteria: {
              [requestNameParam]: dateConvert(expectValue).toISOString().slice(0, 10),
            },
          },
          paging: {
            pageSize: 1500,
            page: 0,
          },
        },
      }
    )

    const responseBody2 = await responseTable.json()
    const resultCount = responseBody2.paging.numberOfResults
    console.log(`Количество элементов (${responseNameParam}) в результах поиска:  ${resultCount}`)
    for (let i = 0; i < resultCount; i++) {
      const expectData = dateConvert(expectValue)

      const actualData = new Date(responseBody2.data[i].resultData[responseNameParam])

      if (compare == '>=' || compare == '<=') {
        if (compare == '>=') {
          result = actualData.getTime() >= expectData.getTime()
          if (result === false) {
            console.log(
              '\u001b[41m',
              `!!!!* Значение в поисковой выдаче не соответствует ожидаемому: ${actualData}*!!!!`
            )
            break
          }
        }
        if (compare == '<=') {
          result = actualData.getTime() <= expectData.getTime()
          if (result === false) {
            console.log(
              '\u001b[41m',
              `!!!!* Значение в поисковой выдаче не соответствует ожидаемому: ${actualData}*!!!!`
            )
            break
          }
        }
      } else {
        console.log()
        console.log('\u001b[41m', 'Добавь оператор сравнения ( >= или <= )')
        result = false
        break
      }
    }

    return result
  }

  async checkAllResultValue2(expectValueResponse, requestNameParam, responseNameParam, expectValueRequest) {
    let responseTable
    let result = true
    const context = await request.newContext()

    try {
      responseTable = await context.post(
        'https://stage.adinsure.sogaz.ru/server/api/entity-infrastructure/shared/datasource/execute?configurationCodeName=AADocumentESDataSource',
        {
          headers: {
            Authorization: `Bearer ${await this.getToken()}`,
          },
          data: {
            data: {
              criteria: {
                [requestNameParam]: expectValueRequest,
              },
            },
            paging: {
              pageSize: 1500,
              page: 0,
            },
          },
        }
      )
      const responseBody2 = await responseTable.json()
      const resultCount = responseBody2.paging.numberOfResults
      console.log(`Количество элементов (${responseNameParam}) в результах поиска:  ${resultCount}`)
      // console.log(responseBody2)
      // console.log('Это  первый элемент массива: ' + responseBody2.data[0].resultData.businessNumber)

      for (let i = 0; i < resultCount; i++) {
        if (expectValueResponse != responseBody2.data[i].resultData[responseNameParam]) {
          console.log(responseBody2.data[i].resultData[responseNameParam])
          result = false
          break
        }
      }
    } catch {
      console.log('Запрос на получение результов поиска')
      console.log('!!!!* Потрачено *!!!!')
      console.log(responseTable)
    }
    return result
  }
}
