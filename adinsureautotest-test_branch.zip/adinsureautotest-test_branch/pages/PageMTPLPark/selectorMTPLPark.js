// @ts-check

const application = {}
const quote = {
  /** users / password / Baseurl*/
  Bolotova: 'Bolotova.Irina',

  Password: 'Test_12345',

  /** страхователь/агент/посредник */
  ЮНИТРАНС: 'ООО "ЮНИТРАНС"',
  Детенышева: 'Детенышева Ольга Александровна',
  фамилияЯшин: 'Яшин',
  имяЯшин: 'Андрей',
  отчествоЯшин: 'Геннадьевич',
  фамилияЩербаченко: 'Щербаченко',
  имяЩербаченко: 'Андрей',
  отчествоЩербаченко: 'Владимирович',

  /** код страхователя/агента/посредника */
  кодЮНИТРАНС: '2935875',
  кодДетенышева: '721437',
  кодЯшин: '2837826',
  кодЩербаченко: '1437866',

  /** боковое меню */
  Contracts: 'Contracts_menu_1',
  MTPL: 'MTPL_1_2',
  MTPLParkQuote: 'MTPLParkQuote_1_3',

  /** боковое меню - Общая информация */
  ContractNumberLink: 'contract-number-link',

  /** Вкладки  */
  PolicyConditions: 'tab-Policy-conditions-nav',
  VehicleData: 'tab-Vehicle-data-nav',
  Attachments: 'tab-attachments-nav',
  PaymentPlan: 'tab-Payment-plan-nav',
  AttachedDocuments: 'tab-Attached-documents-nav',

  /**Блок Policy conditions */
  parkSizeManual: 'park-size-manual',
  PolicyHolder: 'select-policyholder',
  agentFullName: 'agent-search-dialog-button',

  /** Блок Vehicle data */
  LastName: 'party-last-name',
  firstName: 'party-first-name',
  middleName: 'party-middle-name',
  parkIsIndividualList: 'park-individual-list',
  policyNumber: 'park-data-table',

  /** links */
  baseUrl: 'https://stage.adinsure.sogaz.ru',
  recentDocuments: '/server/api/shell/internal/documents/recent-documents/',
  MTPLParkQuoteVehiclesImport:
    '/server/api/configurator/shared/runtime/document/document-form/ru-RU/MTPLParkQuoteVehiclesImport/1',
  files: 'https://stage.adinsure.sogaz.ru/server/api/document-management/public/files',
  loading: '/server/api/core/public/import-documents/get-initial-view-model',
  fileTest: './fixtures/testDataSuite/MTPL/test.pdf',
  Attached: '/server/api/entity-infrastructure/shared/datasource/ExtendedDocumentAttachmentsDataSource',

  /** Кнопки */
  Search: 'Поиск',
  Select: 'Выбрать',
  Save: 'Сохранить',
  Add: 'Добавить',
  ok: 'OK',
  Close: 'Закрыть',
  importVehicle: 'ai-transitions-relations-control-MTPLParkQuoteImportVehicles',
  startLoading: 'ai-transitions-relations-control-StartLoading',
  startImporting: 'ai-transitions-relations-control-StartImporting',
  driversEditing: 'ai-transitions-relations-control-Draft_to_DriversEditing',
  editDrivers: 'Редактирование водителей',
  DriversEditingToDraft: 'ai-transitions-relations-control-DriversEditing_to_Draft',
  waitingForKBM: 'ai-transitions-relations-control-Draft_to_WaitingForKBM',
  PremiumCalculating: 'ai-transitions-relations-control-Draft_to_PremiumCalculating',
  WaitingForRedirector: 'ai-transitions-relations-control-Draft_to_WaitingForRedirector',
  quotePrinting: 'ai-transitions-relations-control-RSAProjectCheckPassed_to_QuotePrinting',
  QuotePrintingToFinished: 'ai-transitions-relations-control-QuotePrinting_to_Finished',

  /** Заголовки */
  VehiclesImport: 'Загрузка списка транспортных средств',
  importVehicleStatus: 'Новый',
  Loaded: 'Загружено',
  Imported: 'Импортировано',
  MtplParkQuote: 'Котировка Парк',
  DriversEditing: 'Редактирование атрибутов',
  Draft: 'Новая',
  RSAProjectCheckPassed: 'Проект полиса сформирован (РСА)',
  QuotePrinting: 'Печать заявления',
  Finished: 'Выпущена',

  /** Документы */
  T5395: 'ADI-T5395.xlsx',
  vin1: 'JTEBR3FJ40K070844',
  vin2: 'JTHB11B1X02002682',
  example1: 'Пример 1',
  example2: 'пример 2',
  test: 'test.pdf',
  vehicleDocAttach: 'Документ ТС',

  /** Вложения */

  /** id field Выбор файла */
  inputFile: "input[type='file']",
  AttachmentType: 'attachment-type',

  /** id combobox Тип БСО */
  bsoType: 'bso-type-ng-select',

  /** id field VIN */
  vin: 'vin',

  /** id checbox VIN идентифицирован */
  vinIdentified: 'vin-identified',

  /** id текстовое поле Номер кузова */
  bodyNumber: 'body-number',

  /** id combobox Марка */
  make: 'make-ng-select',

  /** id combobox Модель */
  model: 'model-ng-select',

  /** id combobox Год выпуска */
  productionYear: 'production-year-ng-select',

  /** id combobox Тип ТС */
  vehicleType: 'vehicle-type-ng-select',

  /** id combobox Категория ТС */
  vehicleCategory: 'vehicle-category-ng-select',

  /** id combobox Мощность, л.с. */
  power: 'power-hp-ng-select',

  /** id field Код модификации */
  modificationCode: 'modification-code',

  /** id field Модификация */
  modificationName: 'modification-name',

  /** id field Код РСА */
  rsaCode: 'rsa-code',

  /** id field Модификация (комбобокс) */
  modificationNameComboBox: '-ng-select', // кривой id у элемента, но работает

  /** id combobox Цель использования */
  usagePurpose: 'usage-purpose-ng-select',

  /** id combobox Лица, допущенные к управлению */
  allowedInput: 'allowed-input-ng-select',
  people: 'allowed-input',
  listOfDrivers: 'Ограниченный список',
  лица: 'Любые лица',

  /** id строки в таблице Данные о лицах, допущенных к управлению */
  driversListRow: 'drivers-list-row',

  /** id field Пробег, км */
  mileage: 'mileage-input',

  /** id combobox Тип документа ТС */
  vehicleDocType: 'vehicle-doc-type-ng-select',

  /** id field Серия документа ТС */
  vehicleDocSeries: 'vehicle-doc-series',

  /** id field Номер документа ТС */
  vehicleDocNumber: 'vehicle-doc-number',

  /** id field Дата выдачи документа ТС */
  vehicleDocDate: 'vehicle-doc-date-input',

  /** id field Премия */
  calculatedPremium: 'calculated-premium-input',

  /** id field Базовый тариф */
  baseTariff: 'base-tariff-input',

  /** id field КБМ */
  kbm: 'kbm-input',

  /** id field КВС */
  kvs: 'kvs-input',

  /** id field КМ */
  km: 'km-input',

  /** id field КО */
  ko: 'ko-input',

  /** id field КП */
  kp: 'kp-input',

  /** id field КС */
  ks: 'ks-input',

  /** id field КТ */
  kt: 'kt-input',

  /** id table Таблица с триггерами */
  triggersList: 'triggers-list',

  /** id field Комментарий (для андеррайтера) */
  commentArea: 'comment-area',

  /** id table Таблица с комментариями (для андеррайтера) */
  conclusionTable: 'conclusion-table',
}

const policy = {
  /** id combobox Способ оплаты */
  paymentMethod: 'payment-method',
  invoice: 'Безналичная оплата по выставленному счету на р/сч СОГАЗ',
  paymentForm: 'payment-form',
  prepayment: 'Предоплата',
  attachedDoc: 'Платёжный документ',

  /** id field Способ оплаты */
  paymentDocumentNumber: 'payment-document-number',

  /** id field Способ оплаты */
  paymentDocumentDate: 'payment-section',
}

export { application, quote, policy }
