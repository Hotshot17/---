const TravelInsurance = {
  /** @description Combobox 'Вариант продукта' */
  product_type: 'product-type',
  /** @description Combobox 'Программа страхования' */
  insurance_programme: 'insurance-programme',
  /** @description Combobox 'Направление поездки' */
  travelDestination: 'travelDestination',
  /** @description Label 'Дата окончания поездки' */
  travel_start_date_input: '#travel-start-date-input',
  /** @description Checkbox 'Многократная поездка' */
  input_data: 'input-data',
  /** @description Label 'Возраст туриста' */
  list_age_traveler_input: 'list-age-traveler-input',
  /** @description Combobox 'Активные виды отдыха и спорта' */
  activity: 'activity',
  /** @description Combobox 'Дополнительные опции' */
  otherOptionsElement: 'otherOptionsElement',
  /** @description Combobox 'Страховая сумма' */
  medical_expenses_sum: 'medical-expenses-sum',
  /** @description Combobox 'Валюта' */
  medicalExpensesCurrency: 'medicalExpensesCurrency',
  /** @description Lable 'Период действия полиса (мес)' */
  policy_duration_input: 'policy-duration-input',
  /** @description Combobox 'Цель поездки' */
  gi_trip_purpose_ng_select: 'gi-trip-purpose-ng-select',
  /** @description Checkbox 'Указать страны транзита' */
  tc_transit_country_check: 'tc-transit-country-check',
  /** @description Combobox 'Формулировка в особых условиях (Эпидемия)' */
  otherFormulationEpidemic: 'otherFormulationEpidemic',
  /** @description Combobox 'Способ оплаты' */
  input_paymentMethod: 'input-paymentMethod',
  /** @description Combobox 'Порядок оплаты премии' */
  input_paymentFrequency: 'input-paymentFrequency',
  /** @description Combobox 'Валюта' */
  input_paymentCurrency: 'input-paymentCurrency',
  /** @description Checkbox 'Плательщик совпадает со страхователем' */
  input_policyHolderAsPayer: 'input-policyHolderAsPayer',
  /** @description Combobox 'Способ оплаты' */
  input_paymentNotificationMethod: 'input-paymentNotificationMethod',
  /** @description Checkbox 'С Ключевым информационным документом ознакомлен' */
  input_aknowledgeKID: 'input-aknowledgeKID',
  /** @description Checkbox 'Получить полис на e-mail после оплаты' */
  input_getPolicyOnEmail: 'input-getPolicyOnEmail',
  /** @description Checkbox 'Согласие на информационную рассылку' */
  input_agreeToInfoLetter: 'input-agreeToInfoLetter',
  /** @description Button 'Кнопка поиск с значком лупа' */
  btn_policy_holder_search: 'btn-policy-holder-search',
  /** @description Combobox 'Поиск контрагента в системах' */
  system_selection_dropdown: 'system-selection-dropdown',
  /** @description Lable 'Фмилия' */
  party_last_name: 'party-last-name',
  /** @description Lable 'Имя' */
  party_first_name: 'party-first-name',
  /** @description Lable 'Отчество' */
  party_middle_name: 'party-middle-name',
  /** @description Checkbox 'Зона военных действий */
  warZone: 'warZone',
  /** @description Кнопка 'Больше'  */
  result_data_table_trip_program: 'result-data-table-trip-program',
  /** @description Combobox 'Активные виды отдыха и спорта' */
  activity_ng_select: 'activity-ng-select',
  /** @description Checkbox 'Отмена поездки' */
  travelCancellationCheckBox: 'travelCancellationCheckBox',
  /** @description Отмена поездки. Сумма*/
  travel_cancellation_sum: 'travel-cancellation-sum',
  /** @description Checkbox 'Мед.расходы' */
  medicalExpensesCheckBox: 'medicalExpensesCheckBox',
  /** @description Combobox 'Вариант страхования' */
  travelCancellationInsuranceType_ng_select: 'travelCancellationInsuranceType-ng-select',
  /**@description  Combobox 'Дата рождения' */
  датаРождения: 'party-birthday-input',
}

export { TravelInsurance }

export const selectorTravelInsurance = {
  /*-----------------------------------------------------------------------Селекторы элементов главного меню-------------------------------------------------------*/
  /** @description Папка  "Страховые продукты"' */
  contractsMenu: 'Contracts_menu_1',

  /** @description Папка  продукта "ВПМЖ"' */
  travelInsurance: 'TravelInsurance_1_2',

  /** @description Элемент создания документа "Предрасчет"' */
  travelApplication: 'TravelApplication_1_3',

  /** @description Элемент создания документа "Котировка"' */
  travelQuote: 'TravelQuote_1_3',

  /*-----------------------------------------------------------------------Селекторы элементов бокового информационного меню(сайдбар)-------------------------------------------------------*/

  /*-----------------------------------------------------------------------Селекторы вкладок документа-------------------------------------------------------*/
  /** @description  id вкладки "Данные о застрахованных лицах" */
  insuredPersonsTab: 'Tab-InsuredPersons-nav',

  /** @description  id вкладки "Общая информация" */
  generalInformationTab: 'Tab-GeneralInformation-nav',

  // /** @description  id вкладки "Параметры объекта" */
  // objectParameters: 'tab-Object-nav',

  /** @description  id вкладки "Андеррайтинг" */
  underwritingTab: 'tab-underwriting-nav',

  /** @description  id вкладки "График платежей и оплата" */
  paymentDataTab: 'tab-paymentData-nav',

  // /** @description  id вкладки "Вложения" */
  // attachedDocuments: 'tab-Attached-documents-nav',

  // /** @description  id вкладки "Выпуск договора" */
  // policyIssue: 'policy-issue-nav',

  // /** @description  id вкладки "Триггеры и комментарии" */
  // constraintsCommentsNav: 'constraints-comments-nav',

  // /** @description  id вкладки "История документа" */
  // contractActivityAndTransitionHistory: 'tab-Contract-activity-nav',
  /*-----------------------------------------------------------------------Селекторы вкладок инфоменю-------------------------------------------------------*/
  // /** @description  id вкладки "Общая информация" */
  // tabSummary: 'tab-Summary-nav',

  // /** @description  id вкладки "Проверки и ошибки" */
  // tabNotification: 'tab-Notifications-nav',

  // /** @description  id вкладки "Всего проблем" */
  // validations: 'RequiredPropertiesValidations',

  // /** @description  id поля "Премия, руб" */
  // premiumRubles: 'premium-rubles',

  /*-----------------------------------------------------------------------Селекторы инфоменю-------------------------------------------------------*/
  /** @description "КВ (общ, у.е.)" */
  infoAgentTotalPremium: 'summary-agentTotalPremium',

  /** @description "КВ (общ, руб)" */
  infoAgentTotalPremiumRUB: 'summary-agentTotalPremiumRUB',

  /** @description "КВ (общ, руб)" */
  infoSummaryPremiumRUB: 'summary-premiumRUB',

  /*-----------------------------------------------------------------------Селекторы вкладок Витрины задач-------------------------------------------------------*/
  /** @description  id вкладки "Задачи группы" */
  tabGroupTasks: 'tab-Group-tasks-nav',

  /*-----------------------------------------------------------------------Селекторы списка действий документа-------------------------------------------------------*/

  // /** @description Button 'Кнопка действия "К оплате"' */
  // approvedToPaymentWaiting: 'ai-transitions-relations-control-Approved_to_PaymentWaiting',

  /** @description Button 'Кнопка действия "Отказаться от оформления"' */
  draftToAnnulled: 'ai-transitions-relations-control-Draft_to_Annulled',

  /** @description Button 'Кнопка действия "Отказаться от оформления"' */
  copyTravelQuote: 'ai-transitions-relations-control-CopyTravelQuote',

  // /** @description Button 'Кнопка действия "Копировать документ"' */
  // copyAccidentPolicy: 'ai-transitions-relations-control-CopyAccidentPolicy',

  // /** @description Button 'Кнопка действия "Вернуть на предыдущий статус"' */
  // annulledSendToHigherLevel: 'ai-transitions-relations-control-Annulled_SendToHigherLevel',

  // /** @description Button 'Кнопка действия "Вернуть на редактирование"' */
  // paymentWaitingSendToLowerLevel: 'ai-transitions-relations-control-PaymentWaiting_SendToLowerLevel',

  /** @description Button 'Кнопка действия "Создать котировку"' */
  createTravelQuote: 'ai-transitions-relations-control-CreateTravelQuote',

  /** @description Button 'Кнопка действия "Создать договор"' */
  createTravelPolicy: 'ai-transitions-relations-control-CreateTravelPolicy',

  /** @description Button 'Кнопка действия "К оплате"' */
  draftToPaymentWaiting: 'ai-transitions-relations-control-Draft_to_PaymentWaiting',

  /** @description Button 'Кнопка действия Оформить договор"' */
  paymentWaitingToActivatedGroup: 'ai-transitions-relations-control-PaymentWaiting_to_ActivatedGroup',

  /** @description Button 'Кнопка действия "Направить на согласование"' */
  draftSendToHigherLevel: 'ai-transitions-relations-control-Draft_SendToHigherLevel',

  /** @description Button 'Кнопка действия "Направить на согласование (Уровень 3)"' */
  controlUW2ToUW3: 'ai-transitions-relations-control-UW2_to_UW3',

  /** @description Button 'Кнопка действия "Оформление особых условий"' */
  controlUW2ToSpecialConditions: 'ai-transitions-relations-control-UW2_to_SpecialConditions',

  // /** @description Button 'Кнопка действия "Оформить"' */
  // paymentWaitingToActivated: 'ai-transitions-relations-control-PaymentWaiting_to_Activated',

  /** @description Button 'Кнопка действия "Согласовать"' */
  uw2ToApproved: 'ai-transitions-relations-control-UW2_to_Approved',

  /** @description Button 'Кнопка действия "Согласовать Ур3"' */
  uw3ToApproved: 'ai-transitions-relations-control-UW3_to_Approved',

  /*-----------------------------------------------------------------------Селекторы вкладки "Общая информация"-------------------------------------------------------*/

  /*-------------------------Селекторы блока "Общая информация" */

  /** @description id textbox "Дата создания" */
  giCreateDate: 'gi-create-date',

  /** @description id textbox "Сервисная комания" */
  giServiceCompany: 'gi-service-company',

  /** @description id textbox "Порядок оплаты" */
  giPaymentFrequency: 'gi-payment-frequency',

  /** @description id checkbox "Дата создания" */
  giWorkingConditionsDangerous: 'gi-working-conditions-dangerous',

  /*-------------------------Селекторы блока "Условия и срок страхования" */

  /** @description id секции "Условия и срок страхования" */
  tcTermsAndConditionsSection: 'tc-terms-and-conditions',

  /** @description combobox "Вариант продукта" */
  productType: 'product-type',

  /** @description combobox "Программа страхования" */
  insuranceProgramme: 'insurance-programme',

  /** @description checkBox "Многократная поездка" */
  inputData: 'input-data',

  /** @description combobox "Направление поездки" */
  travelDestination: 'travelDestination',

  /** @description combobox "Страны поездки" */
  travelCountries: 'travelCountries',

  /** @description combobox "Территории" */
  travelTerritories: 'travelTerritories',

  /** @description textbox 'Дата начала поездки' */
  travelStartDate: 'travel-start-date',

  // /** @description textbox 'Дата окончания поездки' */
  // travelEndDate: '',

  /** @description textbox 'Продолжительность поездки (в днях)' */
  travelDuration: 'travel-duration',

  /** @description Lable 'Период действия полиса (мес)' */
  policyDurationInput: 'policy-duration',

  /** @description Lable 'Продолжительность каждой поездки (в днях)' */
  tripsDurationDay: 'trips-duration-day',

  /** @description combobox 'Кол-во поездок' */
  policyDurationCombobox: 'policy-duration',

  /** @description textbox 'Возраст туриста' */
  listAgeTraveler: 'list-age-traveler',

  /** @description combobox 'Активные виды отдыха и спорта' */
  activity: 'activity',

  /** @description combobox 'Профессиональный спорт' */
  activityProSport: 'TravelActivityProSelection-activityProSport',

  /** @description button 'active' */
  buttonActive: 'buttonActive',

  /** @description button 'active' */
  buttonSport1: 'buttonSport1',

  /** @description button 'active' */
  buttonSport2: 'buttonSport2',

  /** @description button 'active' */
  buttonSport3: 'buttonSport3',

  /** @description button 'active' */
  buttonSport4: 'buttonSport4',

  /** @description button 'active' */
  buttonSport5: 'buttonSport5',

  /** @description combobox 'Дополнительные опции' */
  otherOptionsElement: 'otherOptionsElement',

  /** @description checkBox "Зона военных действий" */
  warZone: 'warZone',

  /** @description checkBox 'Указать страны транзита' */
  tcTransitCountryCheck: 'tc-transit-country-check',

  /** @description checkBox 'Включить ПМЖ (для РФ)' */
  includePermanentResidence: 'includePermanentResidence',

  /** @description textbox 'Cтраны транзита' */
  transitCountryElement: 'transitCountryElement',

  /*-------------------------Селекторы блока "Страхователь" */

  /** @description id кнопки поиска страхователя (лупа) */
  policyHolderSearchButton: 'btn-policy-holder-search',

  /*-------------------------Селекторы блока "Объем услуг" */

  /** @description id секции "Объем услуг" */
  travelScopeSection: 'TravelScope-#',

  /** @description Checkbox 'Мед.расходы' */
  medicalExpensesCheckBox: 'medicalExpensesCheckBox',

  /** @description textbox "Страховая сумма. Мед.расходы" */
  medicalExpensesSum: 'medical-expenses-sum-ng-select',

  /** @description combobox "Валюта. Мед.расходы" */
  medicalExpensesCurrency: 'medicalExpensesCurrency-ng-select',

  /** @description checkbox "Несчастный случай" */
  accidentCheckBox: 'accidentCheckBox',

  /** @description textbox "Страховая сумма. Несчастный случай" */
  accidentSum: 'accident-sum-ng-select',

  /** @description combobox "Валюта. Несчастный случай" */
  accidentCurrency: 'accidentCurrency-ng-select',

  /** @description Checkbox "Отмена поездки" */
  travelCancellationCheckbox: 'travelCancellationCheckBox',

  /** @description textbox "Страховая сумма. Отмена поездки" */
  travelCancellationSum: 'travel-cancellation-sum',

  /** @description combobox "Валюта. Отмена поездки" */
  travelCancellationCurrency: 'travelCancellationCurrency-ng-select',

  /** @description Checkbox 'Гражданская ответственность' */
  civilResponsibilityCheckBox: 'civilResponsibilityCheckBox',

  /** @description textbox "Страховая сумма. Гражданская ответственность" */
  civilResponsibilitySum: 'civil-responsibility-sum-ng-select',

  /** @description combobox "Валюта. Гражданская ответственность" */
  civilResponsibilityCurrency: 'civilResponsibilityCurrency-ng-select',

  /** @description Checkbox 'Задержка или отмена рейса' */
  flightCancellationCheckBox: 'flightCancellationCheckBox',

  /** @description textbox "Страховая сумма. Задержка или отмена рейса" */
  flightCancellationSum: 'flight-cancellation-sum',

  /** @description combobox "Валюта. Задержка или отмена рейса" */
  flightCancellationCurrency: 'flightCancellationCurrency',

  /** @description Checkbox 'Страхование багажа' */
  baggageInsuranceCheckBox: 'baggageInsuranceCheckBox',

  /** @description textbox "Страховая сумма. Страхование багажа" */
  baggageCancellationSum: 'baggage-cancellation-sum',

  /** @description combobox "Валюта. Страхование багажа" */
  baggageInsuranceCurrency: 'baggageInsuranceCurrency',

  /** @description Combobox 'Формулировка в особых условиях (Эпидемия)' */
  otherFormulationEpidemic: 'otherFormulationEpidemic',

  /*-------------------------Селекторы блока "Характеристики риска. Отмена поездки" */

  /** @description id секции "Характеристики риска. Отмена поездки" */
  travelCancelationAttributesSection: 'section-travel-cancellation-attributes',

  /** @description combobox "Тип СС" */
  travelCancellationSumInsuredType: 'travelCancellationSumInsuredType',

  /** @description combobox "Пакет рисков" */
  travelCancellationRisksPackage: 'travelCancellationRisksPackage',

  /** @description combobox "Вариант страхования" */
  travelCancellationInsuranceType: 'travelCancellationInsuranceType',

  /** @description combobox "Организация поездки" */
  travelCancellationOrganization: 'travelCancellationOrganization',

  /*-------------------------Селекторы блока "Характеристики риска. Задержка или отмена рейса" */

  /** @description id секции "Характеристики риска. Задержка или отмена рейса" */
  sectionFlightCancellation: 'section-flight-cancellation',

  /** @description combobox "Тип СС" */
  flightCancellationSumInsuredType: 'flightCancellationSumInsuredType',

  /** @description combobox "Сервисная компания" */
  flightCancellationServiceCompany: 'flightCancellationServiceCompany',

  /** @description таблица последствий */
  flightCansellationConsequencesTable: 'table-flight-cansellation-consequences',

  /*-------------------------Селекторы блока "Характеристики риска. Страхование багажа" */

  /** @description id секции "Характеристики риска. Страхование багажа" */
  sectionBaggageCancellation: 'section-baggage-cancellation',

  /*-------------------------Селекторы блока "Лимиты ответственности" */

  /** @description id секции 'Лимиты ответственности' */
  liabilityLimitsSection: 'section-liability-limits',

  /** @description id таблицы 'Лимиты ответственности' */
  liabilityLimitsTable: 'table-liability-limits-table',

  /*-------------------------Селекторы блока "Орг. структура" */

  /** @description id секции (предрасчет) 'Орг. структура' */
  orgStructureSection: 'org-structure-section',

  /** @description id секции 'Орг. структура' */
  orgStructureSectionQuote: 'section-organisation-structure',

  /** @description id кнопки поиска менеджера договора (лупа) */
  policyManagerSearchButton: 'lookup-policy-manager-dialog-button',

  /*-------------------------Селекторы блока "Посредники и КВ" */

  /** @description id секции 'Посредники и КВ' */
  agentCommissionSection: 'agent-commission-section',

  /** @description id таблицы 'Таблица Посредники и КВ' */
  agentCommissionTable: 'agent-commission-table',

  /*-------------------------Селекторы блока "КВ для агента по программам" */

  /** @description id секции 'КВ для агента по программам' */
  agentCommissionDetailsSection: 'agent-commission-details-section',

  /*-------------------------Селекторы блока "Другие" */

  /** @description checkbox 'Особые условия' */
  specialConditionCheckbox: 'checkbox-special-condition-check',

  /** @description textarea 'Особые условия. Текст' */
  specialConditionValue: 'textarea-special-condition-value',

  /*-----------------------------------------------------------------------Селекторы вкладки "Данные о застрахованных лицах"-------------------------------------------------------*/

  /*--------------------------Селекторы блока "Страховые риски и покрытия"*/

  // /** @description combobox 'Способы установления страховых сумм' */
  // insuranceAmounts: 'sumInsured-type-ng-select',

  /*--------------------------Селекторы блока "Данные о застрахованных лицах"*/

  // /** @description button 'Поиск Застрахованного лица' */
  // personSearchButton: 'person-search-button',

  // /** @description link 'ФИО' */
  // personLink: 'person-link',

  /*-----------------------------------------------------------------------Селекторы вкладки "Андеррайтинг"-------------------------------------------------------*/

  /*--------------------------Селекторы блока "Особые условия"*/

  /** @description checkbox 'Редактировать особые условия' */
  editSpecialConditions: 'chb-edit-special-conditions',

  /** @description textbox 'Особые условия (русскоязычная версия)' */
  textareaSpecialConditionsRUS: 'textarea-special-conditionsRUS',

  /** @description textbox 'Особые условия (англоязычная версия)' */
  textareaSpecialConditionsENG: 'textarea-special-conditionsENG',

  /*--------------------------Селекторы блока "Особые условия"*/

  /** @description id секции 'Основные коэффициенты' */
  generalCoefficientsSection: 'TravelCoefficientsDataGrid-generalCoefficients',

  /*--------------------------Селекторы блока "Триггеры"*/

  /** @description id таблицы 'Основные коэффициенты' */
  triggerTable: 'ai-data-grid-table',

  /** @description id таблицы 'Медицинские расходы' */
  medCoefficientsTable: 'TravelCoefficientsDataGrid-coefficientsArray',

  /** @description id таблицы 'Последствия' */
  consequencesCoefficientsTable: 'TravelMedicalExpensesConsequencesDG-consequences',

  /** @description id таблицы 'Основные коэффициенты' */
  accidentCoefficientsTable: 'TravelCoefficientsDataGrid-coefficientsArray-1',

  /** @description id таблицы 'Основные коэффициенты' */
  accidentConsequencesCoefficientsTable: 'TravelAccidentConsequencesDG-consequences',

  /** @description id таблицы 'Основные коэффициенты' */
  civilRespCoefficientsTable: 'TravelCoefficientsDataGrid-coefficientsArray-2',

  /** @description id таблицы 'Основные коэффициенты' */
  civilRespConsequencesCoefficientsTable: 'TravelCivilResponsibilityConsequencesDG-consequences',

  /** @description id таблицы 'Отмена поездки' */
  travelCancelCoefficientsTable: 'TravelCoefficientsDataGrid-coefficientsArray-3',

  /** @description id таблицы 'Отмена поездки. Последствия' */
  travelCancelConsequencesCoefficientsTable: 'TravelTravelCancellationConsequencesDG-consequences',

  /** @description id таблицы 'Задержка или отмена рейса' */
  flightCancelCoefficientsTable: 'TravelCoefficientsDataGrid-coefficientsArray-4',

  /** @description id таблицы 'Задержка или отмена рейса. Последствия' */
  flightCancelConsequencesCoefficientsTable: 'TravelFlightCancellationConsequencesDG-consequences',

  /*-----------------------------------------------------------------------Селекторы вкладки "График платежей и оплата"-------------------------------------------------------*/

  /*--------------------------Селекторы блока "Плательщик"*/

  /** @description combobox 'Способ уведомления' */
  notificationMethod: 'input-paymentNotificationMethod',

  /*--------------------------Селекторы блока "Поступление взносов"*/

  /** @description Checkbox 'С Ключевым информационным документом ознакомлен' */
  inputAknowledgeKID: 'input-aknowledgeKID',

  // /** @description button 'Добавить взнос' */
  // addPaymentButton: 'PaymentDataGrid-add-button',

  // /** @description button 'ОК. Взносы' */
  // okPaymentButton: 'PaymentDataGrid-ok-button',

  /*-----------------------------------------------------------------------Селекторы вкладки "Триггеры и комментарии"-------------------------------------------------------*/

  /*--------------------------Селекторы блока "Триггеры"*/

  //   /** @description combobox 'Статус' */
  //   quoteState: 'quote-state',
}
// /** @description Combobox 'Вариант продукта' */
// this.product_type = 'product-type'
// /** @description Combobox 'Программа страхования' */
// this.insurance_programme = 'insurance-programme'
// /** @description Combobox 'Направление поездки' */
// this.travelDestination = 'travelDestination'
// /** @description Label 'Дата окончания поездки' */
// this.travel_start_date_input = '#travel-start-date-input'
// /** @description Checkbox 'Многократная поездка' */
// this.input_data = 'input-data'
// /** @description Label 'Возраст туриста' */
// this.list_age_traveler_input = 'list-age-traveler-input'
// /** @description Combobox 'Активные виды отдыха и спорта' */
// this.activity = 'activity'
// /** @description Combobox 'Дополнительные опции' */
// this.otherOptionsElement = 'otherOptionsElement'
// /** @description Combobox 'Страховая сумма' */
// this.medical_expenses_sum = 'medical-expenses-sum'
// /** @description Combobox 'Валюта' */
// this.medicalExpensesCurrency = 'medicalExpensesCurrency'
// /** @description Lable 'Период действия полиса (мес)' */
// this.policy_duration_input = 'policy-duration-input'
// /** @description Combobox 'Цель поездки' */
// this.gi_trip_purpose_ng_select = 'gi-trip-purpose-ng-select'
// /** @description Checkbox 'Указать страны транзита' */
// this.tc_transit_country_check = 'tc-transit-country-check'
// /** @description Combobox 'Формулировка в особых условиях (Эпидемия)' */
// this.otherFormulationEpidemic = 'otherFormulationEpidemic'
// /** @description Combobox 'Способ оплаты' */
// this.input_paymentMethod = 'input-paymentMethod'
// /** @description Combobox 'Порядок оплаты премии' */
// this.input_paymentFrequency = 'input-paymentFrequency'
// /** @description Combobox 'Валюта' */
// this.input_paymentCurrency = 'input-paymentCurrency'
// /** @description Checkbox 'Плательщик совпадает со страхователем' */
// this.input_policyHolderAsPayer = 'input-policyHolderAsPayer'
// /** @description Combobox 'Способ оплаты' */
// this.input_paymentNotificationMethod = 'input-paymentNotificationMethod'

// /** @description Checkbox 'Получить полис на e-mail после оплаты' */
// this.input_getPolicyOnEmail = 'input-getPolicyOnEmail'
// /** @description Checkbox 'Согласие на информационную рассылку' */
// this.input_agreeToInfoLetter = 'input-agreeToInfoLetter'
// /** @description Button 'Кнопка поиск с значком лупа' */
// this.btn_policy_holder_search = 'btn-policy-holder-search'
// /** @description Combobox 'Поиск контрагента в системах' */
// this.system_selection_dropdown = 'system-selection-dropdown'
// /** @description Lable 'Фмилия' */
// this.party_last_name = 'party-last-name'
// /** @description Lable 'Имя' */
// this.party_first_name = 'party-first-name'
// /** @description Lable 'Отчество' */
// this.party_middle_name = 'party-middle-name'
// /** @description Combobox 'Направление поездки' */
// this.travelDestination = 'travelDestination'
// /** @description Checkbox 'Указать страны транзита' */
// this.tc_transit_country_check = 'tc-transit-country-check'
// /** @description Checkbox 'Зона военных действий */
// this.warZone = 'warZone'
// /** @description Кнопка 'Больше'  */
// this.result_data_table_trip_program = 'result-data-table-trip-program'
// /** @description Combobox 'Активные виды отдыха и спорта' */
// this.activity_ng_select = 'activity-ng-select'
// /** @description Checkbox 'Отмена поездки' */
// this.travelCancellationCheckBox = 'travelCancellationCheckBox'
// /** @description */
// this.travel_cancellation_sum = 'travel-cancellation-sum'
// /** @description Checkbox 'Мед.расходы' */
// this.medicalExpensesCheckBox = 'medicalExpensesCheckBox'
// /** @description Checkbox 'Многократная поездка' */
// this.input_data = 'input-data'
// /** @description Checkbox 'Зона военных действий' */
// this.warZone = 'warZone'
// /** @description Combobox 'Вариант страхования' */
// this.travelCancellationInsuranceType_ng_select = 'travelCancellationInsuranceType-ng-select'
