export const selectorDoc = {
  /*-----------------------------------------------------------------------Селекторы элементов главного меню-------------------------------------------------------*/
  /** @description Папка  "Страховые продукты"' */
  contracts: 'Contracts_menu_1',

  /** @description Папка  продукта "Прочие продукты"' */
  otherProduct: 'Other_1_2',

  /** @description Элемент создания документа   "Договор"' */
  quotePdi: 'QuoteMP_3_3',

  /*-----------------------------------------------------------------------Селекторы вкладок документа-------------------------------------------------------*/
  /** @description  id вкладки "Условия страхования" */
  tabInsuranceConditions: 'tab-policyConditions-nav',

  /** @description  id вкладки "Андеррайтинг" */
  tabCalculations: 'tab-calculations-nav',

  /** @description  id вкладки "Договор" */
  policyInformation: 'tab-policyInformation-nav',

  /** @description  id вкладки "Параметры договора" */
  tabPolicyAttributes: 'tab-policy-attributes-nav',

  /** @description  id вкладки "Выпуск договора" */
  tabIssueOfContract: 'tab-Issue-contract-nav',

  /** @description  id вкладки "Вложения" */
  tabAttachedDocuments: 'tab-Attached-documents-nav',

  /** @description  id вкладки "История документа" */
  tabContractActivityAndTransitionHistory: 'tab-contract-activity-transition-history-nav',

  /** @description  id вкладки "График платежей и оплата" */
  paymentInformation: 'tab-paymentInformation-nav',

  /*-----------------------------------------------------------------------Селекторы списка действий документа-------------------------------------------------------*/
  /** @description Button 'Кнопка действия "К оплате/Оплатить' */
  draftToPaymentWaiting: 'ai-transitions-relations-control-Draft_to_PaymentWaiting',

  /** @description Button 'Выпустить котировку' */
  mpCreatePolicy: 'ai-transitions-relations-control-MPCreatePolicyV3',

  /** @description Button 'Отказаться от оформления котировки' */
  draftToRejected: 'ai-transitions-relations-control-Draft_to_Rejected',

  /*-----------------------------------------------------------------------Селекторы ролей-------------------------------------------------------*/
  /** @description  id Роли "Продавец" */
  pmiAgent: 'ai-actor-selection-control-PMIAgent',

  /** @description  id Роли "Андеррайтер" */
  pmiUnderwriter: 'ai-actor-selection-control-PMIUnderwriter',

  /** @description  id Роли "Куратор продаж" */
  pmiPolicyViewer: 'ai-actor-selection-control-PMIPolicyViewer',

  /* ---------------------------------------------------------Вкладка "Условия страхования" -------------------------------------------------- */
  /** @description id секции Программа страхования */
  insuranceProgramme: 'MPInsuranceSelection-#',

  /** @description Button секции По адресу страхователя */
  policyHolderAddress: 'policyholder-address-button',

  /** @description id секции "Страхователь" */
  policyHolder: 'MPPolicyHolderData-policyHolder',

  /** @description id секций "Общее добровольное страхование от несчастных случаев и болезней" и "Финансовый риск" */
  personalRisk: 'MPPersonalRisks-#',

  /* ---------------------------------------------------------Вкладка "Договор" ------------------------------------------------------------- */
  /** @description id секции Орг. структура */
  organisationInformation: 'MPOrganisationInformation-policyData',

  /** @description id секции Менеджер договора */
  policyManager: 'MPServiceProvidersManager-policyPartyData',

  /** @description id секции Ответственный руководитель */
  policySupervisor: 'MPInsuranceSupervisor-#',

  /* ---------------------------------------------------------селекторы вкладки "График платежей и оплата" -------------------------------------------------- */
  /** @description  id секции "Порядок оплаты премии" */
  paymentDetails: 'MPPaymentDetails-#',

  /** @description  id секции "Плательщик" */
  payerInformation: 'MPPayerData-#',

  /** @description  id секции "Порядок оплаты премии" */
  paymentData: 'recievedGraph',
}
